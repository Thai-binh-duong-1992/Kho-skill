---
name: "so-do-tu-duy"
description: "Vẽ sơ đồ tư duy, sơ đồ khái niệm hoặc ma trận ưu tiên tương tác nhiều tab, chuyên nghiệp cho mọi chủ đề. Dùng khi nói vẽ/tạo sơ đồ tư duy, mindmap, concept map, ma trận, sơ đồ hoá ý tưởng hay tài liệu."
---

# Sơ đồ tư duy tương tác chuyên nghiệp

Skill này giúp người dùng biến một ý tưởng, ghi chú hay tài liệu thành **sơ đồ tư duy tương tác** dạng artifact. Sơ đồ có các chức năng sau:
- zoom, kéo thả, thêm/sửa/xoá ý;
- phím Tab/Enter để thêm ý, hoàn tác;
- chế độ dàn ý, lọc nhãn, tìm kiếm không dấu;
- luồng liên hệ có nhãn với 3 loại quan hệ;
- xuất PDF/PNG/SVG/Markdown/OPML/JSON;
- lưu vào tài khoản.

Skill có **hai kiểu giao diện** (mục "Kiểu giao diện"):
- **K01 (mặc định):** nhiều tab trong một gói; nhánh lớn xếp xen kẽ hai bên ý gốc; màu theo nhóm, biểu tượng và ảnh minh hoạ trên nút; ma trận trên hệ trục toạ độ với ô phóng to/thu nhỏ; menu "Chú giải" và "Chỉnh sửa sơ đồ" thu gọn.
- **Cổ điển:** một sơ đồ, có dàn ý, lọc nhãn, tìm kiếm, xuất PDF/PNG/SVG/Markdown/OPML.

Mọi sơ đồ chạy trên **một bộ mã dùng chung có sẵn trong skill**. Claude chỉ viết **dữ liệu** của sơ đồ, nên chất lượng đồng nhất ở mọi khung chat và mọi tài khoản, tạo nhanh và tốn ít token. Skill **độc lập**: không cần quyền vào artifact hay tài khoản nào khác.

Cấu trúc skill (đường dẫn tính từ thư mục của skill; Claude được báo thư mục này khi tải skill, gọi là `SKILL_DIR`):

| File | Vai trò |
|---|---|
| `scripts/dung_so_do.py` | Kiểm tra dữ liệu và dựng trang theo chế độ xuất: `artifact`, `html`, `both` |
| `assets/engine.js`, `assets/engine.css` | Mã và giao diện sơ đồ. **Không sửa** |
| `assets/d3.min.js` | Thư viện vẽ d3 7.8.5, chỉ dùng cho file HTML tự chạy |
| `assets/demo.json` | Dữ liệu mẫu đủ nhãn, nhóm màu và 3 loại quan hệ; dùng để chạy thử hoặc tham khảo định dạng |
| `scripts/k01.py` | Kiểm tra và dựng kiểu K01; `dung_so_do.py` tự gọi khi dữ liệu có `"style": "k01"` |
| `assets/k01/k01.js`, `assets/k01/k01.css` | Mã và giao diện kiểu K01. **Không sửa** |
| `assets/demo-k01.json` | Dữ liệu mẫu kiểu K01: 3 tab (sơ đồ hai bên có liên kết, sơ đồ bậc thang, ma trận 3×2 có ô trải hai mức) |

- **Phiên bản skill:** 1.3 (11/2026), bản độc lập, có chọn chế độ xuất Artifact / File HTML / Cả hai; thêm kiểu giao diện K01 (nhiều tab, ma trận trên hệ trục).

## Nguyên tắc vận hành (áp dụng ở mọi bước)

1. **Người dùng là tác giả.** Claude dựng khung, đề xuất, kiểm tra; người dùng quyết định nội dung. Bằng chứng cho thấy người **tự dựng/tự hoàn thiện** sơ đồ học và nhớ tốt hơn rõ rệt so với người chỉ đọc sơ đồ làm sẵn. Vì vậy luôn mời người dùng tự hoàn thiện.
2. **Mỗi câu trả lời kết thúc bằng đúng một khối gợi ý**, ứng với bước cuối cùng đã làm trong câu trả lời đó. Khối gợi ý cho người dùng biết đang ở bước mấy và có thể nói gì tiếp, kèm 2–4 câu mẫu để chép. Dạng chuẩn:
   > **Bước x/7 – Tên bước.** Anh/chị có thể nói: "…", "…", hoặc "…".

   Cách gộp bước trong một câu trả lời:
   - **Bình thường:** Bước 1–2 có thể chung một câu trả lời (khối gợi ý Bước 2 hoặc Bước 1 nếu cần hỏi). Bước 3 là một câu trả lời riêng. Bước 4 lặp lại đến khi người dùng duyệt. Bước 5–7 chung một câu trả lời cuối: dựng, kiểm tra, rồi bàn giao kèm bảng kiểm 1 phút, chỉ có khối gợi ý Bước 7/7.
   - **"Dựng luôn":** Bước 1–7 chung một câu trả lời. Không trình dàn ý đầy đủ; chỉ nêu một dòng các lựa chọn mặc định đã dùng (loại sơ đồ, số nhánh, bộ nhãn, kiểu lưu, chế độ xuất) và dòng tự kiểm tra, rồi bàn giao. Chỉ có khối gợi ý Bước 7/7.
3. **Ngôn ngữ:** trả lời theo ngôn ngữ người dùng đang viết; mặc định tiếng Việt, xưng "anh/chị" khi chưa rõ. Nội dung sơ đồ theo ngôn ngữ người dùng; giao diện sơ đồ là tiếng Việt.
4. **Trung thực với nguồn.**
   - Nội dung rút từ tài liệu của người dùng phải giữ đúng ý gốc.
   - **Khi người dùng có tài liệu hoặc ghi chú:** ý nào Claude tự thêm thì gắn nhãn `GY` (gợi ý chờ duyệt) và ghi "Claude đề xuất" trong ghi chú. `GY` được ưu tiên hơn nhãn khác cho đến khi người dùng duyệt (mỗi ý chỉ có một nhãn).
   - **Khi cả sơ đồ do Claude soạn từ kiến thức chung** (người dùng chỉ nêu chủ đề): không gắn `GY` cho từng ý; nói một lần trong trường `source` ("Claude soạn từ kiến thức chung, cần người dùng kiểm tra") và một câu trong lời bàn giao.
   - Với thông tin dễ thay đổi (luật, giá, số liệu hiện hành), tìm nguồn trước khi đưa vào và ghi nguồn trong ghi chú của ý.
5. **Không làm gián đoạn:** chỉ hỏi những gì thực sự thay đổi kết quả, tối đa 3 câu một lần. Người dùng nói "dựng luôn" hoặc "làm nhanh" thì bỏ qua bước duyệt (Bước 4), tự chọn phương án hợp lý nhất và nói rõ đã chọn gì.
6. **Bảo mật:** nếu nội dung có dữ liệu định danh (hồ sơ người bệnh, lương, CCCD…), nhắc người dùng **trước khi dựng**:
   - Artifact chia sẻ từ một Project cho người xem thấy cả tệp đính kèm của cuộc trò chuyện gốc.
   - Nên ẩn danh hoá dữ liệu hoặc dựng sơ đồ ở cuộc trò chuyện không có tệp nhạy cảm.

## Chế độ xuất sơ đồ (người dùng chọn)

Cùng một dữ liệu, skill xuất được theo 3 chế độ. Người dùng chọn ở Bước 1 hoặc đổi bất cứ lúc nào sau khi dựng ("Xuất thêm file HTML", "Đưa lên artifact").

| Chế độ | Kết quả | Hợp khi | Lưu và chia sẻ |
|---|---|---|---|
| **Artifact** | Trang sơ đồ trên Claude, có link | Dùng lâu dài, sửa nhiều lần, làm việc nhóm | Lưu vào tài khoản; chia sẻ bằng nút Chia sẻ; có chế độ dùng chung cho nhóm |
| **File HTML** | Một file `<id>.html` khoảng 300–400 KB | Gửi qua email, Zalo, USB; người nhận không dùng Claude; máy không có mạng; tài khoản không có artifact | Lưu trên trình duyệt đang mở; chia sẻ bằng cách gửi file; không có chế độ dùng chung |
| **Cả hai** | Artifact + file HTML cùng nội dung | Vừa làm việc trên Claude vừa cần bản gửi đi | Hai bản độc lập; sửa bên này không tự sang bên kia |

Cách chọn mặc định khi người dùng không nói:
1. Có công cụ Artifact trong phiên → **Artifact**.
2. Không có công cụ Artifact nhưng chạy được mã và gửi được file → **File HTML**, và nói một câu: "Phiên này không xuất bản được artifact nên em xuất file HTML; anh/chị mở bằng trình duyệt."
3. Người dùng nhắc tới gửi email, Zalo, in cho người ngoài, dùng không cần mạng hoặc không cần Claude → đề xuất **File HTML** hoặc **Cả hai** trong một câu.

Ràng buộc:
- Người dùng chọn Artifact nhưng phiên không có công cụ Artifact: nói rõ không xuất bản được ở đây, đề xuất File HTML; người dùng đồng ý (hoặc không có mặt để trả lời) thì làm File HTML.
- `storage: "shared"` chỉ có tác dụng với Artifact. Người dùng muốn "cả nhóm cùng sửa" mà chọn File HTML: nói rõ file HTML không dùng chung được; cách thay thế là một người sửa rồi **Xuất… → JSON**, người kế tiếp **Nhập…** file JSON đó.
- Không hỏi riêng về chế độ xuất nếu mặc định đã hợp lý; gộp vào câu hỏi Bước 1 khi thật sự cần.

## Kiểu giao diện: K01 (mặc định) hay Cổ điển

| Kiểu | Chọn khi | Dữ liệu |
|---|---|---|
| **K01** (mặc định) | Mọi yêu cầu thông thường; nhất là khi cần nhiều tab, ma trận ưu tiên, trình chiếu tổng kết, nút có biểu tượng/ảnh | `"style": "k01"`, mục "Định dạng dữ liệu kiểu K01" |
| **Cổ điển** | Người dùng cần chế độ dàn ý, lọc nhãn, tìm kiếm, xuất PDF/PNG/SVG/Markdown/OPML, hoặc cả nhóm cùng sửa một bản; hoặc người dùng nói "kiểu cũ", "kiểu cổ điển" | Không có `style`, mục "Định dạng dữ liệu (`data.json`)" |

Không hỏi riêng về kiểu giao diện; dùng K01 trừ khi yêu cầu rơi vào dòng Cổ điển. Nói một câu kiểu đã dùng ở dòng mặc định (Bước 3 hoặc khi "dựng luôn").

### Kiểu K01 có gì

1. **Nhiều tab trong một gói.** Mỗi tab là một **sơ đồ** (`kind: "map"`) hoặc một **ma trận** (`kind: "matrix"`). Tối đa khoảng 8 tab; tên tab ngắn, ví dụ "Công việc → Tính năng", "Thang trưởng thành", "Ma trận ưu tiên".
2. **Nhánh lớn phân bổ đều hai bên ý gốc:** nhánh 1 bên phải, nhánh 2 bên trái, nhánh 3 bên phải… (`layout: "balanced"`, mặc định). Sơ đồ tầng/bậc dùng `layout: "ladder"`: các bậc nằm một bên, xếp bậc thang (bậc trên lùi xa hơn).
3. **Màu sắc đa dạng:** mỗi nhánh lớn tự nhận một màu trong 8 màu nhóm (`c1`–`c8`), ý con kế thừa màu nhánh. Có thêm màu nghĩa: `ok` (xanh, an toàn), `warn` (vàng, lưu ý), `info` (xanh dương), `bad` (đỏ, rủi ro), `gx` (xám, đọc thêm). Chỉ ghi `color` khi màu mang nghĩa.
4. **Biểu tượng và ảnh minh hoạ:** mỗi nút, ô thẻ, ô ma trận có thể có `icon` (bộ biểu tượng có sẵn, danh sách ở mục dữ liệu); Claude **tự chọn icon phù hợp nội dung** cho nhánh lớn và các ý chính. Ảnh minh hoạ (`img`, chỉ `https://…` hoặc `data:image/…`) **chỉ dùng khi người dùng đưa ảnh hoặc yêu cầu**, vì ảnh làm tệp nặng hơn.
5. **Thẻ nhiều ô** (`type: "card"`): gom 2–4 ý ngắn (Là gì, Dùng khi, Ví dụ, Lưu ý…) vào **một ô vuông lớn chia 2 cột** (`cols: 2`, mặc định nên dùng). Số ô lẻ thì ô cuối tự trải hết hàng. Không dàn 3–4 ô thành một hàng dài.
6. **Menu thu gọn:** "Chú giải" (góc trái) và "Chỉnh sửa sơ đồ" (góc phải) mặc định thu gọn, bấm mới mở, để sơ đồ không bị che. Chú giải tự liệt kê các nhánh và màu, các loại đường liên kết đang dùng, nét đứt "đọc thêm"; có thể tự khai báo `legend`.
7. **Chỉnh sửa trên trang** (người có quyền, xem dưới): bấm ý để sửa chữ, màu, biểu tượng, ảnh; thêm ý con, ý cùng cấp; xoá; nối đường liên kết 3 loại (dẫn đến, tương hỗ, đối lập/kìm hãm) có nhãn; hoàn tác/làm lại; khôi phục gốc; xuất/nhập JSON.
8. **Ma trận trên hệ trục toạ độ:** trục tung và trục hoành có tên và **số mức tuỳ ý (1–5)**: 2×2, 3×2, 3×3… Mỗi ô đặt theo toạ độ `x:[từ,đến]`, `y:[từ,đến]` (đếm từ 0, mức thấp nhất = 0; trục tung thấp ở dưới, cao ở trên), nên một ô **trải được nhiều mức** (ví dụ "Rủi ro CAO × mọi tần suất" là một cột đứng). Khi chưa phóng to, ô chỉ hiện tên, dòng phụ và số mục; **bấm ô để phóng to** (phủ cả khung ma trận, hiện đủ nội dung), bấm thanh tiêu đề, nút ✕ hoặc Esc để thu nhỏ. Người có quyền thấy nút **Sửa nội dung** trong ô đang phóng to (tên, dòng phụ, màu, biểu tượng, ảnh, các mục nội dung, danh sách mục), nút **Xoá ô**, và nút **+ Thêm ô** ở mọi vị trí trống trên lưới.

9. **Kéo thả tự do:** kéo một nút để đặt ở vị trí tuỳ ý; **cả nhánh con đi theo**, đường nối cha–con và đường liên kết tự vẽ lại. Máy tính: bấm giữ chuột trên nút rồi kéo (kéo vào nền trống để di chuyển cả khung). Điện thoại: **chạm giữ khoảng nửa giây** rồi kéo (vuốt nhanh vẫn là kéo cả khung). Nút **"Sắp xếp lại"** ở thanh dưới trả cả tab về bố cục tự động; trong menu Chỉnh sửa, ý đã kéo có nút **"Về vị trí tự động"** cho riêng nhánh đó.
10. **Chỉnh đường liên kết:** khi bật Chỉnh sửa và chọn một đường liên kết, đường hiện 3 điểm kéo: **điểm giữa** để uốn cong đường (tránh che chữ), **hai đầu** để kéo sang ý khác và đổi ý đầu/ý đích. Kéo thả đều hoàn tác được.

### Ai được sửa (kiểu K01)

| Chế độ xuất | Ai sửa được | Lưu ở đâu |
|---|---|---|
| Artifact | **Chỉ chủ sơ đồ** (người tạo artifact). Người được chia sẻ chỉ xem, không thấy menu Chỉnh sửa | Chủ bấm **Lưu bản chung**: lưu vào kho `db` của artifact (`maps/<id>`), mọi người xem thấy bản mới khi mở hoặc tải lại |
| File HTML | Ai mở file cũng sửa được, trên máy của mình | Tự lưu trên trình duyệt đang mở. Chuyển cho người khác: **Xuất JSON**, người nhận mở file HTML rồi **Nhập JSON** |

**Kéo thả nút:** ai mở sơ đồ cũng kéo được để xem cho tiện, nhưng **chỉ người có quyền sửa mới lưu được vị trí** (Artifact: chủ sơ đồ bấm Lưu bản chung; File HTML: tự lưu trên trình duyệt). Người xem artifact kéo nút thì vị trí chỉ giữ tạm trên màn hình của họ, tải lại là về bố cục của bản chung. Chỉnh đường liên kết chỉ có trong chế độ Chỉnh sửa.

"Khôi phục gốc" (bấm hai lần) đưa sơ đồ về dữ liệu Claude dựng; với artifact, chủ bấm Lưu bản chung để áp dụng cho mọi người, hoặc Hoàn tác.

## Quy trình 7 bước

### Bước 1/7 – Tiếp nhận và làm rõ

Xác định 6 điều; điều gì người dùng đã nói thì không hỏi lại:

| Điều cần biết | Mặc định khi người dùng không nói |
|---|---|
| Chủ đề và **câu hỏi trọng tâm** (sơ đồ trả lời câu hỏi gì) | Tự đặt từ chủ đề, ví dụ "Làm sao giảm thời gian chờ khám?" |
| Mục đích: học, trình bày, lập kế hoạch, phân tích nguyên nhân, động não | Suy từ cách diễn đạt |
| Nguồn nội dung: tệp đính kèm, ghi chú dán vào, hay chỉ ý tưởng | Dùng những gì có trong cuộc trò chuyện |
| Người xem và mức chi tiết | Người trong ngành, 2–3 cấp dưới gốc |
| Lưu riêng từng người hay dùng chung cho nhóm | Riêng từng người |
| Chế độ xuất: Artifact, File HTML hay Cả hai (mục "Chế độ xuất sơ đồ") | Artifact nếu phiên có công cụ Artifact, ngược lại File HTML |

Nếu người dùng gửi tài liệu dài, đọc hết trước khi hỏi.

> **Bước 1/7 – Làm rõ yêu cầu.** Anh/chị có thể nói: "Sơ đồ để trình bày giao ban, người xem là trưởng khoa", "Dựa vào file đính kèm", "Cho cả nhóm cùng sửa", "Xuất file HTML để gửi Zalo", hoặc "Dựng luôn, không cần hỏi".

### Bước 2/7 – Chọn loại sơ đồ

| Mục đích | Loại | Dấu hiệu |
|---|---|---|
| Động não, ghi biên bản, dàn ý đề án, ôn tập | **Sơ đồ tư duy** | Một tâm; quan hệ "thuộc về / chi tiết của"; ít luồng (0–5) |
| Giải thích cơ chế, quy trình liên khoa, nguyên nhân gốc | **Sơ đồ khái niệm** | Quan hệ giữa các ý quan trọng ngang bản thân các ý; nhiều luồng có nhãn (5–15) |
| Thẩm định, ra quyết định | Sơ đồ lập luận | Luận điểm, ủng hộ, phản bác |
| Thứ tự tuyến tính, cần in thành văn bản | Dàn ý | Đọc từ trên xuống |

- Skill dựng trực tiếp hai loại đầu.
- Với **sơ đồ lập luận**: dựng dưới dạng sơ đồ khái niệm. Gốc là quyết định; nhánh là "Ủng hộ" và "Phản bác"; dùng quan hệ **đối lập** cho các cặp phản bác. Nói rõ với người dùng đây là cách thể hiện gần đúng.
- Với **dàn ý thuần**: gợi ý dùng chế độ Dàn ý của sơ đồ, hoặc trả về Markdown.
- Báo cho người dùng loại đã chọn và lý do trong một câu.

> **Bước 2/7 – Chọn loại sơ đồ.** Anh/chị có thể nói: "Đồng ý", "Làm sơ đồ khái niệm vì tôi cần thấy quan hệ nhân quả", hoặc "Chỉ cần dàn ý".

### Bước 3/7 – Dựng dàn ý theo nguyên tắc

Dựng dàn ý **bằng chữ** trước, chưa dựng sơ đồ. Áp dụng các nguyên tắc ở mục "Nguyên tắc thiết kế":
1. Liệt kê nhanh 15–25 khái niệm chính (không cần trình bày), rồi gom thành **3–7 nhánh chính, lý tưởng 4–6**, không trùng nhau, cùng một cấp độ khái quát. Nhánh cấp 1 mang thông điệp chính.
2. Mỗi ý có khoảng 3–7 ý con (tránh ý chỉ có 1 ý con: gộp vào cha). Sâu tối đa khoảng 4 cấp dưới gốc; sâu hơn thì tách sơ đồ con.
3. Tên ý **ngắn: 2–8 âm tiết** (khoảng 2–5 từ; mã kiểm tra đếm âm tiết theo dấu cách), cùng kiểu ngữ pháp trong một nhánh. Không viết cả câu; giải thích, số liệu, ví dụ, nguồn để vào **ghi chú**.
4. Chọn **bộ nhãn** theo lĩnh vực (bảng "Bộ nhãn theo lĩnh vực"), tối đa 6 nhãn. Không dùng nhãn nếu không cần.
5. Đề xuất **luồng liên hệ** giữa các nhánh khác nhau. Mỗi luồng gồm:
   - **loại quan hệ:** `→` dẫn đến/nhân quả (gồm cả "làm tăng", "cần cho", "dẫn tới"), `↔` tương hỗ/hai chiều, `⊣` đối lập/kìm hãm (gồm "mâu thuẫn với", "ức chế", "cản trở", "làm giảm" khi muốn nhấn mạnh tác động ngược);
   - **nhãn động từ ngắn**, để đọc thành câu: "A *làm tăng* B".
   - Số luồng: sơ đồ tư duy khoảng 3–5; sơ đồ khái niệm tối đa khoảng 15.
6. Đánh số ý khi thứ tự có nghĩa (các bước quy trình).

Trình bày dàn ý theo mẫu dưới đây, để người dùng sửa bằng chữ dễ dàng:

```markdown
Tiêu đề: [tên ngắn hiện trên đầu trang] · Dòng phụ: [đơn vị, năm…]
# [Gốc: chủ đề hoặc câu hỏi trọng tâm] — ghi chú: [mục đích sơ đồ]
Nhãn: [BC] có bằng chứng · [SL] suy luận · Lưu: riêng từng người · Xuất: Artifact

- Nhánh 1 — ghi chú: [ý chính của nhánh]
  - [BC] Ý con — ghi chú: giải thích ngắn, nguồn
  - Ý con
- Nhánh 2 (thu gọn sẵn)
  ...

Luồng liên hệ:
- Ý A → Ý B : làm tăng
- Ý C ↔ Ý D : bổ trợ
- Ý E ⊣ Ý F : kìm hãm
```

Tên các ý được nhắc trong "Luồng liên hệ" phải **duy nhất** trong sơ đồ (trùng thì thêm chữ phân biệt). Luồng nối hai ý ở **hai nhánh khác nhau**, không nối cha với con.

Ngay dưới dàn ý, ghi một dòng tự kiểm tra, ví dụ: "5 nhánh chính · 32 ý (không kể gốc) · sâu 3 cấp · 4 luồng · 2 ý dài hơn 8 âm tiết đã chuyển chi tiết vào ghi chú". Cách đếm giống mã kiểm tra: **gốc là cấp 0**, "sâu 3 cấp" nghĩa là 3 cấp dưới gốc; số ý không kể gốc.

Với **kiểu K01**, dàn ý chia theo tab: ghi `## Tab 1 · [tên tab] (sơ đồ hai bên | bậc thang | ma trận)` rồi dàn ý của tab đó. Tab ma trận ghi tên hai trục, các mức của mỗi trục (thấp → cao) và bảng ô:

```markdown
## Tab 3 · Ma trận ưu tiên (ma trận)
Trục tung: Tần suất (Thấp, Cao) · Trục hoành: Rủi ro (Thấp, Trung bình, Cao)
- Ô 1 · Chuẩn hoá — Tần suất CAO × Rủi ro THẤP — màu ok — Đặc điểm: … — Mục: …, …
- Ô 4 · Con người quyết định — Rủi ro CAO × mọi tần suất (cột đứng) — màu bad
- (Tần suất THẤP × Rủi ro TRUNG BÌNH: để trống)
```

Dòng tự kiểm tra thêm số tab và số ô ma trận, ví dụ "3 tab · 2 sơ đồ (28 ý) · 1 ma trận 3×2 (4 ô, 1 vị trí trống) · 2 liên kết · kiểu K01".

> **Bước 3/7 – Dàn ý đã xong.** Anh/chị có thể nói: "Gộp nhánh 2 và 3", "Thêm nhánh Ngân sách với 3 ý…", "Bỏ nhãn", "Thêm luồng từ X tới Y: làm giảm", "Xuất file HTML", hoặc "Dựng sơ đồ".

### Bước 4/7 – Duyệt dàn ý

- Sửa theo yêu cầu, trình lại **chỉ phần thay đổi** kèm dòng tự kiểm tra.
- Nhắc nhẹ, một lần, khi người dùng muốn:
  - quá 7 nhánh chính;
  - tên ý quá dài;
  - quá nhiều luồng.

  Người dùng vẫn giữ ý mình thì làm theo.
- Người dùng nói "dựng", "đồng ý", "ok" thì sang Bước 5.

> **Bước 4/7 – Duyệt dàn ý.** Anh/chị có thể nói: "Đổi tên nhánh 1 thành…", "Chuyển ý X sang nhánh Y", "Tách ý Z thành hai ý", hoặc "Dựng sơ đồ".

### Bước 5/7 – Dựng sơ đồ từ bộ mã của skill

1. Viết file `data.json` theo mục "Định dạng dữ liệu kiểu K01" (mặc định) hoặc "Định dạng dữ liệu" (kiểu cổ điển), đặt trong thư mục làm việc.
2. Chạy **mã kiểm tra và dựng trang** với `--mode` theo chế độ đã chọn (`artifact`, `html` hoặc `both`). Sửa mọi LỖI. Các CẢNH BÁO thì sửa nếu hợp lý, hoặc báo người dùng.
3. Theo chế độ:
   - **Artifact:** xuất bản bằng công cụ Artifact (mục "Xuất bản"), kèm `engine.js`, `engine.css` (kiểu K01: `k01.js`, `k01.css`) vừa được chép ra thư mục dựng, và khai báo capabilities theo đúng kiểu.
   - **File HTML:** gửi file `so-do/<id>.html` cho người dùng bằng công cụ gửi file (mục "Giao file HTML").
   - **Cả hai:** làm cả hai việc trên.
4. Xuất bản artifact thất bại: chuyển sang File HTML theo mục "Phương án dự phòng" và báo người dùng một câu.

Không viết lại mã sơ đồ bằng tay. Không sửa `engine.js`, `engine.css`, `k01.js`, `k01.css`; muốn đổi tính năng thì nâng cấp bộ mã trong skill.

(Bước 5 không có khối gợi ý riêng; trước khi bắt đầu chỉ báo một dòng "Đang dựng sơ đồ từ dàn ý đã duyệt".)

### Bước 6/7 – Kiểm tra

Claude tự kiểm tra:
- mã kiểm tra không còn LỖI;
- Artifact: kết quả xuất bản có đủ 3 file `index.html`, `engine.js`, `engine.css` và capabilities đã khai báo;
- File HTML: file `<id>.html` đã gửi tới người dùng; nếu có trình duyệt hoặc công cụ chạy trình duyệt không giao diện, mở file kiểm tra sơ đồ hiện đủ ý và không báo lỗi.

Nếu có công cụ trình duyệt, mở sơ đồ kiểm tra nhanh. Bảng kiểm 1 phút dưới đây được đưa vào câu trả lời bàn giao (Bước 7), không gửi riêng:
- [ ] Bấm một nhánh chính: nhánh mở và sơ đồ tự zoom vào.
- [ ] Chọn một ý, bấm Tab, gõ tên, Enter: ý con mới xuất hiện; Ctrl+Z hoàn tác được.
- [ ] Bảng bên phải (bỏ chọn ý để thấy) có chú giải màu nhóm, nhãn và **đường nối**.
- [ ] Xuất… → PDF A4 tải về được.
- [ ] Mở trên điện thoại: chạm ý để xem chi tiết.
- [ ] (File HTML) Tải file về máy, mở bằng Chrome, Edge hoặc Safari; sửa thử một ý, đóng rồi mở lại vẫn còn.

(Bước 6 không có khối gợi ý riêng; khối gợi ý Bước 7/7 bao gồm cả các câu như "Chữ nhỏ quá", "Nút xuất không chạy".)

### Bước 7/7 – Bàn giao và hướng dẫn dùng

Trả lời ngắn gọn:
1. Một câu nói sơ đồ là gì: số nhánh, số ý (không kể gốc), số luồng, loại sơ đồ.
2. Bảng kiểm 1 phút của Bước 6 (gộp vào đây).
3. Ba thao tác quan trọng nhất:
   - bấm ý để mở/thu;
   - chọn ý rồi Tab/Enter để thêm;
   - Xuất… để lấy PDF.
4. Lời mời tự hoàn thiện: tự thêm ý, nối luồng, dùng sơ đồ trong vài tuần (giao ban, ôn tập). Căn cứ (có bằng chứng, phân tích gộp của Schroeder và cộng sự về sơ đồ khái niệm): người tự dựng sơ đồ học tốt hơn người chỉ đọc sơ đồ làm sẵn (g 0,72 so với 0,43), và dùng trên 1 tuần cho cỡ hiệu ứng gần gấp đôi dưới 1 tuần (0,68 so với 0,36). Chỉ nêu ngắn một câu, không trích số trừ khi người dùng hỏi.
5. Cảnh báo phù hợp theo chế độ xuất:
   - **Artifact:** sơ đồ mới ở chế độ riêng tư, muốn chia sẻ thì dùng nút Chia sẻ. **Gỡ xuất bản (unpublish) không quay lại được và xoá dữ liệu đã lưu.**
   - **File HTML:** thay đổi lưu trên trình duyệt đang mở; đổi máy, đổi trình duyệt, dùng cửa sổ ẩn danh hoặc xoá dữ liệu duyệt web thì không còn. Sao lưu và chuyển cho người khác bằng **Xuất… → JSON**, người nhận mở file HTML rồi **Nhập…**. Gửi file HTML là gửi cả nội dung sơ đồ, nên cân nhắc người nhận.
   - Nếu có dữ liệu nhạy cảm, nhắc lại cảnh báo ở Nguyên tắc 6.
6. Cách sửa về sau: nói "sửa sơ đồ này…" trong cùng cuộc trò chuyện. Ở cuộc trò chuyện khác: với Artifact thì **dán link sơ đồ**; với File HTML thì **đính kèm file JSON xuất từ sơ đồ** (hoặc file HTML). Nếu không, Claude sẽ tạo sơ đồ mới.

> **Bước 7/7 – Hoàn tất.** Anh/chị có thể nói: "Thêm nhánh…", "Cho cả nhóm cùng sửa", "Xuất thêm file HTML" (hoặc "Đưa lên artifact"), "Tạo thêm sơ đồ con cho nhánh X", "Chữ nhỏ quá" hoặc "Nút xuất không chạy".

## Quy ước đường nối (cố định cho mọi sơ đồ, không thay đổi)

| Đường nét | Ý nghĩa | Trong dữ liệu |
|---|---|---|
| Nét liền, màu theo nhóm, dày ở cấp 1 và mảnh dần | Quan hệ cha – con (phân cấp) | cấu trúc `children` |
| Nét đứt, mũi tên một đầu | Dẫn đến / nhân quả | `"kind": "cause"` (mặc định) |
| Nét đứt, mũi tên hai đầu | Tương hỗ / hai chiều | `"kind": "mutual"` |
| Nét gạch – chấm, đầu chặn hình chữ T | Đối lập / kìm hãm: mâu thuẫn, phản bác, ức chế, cản trở (đầu chặn chữ T cũng là ký hiệu ức chế quen thuộc trong sơ đồ y sinh) | `"kind": "oppose"` |
| Nét chấm mờ, không mũi tên | Luồng tạm gắn vào nhánh đang thu gọn | tự động |
| Viền đậm quanh ô | Ý đang chọn | tự động |
| Nền vàng (viền nét đứt khi kéo thả) | Kết quả tìm kiếm / ô đích khi kéo thả | tự động |

- Các kiểu nét khác nhau cả về **hình dạng** chứ không chỉ màu, nên in đen trắng vẫn phân biệt được (WCAG 1.4.1).
- Chú giải đường nối tự hiện trong bảng bên phải và ở đầu file PDF.
- Khi giải thích sơ đồ cho người dùng, luôn dùng đúng các tên gọi trong bảng này.

## Bộ nhãn theo lĩnh vực (đề xuất, người dùng duyệt ở Bước 3)

| Lĩnh vực | Bộ nhãn (key · label) |
|---|---|
| Nghiên cứu, học thuật, y khoa | BC · có bằng chứng; SL · suy luận; KN · kinh nghiệm |
| Dự án, kế hoạch | CAO · ưu tiên cao; VUA · ưu tiên vừa; THAP · ưu tiên thấp |
| Theo dõi công việc | XONG · đã xong; DANG · đang làm; CHUA · chưa làm |
| Quản lý rủi ro, chất lượng | RC · rủi ro cao; RV · rủi ro vừa; RT · rủi ro thấp |
| Động não ý tưởng | THU · thử ngay; CAN · cần cân nhắc; GAC · tạm gác |
| Ôn tập, học bài | NHO · cần nhớ; HIEU · cần hiểu; HOI · còn thắc mắc |
| Ý do Claude gợi ý chờ duyệt (thêm vào bất kỳ bộ nào) | GY · gợi ý chờ duyệt |

- Chọn bộ theo **mục đích của người dùng**, không theo chủ đề: cùng chủ đề y khoa, nếu để ôn tập thì dùng bộ "Ôn tập", nếu để trình bày kiến thức có nguồn thì dùng bộ "Nghiên cứu". Các nhãn trong một bộ phải loại trừ nhau (mỗi ý chỉ hợp một nhãn).
- Chỉ đưa vào `tags` những nhãn thực sự dùng.
- Key ngắn, viết hoa, không dấu, tối đa 4–5 ký tự; label là cụm tiếng Việt có dấu.
- Tối đa 6 nhãn.

## Nguyên tắc thiết kế (có nhãn mức bằng chứng)

Chưa có nghiên cứu thực nghiệm nào kiểm tra riêng số nhánh, màu, nhánh cong hay độ sâu tối ưu của sơ đồ tư duy. Các con số dưới đây là ngoại suy, ghi rõ nhãn:

| Nguyên tắc | Khuyến nghị | Mức |
|---|---|---|
| Gốc | Một tên chủ đề hoặc câu hỏi trọng tâm | Bằng chứng (Novak & Cañas, cho sơ đồ khái niệm) |
| Số nhánh chính | 3–7, lý tưởng 4–6; nhiều hơn thì gom nhóm | Suy luận (Cowan 2001: trí nhớ làm việc giữ khoảng 4 nhóm, không phải 7±2) |
| Số ý con | Khoảng 3–7 mỗi ý | Suy luận |
| Tên ý | Ngắn, 2–8 âm tiết (khoảng 2–5 từ), cùng kiểu ngữ pháp; chi tiết vào ghi chú | Bằng chứng về lỗi "viết cả câu trong ô"; con số là suy luận |
| Nhánh cấp 1 | Mang thông điệp chính | Bằng chứng gián tiếp (ý trung tâm được hưởng lợi gấp ba ý chi tiết) |
| Màu | Mỗi nhóm một màu, con kế thừa màu cha; bảng Okabe–Ito | Bằng chứng gián tiếp (Gestalt); bộ mã tự làm |
| Không chỉ dùng màu | Nhãn có chữ, nét nối khác hình dạng, có chú giải | Chuẩn WCAG 2.2 (1.4.1, 1.4.11: tương phản đồ hoạ ≥ 3:1) |
| Luồng liên hệ | Có loại quan hệ + nhãn động từ; ít mà chất | Nhãn: bằng chứng (Novak); số lượng: suy luận |
| Mở dần | Mặc định mở 2 cấp dưới gốc (`openDepth` 2), tối đa 3 | Suy luận (progressive disclosure, NN/g) |
| Thứ tự | Đánh số khi thứ tự có nghĩa; xếp từ nền tảng đến ứng dụng | Kinh nghiệm |
| Sửa nhiều vòng | Ít nhất 3 vòng | Khuyến nghị của Novak & Cañas |

Các "luật" của Tony Buzan (ít nhất 3 màu, mỗi nhánh một từ, nhánh cong) là kinh nghiệm, không phải luật khoa học. Thuyết não trái/não phải bị xem là đơn giản hoá quá mức.

## Định dạng dữ liệu (`data.json`)

```json
{
  "id": "giam-thoi-gian-cho-kham",
  "title": "Giảm thời gian chờ khám",
  "eyebrow": "Đề án cải tiến · 2027",
  "rev": 1,
  "openDepth": 2,
  "storage": "personal",
  "source": "Báo cáo khảo sát người bệnh quý III/2026",
  "tags": [{"key": "CAO", "label": "ưu tiên cao"}, {"key": "VUA", "label": "ưu tiên vừa"}],
  "tree": {
    "id": "r", "name": "Giảm thời gian chờ khám?", "note": "Câu hỏi trọng tâm của đề án.",
    "children": [
      {"id": "a", "name": "Đăng ký khám", "children": [
        {"id": "a1", "name": "Đặt lịch trực tuyến", "tag": "CAO", "note": "Giải thích, số liệu, nguồn."}
      ]},
      {"id": "b", "name": "Quy trình", "collapsed": true, "children": [
        {"id": "b1", "name": "Gộp quầy thu ngân", "tag": "VUA"}
      ]}
    ]
  },
  "flows": [
    {"from": "a1", "to": "b1", "label": "giảm tải cho", "kind": "cause"}
  ]
}
```

| Trường | Bắt buộc | Ý nghĩa |
|---|---|---|
| `id` | có | Mã sơ đồ, viết thường không dấu, nối bằng gạch ngang. Dùng làm tên file xuất và khoá lưu trữ; **không đổi khi cập nhật** |
| `title` | có | Tên hiện trên đầu trang và PDF: tên ngắn, cụ thể, không phải câu mô tả |
| `eyebrow` | không | Dòng chữ nhỏ trên tiêu đề (đơn vị, năm, loại sơ đồ) |
| `rev` | có | Số phiên bản nội dung, bắt đầu từ 1. **Tăng 1 mỗi lần Claude cập nhật nội dung**: người đã sửa bản cũ sẽ được hỏi dùng bản mới hay giữ bản của họ |
| `openDepth` | không | Số cấp mở sẵn dưới gốc (mặc định 2) |
| `storage` | không | `personal` (mỗi người một bản, mặc định) hoặc `shared` (cả nhóm cùng sửa một bản; người sửa sau ghi đè) |
| `source` | không | Nguồn nội dung, in ở chân PDF và bảng hướng dẫn |
| `tags` | không | Tối đa 6 nhãn `{key, label}`, key không trùng; chỉ khai báo nhãn có dùng; màu nhãn tự gán theo thứ tự |
| `tree` | có | Ý gốc; mỗi ý có `id` (duy nhất, ngắn: `a`, `a1`, `a1b`…), `name`, và tuỳ chọn `tag`, `note`, `children`, `collapsed` (true/false để ghi đè `openDepth` cho riêng ý đó) |
| `flows` | không | Luồng liên hệ `{from, to, label, kind}`; `from`/`to` là `id` của ý; `kind`: `cause` / `mutual` / `oppose` |

Màu nhóm tự gán theo thứ tự nhánh cấp 1 (7 màu Okabe–Ito đã chỉnh tương phản), không cần khai báo.

## Định dạng dữ liệu kiểu K01

```json
{
  "style": "k01",
  "id": "giam-thoi-gian-cho-kham",
  "title": "Giảm thời gian chờ khám",
  "eyebrow": "Đề án cải tiến · 2027",
  "rev": 1,
  "source": "Báo cáo khảo sát người bệnh quý III/2026",
  "logos": [{"src": "data:image/png;base64,…", "alt": "Tên đơn vị"}],
  "mark": "burst",
  "openDepth": 1,
  "tabs": [
    {"label": "Nguyên nhân → Giải pháp", "kind": "map", "layout": "balanced",
     "root": {"t": "Giảm thời gian chờ khám", "sub": "Chờ ở khâu nào, gỡ thế nào?", "c": [
       {"t": "Đăng ký", "icon": "file", "c": [
         {"id": "dk1", "t": "Đặt lịch trực tuyến", "icon": "calendar", "note": "Giãn giờ đến", "chips": [{"t": "Ưu tiên cao", "tone": "bad"}]}]},
       {"t": "Khám bệnh", "icon": "hosp", "c": [
         {"id": "kb1", "t": "Phân luồng theo chuyên khoa", "icon": "flow"},
         {"t": "Chẩn đoán, chỉ định điều trị", "tone": "bad"}]},
       {"t": "Đọc thêm", "dashed": true, "c": [
         {"type": "card", "cols": 2, "items": [
           {"lab": "Là gì", "t": "…", "icon": "info"}, {"lab": "Lưu ý", "t": "…", "icon": "shield", "safe": true}]}]}
     ]},
     "flows": [{"from": "dk1", "to": "kb1", "kind": "cause", "label": "giãn tải cho"}]},
    {"label": "Lộ trình", "kind": "map", "layout": "ladder", "stepLabel": "Bậc",
     "root": {"t": "Lộ trình triển khai", "icon": "rocket", "c": [
       {"type": "step", "n": 2, "t": "Mở rộng", "c": [{"type": "card", "cols": 2, "items": [{"lab": "Việc chính", "t": "…", "icon": "tool"}]}]},
       {"type": "step", "n": 1, "t": "Thử nghiệm", "c": []}]}},
    {"label": "Ma trận ưu tiên", "kind": "matrix", "title": "Ma trận chọn giải pháp",
     "x": {"title": "Chi phí triển khai", "levels": ["Thấp", "Trung bình", "Cao"]},
     "y": {"title": "Tác động", "levels": ["Thấp", "Cao"]},
     "itemsTitle": "Giải pháp trong ô",
     "cells": [
       {"name": "Làm ngay", "axis": "Tác động CAO × Chi phí THẤP", "color": "ok", "icon": "rocket", "x": [0, 0], "y": [1, 1],
        "sections": [{"h": "Đặc điểm", "t": "…"}, {"h": "Cách làm", "list": ["…", "…"]}], "items": ["Đặt lịch trực tuyến"]},
       {"name": "Cân nhắc kỹ", "axis": "Chi phí CAO × mọi mức tác động", "color": "bad", "x": [2, 2], "y": [0, 1]}
     ]}
  ]
}
```

| Trường | Bắt buộc | Ý nghĩa |
|---|---|---|
| `style` | có | Luôn là `"k01"` |
| `id`, `title`, `eyebrow`, `rev`, `source` | như kiểu cổ điển | `id` không đổi khi cập nhật; **tăng `rev` mỗi lần Claude cập nhật nội dung** (bản đã lưu với `rev` cũ bị bỏ qua, người xem thấy nội dung mới) |
| `logos` | không | Logo đơn vị ở góc phải tiêu đề (`src` là `https://…` hoặc `data:image/…`). **Chỉ thêm khi người dùng đưa logo**; không tự vẽ hay lấy logo của tổ chức thật |
| `mark` | không | Hình trang trí cạnh tiêu đề và trong ý gốc: `"burst"` (chùm tia nhiều màu, mặc định), tên một icon, hoặc `"none"` |
| `openDepth` | không | Số cấp mở sẵn dưới gốc khi mở tab (mặc định 1: chỉ hiện nhánh lớn, bấm để mở dần) |
| `tabs[]` | có | Danh sách tab. Tab có `label`, `kind` (`map` / `matrix`) |
| `tabs[].layout` | không | `balanced` (mặc định, xen kẽ hai bên), `ladder` (bậc thang một bên), `right` (một bên) |
| `tabs[].root` | có với map | Ý gốc `{t, sub, icon, img, c}` |
| Ý trong cây | | `t` (tên ngắn), `c` (ý con), `type` (`branch` ở cấp 1, `idea` từ cấp 2 – tự gán; `card`, `step` khi cần), `note`, `icon`, `img`, `color`, `dashed`, `chips` (`[{t, tone: ok/warn/bad/info}]`), `tone: "bad"` (ô đỏ có dấu ✕, cho việc con người phải quyết định), `id` (chỉ cần cho ý được nối liên kết) |
| `ox`, `oy` | không | Độ lệch vị trí (px) so với bố cục tự động, do kéo thả tạo ra; áp cho cả nhánh con. Claude thường không ghi; giữ nguyên khi cập nhật dữ liệu người dùng đã sắp |
| `card` | | `{type: "card", cols: 2, items: [{lab, t, icon, safe, dashed}]}`; `safe` tô nền nhạt cho mục an toàn; `dashed` viền nét đứt |
| `step` | | `{type: "step", n, t, color}`; nhãn bậc lấy từ `tabs[].stepLabel` (mặc định "Bậc") |
| `tabs[].flows` | không | `{from, to, kind, label}` như kiểu cổ điển; `from`/`to` là `id` của ý trong cùng tab; `bx`, `by` (tuỳ chọn) là độ uốn do kéo điểm giữa |
| `tabs[].legend` | không | Chú giải tự khai báo: `[{h: "Tiêu đề"}, {color: "c1", t: "…"}, {icon: "shield", t: "…"}]`; bỏ trống thì tự sinh từ các nhánh |
| `tabs[].x`, `tabs[].y` | có với matrix | `{title, levels: [thấp → cao]}`, 1–5 mức mỗi trục |
| `tabs[].cells[]` | có với matrix | `name`, `axis` (dòng phụ), `x: [từ, đến]`, `y: [từ, đến]`, `color`, `icon`, `img`, `sections: [{h, t} hoặc {h, list: […]}]`, `items: ["…"]` (danh sách mục hiện thành nhãn màu). Các ô không chồng nhau; vị trí bỏ trống được phép |
| `tabs[].title`, `desc`, `itemsTitle` | không | Tiêu đề, mô tả của ma trận; tên nhóm "mục trong ô" |

Biểu tượng có sẵn (`icon`): bell, book, box, bulb, calendar, cart, chart, chat, check, clock, code, cog, cursor, doc, eye, file, flag, flow, folder, gauge, globe, grid, heart, home, hosp, info, layers, leaf, link, lock, mail, map, memory, mic, money, org, pen, phone, pill, plug, plus, pulse, quote, rocket, search, share, shield, signal, spark, star, swap, table, target, tool, trophy, user, users, warn, x.

Nguyên tắc nội dung (Bước 3) giữ nguyên cho từng tab sơ đồ: 3–7 nhánh lớn, tên ý ngắn, chi tiết vào `note` hoặc thẻ `card`. Ma trận: tên ô ngắn, `axis` ghi rõ toạ độ ("Tần suất CAO × Rủi ro THẤP").

## Mã kiểm tra và dựng trang

Mã nằm sẵn ở `SKILL_DIR/scripts/dung_so_do.py`, không chép lại. Chạy từ thư mục làm việc:

```bash
python3 SKILL_DIR/scripts/dung_so_do.py data.json so-do --mode artifact   # Artifact (mặc định)
python3 SKILL_DIR/scripts/dung_so_do.py data.json so-do --mode html       # File HTML tự chạy
python3 SKILL_DIR/scripts/dung_so_do.py data.json so-do --mode both       # Cả hai
```

- Dòng đầu kết quả là dòng tự kiểm tra (số ý, số nhánh, độ sâu, số luồng, số nhãn); dùng đúng dòng này khi báo người dùng.
- `LỖI:` phải sửa trong `data.json` rồi chạy lại; mã dừng, không dựng trang.
- `CẢNH BÁO:` là gợi ý theo nguyên tắc thiết kế. Cảnh báo "nhãn chưa dùng" bỏ qua được khi người dùng muốn tự gắn nhãn sau.
- `artifact` ghi vào thư mục `so-do`: `index.html`, `engine.js`, `engine.css`. Thư mục dựng phải nằm trong thư mục làm việc để công cụ Artifact đọc được.
- `html` ghi một file `so-do/<id>.html` khoảng 300–400 KB, đã nhúng sẵn giao diện, mã và thư viện d3. Phông chữ tải từ Google Fonts khi có mạng, không có mạng thì dùng phông dự phòng.
- `both` ghi cả hai loại trên. Tuỳ chọn cũ `--standalone` vẫn chạy, tương đương `--mode html`.
- Mã chỉ dùng thư viện chuẩn của Python 3, không cần cài thêm gì.

Kiểu K01 dùng cùng lệnh: mã tự nhận `"style": "k01"`, dòng đầu kết quả ghi số tab, số ý, số ô ma trận, số liên kết. `artifact` ghi `index.html`, `k01.js`, `k01.css`; `html` ghi `<id>.html` khoảng 100 KB (không cần d3).

Nếu không chạy được Python, Claude tự kiểm theo đúng các quy tắc ghi ở đầu file mã, rồi đọc `assets/engine.js` và `assets/engine.css` để dựng trang như chế độ chính. Lưu ý thay mọi `</` trong dữ liệu JSON thành `<\/`.

## Xuất bản

Gọi công cụ Artifact (publish) với:
- `file_path`: `so-do/index.html`.
- `files`:
  ```json
  {"engine.js": "so-do/engine.js", "engine.css": "so-do/engine.css"}
  ```
- `capabilities`: `{"db": {}, "user": {}, "downloads": true}`.
  - `db` + `user`: lưu thay đổi vào tài khoản. Bản riêng nằm ở `data/users/<id>/sodo-<id sơ đồ>`; bản dùng chung ở `maps/sodo-<id sơ đồ>`.
  - `downloads`: cho các nút xuất file chạy.
  - Nếu môi trường yêu cầu tải skill hướng dẫn capabilities trước khi khai báo, tải skill đó rồi khai báo đúng bộ trên.
- `icon`: `map` (chỉ ở lần xuất bản đầu).
- `description`: một câu, ví dụ "Sơ đồ tư duy 5 nhánh về đề án giảm thời gian chờ khám."

Với **kiểu K01**:
- `files`: `{"k01.js": "so-do/k01.js", "k01.css": "so-do/k01.css"}`.
- `capabilities`: `{"db": {"rules": [{"path": "maps", "read": "view", "write": "owner"}]}, "user": {}, "downloads": true}` — chỉ chủ sơ đồ ghi được bản chung, mọi người được chia sẻ đọc được.
- Sau lần xuất bản đầu, có thể kiểm bằng `ArtifactData` `list` collection `maps` (thường rỗng cho tới khi chủ bấm Lưu bản chung).

Sau khi xuất bản:
- Kết quả xuất bản phải có đủ `engine.js` và `engine.css` (kiểu K01: `k01.js` và `k01.css`).
- Không dán URL vào câu trả lời; thẻ artifact đã có link.
- Nếu `storage` là `shared`, nhắc người dùng chia sẻ sơ đồ cho nhóm bằng nút Chia sẻ. Người được chia sẻ quyền xem không sửa được bản dùng chung; sơ đồ sẽ báo "Chỉ xem".

## Giao file HTML

- Gửi `so-do/<id>.html` bằng công cụ gửi file của phiên (ví dụ SendUserFile, kiểu hiển thị tệp đính kèm), chú thích một dòng: "Mở bằng Chrome, Edge hoặc Safari". Không xuất bản file này thành artifact.
- Phiên có thư mục trên máy người dùng và người dùng muốn lưu vào đó: ghi file vào thư mục ấy và nói rõ vị trí.
- Không dán mã HTML vào câu trả lời.
- Trong file HTML, nút Xuất… tải file trực tiếp; trạng thái góc trên ghi "Lưu trên trình duyệt này" là bình thường.

## Cập nhật sơ đồ đã có

1. Nếu sơ đồ tạo ở cuộc trò chuyện khác, cần link. Đọc trang bằng Artifact `read` với `url`, rồi lấy JSON trong thẻ `<script id="sodo-data">`.
2. Sửa dữ liệu theo yêu cầu, giữ nguyên `id` của sơ đồ và `id` của các ý cũ, **tăng `rev` thêm 1**, chạy lại mã kiểm tra và dựng trang.
3. Xuất bản với `url` của sơ đồ (hoặc cùng `file_path` nếu cùng cuộc trò chuyện). Không cần gửi lại `files`, vì các file không gửi sẽ được giữ.
4. Muốn nâng cấp sơ đồ cũ lên bộ mã mới nhất của skill thì gửi lại `files` như mục Xuất bản.
5. Nhắc người dùng: ai đã chỉnh sửa trên bản cũ sẽ thấy thông báo để chọn "Dùng bản mới" hoặc "Giữ bản của tôi".
6. Với file HTML: dựng lại bằng `--mode html` và gửi file mới. Thay đổi người dùng đã lưu trên trình duyệt vẫn giữ nếu họ mở file mới ở cùng trình duyệt; sơ đồ sẽ hỏi dùng bản mới hay giữ bản của họ.

Đổi chế độ sau khi dựng: "Xuất thêm file HTML" thì dựng `--mode html` từ dữ liệu hiện có và gửi file; "Đưa lên artifact" thì dựng `--mode artifact` và xuất bản. Nếu người dùng đã sửa trên bản đang có, lấy dữ liệu mới theo đoạn dưới trước khi dựng.

Kiểu K01: bản chủ sơ đồ đã Lưu bản chung nằm trong kho `db` của artifact (`maps/<id>`, trường `json` là danh sách tab). Khi cập nhật, đọc bằng `ArtifactData` `get` collection `maps` doc `<id>` (nếu có) và lấy `json` làm dữ liệu gốc để sửa, rồi tăng `rev`; nếu không, dùng `sodo-data` trong trang. Với file HTML, mời người dùng **Xuất JSON** và gửi file.

Những thay đổi người dùng tự làm trên sơ đồ nằm trong bộ nhớ của người xem, Claude không đọc được. Nếu người dùng muốn Claude dựa trên bản họ đã sửa, mời họ bấm **Xuất… → JSON** rồi dán vào chat. Claude dùng `tree` và `flows` trong file đó làm dữ liệu mới.

## Phương án dự phòng

| Tình huống | Cách làm |
|---|---|
| Chọn Artifact nhưng không có công cụ Artifact, hoặc xuất bản bị từ chối | Báo một câu rồi chuyển sang File HTML: dựng `--mode html` và gửi file `<id>.html` (mục "Giao file HTML"). Người dùng mở bằng trình duyệt (Chrome, Edge, Safari): đủ tính năng sửa, dàn ý, tìm kiếm, xuất PDF/PNG/SVG/Markdown/OPML/JSON. Khác biệt: thay đổi lưu trên trình duyệt đang mở, không lưu vào tài khoản và không dùng chung cho nhóm; nhắc người dùng Xuất JSON để sao lưu hoặc gửi đồng nghiệp |
| Không chạy được mã Python nhưng tạo được file | Tự kiểm theo quy tắc, dựng `index.html` theo mục "Mã kiểm tra và dựng trang" |
| Không tạo được file nào (không có công cụ chạy mã, tạo file hay artifact) | Không tự viết lại toàn bộ mã. Trả dàn ý Markdown đã duyệt kèm một khối ```mermaid mindmap``` để xem nhanh, và nói rõ bản đầy đủ tính năng cần bật tính năng tạo file hoặc artifact |
| Sơ đồ trên ~300 ý hoặc dữ liệu lớn hơn 200 KB | Đề xuất tách thành sơ đồ tổng quan và các sơ đồ con, mỗi nhánh lớn một sơ đồ |

## Bảng kiểm trước khi bàn giao

- [ ] Sơ đồ trả lời được câu hỏi trọng tâm; tiêu đề ngắn, cụ thể.
- [ ] 3–7 nhánh chính; nhánh cấp 1 mang thông điệp chính.
- [ ] Tên ý ngắn (≤ 8 âm tiết), cùng kiểu ngữ pháp; chi tiết và nguồn nằm trong ghi chú.
- [ ] Bộ nhãn phù hợp lĩnh vực, ≤ 6 nhãn, mỗi nhãn một nghĩa.
- [ ] Mọi luồng có loại quan hệ đúng và nhãn động từ; số luồng vừa phải.
- [ ] Ý Claude thêm vào tài liệu của người dùng có nhãn GY; sơ đồ soạn từ kiến thức chung đã ghi rõ trong `source`; thông tin dễ thay đổi có nguồn.
- [ ] Đã dùng đúng chế độ xuất người dùng chọn (hoặc mặc định hợp lý và đã nói rõ).
- [ ] Mã kiểm tra không còn LỖI; Artifact có đủ engine.js, engine.css và capabilities; File HTML đã gửi tới người dùng.
- [ ] Đã nhắc cảnh báo đúng chế độ: chia sẻ và gỡ xuất bản (Artifact), lưu trên trình duyệt và sao lưu JSON (File HTML), dữ liệu nhạy cảm (nếu có).
- [ ] Kiểu K01: khi cập nhật sơ đồ người dùng đã sắp, giữ nguyên `ox`/`oy`/`bx`/`by` của các ý không đổi.
- [ ] Kiểu K01: nhánh lớn xen kẽ hai bên (trừ tab bậc thang); thẻ `card` 2 cột; icon hợp nội dung; ma trận có tên trục, mức trục đúng chiều (thấp → cao), ô không chồng nhau.
- [ ] Câu trả lời cuối có khối gợi ý Bước 7/7.

## Lỗi thường gặp

| Hiện tượng | Nguyên nhân | Cách xử lý |
|---|---|---|
| Trang trắng, báo "Không đọc được dữ liệu sơ đồ" | JSON hỏng, hoặc trong dữ liệu có `</script>` chưa đổi thành `<\/` | Chạy lại mã dựng trang (đã tự thay) |
| Sơ đồ hiện nhưng không có giao diện, chữ thô | Thiếu `engine.css` hoặc `engine.js` | Chạy lại mã dựng trang (tự chép 2 file), xuất bản lại kèm `files` |
| Mã dựng báo thiếu file trong `assets` | Skill được tải lên thiếu thư mục `assets` | Tải lên lại đủ cả thư mục skill (file zip gốc) |
| Nút Xuất chỉ hiện ô sao chép hoặc ảnh xem trước | Thiếu capability `downloads`, hoặc môi trường không cho tải file | Xuất bản lại với capabilities đầy đủ |
| Góc trên ghi "Lưu trên trình duyệt này" | File HTML (bình thường); hoặc Artifact thiếu `db`/`user`, gói tài khoản không có lưu trữ, người xem chưa đăng nhập | File HTML: không cần xử lý. Artifact: kiểm tra capabilities. Cả hai: nhắc Xuất JSON để sao lưu |
| Mở file HTML thấy sửa lần trước bị mất | Mở bằng trình duyệt khác, cửa sổ ẩn danh, hoặc đã xoá dữ liệu duyệt web | Mở lại đúng trình duyệt cũ; từ nay sao lưu bằng Xuất JSON và khôi phục bằng Nhập |
| Người khác mở link sơ đồ không được | Sơ đồ ở chế độ riêng tư | Nút Chia sẻ của artifact |
| Đã cập nhật mà người xem vẫn thấy bản cũ | Họ đang giữ bản đã sửa | Họ bấm "Dùng bản mới" trong bảng bên phải (chỉ hiện khi `rev` đã tăng) |
| Kiểu K01: người được chia sẻ không thấy menu Chỉnh sửa | Đúng thiết kế: chỉ chủ sơ đồ sửa | Muốn người khác sửa: gửi file HTML, hoặc dùng kiểu cổ điển với `storage: "shared"` |
| Kiểu K01: chủ bấm Lưu bản chung báo chưa lưu được | Artifact thiếu capability `db`/`user`, hoặc người xem chưa đăng nhập | Xuất bản lại với capabilities kiểu K01 |
| Kiểu K01: kéo vào nút thì nút di chuyển chứ không kéo được cả khung | Đúng thiết kế: kéo trên nút là di chuyển nút | Kéo ở vùng nền trống để di chuyển cả khung; "Sắp xếp lại" để về bố cục tự động |
| PDF nhiều trang | Sơ đồ mở quá nhiều ý cho một trang | Bình thường: bộ mã tự chia trang theo nhánh để chữ ≥ 6,5 pt. Muốn một trang thì thu gọn bớt hoặc chọn A3 |

## Nguồn

- Novak & Cañas (2006), *The Theory Underlying Concept Maps*: https://users.cs.northwestern.edu/~paritosh/papers/sketch-to-models/Novak-Canas-TheoryUnderlyingConceptMapsHQ.pdf
- Nesbit & Adesope (2006), phân tích gộp concept map: https://www.sfu.ca/~jcnesbit/articles/NesbitAdesope2006.pdf
- Schroeder và cộng sự (tóm tắt TUM): https://www.clearinghouse.edu.tum.de/wp-content/uploads/2023/10/CHU_KR-19_ENG_Schroeder-2_2017.pdf
- Cowan (2001), giới hạn trí nhớ làm việc: https://memory.psych.missouri.edu/assets/doc/articles/2001/cowan-bbs-2001.pdf
- NN/g, Progressive Disclosure: https://www.nngroup.com/alertbox/progressive-disclosure.html
- W3C WCAG 2.2, SC 1.4.11: https://w3.org/WAI/WCAG22/Understanding/non-text-contrast
- W3C APG, Tree View: https://w3.org/WAI/ARIA/apg/patterns/treeview
- Okabe–Ito (The Node): https://thenode.biologists.com/data-visualization-with-flying-colors/research/
- Help Center, Publishing and sharing artifacts: https://support.claude.com/en/articles/9547008-publishing-and-sharing-artifacts