"""Kiểm tra và dựng sơ đồ kiểu K01 (nhiều tab, nhánh xen kẽ hai bên, ma trận trên hệ trục).
Được dung_so_do.py gọi khi data.json có "style": "k01"."""
import json, html, re, os, shutil

ICONS = None
COLORS = {'c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'c8', 'ok', 'warn', 'info', 'bad', 'gx'}
TYPES = {'root', 'branch', 'idea', 'card', 'step'}
FONTS = '''<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700;800&family=Lora:wght@500;600;700&display=swap">'''


def icons(assets):
    global ICONS
    if ICONS is None:
        js = open(os.path.join(assets, 'k01', 'k01.js'), encoding='utf-8').read()
        blk = js[js.index('const P = {'):js.index('const ICONS')]
        ICONS = set(re.findall(r"(?<![\w-])([a-z]+): '<", blk))
    return ICONS


def check(d, assets):
    err, warn, st = [], [], {'tabs': 0, 'nodes': 0, 'cells': 0, 'flows': 0}
    ic = icons(assets)
    if not re.fullmatch(r'[a-z0-9][a-z0-9\-]{1,60}', str(d.get('id', ''))): err.append('id phải viết thường không dấu, nối bằng gạch ngang')
    if not d.get('title'): err.append('thiếu title')
    if not isinstance(d.get('rev'), int) or d['rev'] < 1: err.append('rev phải là số nguyên ≥ 1')
    tabs = d.get('tabs')
    if not isinstance(tabs, list) or not tabs: err.append('thiếu tabs (ít nhất 1 tab)'); return err, warn, st
    if len(tabs) > 8: warn.append(f'{len(tabs)} tab; nên ≤ 8')
    for l in d.get('logos', []) or []:
        if not re.match(r'^(https://|data:image/)', str(l.get('src', ''))): err.append('logo phải là https://… hoặc data:image/…')
    for ti, t in enumerate(tabs):
        st['tabs'] += 1
        name = t.get('label') or f'tab {ti + 1}'
        if not t.get('label'): warn.append(f'tab {ti + 1} chưa có label')
        kind = t.get('kind', 'map')
        if kind == 'map':
            root = t.get('root')
            if not isinstance(root, dict): err.append(f'{name}: thiếu root'); continue
            ids = set()
            def walk(n, depth):
                if depth > 0: st['nodes'] += 1
                ty = n.get('type') or ('root' if depth == 0 else 'branch' if depth == 1 else 'idea')
                if ty not in TYPES: err.append(f'{name}: type lạ "{ty}"')
                if n.get('id'):
                    if n['id'] in ids: err.append(f'{name}: id trùng {n["id"]}')
                    ids.add(n['id'])
                if ty == 'card':
                    if not n.get('items'): err.append(f'{name}: thẻ card thiếu items')
                    for it in n.get('items', []):
                        if it.get('icon') and it['icon'] not in ic: warn.append(f'{name}: icon lạ "{it["icon"]}" (bỏ qua)')
                elif not str(n.get('t', '')).strip(): err.append(f'{name}: có ý thiếu t (tên)')
                if n.get('color') and n['color'] not in COLORS: err.append(f'{name}: color "{n["color"]}" không có; dùng c1–c8, ok, warn, info, bad, gx')
                if n.get('icon') and n['icon'] not in ic: warn.append(f'{name}: icon lạ "{n["icon"]}" (bỏ qua)')
                if n.get('img') and not re.match(r'^(https://|data:image/)', str(n['img'])): err.append(f'{name}: img phải là https://… hoặc data:image/…')
                if depth > 0 and ty in ('idea', 'branch') and len(str(n.get('t', '')).split()) > 10: warn.append(f'{name}: tên dài, nên chuyển chi tiết vào note: {n.get("t")}')
                kids = n.get('c', []) or []
                if depth == 0 and not 2 <= len(kids) <= 8: warn.append(f'{name}: gốc có {len(kids)} nhánh; nên 3–7')
                for c in kids: walk(c, depth + 1)
            walk(root, 0)
            for f in t.get('flows', []) or []:
                st['flows'] += 1
                if f.get('from') not in ids or f.get('to') not in ids: err.append(f'{name}: liên kết trỏ tới id không có (đặt "id" cho hai ý cần nối): {f}')
                if f.get('kind', 'cause') not in ('cause', 'mutual', 'oppose'): err.append(f'{name}: kind sai: {f}')
                f.setdefault('id', f'f{ti}-{st["flows"]}')
        elif kind == 'matrix':
            x, y = t.get('x') or {}, t.get('y') or {}
            X, Y = x.get('levels') or [], y.get('levels') or []
            if not 1 <= len(X) <= 5 or not 1 <= len(Y) <= 5: err.append(f'{name}: mỗi trục cần 1–5 mức (levels)')
            if not x.get('title') or not y.get('title'): err.append(f'{name}: thiếu title của trục x hoặc y')
            grid = [[None] * len(X) for _ in Y]
            for ci, c in enumerate(t.get('cells', []) or []):
                st['cells'] += 1
                cx, cy = c.get('x'), c.get('y')
                if not (isinstance(cx, list) and isinstance(cy, list) and len(cx) == 2 and len(cy) == 2): err.append(f'{name}: ô "{c.get("name")}" cần x:[từ,đến] và y:[từ,đến] (đếm từ 0, mức thấp = 0)'); continue
                if not (0 <= cx[0] <= cx[1] < len(X) and 0 <= cy[0] <= cy[1] < len(Y)): err.append(f'{name}: ô "{c.get("name")}" nằm ngoài trục'); continue
                for r in range(cy[0], cy[1] + 1):
                    for k in range(cx[0], cx[1] + 1):
                        if grid[r][k] is not None: err.append(f'{name}: ô "{c.get("name")}" chồng lên ô "{grid[r][k]}"')
                        grid[r][k] = c.get('name')
                if not c.get('name'): err.append(f'{name}: có ô thiếu name')
                if c.get('color') and c['color'] not in COLORS: err.append(f'{name}: color "{c["color"]}" không có')
                if c.get('icon') and c['icon'] not in ic: warn.append(f'{name}: icon lạ "{c["icon"]}" (bỏ qua)')
            free = sum(v is None for row in grid for v in row)
            if free: warn.append(f'{name}: {free} vị trí trống trên lưới (người sửa sẽ thấy nút "+ Thêm ô")')
        else:
            err.append(f'{name}: kind phải là map hoặc matrix')
    return err, warn, st


def build(d, outdir, mode, assets):
    os.makedirs(outdir, exist_ok=True)
    title = html.escape(d['title'])
    payload = json.dumps(d, ensure_ascii=False, indent=1).replace('</', '<\\/')
    out = []
    if mode in ('artifact', 'both'):
        page = f'''<title>{title}</title>
<meta name="claude:viewport-fit-sides" content="cover">
{FONTS}
<link rel="stylesheet" href="k01.css">
<div id="sodo-app"></div>
<script type="application/json" id="sodo-data">
{payload}
</script>
<script src="k01.js"></script>
'''
        p = os.path.join(outdir, 'index.html'); open(p, 'w', encoding='utf-8').write(page)
        for f in ('k01.js', 'k01.css'): shutil.copyfile(os.path.join(assets, 'k01', f), os.path.join(outdir, f))
        out.append(f'Artifact: đã dựng {p} + k01.js + k01.css (xuất bản cả 3 file, capabilities db + user)')
    if mode in ('html', 'both'):
        rd = lambda f: open(os.path.join(assets, 'k01', f), encoding='utf-8').read()
        page = f'''<!doctype html>
<html lang="vi"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>{title}</title>
{FONTS}
<style>body{{margin:0}}[hidden]{{display:none!important}}
{rd('k01.css')}</style>
</head><body>
<div id="sodo-app"></div>
<script type="application/json" id="sodo-data">
{payload}
</script>
<script>window.K01_MODE='html';</script>
<script>{rd('k01.js')}</script>
</body></html>
'''
        p = os.path.join(outdir, d['id'] + '.html'); open(p, 'w', encoding='utf-8').write(page)
        out.append(f'File HTML: đã dựng {p} ({os.path.getsize(p)//1024} KB) - gửi file này cho người dùng')
    return out
