#!/usr/bin/env python3
"""Kiểm tra dữ liệu sơ đồ và dựng trang.

Cách dùng:
  python3 dung_so_do.py data.json THU_MUC_RA [--mode artifact|html|both]

  data.json có "style": "k01" thì dựng kiểu K01 (assets/k01/), ngược lại dựng kiểu cổ điển (d3).

  artifact (mặc định): ghi index.html, engine.js, engine.css để xuất bản Artifact.
  html: ghi một file <id>.html đã nhúng sẵn toàn bộ mã (kể cả d3), mở bằng
        trình duyệt là dùng được, không cần mạng (trừ phông chữ, có phông dự phòng).
  both: ghi cả hai.
  --standalone: tên cũ, tương đương --mode html.
"""
import json, sys, html, re, os, shutil

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.normpath(os.path.join(HERE, '..', 'assets'))

argv = sys.argv[1:]
MODE = 'artifact'
if '--standalone' in argv:
    MODE = 'html'; argv.remove('--standalone')
if '--mode' in argv:
    i = argv.index('--mode')
    if i + 1 >= len(argv) or argv[i + 1] not in ('artifact', 'html', 'both'):
        print('LỖI: --mode phải là artifact, html hoặc both'); sys.exit(2)
    MODE = argv[i + 1]; del argv[i:i + 2]
args = [a for a in argv if not a.startswith('--')]
if len(args) != 2:
    print(__doc__); sys.exit(2)
SRC, OUTDIR = args
d = json.load(open(SRC, encoding='utf-8'))

# ---------- Kiểu K01: nhiều tab, nhánh xen kẽ hai bên, ma trận trên hệ trục ----------
if d.get('style') == 'k01':
    sys.path.insert(0, HERE)
    import k01
    e, w, st = k01.check(d, ASSETS)
    print(f"Kiểu K01 · {st['tabs']} tab · {st['nodes']} ý (không kể gốc) · {st['cells']} ô ma trận · {st['flows']} liên kết")
    for x in e: print('LỖI:', x)
    for x in w: print('CẢNH BÁO:', x)
    if e: sys.exit(1)
    for line in k01.build(d, OUTDIR, MODE, ASSETS): print(line)
    sys.exit(0)
err, warn = [], []

# ---------- Kiểm tra dữ liệu ----------
if not re.fullmatch(r'[a-z0-9][a-z0-9\-]{1,60}', str(d.get('id', ''))): err.append('id phải viết thường không dấu, nối bằng gạch ngang')
if not d.get('title'): err.append('thiếu title')
if not isinstance(d.get('rev'), int) or d['rev'] < 1: err.append('rev phải là số nguyên ≥ 1')
if d.get('storage', 'personal') not in ('personal', 'shared'): err.append('storage phải là personal hoặc shared')
keys = [str(t.get('key', '')).strip() for t in d.get('tags', [])]
if '' in keys: err.append('có nhãn thiếu key')
if len(set(keys)) != len(keys): err.append('key nhãn bị trùng')
if len(keys) > 6: err.append('tối đa 6 nhãn')
tags, used = set(keys), set()
tree = d.get('tree')
if not isinstance(tree, dict): err.append('thiếu tree'); tree = {'id': 'r', 'name': '?', 'children': []}
ids, parent = set(), {}
stat = {'nodes': 0, 'depth': 0}

def walk(n, depth, par):
    if depth > 0: stat['nodes'] += 1
    stat['depth'] = max(stat['depth'], depth)
    nid = n.get('id')
    if not nid: err.append(f'ý thiếu id: {n.get("name")}')
    elif nid in ids: err.append(f'id trùng: {nid}')
    ids.add(nid); parent[nid] = par
    name = str(n.get('name', '')).strip()
    if not name: err.append(f'ý {nid} thiếu name')
    if depth > 0 and len(name.split()) > 8: warn.append(f'tên dài ({len(name.split())} âm tiết), nên ≤ 8 và chuyển chi tiết vào note: {name}')
    if n.get('tag'):
        used.add(n['tag'])
        if n['tag'] not in tags: err.append(f'nhãn {n["tag"]} của ý {nid} không có trong tags')
    kids = n.get('children', []) or []
    if depth == 0 and not 3 <= len(kids) <= 7: warn.append(f'gốc có {len(kids)} nhánh chính; nên 3–7 (lý tưởng 4–6)')
    if depth > 0 and len(kids) > 7: warn.append(f'ý "{name}" có {len(kids)} ý con; nên ≤ 7, gom nhóm bớt')
    if depth > 0 and len(kids) == 1: warn.append(f'ý "{name}" chỉ có 1 ý con; cân nhắc gộp vào')
    for c in kids: walk(c, depth + 1, nid)

walk(tree, 0, None)
for k in tags - used: warn.append(f'nhãn {k} khai báo nhưng chưa dùng (bỏ qua nếu để người dùng tự gắn)')
if stat['depth'] > 4: warn.append(f'sâu {stat["depth"]} cấp dưới gốc; nên ≤ 4, sâu hơn thì tách sơ đồ con')

def anc(x):
    while x is not None:
        yield x; x = parent.get(x)

flows = d.get('flows', []) or []
for f in flows:
    a, b = f.get('from'), f.get('to')
    if a not in ids or b not in ids: err.append(f'luồng trỏ tới id không tồn tại: {f}'); continue
    if a == b: err.append(f'luồng tự nối: {f}')
    elif a in anc(b) or b in anc(a): warn.append(f'luồng nối ý với tổ tiên/con cháu của nó ({a} – {b}); luồng nên nối hai nhánh khác nhau')
    if f.get('kind', 'cause') not in ('cause', 'mutual', 'oppose'): err.append(f'kind sai: {f}')
    if not f.get('label'): warn.append(f'luồng chưa có nhãn động từ: {a} → {b}')
    elif len(str(f['label']).split()) > 4: warn.append(f'nhãn luồng dài: {f["label"]}')
if len(flows) > 15: warn.append(f'{len(flows)} luồng; trên ~15 dễ rối')
payload = json.dumps(d, ensure_ascii=False, indent=1).replace('</', '<\\/')
if len(payload.encode()) > 200_000: warn.append('dữ liệu lớn hơn 200 KB; lưu vào tài khoản có thể không được, nên tách sơ đồ')

print(f'{stat["nodes"]} ý (không kể gốc) · {len(tree.get("children", []) or [])} nhánh chính · sâu {stat["depth"]} cấp dưới gốc · {len(flows)} luồng · {len(keys)} nhãn')
for e in err: print('LỖI:', e)
for w in warn: print('CẢNH BÁO:', w)
if err: sys.exit(1)

# ---------- Dựng trang ----------
for f in ('engine.js', 'engine.css', 'd3.min.js'):
    if not os.path.isfile(os.path.join(ASSETS, f)):
        print('LỖI: thiếu file', os.path.join(ASSETS, f), '- skill bị thiếu thư mục assets'); sys.exit(1)
os.makedirs(OUTDIR, exist_ok=True)
TITLE = html.escape(d['title'])
FONTS = '''<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600&family=Lora:wght@500;600&display=swap">'''

if MODE in ('artifact', 'both'):
    page = f'''<title>{TITLE}</title>
<meta name="claude:viewport-fit-sides" content="cover">
{FONTS}
<link rel="stylesheet" href="engine.css">
<div id="sodo-app"></div>
<script type="application/json" id="sodo-data">
{payload}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/d3/7.8.5/d3.min.js"></script>
<script src="engine.js"></script>
'''
    out = os.path.join(OUTDIR, 'index.html')
    open(out, 'w', encoding='utf-8').write(page)
    for f in ('engine.js', 'engine.css'):
        shutil.copyfile(os.path.join(ASSETS, f), os.path.join(OUTDIR, f))
    print('Artifact: đã dựng', out, '+ engine.js + engine.css (xuất bản cả 3 file)')
if MODE in ('html', 'both'):
    rd = lambda f: open(os.path.join(ASSETS, f), encoding='utf-8').read()
    # Ngoài Claude không có kho lưu: sơ đồ tự lưu trên trình duyệt.
    # Đoạn nối dưới đây chỉ cho nút Xuất tải file trực tiếp.
    shim = '''if(!window.claude){window.claude={use:async function(n){if(n!=='downloads')return null;return{save:async function(o){var b=o.data instanceof Blob?o.data:new Blob([o.data]);var a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=o.filename;document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1500);}};}};}'''
    page = f'''<!doctype html>
<html lang="vi"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>{TITLE}</title>
{FONTS}
<style>body{{margin:0}}
{rd('engine.css')}</style>
</head><body>
<div id="sodo-app"></div>
<script type="application/json" id="sodo-data">
{payload}
</script>
<script>{rd('d3.min.js')}</script>
<script>{shim}</script>
<script>{rd('engine.js')}</script>
</body></html>
'''
    out = os.path.join(OUTDIR, d['id'] + '.html')
    open(out, 'w', encoding='utf-8').write(page)
    print('File HTML: đã dựng', out, f'({os.path.getsize(out)//1024} KB) - gửi file này cho người dùng')
