/* Khuôn sơ đồ tư duy tương tác – engine.js
   Đọc dữ liệu từ <script type="application/json" id="sodo-data"> trong trang, dựng sơ đồ bằng D3 (tải trước file này).
   Quy ước đường nối: nét liền màu nhóm = cha–con; nét đứt + mũi tên = dẫn đến/nhân quả; nét đứt + hai mũi tên = tương hỗ;
   nét gạch–chấm + đầu chặn = đối lập/mâu thuẫn; nét chấm mờ = luồng tạm gắn vào nhánh đang thu gọn. */
(function(){
'use strict';
const ENGINE_VERSION='1.0';
const CFG=(()=>{ try{ return JSON.parse(document.getElementById('sodo-data').textContent); }catch(e){ return null; } })();
const host=document.getElementById('sodo-app');
if(!CFG||!CFG.tree||!host){ if(host) host.innerHTML='<p style="padding:24px">Không đọc được dữ liệu sơ đồ (thẻ sodo-data).</p>'; return; }
const TITLE=CFG.title||CFG.tree.name||'Sơ đồ tư duy';
const MAP_ID=String(CFG.id||'so-do').replace(/[^A-Za-z0-9_\-.~:@+]/g,'-').slice(0,80)||'so-do';
const DOCNAME=CFG.docName||('sodo-'+MAP_ID);
const LKEY=CFG.storageKey||('sodo-'+MAP_ID);
const REV=+CFG.rev||1;
const SHARED=CFG.storage==='shared';
const SOURCE=CFG.source||'';
const TAGS=(Array.isArray(CFG.tags)?CFG.tags:[]).slice(0,6).map((t,i)=>({key:String(t.key||'').trim().slice(0,8),label:String(t.label||t.key||''),i})).filter(t=>t.key);
const TAG=Object.fromEntries(TAGS.map(t=>[t.key,t]));
const KINDS={cause:{label:'Dẫn đến / nhân quả',out:'Dẫn đến',inn:'Do'},mutual:{label:'Tương hỗ / hai chiều',out:'Hai chiều với',inn:'Hai chiều với'},oppose:{label:'Đối lập / kìm hãm',out:'Đối lập, kìm hãm',inn:'Bị đối lập, kìm hãm bởi'}};
const reduceMQ=matchMedia('(prefers-reduced-motion: reduce)'); const reduced=()=>reduceMQ.matches;
const mobileMQ=matchMedia('(max-width:860px)');
const SESSION=Math.random().toString(36).slice(2,10);
let uid=0, fuid=0;
function N(name,tag,note,children){ return {id:'n'+(++uid),name,tag:tag||'',note:note||'',children:children||[]}; }
function esc(s){ return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
function tagColor(k){ const t=TAG[k]; return t?`var(--t${t.i+1})`:'var(--muted)'; }
function tagChip(k){ return k?`<span class="tag" style="--tc:${tagColor(k)}" title="${esc(TAG[k]?TAG[k].label:k)}">${esc(k)}</span>`:''; }

/* ---------- Khung giao diện ---------- */
host.innerHTML=`<div class="app">
  <header>
    <div class="top">
      <div>${CFG.eyebrow?`<div class="eyebrow">${esc(CFG.eyebrow)}</div>`:''}<h1>${esc(TITLE)}</h1></div>
      <div class="meta">${TAGS.map(t=>`<span>${tagChip(t.key)} ${esc(t.label)}</span>`).join('')}<span class="stat" id="stats"></span><span class="store" id="store">Lưu trên trình duyệt này</span></div>
    </div>
    <div class="toolbar">
      <div class="search"><input id="q" type="search" placeholder="Tìm ý, gõ có dấu hoặc không…" aria-label="Tìm trong sơ đồ"><span id="qcount"></span></div>
      ${TAGS.length?`<select id="filter" class="mini" aria-label="Lọc theo nhãn"><option value="">Mọi nhãn</option>${TAGS.map(t=>`<option value="${esc(t.key)}">Chỉ ${esc(t.key)}</option>`).join('')}</select>`:''}
      <div class="tools">
        <button id="btn-undo" title="Hoàn tác (Ctrl/Cmd+Z)" disabled>↶ Hoàn tác</button>
        <button id="btn-redo" title="Làm lại (Ctrl+Shift+Z hoặc Ctrl+Y)" disabled>↷ Làm lại</button>
        <span class="sep"></span>
        <button id="btn-outline" aria-pressed="false" title="Chuyển giữa sơ đồ và dàn ý">Dàn ý</button>
        <button id="btn-expand">Mở hết</button>
        <button id="btn-collapse">Thu gọn</button>
        <button id="btn-fit">Vừa khung</button>
        <button id="btn-tidy">Sắp xếp lại</button>
        <label class="chk"><input id="chk-flows" type="checkbox" checked> Hiện luồng</label>
        <span class="sep"></span>
        <button id="btn-export">Xuất…</button>
        <button id="btn-import">Nhập…</button>
        <button id="btn-reset" class="danger">Khôi phục gốc</button>
      </div>
    </div>
  </header>
  <main>
    <div class="stage">
      <svg id="map" aria-label="${esc(TITLE)}"></svg>
      <div id="outline" hidden></div>
      <div class="hint" id="hint" role="status"></div>
      <div class="linkbar" id="linkbar" hidden><span id="linktext"></span><button id="btn-cancel-link">Huỷ</button></div>
    </div>
    <aside id="panel" aria-live="polite"></aside>
  </main>
</div>`;
const $=id=>document.getElementById(id);
const panel=$('panel');

/* ---------- Dữ liệu ---------- */
function walk(n,fn,p=null){ fn(n,p); (n.children||[]).forEach(c=>walk(c,fn,n)); }
function seed(){
  const t=JSON.parse(JSON.stringify(CFG.tree)); const depth=Math.max(1,+CFG.openDepth||2);
  (function prep(n,d){ n.name=String(n.name||''); n.tag=n.tag||''; n.note=n.note||''; n.children=n.children||[];
    if(n.children.length) n._c=d===0?false:(typeof n.collapsed==='boolean'?n.collapsed:d>=depth); else delete n._c; delete n.collapsed; n.children.forEach(c=>prep(c,d+1)); })(t,0);
  return {version:2,baseRev:REV,tree:t,flows:(CFG.flows||[]).map((f,i)=>({id:f.id||('f'+(i+1)),from:f.from,to:f.to,label:f.label||'',kind:KINDS[f.kind]?f.kind:'cause'}))};
}
function normalize(s){ s.flows=(s.flows||[]).map(f=>({id:f.id,from:f.from,to:f.to,label:f.label||'',kind:KINDS[f.kind]?f.kind:'cause'})); if(!s.baseRev) s.baseRev=REV; s.version=2; return s; }
function readLocal(k){ try{ const s=JSON.parse(localStorage.getItem(k)); if(s&&s.tree&&s.tree.name!==undefined) return s; }catch(e){} return null; }
function syncIds(){ let m=0,f=0; walk(state.tree,n=>{ if(!n.id) n.id='n'+(++m+100000); const k=+String(n.id).replace(/^\D+/,''); if(k>m) m=k; if(!n.children) n.children=[]; });
  (state.flows||[]).forEach(x=>{ const k=+String(x.id).replace(/^\D+/,''); if(k>f) f=k; }); uid=Math.max(uid,m); fuid=Math.max(fuid,f); }
function ensureUniqueIds(){ const seen=new Set(); walk(state.tree,n=>{ if(!n.id||seen.has(n.id)) n.id='n'+(++uid); seen.add(n.id); }); }

let state=normalize(readLocal(LKEY)||seed());
syncIds(); ensureUniqueIds();
let newerRev=state.baseRev<REV;

let selectedId=null, linkFrom=null, matches=new Set(), showFlows=true, filterTag='', outlineMode=false, hintKey='idle';
let cur=null, byId=new Map(), dataById=new Map(), parentOf=new Map(), prevPos=new Map(), dragState=null, visOrder=[];
function index(){ dataById.clear(); parentOf.clear(); walk(state.tree,(n,p)=>{ dataById.set(n.id,n); if(p) parentOf.set(n.id,p.id); }); }
function norm(s){ return String(s).normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[đĐ]/g,'d').toLowerCase(); }
function short(s,n=40){ s=String(s); return s.length>n? s.slice(0,n-1)+'…' : s; }
function countDesc(n){ let c=0; walk(n,()=>c++); return c-1; }
function groupIndex(id){ let x=id, p=parentOf.get(x); if(!p) return -1; while(parentOf.get(p)){ x=p; p=parentOf.get(p); } return state.tree.children.findIndex(c=>c.id===x); }
function colorVar(gi){ return gi<0?'var(--accent)':`var(--g${(gi%7)+1})`; }

/* ---------- Gợi ý theo ngữ cảnh ---------- */
const K=s=>`<kbd>${s}</kbd>`;
function setHint(key,name){
  hintKey=key; const el=$('hint'); if(!el) return; const touch=mobileMQ.matches;
  const H={
    idle: touch?'Chạm một ý để mở/thu và xem chi tiết · Chụm hai ngón để phóng to · Giữ và kéo ý để chuyển nhánh'
               :`Bấm một ý để mở/thu · Kéo nền để di chuyển · Lăn chuột để phóng to · Chọn ý rồi ${K('Tab')} thêm ý con, ${K('Enter')} thêm cùng cấp`,
    sel: touch?`Đã chọn «${esc(short(name||'',28))}» · Dùng các nút trong bảng chi tiết để thêm, nối luồng hoặc xoá`
              :`Đã chọn «${esc(short(name||'',28))}» · ${K('Tab')} ý con · ${K('Enter')} cùng cấp · ${K('F2')} sửa · ${K('Delete')} xoá · ${K('Space')} mở/thu · mũi tên để di chuyển`,
    edit:`Gõ nội dung ý (cụm 2–5 từ là dễ đọc nhất) · ${K('Enter')} xong và quay lại sơ đồ · giải thích dài để vào ô Ghi chú`,
    link: touch?'Chạm ý đích để nối luồng · Chạm “Huỷ” để thôi':`Bấm ý đích để nối luồng · ${K('Esc')} để huỷ`,
    flow:'Chọn loại quan hệ (dẫn đến, tương hỗ, đối lập/kìm hãm) và gõ nhãn động từ cho luồng ở bảng chi tiết, ví dụ “kiểm tra”, “làm tăng”',
    drag:'Thả lên một ý để chuyển cả nhánh vào đó · Thả ra chỗ trống để đặt vị trí tự do · Hoàn tác được nếu nhầm',
    outline:'Gõ thẳng vào từng dòng · Enter: dòng mới · Tab: lùi vào · Shift+Tab: lùi ra'
  };
  el.innerHTML=H[key]||H.idle; el.hidden=outlineMode;
}

/* ---------- Lưu trữ: trình duyệt + lưu trữ bền vững của artifact (riêng hoặc dùng chung) ---------- */
let remote=null, saveT=null, writing=false, pendingWrite=false, storeMode='local', unsub=null, editingUntil=0;
function setStore(mode){ storeMode=mode; const el=$('store');
  const txt={local:'Lưu trên trình duyệt này',cloud:SHARED?'Đã lưu bản dùng chung':'Đã lưu vào tài khoản',saving:'Đang lưu…',err:'Chưa lưu được vào tài khoản',big:'Quá lớn để lưu tài khoản',ro:'Chỉ xem: thay đổi chỉ lưu trên máy này'}[mode]||'';
  el.textContent=txt; el.className='store '+(mode==='cloud'||mode==='saving'?'cloud':mode==='local'?'':'err'); }
function save(){ state.savedAt=Date.now(); editingUntil=Date.now()+2500; try{ localStorage.setItem(LKEY,JSON.stringify(state)); }catch(e){} updateStats();
  if(remote){ clearTimeout(saveT); saveT=setTimeout(pushRemote,1200); } }
async function pushRemote(){
  if(!remote) return; if(writing){ pendingWrite=true; return; }
  writing=true; setStore('saving');
  const json=JSON.stringify(state);
  try{ if(new TextEncoder().encode(json).length>250000) throw {code:'too_big'};
    await remote.set({version:2,json,savedAt:state.savedAt,writer:SESSION}); setStore('cloud'); }
  catch(e){ const c=e&&e.code; setStore(c==='too_big'?'big':(SHARED&&c&&c!=='unavailable'?'ro':'err')); }
  writing=false; if(pendingWrite){ pendingWrite=false; pushRemote(); }
}
function adopt(s,msg){ state=normalize(s); syncIds(); ensureUniqueIds(); newerRev=state.baseRev<REV; undoStack=[]; redoStack=[]; updUndo();
  if(selectedId&&!JSON.stringify(state.tree).includes('"'+selectedId+'"')) selectedId=null;
  try{ localStorage.setItem(LKEY,JSON.stringify(state)); }catch(e){}
  refresh(); if(msg) toast(msg); }
async function initRemote(){
  const c=window.claude; if(!c||typeof c.use!=='function') return;
  try{
    const [db,user]=await Promise.all([c.use('db'),c.use('user')]);
    if(!db) return;
    let ref;
    if(SHARED) ref=db.doc('maps/'+DOCNAME);
    else { if(!user) return; const id=await user.id(); if(!id) return; ref=db.doc('data/users/'+id+'/'+DOCNAME); }
    const snap=await Promise.race([ref.get(),new Promise((_,rej)=>setTimeout(()=>rej({code:'timeout'}),10000))]);
    remote=ref;
    let s=null; if(snap.exists){ try{ s=JSON.parse(snap.data().json); }catch(e){ s=null; } }
    if(s&&s.tree&&(s.savedAt||0)>(state.savedAt||0)){ adopt(s,SHARED?'Đã mở bản dùng chung mới nhất':'Đã mở bản lưu trong tài khoản của anh/chị'); if(!outlineMode) fitAll(); setStore('cloud'); }
    else if(state.savedAt){ pushRemote(); } else setStore('cloud');
    if(SHARED&&ref.onSnapshot){
      unsub=ref.onSnapshot(sn=>{ if(!sn.exists) return; const d=sn.data(); if(!d||d.writer===SESSION) return;
        let r=null; try{ r=JSON.parse(d.json); }catch(e){ return; }
        if(r&&(r.savedAt||0)>(state.savedAt||0)){ if(Date.now()<editingUntil){ setTimeout(()=>{ if((r.savedAt||0)>(state.savedAt||0)) adopt(r,'Đã cập nhật thay đổi của người khác'); },2600); } else adopt(r,'Đã cập nhật thay đổi của người khác'); } },()=>{});
    }
    if(!selectedId) renderPanel();
  }catch(e){ remote=null; setStore('local'); }
}
let dl=null;
async function initDownloads(){ const c=window.claude; if(!c||typeof c.use!=='function') return; try{ dl=await c.use('downloads'); }catch(e){ dl=null; } }

/* ---------- Hoàn tác / làm lại ---------- */
let undoStack=[], redoStack=[], editKey=null;
function snap(){ return JSON.stringify({tree:state.tree,flows:state.flows,sel:selectedId}); }
function checkpoint(){ undoStack.push(snap()); if(undoStack.length>120) undoStack.shift(); redoStack=[]; editKey=null; updUndo(); }
function beginEdit(key){ if(editKey!==key){ checkpoint(); editKey=key; } }
function endEdit(){ editKey=null; }
function restore(json){ const o=JSON.parse(json); state.tree=o.tree; state.flows=o.flows; syncIds(); index(); selectedId=(o.sel&&dataById.has(o.sel))?o.sel:null; if(selectedId) revealId(selectedId); save(); refresh();
  if(!outlineMode){ const t=document.activeElement; if(!t||t===document.body||(t.closest&&t.closest('#map'))) focusNode(selectedId||state.tree.id); } }
function undo(){ if(!undoStack.length){ toast('Không còn gì để hoàn tác'); return; } redoStack.push(snap()); editKey=null; restore(undoStack.pop()); updUndo(); toast('Đã hoàn tác'); }
function redo(){ if(!redoStack.length){ toast('Không còn gì để làm lại'); return; } undoStack.push(snap()); editKey=null; restore(redoStack.pop()); updUndo(); toast('Đã làm lại'); }
function updUndo(){ $('btn-undo').disabled=!undoStack.length; $('btn-redo').disabled=!redoStack.length; }
function refresh(){ if(outlineMode) renderOutline(); else render(); renderPanel(); }

/* ---------- Đo chữ ---------- */
const ctx=document.createElement('canvas').getContext('2d');
function measure(t,fs,isRoot,bold){ ctx.font=`${isRoot?600:(bold?600:500)} ${fs}px ${isRoot?'Lora, Georgia, serif':'"Be Vietnam Pro", system-ui, sans-serif'}`; return ctx.measureText(t).width; }
function wrap(t,max){ const words=String(t).split(/\s+/); const lines=[]; let line='';
  words.forEach(w=>{ if(!line) line=w; else if((line+' '+w).length<=max) line+=' '+w; else { lines.push(line); line=w; } }); if(line) lines.push(line); return lines.length?lines:['']; }
function chipW(k){ if(!k) return 0; ctx.font='600 9.5px "Be Vietnam Pro", system-ui, sans-serif'; return Math.max(24,Math.ceil(ctx.measureText(k).width)+12); }

/* ---------- SVG & zoom ---------- */
const svg=d3.select('#map');
const defs=svg.append('defs');
defs.append('marker').attr('id','mk-arrow').attr('viewBox','0 0 10 10').attr('refX',9).attr('refY',5).attr('markerWidth',7).attr('markerHeight',7).attr('orient','auto-start-reverse')
  .append('path').attr('class','mk').attr('d','M0,0 L10,5 L0,10 z');
defs.append('marker').attr('id','mk-bar').attr('viewBox','0 0 4 12').attr('refX',3).attr('refY',6).attr('markerWidth',4).attr('markerHeight',12).attr('orient','auto')
  .append('rect').attr('class','mk').attr('x',0.5).attr('y',0).attr('width',3).attr('height',12);
const gRoot=svg.append('g');
const gLinks=gRoot.append('g').attr('class','links').attr('aria-hidden','true');
const gFlows=gRoot.append('g').attr('class','flows').attr('aria-hidden','true');
const gNodes=gRoot.append('g').attr('class','nodes').attr('role','tree').attr('aria-label','Sơ đồ tư duy: dùng phím mũi tên để di chuyển');
const zoom=d3.zoom().scaleExtent([0.12,2.6]).on('zoom',e=>gRoot.attr('transform',e.transform));
svg.call(zoom).on('dblclick.zoom',null);
svg.on('click',e=>{ if(e.target===svg.node()){ if(linkFrom){ cancelLink(); return; } selectedId=null; render({animate:false}); renderPanel(); } });
function linkPath(s,t){ const x1=s.px+10+s.w, y1=s.py, x2=t.px-7, y2=t.py, mx=(x1+x2)/2; return `M${x1},${y1}C${mx},${y1} ${mx},${y2} ${x2},${y2}`; }
function linkWidth(t){ return t.depth===1?3.2:(t.depth===2?2.2:1.5); }

/* ---------- Dựng sơ đồ ---------- */
function render(opts={}){
  const dur=(opts.animate===false||reduced())?0:450;
  index();
  const root=d3.hierarchy(state.tree,d=>d._c?null:(d.children&&d.children.length?d.children:null));
  const gIdx=new Map(); (state.tree.children||[]).forEach((c,i)=>gIdx.set(c.id,i));
  root.each(d=>{ const isRoot=d.depth===0; d.fs=isRoot?17:(d.depth===1?13.5:12.5); d.lines=wrap(d.data.name||'(chưa đặt tên)',isRoot?22:(d.depth===1?24:30));
    d.chip=d.data.tag?chipW(d.data.tag)+6:0; d.w=Math.ceil(Math.max(...d.lines.map(l=>measure(l,d.fs,isRoot,d.depth===1))))+d.chip+(isRoot?30:22);
    d.lh=d.fs*1.38; d.h=d.lines.length*d.lh+(isRoot?20:(d.depth===1?16:13)); const b=d.ancestors().find(a=>a.depth===1); d.gi=b?gIdx.get(b.data.id):-1; });
  d3.tree().nodeSize([1,1]).separation((a,b)=>(a.h+b.h)/2+(a.parent===b.parent?10:26))(root);
  const maxW=[]; root.each(d=>{ maxW[d.depth]=Math.max(maxW[d.depth]||0,d.w); });
  const xs=[0]; for(let k=1;k<maxW.length;k++) xs[k]=xs[k-1]+maxW[k-1]+76;
  root.each(d=>{ const p=d.parent; d.ox=(p?p.ox:0)+(d.data.ox||0); d.oy=(p?p.oy:0)+(d.data.oy||0); d.px=xs[d.depth]+d.ox; d.py=d.x+d.oy; });
  cur=root; byId=new Map(root.descendants().map(d=>[d.data.id,d]));
  visOrder=[]; root.eachBefore(d=>visOrder.push(d));
  const activeId=(selectedId&&byId.has(selectedId))?selectedId:state.tree.id;
  const startPos=d=>{ let id=parentOf.get(d.data.id); while(id&&!prevPos.has(id)) id=parentOf.get(id); return id?prevPos.get(id):[d.px,d.py]; };
  const endPos=id=>{ let x=parentOf.get(id); while(x&&!byId.has(x)) x=parentOf.get(x); const n=x&&byId.get(x); return n?[n.px,n.py]:null; };

  const lsel=gLinks.selectAll('path').data(root.links(),l=>l.target.data.id);
  lsel.exit().transition().duration(dur).style('opacity',0).remove();
  const lent=lsel.enter().append('path').style('opacity',0).attr('d',l=>linkPath(l.source,l.target));
  lent.merge(lsel).attr('stroke',l=>colorVar(l.target.gi)).attr('stroke-width',l=>linkWidth(l.target)).transition().duration(dur).style('opacity',null).attr('d',l=>linkPath(l.source,l.target));

  const sel=gNodes.selectAll('g.node').data(root.descendants(),d=>d.data.id);
  sel.exit().transition().duration(dur).style('opacity',0).attr('transform',function(){ const p=endPos(this.__id); return p?`translate(${p[0]},${p[1]})`:this.getAttribute('transform'); }).remove();
  const ent=sel.enter().append('g').attr('class','node').attr('role','treeitem')
    .attr('transform',d=>{ const s=startPos(d); return `translate(${s[0]},${s[1]})`; }).style('opacity',0);
  ent.append('rect').attr('class','box'); ent.append('rect').attr('class','chip'); ent.append('text').attr('class','chipt').attr('text-anchor','middle').attr('aria-hidden','true');
  ent.append('text').attr('class','lbl').attr('aria-hidden','true'); ent.append('circle').attr('class','dot'); ent.append('text').attr('class','badge').attr('aria-hidden','true'); ent.append('title');
  ent.call(drag).on('click',onNodeClick).on('keydown',onNodeKey).on('focus',function(e,d){ const n=byId.get(d.data.id); ensureVisible(n); });
  const all=ent.merge(sel);
  all.each(function(d){
    this.__id=d.data.id;
    const g=d3.select(this), kids=(d.data.children||[]).length, isRoot=d.depth===0;
    const sibs=d.parent?d.parent.children:[d];
    const dim=!!filterTag&&!isRoot&&d.data.tag!==filterTag;
    const tg=d.data.tag, tl=tg&&TAG[tg]?TAG[tg].label:tg;
    g.style('--c',colorVar(d.gi)).classed('root',isRoot).classed('lv1',d.depth===1).classed('lv2',d.depth===2).classed('sel',d.data.id===selectedId)
     .classed('match',matches.has(d.data.id)).classed('collapsed',!!d.data._c&&kids>0).classed('dim',dim)
     .attr('tabindex',d.data.id===activeId?0:-1)
     .attr('aria-level',d.depth+1).attr('aria-setsize',sibs.length).attr('aria-posinset',sibs.indexOf(d)+1)
     .attr('aria-selected',String(d.data.id===selectedId))
     .attr('aria-expanded',kids?String(!d.data._c):null)
     .attr('aria-label',(tg?`[${tl}] `:'')+d.data.name+(kids&&d.data._c?`, ${countDesc(d.data)} ý đang ẩn`:''));
    g.select('title').text((tg?`[${tg}: ${tl}] `:'')+d.data.name+(d.data.note?`\n\n${d.data.note}`:''));
    g.select('.box').attr('x',10).attr('y',-d.h/2).attr('width',d.w).attr('height',d.h).attr('rx',isRoot?12:8);
    const cw=chipW(tg);
    g.select('.chip').attr('x',19).attr('y',-8).attr('width',cw).attr('height',16).attr('rx',4).style('fill',tg?tagColor(tg):null).attr('display',tg?null:'none');
    g.select('.chipt').attr('x',19+cw/2).attr('y',3.5).text(tg||'').attr('display',tg?null:'none');
    const lx=10+(isRoot?15:11)+d.chip, y0=-d.h/2+(isRoot?10:(d.depth===1?8:6.5))+d.fs*1.02;
    g.select('.lbl').selectAll('tspan').data(d.lines).join('tspan').attr('x',lx).attr('y',(l,i)=>y0+i*d.lh).text(l=>l);
    g.select('.dot').attr('r',kids?6:3.5).attr('display',isRoot?'none':null);
    g.select('.badge').attr('x',10+d.w+8).attr('y',4).text(d.data._c&&kids?`+${countDesc(d.data)}`:'');
  });
  all.transition().duration(dur).style('opacity',1).attr('transform',d=>`translate(${d.px},${d.py})`);
  prevPos=new Map(root.descendants().map(d=>[d.data.id,[d.px,d.py]]));
  drawFlows();
  updateStats();
  if(!linkFrom&&!dragState){ const s=selectedId&&dataById.get(selectedId); setHint(s?'sel':'idle',s&&s.name); }
}

function visibleNode(id){ let x=id; while(x&&!byId.has(x)) x=parentOf.get(x); return x?byId.get(x):null; }
function badgeW(d){ return (d.data._c&&(d.data.children||[]).length)?(String(countDesc(d.data)).length*7+16):0; }
function flowGeom(a,b){ const x1=a.px+12+a.w+badgeW(a), y1=a.py, x2=b.px+14+b.w+badgeW(b), y2=b.py; const cx=Math.max(x1,x2)+50+Math.min(160,Math.abs(y2-y1)*0.18);
  return {d:`M${x1},${y1}C${cx},${y1} ${cx},${y2} ${x2},${y2}`, lx:(x1+x2)*0.125+cx*0.75, ly:(y1+y2)/2}; }
function isReal(d){ return d.a.data.id===d.f.from&&d.b.data.id===d.f.to; }
function drawFlows(){
  const data=showFlows?state.flows.map(f=>{ const a=visibleNode(f.from), b=visibleNode(f.to); return a&&b&&a!==b?{f,a,b,g:flowGeom(a,b)}:null; }).filter(Boolean):[];
  const s=gFlows.selectAll('g.flow').data(data,d=>d.f.id);
  s.exit().remove();
  const e=s.enter().append('g').attr('class','flow'); e.append('path'); e.append('text').attr('class','flbl').attr('text-anchor','middle');
  const m=e.merge(s);
  m.attr('class',d=>`flow k-${d.f.kind||'cause'}${isReal(d)?'':' proxy'}`);
  m.select('path').attr('d',d=>d.g.d)
    .attr('marker-end',d=>!isReal(d)?null:(d.f.kind==='oppose'?'url(#mk-bar)':'url(#mk-arrow)'))
    .attr('marker-start',d=>isReal(d)&&d.f.kind==='mutual'?'url(#mk-arrow)':null);
  placeLabels(data);
  m.select('text').attr('x',d=>d.g.lx).attr('y',d=>d.g.ly+4).text(d=>isReal(d)?(d.f.label||''):'');
}
// Tránh nhãn luồng chồng nhau: đẩy nhãn xuống dần khi trùng chỗ
function placeLabels(data){ const placed=[];
  data.filter(d=>isReal(d)&&d.f.label).sort((a,b)=>a.g.ly-b.g.ly).forEach(d=>{ const w=String(d.f.label).length*5.6+8; let tries=0;
    while(tries<12&&placed.some(p=>Math.abs(p.x-d.g.lx)<(p.w+w)/2&&Math.abs(p.y-d.g.ly)<13)){ d.g.ly+=13; tries++; }
    placed.push({x:d.g.lx,y:d.g.ly,w}); }); }
function positionAll(){
  gNodes.selectAll('g.node').attr('transform',d=>`translate(${d.px},${d.py})`);
  gLinks.selectAll('path').attr('d',l=>linkPath(l.source,l.target));
  const fd=[]; gFlows.selectAll('g.flow').each(function(d){ d.g=flowGeom(d.a,d.b); fd.push(d); }); placeLabels(fd);
  gFlows.selectAll('g.flow').each(function(d){ const g=d3.select(this); g.select('path').attr('d',d.g.d); g.select('text').attr('x',d.g.lx).attr('y',d.g.ly+4); });
}

/* ---------- Zoom tự động (tắt hiệu ứng khi máy bật "giảm chuyển động") ---------- */
function viewSize(){ const el=svg.node(), W=el.clientWidth, H0=el.clientHeight; const cover=(mobileMQ.matches&&panel.classList.contains('open'))?panel.offsetHeight:0; return [W,Math.max(160,H0-cover)]; }
function zoomTo(list,maxScale=1.3){
  if(outlineMode) return; const [W,H]=viewSize(); if(!W||!H||!list.length) return;
  let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;
  list.forEach(n=>{ x0=Math.min(x0,n.px-14); x1=Math.max(x1,n.px+10+n.w+42); y0=Math.min(y0,n.py-n.h/2); y1=Math.max(y1,n.py+n.h/2); });
  const pad=28, s=Math.max(0.12,Math.min(maxScale,(W-pad*2)/(x1-x0),(H-pad*2)/(y1-y0)));
  const t=d3.zoomIdentity.translate(W/2-(x0+x1)/2*s,H/2-(y0+y1)/2*s).scale(s);
  svg.interrupt(); if(reduced()) svg.call(zoom.transform,t); else svg.transition().duration(650).ease(d3.easeCubicInOut).call(zoom.transform,t);
}
function ensureVisible(d){
  if(!d||outlineMode) return; const [W,H]=viewSize(); const t=d3.zoomTransform(svg.node());
  const sx0=t.applyX(d.px), sx1=t.applyX(d.px+10+d.w), sy=t.applyY(d.py), m=36;
  if(sx0>=m&&sx1<=W-m&&sy>=m&&sy<=H-m) return;
  const dx=(W/2-(sx0+sx1)/2)/t.k, dy=(H/2-sy)/t.k;
  svg.interrupt(); if(reduced()) svg.call(zoom.translateBy,dx,dy); else svg.transition().duration(300).call(zoom.translateBy,dx,dy);
}
function focusOn(n){ if(!n) return; const list=n.children?[n,...n.children]:[n].concat(n.parent?[n.parent]:[]); zoomTo(list, n.children?1.25:1.4); }
function fitAll(){ if(cur) zoomTo(cur.descendants(),1.1); }
function focusNode(id){ const el=gNodes.selectAll('g.node').filter(d=>d.data.id===id).node(); if(el) el.focus({preventScroll:true}); }

/* ---------- Chuột ---------- */
function onNodeClick(e,d){
  e.stopPropagation(); if(e.defaultPrevented) return;
  const id=d.data.id;
  if(linkFrom){
    if(linkFrom===id) toast('Chọn một ý khác làm đích');
    else if(state.flows.some(f=>(f.from===linkFrom&&f.to===id))) toast('Luồng này đã có');
    else { checkpoint(); const src=linkFrom; const f={id:'f'+(++fuid),from:src,to:id,label:'',kind:'cause'}; state.flows.push(f); cancelLink(true); selectedId=src; save(); render(); renderPanel(); focusFlowLabel(f.id); setHint('flow'); toast('Đã nối luồng · chọn loại quan hệ và gõ nhãn ở bảng chi tiết'); return; }
    cancelLink(true); selectedId=id; render(); renderPanel(); return;
  }
  selectedId=id;
  if((d.data.children||[]).length) d.data._c=!d.data._c;
  save(); render(); renderPanel(); focusOn(byId.get(id));
}
function selectNode(id){ selectedId=id; render({animate:false}); renderPanel(); focusNode(id); }

/* ---------- Bàn phím: mẫu cây WAI-ARIA + phím tắt sơ đồ tư duy ---------- */
function onNodeKey(e,d){
  if(e.ctrlKey||e.metaKey||e.altKey) return;
  const id=d.data.id, n=d.data, kids=(n.children||[]).length, isRoot=d.depth===0;
  const i=visOrder.findIndex(x=>x.data.id===id);
  const go=t=>{ if(t) selectNode(t.data.id); };
  const toggleTo=(open)=>{ n._c=!open; save(); selectedId=id; render(); renderPanel(); focusNode(id); focusOn(byId.get(id)); };
  switch(e.key){
    case 'ArrowDown': e.preventDefault(); go(visOrder[i+1]); break;
    case 'ArrowUp': e.preventDefault(); go(visOrder[i-1]); break;
    case 'Home': e.preventDefault(); go(visOrder[0]); break;
    case 'End': e.preventDefault(); go(visOrder[visOrder.length-1]); break;
    case 'ArrowRight': e.preventDefault(); if(kids&&n._c) toggleTo(true); else if(d.children) go(d.children[0]); break;
    case 'ArrowLeft': e.preventDefault(); if(kids&&!n._c&&!isRoot) toggleTo(false); else if(d.parent) go(d.parent); break;
    case '*': e.preventDefault(); (d.parent?d.parent.data.children:[n]).forEach(c=>{ c._c=false; }); save(); selectedId=id; render(); renderPanel(); focusNode(id); break;
    case ' ': e.preventDefault(); if(kids) toggleTo(!!n._c); else selectNode(id); break;
    case 'Enter': e.preventDefault(); if(isRoot) addChild(id); else addSibling(id); break;
    case 'Tab': if(e.shiftKey) return; e.preventDefault(); addChild(id); break;
    case 'F2': e.preventDefault(); selectedId=id; render({animate:false}); renderPanel(true); break;
    case 'Delete': case 'Backspace': if(isRoot) return; e.preventDefault(); askDelete(id); break;
  }
}

/* ---------- Kéo thả ---------- */
const drag=d3.drag().clickDistance(6)
  .subject((e,d)=>({x:d.px,y:d.py}))
  .on('start',function(e,d){ const sub=d.descendants(); dragState={d,sx:d.px,sy:d.py,sub,base:sub.map(n=>[n.px,n.py]),ids:new Set(sub.map(n=>n.data.id)),moved:false,target:null}; })
  .on('drag',function(e,d){
    const ds=dragState; if(!ds) return; const dx=e.x-ds.sx, dy=e.y-ds.sy;
    if(!ds.moved){ if(Math.hypot(dx,dy)<6) return; ds.moved=true; setHint('drag'); gNodes.selectAll('g.node').filter(n=>ds.ids.has(n.data.id)).raise().classed('dragging',true); }
    ds.sub.forEach((n,i)=>{ n.px=ds.base[i][0]+dx; n.py=ds.base[i][1]+dy; });
    let t=null; if(d.depth>0){ for(const n of cur.descendants()){ if(ds.ids.has(n.data.id)) continue; if(e.x>=n.px-10&&e.x<=n.px+10+n.w&&Math.abs(e.y-n.py)<=n.h/2+4){ t=n; break; } } }
    ds.target=t; gNodes.selectAll('g.node').classed('drop',n=>!!t&&n.data.id===t.data.id);
    positionAll();
  })
  .on('end',function(e,d){
    const ds=dragState; dragState=null; gNodes.selectAll('g.node').classed('drop',false).classed('dragging',false);
    if(!ds||!ds.moved) return;
    checkpoint();
    if(ds.target){
      const tid=ds.target.data.id, tname=ds.target.data.name;
      reparent(d.data.id,tid); d.data.ox=0; d.data.oy=0; selectedId=d.data.id; save(); render(); renderPanel();
      const tn=byId.get(tid); if(tn) zoomTo([tn,...(tn.children||[])],1.25); toast(`Đã chuyển nhánh vào «${short(tname,30)}» · Ctrl+Z để hoàn tác`);
    } else { d.data.ox=(d.data.ox||0)+(e.x-ds.sx); d.data.oy=(d.data.oy||0)+(e.y-ds.sy); save(); render({animate:false}); }
  });

/* ---------- Thao tác dữ liệu ---------- */
function isAncestor(a,b){ let x=b; while(x){ if(x===a) return true; x=parentOf.get(x); } return false; }
function reparent(id,targetId){
  index(); if(isAncestor(id,targetId)) return;
  const p=dataById.get(parentOf.get(id)), n=dataById.get(id), t=dataById.get(targetId); if(!p||!n||!t) return;
  p.children=p.children.filter(c=>c.id!==id); (t.children=t.children||[]).push(n); t._c=false;
}
function newNode(){ return N('Ý mới','',''); }
function afterAdd(n,anchorId){ selectedId=n.id; editKey='name:'+n.id; save(); render(); renderPanel(true); const pn=byId.get(anchorId); if(pn) zoomTo([pn,...(pn.children||[])],1.25); }
function addChild(pid){ index(); const p=dataById.get(pid); checkpoint(); const n=newNode(); (p.children=p.children||[]).push(n); p._c=false; afterAdd(n,pid); }
function addSibling(id){ index(); const p=dataById.get(parentOf.get(id)); if(!p) return addChild(id); checkpoint(); const n=newNode(); const i=p.children.findIndex(c=>c.id===id); p.children.splice(i+1,0,n); afterAdd(n,p.id); }
function removeNode(id){ index(); const p=dataById.get(parentOf.get(id)); if(!p) return; checkpoint(); const gone=new Set(); walk(dataById.get(id),n=>gone.add(n.id));
  const i=p.children.findIndex(c=>c.id===id); p.children=p.children.filter(c=>c.id!==id);
  state.flows=state.flows.filter(f=>!gone.has(f.from)&&!gone.has(f.to));
  selectedId=(p.children[i]||p.children[i-1]||p).id; save(); refresh(); if(!outlineMode){ focusNode(selectedId); focusOn(byId.get(p.id)); } toast('Đã xoá · Ctrl+Z để hoàn tác'); }
function askDelete(id){ index(); const n=dataById.get(id); if(!n) return; const k=(n.children||[]).length;
  if(!k){ removeNode(id); return; }
  confirmBox('Xoá nhánh này?',`«${short(n.name,60)}» cùng ${countDesc(n)} ý bên dưới sẽ bị xoá, kèm các luồng nối tới. Có thể hoàn tác bằng Ctrl+Z.`,'Xoá nhánh',()=>removeNode(id),()=>focusNode(id)); }
function focusBranch(id){ index(); let x=id; while(parentOf.get(x)){ const p=dataById.get(parentOf.get(x)); p._c=false; p.children.forEach(c=>{ if(c.id!==x&&(c.children||[]).length) c._c=true; }); x=p.id; }
  const n=dataById.get(id); n._c=false; save(); selectedId=id; render(); renderPanel(); focusOn(byId.get(id)); toast('Đang tập trung vào một nhánh · bấm “Mở hết” để xem lại toàn bộ'); }

/* ---------- Nối luồng ---------- */
function startLink(id){ linkFrom=id; $('linktext').textContent=`Bấm ý đích để nối luồng từ «${short(dataById.get(id).name,34)}»`; $('linkbar').hidden=false; setHint('link');
  if(mobileMQ.matches) panel.classList.remove('open'); }
function cancelLink(silent){ linkFrom=null; $('linkbar').hidden=true; setHint('idle'); if(!silent) renderPanel(); }
$('btn-cancel-link').onclick=()=>cancelLink();
function focusFlowLabel(fid){ const el=panel.querySelector(`input[data-flbl="${fid}"]`); if(el){ el.focus(); } }

/* ---------- Chú giải đường nối (dùng chung cho bảng và PDF) ---------- */
const LINE_LEGEND=[
  {key:'tree',label:'Quan hệ cha – con (nét liền, dày ở cấp 1, mảnh dần)'},
  {key:'cause',label:'Dẫn đến / nhân quả (nét đứt, mũi tên một đầu)'},
  {key:'mutual',label:'Tương hỗ / hai chiều (nét đứt, mũi tên hai đầu)'},
  {key:'oppose',label:'Đối lập / kìm hãm: mâu thuẫn, ức chế, cản trở (gạch – chấm, đầu chặn)'},
  {key:'proxy',label:'Luồng tạm gắn vào nhánh đang thu gọn (chấm mờ)'},
  {key:'sel',label:'Viền đậm: ý đang chọn · nền vàng: kết quả tìm'}
];
function lineSample(k){
  const W=46,H=14,y=7; const st='stroke:var(--flow);fill:none;stroke-width:1.6';
  if(k==='tree') return `<svg width="${W}" height="${H}" aria-hidden="true"><path d="M2,${y}H44" style="stroke:var(--g2);stroke-width:3;fill:none"/></svg>`;
  if(k==='cause') return `<svg width="${W}" height="${H}" aria-hidden="true"><path d="M2,${y}H36" style="${st};stroke-dasharray:6 4"/><path d="M36,2 L44,${y} L36,12z" style="fill:var(--flow)"/></svg>`;
  if(k==='mutual') return `<svg width="${W}" height="${H}" aria-hidden="true"><path d="M10,${y}H36" style="${st};stroke-dasharray:6 4"/><path d="M36,2 L44,${y} L36,12z" style="fill:var(--flow)"/><path d="M10,2 L2,${y} L10,12z" style="fill:var(--flow)"/></svg>`;
  if(k==='oppose') return `<svg width="${W}" height="${H}" aria-hidden="true"><path d="M2,${y}H41" style="${st};stroke-dasharray:10 3 2 3"/><rect x="41" y="1" width="3" height="12" style="fill:var(--flow)"/></svg>`;
  if(k==='proxy') return `<svg width="${W}" height="${H}" aria-hidden="true"><path d="M2,${y}H44" style="${st};stroke-dasharray:1.5 4;stroke-linecap:round;opacity:.5"/></svg>`;
  return `<svg width="${W}" height="${H}" aria-hidden="true"><rect x="2" y="1" width="20" height="12" rx="3" style="fill:var(--surface);stroke:var(--accent);stroke-width:3"/><rect x="25" y="1" width="19" height="12" rx="3" style="fill:var(--hl);stroke:var(--line)"/></svg>`;
}

/* ---------- Bảng chi tiết ---------- */
function helpHTML(){
  const groups=(state.tree.children||[]).map((c,i)=>`<button data-goto="${esc(c.id)}" style="--c:${colorVar(i)}"><span class="sw"></span>${esc(c.name)}</button>`).join('');
  const storeTxt=storeMode==='cloud'||storeMode==='saving'?(SHARED?'Đây là bản dùng chung: mọi người có quyền sửa cùng thấy và cùng sửa một bản. Người sửa sau cùng sẽ ghi đè.':'Thay đổi được lưu vào tài khoản của anh/chị, mở trên máy khác vẫn thấy. Mỗi người xem có bản riêng.'):'Thay đổi đang lưu trên trình duyệt này. Dùng <b>Xuất…</b> (JSON) để giữ bản sao hoặc chuyển sang máy khác.';
  return `${newerRev?`<div class="banner"><div><b>Tác giả đã cập nhật nội dung sơ đồ.</b> Bản đang mở là bản anh/chị đã chỉnh sửa từ nội dung cũ. Dùng bản mới sẽ thay toàn bộ chỉnh sửa (có thể hoàn tác).</div><div class="row"><button class="primary" id="btn-newrev">Dùng bản mới</button><button id="btn-keeprev">Giữ bản của tôi</button></div></div>`:''}
<h2>Cách dùng sơ đồ</h2>
<ul>
<li><b>Xem:</b> bấm một ý để mở hoặc thu nhánh; sơ đồ tự zoom vào vùng vừa mở. Lăn chuột hoặc chụm hai ngón để phóng to.</li>
<li><b>Thêm, sửa:</b> chọn ý rồi bấm <kbd>Tab</kbd> (ý con) hoặc <kbd>Enter</kbd> (cùng cấp), gõ tên, bấm <kbd>Enter</kbd>. Giải thích dài để vào ô Ghi chú.</li>
<li><b>Chuyển nhánh:</b> kéo một ý thả lên ý khác. Kéo ra chỗ trống để đặt vị trí; <b>Sắp xếp lại</b> trả về bố cục tự động.</li>
<li><b>Nối luồng:</b> chọn ý → <b>Nối luồng</b> → bấm ý đích → chọn loại quan hệ và gõ nhãn động từ.</li>
<li><b>Dàn ý:</b> xem và gõ cả sơ đồ dạng danh sách thụt lề; sửa ở đâu, bên kia đổi theo.</li>
<li><b>Xuất:</b> PDF (A4/A3, tự chia trang), ảnh PNG/SVG, Markdown, OPML, JSON.</li>
</ul>
${groups?`<h3>Các nhóm</h3><div class="legend">${groups}</div>`:''}
<h3>Đường nối</h3>
<div class="legend lines">${LINE_LEGEND.map(l=>`<div>${lineSample(l.key)}<span>${esc(l.label)}</span></div>`).join('')}</div>
${TAGS.length?`<h3>Nhãn</h3><div class="legend">${TAGS.map(t=>`<div>${tagChip(t.key)} ${esc(t.label)}</div>`).join('')}</div>`:''}
<h3>Phím tắt</h3>
<div class="keys">
<span><kbd>Tab</kbd></span><span>Thêm ý con</span>
<span><kbd>Enter</kbd></span><span>Thêm ý cùng cấp</span>
<span><kbd>F2</kbd></span><span>Sửa nội dung ý đang chọn</span>
<span><kbd>Delete</kbd></span><span>Xoá ý</span>
<span><kbd>Space</kbd></span><span>Mở / thu nhánh</span>
<span><kbd>↑</kbd> <kbd>↓</kbd></span><span>Sang ý trước / sau</span>
<span><kbd>→</kbd> <kbd>←</kbd></span><span>Mở hoặc vào ý con / thu hoặc về ý cha</span>
<span><kbd>Home</kbd> <kbd>End</kbd> <kbd>*</kbd></span><span>Ý đầu / ý cuối / mở mọi ý cùng cấp</span>
<span><kbd>Ctrl</kbd>+<kbd>Z</kbd></span><span>Hoàn tác (<kbd>Ctrl</kbd>+<kbd>Y</kbd> làm lại)</span>
</div>
<h3>Lưu thay đổi</h3>
<p class="empty">${storeTxt}</p>
${SOURCE?`<h3>Nguồn</h3><p class="empty">${esc(SOURCE)}</p>`:''}`;
}
function wireHelp(){
  panel.querySelectorAll('[data-goto]').forEach(b=>b.onclick=()=>{ index(); const id=b.dataset.goto; const n=dataById.get(id); if(!n) return; n._c=false; if(outlineMode) setOutline(false); selectedId=id; save(); render(); renderPanel(); focusOn(byId.get(id)); });
  const a=$('btn-newrev'); if(a) a.onclick=()=>{ checkpoint(); const s=seed(); state.tree=s.tree; state.flows=s.flows; state.baseRev=REV; newerRev=false; syncIds(); selectedId=null; save(); refresh(); fitAll(); toast('Đã dùng nội dung mới · Ctrl+Z để quay lại bản của anh/chị'); };
  const b=$('btn-keeprev'); if(b) b.onclick=()=>{ state.baseRev=REV; newerRev=false; save(); renderPanel(); };
}
function renderPanel(focusName){
  index();
  const n=selectedId&&dataById.get(selectedId);
  panel.classList.toggle('open',!!n);
  if(!n){ panel.innerHTML=helpHTML(); wireHelp(); return; }
  const path=[]; let x=n.id; while(x){ path.unshift(dataById.get(x)); x=parentOf.get(x); }
  const kids=(n.children||[]).length, isRoot=n.id===state.tree.id;
  const out=state.flows.filter(f=>f.from===n.id), inn=state.flows.filter(f=>f.to===n.id);
  const kindSel=f=>`<select data-fkind="${esc(f.id)}" aria-label="Loại quan hệ">${Object.entries(KINDS).map(([k,v])=>`<option value="${k}"${(f.kind||'cause')===k?' selected':''}>${esc(v.label)}</option>`).join('')}</select>`;
  const fl=(f,dir)=>{ const o=dataById.get(dir==='out'?f.to:f.from); const kd=KINDS[f.kind||'cause']; return o?`<li><div class="fl-top"><span>${dir==='out'?kd.out:kd.inn} <b>${esc(short(o.name,40))}</b></span><span style="display:flex;gap:4px"><button data-goto="${esc(o.id)}">Xem</button><button data-delflow="${esc(f.id)}" class="danger">Bỏ</button></span></div><div class="fl-row">${kindSel(f)}<input data-flbl="${esc(f.id)}" value="${esc(f.label||'')}" placeholder="Nhãn động từ, ví dụ “làm tăng”" aria-label="Nhãn của luồng"></div></li>`:''; };
  panel.innerHTML=`<button class="closer" id="btn-close">Đóng</button>
  <div class="crumb">${path.slice(0,-1).map(p=>esc(short(p.name,28))).join(' › ')}${path.length>1?' › ':''}<b>${esc(short(n.name,40))}</b></div>
  <div class="field"><label for="node-name">Nội dung ý</label><textarea id="node-name" rows="2">${esc(n.name)}</textarea><small>Cụm 2–5 từ là dễ đọc nhất · <kbd>Enter</kbd> xong, quay lại sơ đồ</small></div>
  ${TAGS.length?`<div class="field"><label for="node-tag">Nhãn</label><select id="node-tag">${TAGS.map(t=>`<option value="${esc(t.key)}"${n.tag===t.key?' selected':''}>${esc(t.key)} · ${esc(t.label)}</option>`).join('')}<option value=""${!n.tag?' selected':''}>Không gắn nhãn</option></select></div>`:''}
  <div class="field"><label for="node-note">Ghi chú, nguồn</label><textarea id="node-note" rows="4" placeholder="Giải thích, ví dụ, số liệu, nguồn tham khảo…">${esc(n.note||'')}</textarea></div>
  <div class="actions">
    <button id="act-toggle"${kids?'':' disabled'}>${kids?(n._c?`Mở nhánh (${kids})`:'Thu nhánh'):'Không có ý con'}</button>
    <button id="act-focus">Tập trung nhánh</button>
    <button id="act-child" class="primary">Thêm ý con</button>
    <button id="act-sib"${isRoot?' disabled':''}>Thêm cùng cấp</button>
    <button id="act-link">Nối luồng</button>
    <button id="act-del" class="danger"${isRoot?' disabled':''}>Xoá</button>
  </div>
  <h3>Luồng liên hệ</h3>
  ${out.length+inn.length?`<ul class="flowlist">${out.map(f=>fl(f,'out')).join('')}${inn.map(f=>fl(f,'in')).join('')}</ul>`:'<p class="empty">Chưa có luồng. Bấm “Nối luồng” rồi chọn ý đích ở nhánh khác.</p>'}
  <div class="tipbox">Gợi ý: nhãn luồng là một động từ ngắn để đọc thành câu, ví dụ «${esc(short(n.name,24))}» <i>làm tăng</i> «…». Nhiều hơn khoảng 5 luồng cho một sơ đồ cỡ vừa thường làm rối mắt.</div>`;
  const nameEl=$('node-name'), noteEl=$('node-note');
  const back=()=>{ endEdit(); if(outlineMode) return; render({animate:false}); focusNode(n.id); };
  nameEl.oninput=()=>{ beginEdit('name:'+n.id); n.name=nameEl.value.replace(/\n/g,' '); save(); if(outlineMode) renderOutline(); else render({animate:false}); setHint('edit'); };
  nameEl.onfocus=()=>setHint('edit');
  nameEl.onkeydown=e=>{ if((e.key==='Enter'&&!e.shiftKey)||e.key==='Escape'){ e.preventDefault(); back(); } };
  nameEl.onblur=endEdit;
  if($('node-tag')) $('node-tag').onchange=e=>{ checkpoint(); n.tag=e.target.value; save(); if(outlineMode) renderOutline(); else render({animate:false}); };
  noteEl.oninput=()=>{ beginEdit('note:'+n.id); n.note=noteEl.value; save(); };
  noteEl.onblur=endEdit;
  $('act-toggle').onclick=()=>{ n._c=!n._c; save(); refresh(); focusOn(byId.get(n.id)); };
  $('act-focus').onclick=()=>{ if(outlineMode) setOutline(false); focusBranch(n.id); };
  $('act-child').onclick=()=>addChild(n.id);
  $('act-sib').onclick=()=>addSibling(n.id);
  $('act-link').onclick=()=>{ if(outlineMode) setOutline(false); startLink(n.id); };
  $('act-del').onclick=()=>askDelete(n.id);
  $('btn-close').onclick=()=>{ selectedId=null; render({animate:false}); renderPanel(); };
  panel.querySelectorAll('[data-delflow]').forEach(b=>b.onclick=()=>{ checkpoint(); state.flows=state.flows.filter(f=>f.id!==b.dataset.delflow); save(); render({animate:false}); renderPanel(); });
  panel.querySelectorAll('[data-fkind]').forEach(s=>s.onchange=()=>{ const f=state.flows.find(x=>x.id===s.dataset.fkind); if(!f) return; checkpoint(); f.kind=s.value; save(); drawFlows(); renderPanel(); });
  panel.querySelectorAll('[data-flbl]').forEach(inp=>{ inp.oninput=()=>{ const f=state.flows.find(x=>x.id===inp.dataset.flbl); if(!f) return; beginEdit('flow:'+f.id); f.label=inp.value; save(); drawFlows(); }; inp.onblur=endEdit;
    inp.onfocus=()=>setHint('flow');
    inp.onkeydown=e=>{ if(e.key==='Enter'||e.key==='Escape'){ e.preventDefault(); back(); } }; });
  panel.querySelectorAll('[data-goto]').forEach(b=>b.onclick=()=>{ if(outlineMode) setOutline(false); revealId(b.dataset.goto); selectedId=b.dataset.goto; save(); render(); renderPanel(); focusOn(byId.get(selectedId)); });
  if(focusName){ nameEl.focus(); nameEl.select(); setHint('edit'); }
}
function revealId(id){ index(); let x=parentOf.get(id); while(x){ dataById.get(x)._c=false; x=parentOf.get(x); } }

/* ---------- Chế độ dàn ý (đồng bộ hai chiều) ---------- */
const outlineEl=$('outline');
function setOutline(on){
  outlineMode=on; const b=$('btn-outline'); b.setAttribute('aria-pressed',String(on)); b.textContent=on?'Sơ đồ':'Dàn ý';
  outlineEl.hidden=!on; $('map').style.display=on?'none':''; $('hint').hidden=on;
  ['btn-fit','btn-tidy'].forEach(i=>$(i).disabled=on);
  if(on){ renderOutline(selectedId); } else { render({animate:false}); if(selectedId&&byId.has(selectedId)){ focusOn(byId.get(selectedId)); } else fitAll(); }
}
function renderOutline(focusId,caretEnd=true){
  index();
  const rows=[]; const gIdx=new Map(); (state.tree.children||[]).forEach((c,i)=>gIdx.set(c.id,i));
  (function rec(n,lv,gi){ const k=(n.children||[]).length;
    rows.push(`<div class="ol-row lv${Math.min(lv,2)}" data-id="${esc(n.id)}" style="--lv:${lv};--c:${colorVar(gi)}" role="treeitem" aria-level="${lv+1}"${k?` aria-expanded="${!n._c}"`:''}>
      <button class="ol-tg" data-tg="${esc(n.id)}" tabindex="-1" aria-label="${k?(n._c?'Mở':'Thu'):'Không có ý con'}"${k?'':' disabled'}>${k?(n._c?'▶':'▼'):'•'}</button>
      ${tagChip(n.tag)}
      <span class="ol-txt" contenteditable="true" spellcheck="false" data-txt="${esc(n.id)}">${esc(n.name)}</span>
      ${k&&n._c?`<span class="empty" style="margin-top:3px">+${countDesc(n)}</span>`:''}
      <button class="ol-go" data-olgo="${esc(n.id)}" tabindex="-1" title="Xem trên sơ đồ">Sơ đồ ↗</button></div>`);
    if(!n._c) (n.children||[]).forEach(c=>rec(c,lv+1,lv===0?gIdx.get(c.id):gi)); })(state.tree,0,-1);
  outlineEl.innerHTML=`<p class="ol-intro"><b>Chế độ dàn ý.</b> Gõ thẳng vào từng dòng. <kbd>Enter</kbd> thêm dòng cùng cấp · <kbd>Tab</kbd> lùi vào thành ý con của dòng trên · <kbd>Shift</kbd>+<kbd>Tab</kbd> lùi ra · <kbd>↑</kbd><kbd>↓</kbd> chuyển dòng · <kbd>Backspace</kbd> trên dòng trống để xoá · <kbd>Ctrl</kbd>+<kbd>Z</kbd> hoàn tác. Bấm “Sơ đồ” để quay lại hình vẽ.</p><div class="ol-list" role="tree" aria-label="Dàn ý">${rows.join('')}</div>`;
  outlineEl.querySelectorAll('[data-tg]').forEach(b=>b.onclick=()=>{ const n=dataById.get(b.dataset.tg); n._c=!n._c; save(); renderOutline(n.id); });
  outlineEl.querySelectorAll('[data-olgo]').forEach(b=>b.onclick=()=>{ const id=b.dataset.olgo; revealId(id); selectedId=id; save(); setOutline(false); renderPanel(); });
  outlineEl.querySelectorAll('[data-txt]').forEach(el=>{
    const id=el.dataset.txt;
    el.addEventListener('focus',()=>{ if(selectedId!==id){ selectedId=id; renderPanel(); } });
    el.addEventListener('input',()=>{ const n=dataById.get(id); if(!n) return; beginEdit('ol:'+id); n.name=el.textContent.replace(/\n/g,' '); save();
      const pn=$('node-name'); if(pn&&selectedId===id) pn.value=n.name; });
    el.addEventListener('blur',endEdit);
    el.addEventListener('paste',e=>{ e.preventDefault(); const t=(e.clipboardData.getData('text/plain')||'').replace(/\s*\n\s*/g,' '); document.execCommand('insertText',false,t); });
    el.addEventListener('keydown',e=>olKey(e,id,el));
  });
  if(focusId) focusOutline(focusId,caretEnd);
}
function focusOutline(id,end=true){ const el=outlineEl.querySelector(`[data-txt="${CSS.escape(id)}"]`); if(!el) return; el.focus({preventScroll:false});
  const r=document.createRange(); r.selectNodeContents(el); r.collapse(!end); const s=getSelection(); s.removeAllRanges(); s.addRange(r); el.scrollIntoView({block:'nearest'}); }
function olKey(e,id,el){
  if(e.ctrlKey||e.metaKey||e.altKey) return;
  index(); const n=dataById.get(id), p=dataById.get(parentOf.get(id));
  const rows=[...outlineEl.querySelectorAll('[data-txt]')].map(x=>x.dataset.txt); const i=rows.indexOf(id);
  if(e.key==='Enter'){ e.preventDefault(); checkpoint(); const m=newNode(); m.name='';
    if(!p||(!n._c&&(n.children||[]).length)){ (n.children=n.children||[]).unshift(m); n._c=false; } else { const k=p.children.indexOf(n); p.children.splice(k+1,0,m); }
    selectedId=m.id; save(); renderOutline(m.id); renderPanel(); return; }
  if(e.key==='Tab'&&!e.shiftKey){ e.preventDefault(); if(!p) return; const k=p.children.indexOf(n); if(k<1){ toast('Không có dòng phía trên cùng cấp để lùi vào'); return; }
    checkpoint(); const prev=p.children[k-1]; p.children.splice(k,1); (prev.children=prev.children||[]).push(n); prev._c=false; save(); renderOutline(id); return; }
  if(e.key==='Tab'&&e.shiftKey){ e.preventDefault(); if(!p) return; const gp=dataById.get(parentOf.get(p.id)); if(!gp){ toast('Ý cấp 1 không lùi ra được nữa'); return; }
    checkpoint(); p.children=p.children.filter(c=>c.id!==id); const k=gp.children.indexOf(p); gp.children.splice(k+1,0,n); save(); renderOutline(id); return; }
  if(e.key==='Backspace'&&!el.textContent&&p&&!(n.children||[]).length){ e.preventDefault(); checkpoint(); p.children=p.children.filter(c=>c.id!==id);
    state.flows=state.flows.filter(f=>f.from!==id&&f.to!==id); const prevId=rows[i-1]; selectedId=prevId; save(); renderOutline(prevId); renderPanel(); return; }
  if(e.key==='ArrowUp'&&i>0){ e.preventDefault(); focusOutline(rows[i-1]); return; }
  if(e.key==='ArrowDown'&&i<rows.length-1){ e.preventDefault(); focusOutline(rows[i+1]); return; }
  if(e.key==='Escape'){ e.preventDefault(); el.blur(); }
}

/* ---------- Hộp thoại, thông báo ---------- */
function overlay(html){ const o=document.createElement('div'); o.className='overlay'; o.innerHTML=`<div class="dialog" role="dialog" aria-modal="true">${html}</div>`;
  o.addEventListener('click',e=>{ if(e.target===o) o.remove(); }); document.body.appendChild(o); return o; }
function confirmBox(title,text,okLabel,onOk,onCancel){ const o=overlay(`<h2>${esc(title)}</h2><p>${esc(text)}</p><div class="row"><button data-x>Huỷ</button><button class="primary" data-ok>${esc(okLabel)}</button></div>`);
  o.querySelector('[data-x]').onclick=()=>{ o.remove(); if(onCancel) onCancel(); }; o.querySelector('[data-ok]').onclick=()=>{ o.remove(); onOk(); }; o.querySelector('[data-ok]').focus(); }
let toastT; function toast(msg){ let t=document.querySelector('.toast'); if(!t){ t=document.createElement('div'); t.className='toast'; t.setAttribute('role','status'); document.body.appendChild(t); }
  t.textContent=msg; t.hidden=false; clearTimeout(toastT); toastT=setTimeout(()=>{ t.hidden=true; },2800); }
function updateStats(){ const n=countDesc(state.tree); $('stats').textContent=`${n} ý · ${state.flows.length} luồng`; }

/* ---------- Xuất: JSON, Markdown, OPML, SVG, PNG ---------- */
function slug(){ return MAP_ID; }
function toJSON(){ return JSON.stringify({ten:TITLE,engine:ENGINE_VERSION,rev:REV,tags:TAGS.map(t=>({key:t.key,label:t.label})),tree:state.tree,flows:state.flows},null,2); }
function toMarkdown(){
  index(); const L=[`# ${state.tree.name}`,''];
  if(state.tree.note) L.push(`> ${state.tree.note.replace(/\n+/g,' ')}`,'');
  const rec=(n,lv)=>{ const pad='  '.repeat(lv); L.push(`${pad}- ${n.tag?`[${n.tag}] `:''}${n.name}`); if(n.note) L.push(`${pad}  > ${n.note.replace(/\n+/g,' ')}`); (n.children||[]).forEach(k=>rec(k,lv+1)); };
  (state.tree.children||[]).forEach(c=>rec(c,0));
  if(state.flows.length){ L.push('','## Luồng liên hệ',''); state.flows.forEach(f=>{ const a=dataById.get(f.from), b=dataById.get(f.to); if(a&&b) L.push(`- ${a.name} ${f.kind==='mutual'?'↔':(f.kind==='oppose'?'⊣':'→')} ${b.name}${f.label?` : ${f.label}`:''}`); }); }
  return L.join('\n')+'\n';
}
function xmlEsc(s){ return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c])); }
function toOPML(){
  const out=[]; (function rec(n,lv){ const pad='  '.repeat(lv+2); const k=n.children||[];
    const attrs=`text="${xmlEsc(n.name)}"${n.note?` _note="${xmlEsc(n.note)}"`:''}${n.tag?` _tag="${xmlEsc(n.tag)}"`:''}`;
    if(k.length){ out.push(`${pad}<outline ${attrs}>`); k.forEach(c=>rec(c,lv+1)); out.push(`${pad}</outline>`); } else out.push(`${pad}<outline ${attrs}/>`); })(state.tree,0);
  return `<?xml version="1.0" encoding="UTF-8"?>\n<opml version="2.0">\n  <head><title>${xmlEsc(TITLE)}</title><dateCreated>${new Date().toUTCString()}</dateCreated></head>\n  <body>\n${out.join('\n')}\n  </body>\n</opml>\n`;
}
async function mapReady(){ if(!outlineMode) return; const m=$('map'); m.style.visibility='hidden'; m.style.position='absolute'; m.style.display=''; render({animate:false}); await new Promise(r=>setTimeout(r,80)); }
function mapDone(){ if(!outlineMode) return; const m=$('map'); m.style.display='none'; m.style.visibility=''; m.style.position=''; }
function buildSVG(){
  const nodes=cur.descendants(); let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;
  nodes.forEach(n=>{ x0=Math.min(x0,n.px); x1=Math.max(x1,n.px+10+n.w+40); y0=Math.min(y0,n.py-n.h/2); y1=Math.max(y1,n.py+n.h/2); });
  gFlows.selectAll('g.flow').each(function(){ const b=this.getBBox(); x1=Math.max(x1,b.x+b.width+8); y0=Math.min(y0,b.y-4); y1=Math.max(y1,b.y+b.height+4); });
  const pad=28, W=Math.ceil(x1-x0+pad*2), H=Math.ceil(y1-y0+pad*2);
  const src=svg.node(), clone=src.cloneNode(true);
  const a=src.querySelectorAll('*'), b=clone.querySelectorAll('*');
  const P=['fill','stroke','stroke-width','stroke-dasharray','stroke-linejoin','stroke-linecap','opacity','font-family','font-size','font-weight','font-style','letter-spacing','paint-order','display'];
  a.forEach((el,i)=>{ const dd=el.__data__;
    if(dd&&el.matches('g.node')) b[i].setAttribute('data-nid',dd.data.id);
    else if(dd&&el.parentNode===gLinks.node()){ b[i].setAttribute('data-lt',dd.target.data.id); b[i].setAttribute('data-ls',dd.source.data.id); }
    else if(dd&&el.matches('g.flow')){ b[i].setAttribute('data-fa',dd.a.data.id); b[i].setAttribute('data-fb',dd.b.data.id); }
    const cs=getComputedStyle(el); b[i].setAttribute('style',P.map(p=>`${p}:${cs.getPropertyValue(p)}`).join(';'));
    ['class','tabindex','role','aria-level','aria-setsize','aria-posinset','aria-selected','aria-expanded','aria-label','aria-hidden'].forEach(k=>b[i].removeAttribute(k)); });
  clone.removeAttribute('id'); clone.removeAttribute('aria-label'); clone.removeAttribute('style');
  clone.setAttribute('xmlns','http://www.w3.org/2000/svg'); clone.setAttribute('width',W); clone.setAttribute('height',H); clone.setAttribute('viewBox',`0 0 ${W} ${H}`);
  clone.children[1].setAttribute('transform',`translate(${pad-x0},${pad-y0})`);
  const bg=document.createElementNS('http://www.w3.org/2000/svg','rect'); bg.setAttribute('width',W); bg.setAttribute('height',H); bg.setAttribute('fill',getComputedStyle(document.body).backgroundColor);
  clone.insertBefore(bg,clone.firstChild);
  return {text:new XMLSerializer().serializeToString(clone),W,H,x0,y0,pad,el:clone};
}
function svgToPNG(s){ return new Promise((res,rej)=>{ const img=new Image(); const scale=Math.min(2,16000/Math.max(s.W,s.H));
  img.onload=()=>{ const c=document.createElement('canvas'); c.width=Math.round(s.W*scale); c.height=Math.round(s.H*scale); const g=c.getContext('2d'); g.scale(scale,scale); g.drawImage(img,0,0);
    try{ c.toBlob(bl=>bl?res(bl):rej(new Error('blob')),'image/png'); }catch(e){ rej(e); } };
  img.onerror=()=>rej(new Error('img')); img.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(s.text); }); }

/* ---------- Xuất PDF: tự tạo file PDF (không cần thư viện), tự chia trang theo nhánh khi chữ quá nhỏ ---------- */
const PAGES={a4:{w:841.89,h:595.28,name:'A4'},a3:{w:1190.55,h:841.89,name:'A3'}};
const PDF_DPI=200, MIN_PT=6.5, MAX_SC=1.15;
const LIGHT={ink:'#1B2320',muted:'#56625C',line:'#C3CABF',accent:'#2C3D84',flow:'#2C3D84',g:['#D55E00','#0072B2','#00966D','#B17A00','#B66C95','#428BB3','#5E6670'],t:['#2C7656','#9A5E16','#6A55A8','#A23B48','#2B5F8A','#5F6B2E']};
const SANS='"Be Vietnam Pro", system-ui, -apple-system, "Segoe UI", sans-serif', SERIF='Lora, Georgia, "Times New Roman", serif';
function loadSvgImage(text){ return new Promise((res,rej)=>{ const img=new Image(); img.onload=()=>res(img); img.onerror=()=>rej(new Error('img')); img.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(text); }); }
function buildSVGPrint(){ const r=document.documentElement, prev=r.getAttribute('data-theme'); r.setAttribute('data-theme','light'); r.style.setProperty('--bg','#FFFFFF');
  try{ return buildSVG(); } finally{ r.style.removeProperty('--bg'); if(prev===null) r.removeAttribute('data-theme'); else r.setAttribute('data-theme',prev); } }
function today(){ const d=new Date(); return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`; }
function subtreeBox(list){ let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;
  list.forEach(top=>top.descendants().forEach(n=>{ x0=Math.min(x0,n.px-16); x1=Math.max(x1,n.px+10+n.w+badgeW(n)+18); y0=Math.min(y0,n.py-n.h/2-8); y1=Math.max(y1,n.py+n.h/2+8); }));
  return {x0,y0,x1,y1,w:x1-x0,h:y1-y0}; }
function frame(size,portrait,full){ const pw=portrait?size.h:size.w, ph=portrait?size.w:size.h; const u=Math.min(pw,ph)/700, m=28*u;
  const head=full?118*u:52*u, foot=16*u; return {pw,ph,u,m,ax:m,ay:m+head,aw:pw-2*m,ah:ph-2*m-head-foot}; }
function bestFit(box,size,full){ let best=null;
  [false,true].forEach(pt=>{ const f=frame(size,pt,full); const sc=Math.min(f.aw/box.w,f.ah/box.h,MAX_SC); if(!best||sc>best.sc) best={sc,portrait:pt}; });
  return best; }
function pathOf(d){ return d.ancestors().reverse().slice(1).map(a=>a.data.name); }
function planPages(size,s){
  const root=cur, pages=[];
  const whole=s?{x0:s.x0-s.pad,y0:s.y0-s.pad,w:s.W,h:s.H}:subtreeBox([root]); const fw=bestFit(whole,size,true);
  if(fw.sc*12.5>=MIN_PT) return {single:true,pages:[{nodes:[root],box:whole,fit:fw,path:[],label:''}]};
  const fits=b=>{ const f=bestFit(b,size,false); return f.sc*12.5>=MIN_PT?f:null; };
  function plan(d){
    const self=subtreeBox([d]); const f=fits(self);
    if(f||!d.children){ pages.push({nodes:[d],box:self,fit:f||bestFit(self,size,false),path:pathOf(d),label:''}); return; }
    let group=[];
    const flush=()=>{ if(!group.length) return; const b=subtreeBox(group); const label=group.length>1?`${group[0].data.name} … ${group[group.length-1].data.name}`:'';
      pages.push({nodes:group,box:b,fit:bestFit(b,size,false),path:group.length>1?pathOf(d):pathOf(group[0]),label}); group=[]; };
    d.children.forEach(c=>{ const cb=subtreeBox([c]);
      if(!fits(cb)){ flush(); if(c.children) plan(c); else pages.push({nodes:[c],box:cb,fit:bestFit(cb,size,false),path:pathOf(c),label:''}); return; }
      if(group.length&&!fits(subtreeBox(group.concat([c])))) flush();
      group.push(c); });
    flush();
  }
  (root.children||[]).forEach(plan);
  return {single:false,pages};
}
function drawLineSample(g,k,x,y,u){ g.save(); g.strokeStyle=LIGHT.flow; g.fillStyle=LIGHT.flow; g.lineWidth=1.4*u; const L=26*u;
  if(k==='tree'){ g.strokeStyle=LIGHT.g[1]; g.lineWidth=2.6*u; g.beginPath(); g.moveTo(x,y); g.lineTo(x+L,y); g.stroke(); }
  else if(k==='proxy'){ g.globalAlpha=.5; g.setLineDash([1.5*u,4*u]); g.lineCap='round'; g.beginPath(); g.moveTo(x,y); g.lineTo(x+L,y); g.stroke(); }
  else { g.setLineDash(k==='oppose'?[8*u,2.5*u,1.6*u,2.5*u]:[5*u,3.5*u]); g.beginPath(); g.moveTo(x+(k==='mutual'?6*u:0),y); g.lineTo(x+L-6*u,y); g.stroke(); g.setLineDash([]);
    if(k==='oppose'){ g.fillRect(x+L-3*u,y-5*u,2.4*u,10*u); }
    else { g.beginPath(); g.moveTo(x+L-6*u,y-4*u); g.lineTo(x+L,y); g.lineTo(x+L-6*u,y+4*u); g.fill();
      if(k==='mutual'){ g.beginPath(); g.moveTo(x+6*u,y-4*u); g.lineTo(x,y); g.lineTo(x+6*u,y+4*u); g.fill(); } } }
  g.restore(); return L; }
function drawLegend(g,x0,y,maxX,u){
  let x=x0; const rowH=15*u; g.font=`500 ${8.6*u}px ${SANS}`; g.textBaseline='middle';
  const item=(w,draw)=>{ if(x+w>maxX){ x=x0; y+=rowH; } draw(x,y+rowH/2); x+=w+13*u; };
  (state.tree.children||[]).forEach((n,i)=>{ const col=LIGHT.g[i%7]; const tw=g.measureText(n.name).width;
    item(17*u+tw,(px,py)=>{ g.fillStyle=col+'24'; g.strokeStyle=col; g.lineWidth=1.5*u; g.beginPath(); g.roundRect(px,py-5*u,12*u,10*u,2.5*u); g.fill(); g.stroke(); g.fillStyle=LIGHT.ink; g.fillText(n.name,px+17*u,py); }); });
  TAGS.forEach(t=>{ g.font=`600 ${6.8*u}px ${SANS}`; const kw=Math.max(18*u,g.measureText(t.key).width+8*u); g.font=`500 ${8.6*u}px ${SANS}`; const tw=g.measureText(t.label).width;
    item(kw+5*u+tw,(px,py)=>{ g.fillStyle=LIGHT.t[t.i]; g.beginPath(); g.roundRect(px,py-6*u,kw,12*u,2.5*u); g.fill(); g.fillStyle='#FFFFFF'; g.font=`600 ${6.8*u}px ${SANS}`; g.textAlign='center'; g.fillText(t.key,px+kw/2,py+0.5*u); g.textAlign='left'; g.font=`500 ${8.6*u}px ${SANS}`; g.fillStyle=LIGHT.muted; g.fillText(t.label,px+kw+5*u,py); }); });
  x=x0; y+=rowH; const short2={tree:'Cha – con',cause:'Dẫn đến / nhân quả',mutual:'Tương hỗ / hai chiều',oppose:'Đối lập / kìm hãm',proxy:'Gắn tạm (nhánh đang thu)'};
  ['tree','cause','mutual','oppose','proxy'].forEach(k=>{ const tw=g.measureText(short2[k]).width; item(31*u+tw,(px,py)=>{ drawLineSample(g,k,px,py,u); g.fillStyle=LIGHT.muted; g.fillText(short2[k],px+31*u,py); }); });
  g.textBaseline='alphabetic'; return y+rowH;
}
function newCanvas(fr){ const k=PDF_DPI/72; const c=document.createElement('canvas'); c.width=Math.round(fr.pw*k); c.height=Math.round(fr.ph*k); const g=c.getContext('2d'); g.scale(k,k); g.fillStyle='#FFFFFF'; g.fillRect(0,0,fr.pw,fr.ph); return {c,g}; }
function drawFullHeader(g,fr){ const {u,m,pw}=fr; let y=m; const nIdeas=countDesc(state.tree);
  if(CFG.eyebrow){ g.fillStyle=LIGHT.accent; g.font=`500 ${8*u}px ${SANS}`; g.fillText(String(CFG.eyebrow).toUpperCase(),m,y+8*u); y+=13*u; }
  g.fillStyle=LIGHT.ink; g.font=`600 ${20*u}px ${SERIF}`; g.fillText(TITLE,m,y+19*u); y+=26*u;
  g.fillStyle=LIGHT.muted; g.font=`400 ${9*u}px ${SANS}`; g.fillText(`${state.tree.name} · ${nIdeas} ý · ${state.flows.length} luồng · xuất ngày ${today()}`,m,y+9*u); y+=15*u;
  y=drawLegend(g,m,y,pw-m,u)+4*u; g.strokeStyle=LIGHT.line; g.lineWidth=0.8*u; g.beginPath(); g.moveTo(m,y); g.lineTo(pw-m,y); g.stroke(); return y; }
function drawSmallHeader(g,fr,pg,gi){ const {u,m}=fr; let y=m;
  g.fillStyle=LIGHT.muted; g.font=`500 ${8*u}px ${SANS}`; g.fillText(TITLE.toUpperCase(),m,y+8*u); y+=12*u;
  const col=gi>=0?LIGHT.g[gi%7]:LIGHT.accent; g.fillStyle=col; g.fillRect(m,y+4*u,4*u,20*u);
  g.fillStyle=LIGHT.ink; g.font=`600 ${15*u}px ${SERIF}`; const p=pg.path.length?pg.path:[state.tree.name];
  const title=p[p.length-1]; g.fillText(title,m+10*u,y+18*u); y+=26*u;
  g.fillStyle=LIGHT.muted; g.font=`400 ${8.5*u}px ${SANS}`; const sub=(p.length>1?p.slice(0,-1).join(' › ')+' › '+title:'')+(pg.label?`  ·  gồm: ${pg.label}`:'');
  if(sub) g.fillText(sub.length>150?sub.slice(0,149)+'…':sub,m+10*u,y+4*u); }
function drawFooter(g,fr,n,total,size){ const {u,m,pw,ph}=fr; g.fillStyle=LIGHT.muted; g.font=`400 ${7.2*u}px ${SANS}`; g.textAlign='left';
  const src=SOURCE?`Nguồn: ${SOURCE}`:'Ảnh chụp phần sơ đồ đang mở.'; g.fillText(src.length>170?src.slice(0,169)+'…':src,m,ph-m+6*u);
  g.textAlign='right'; g.fillText(`Khổ ${size.name} · trang ${n}/${total}`,pw-m,ph-m+6*u); g.textAlign='left'; }
async function drawDiagram(g,s,box,fr,sc,ids){
  const el=s.el, ox=s.pad-s.x0, oy=s.pad-s.y0; const hidden=[];
  if(ids){ const hide=x=>{ x.setAttribute('visibility','hidden'); hidden.push(x); };
    el.querySelectorAll('[data-nid]').forEach(x=>{ if(!ids.has(x.getAttribute('data-nid'))) hide(x); });
    el.querySelectorAll('[data-lt]').forEach(x=>{ if(!ids.has(x.getAttribute('data-lt'))||!ids.has(x.getAttribute('data-ls'))) hide(x); });
    el.querySelectorAll('[data-fa]').forEach(x=>{ if(!ids.has(x.getAttribute('data-fa'))||!ids.has(x.getAttribute('data-fb'))) hide(x); }); }
  el.setAttribute('viewBox',`${box.x0+ox} ${box.y0+oy} ${box.w} ${box.h}`); el.setAttribute('width',Math.ceil(box.w)); el.setAttribute('height',Math.ceil(box.h));
  const txt=new XMLSerializer().serializeToString(el); hidden.forEach(x=>x.removeAttribute('visibility'));
  const img=await loadSvgImage(txt);
  const dw=box.w*sc, dh=box.h*sc; g.drawImage(img,fr.ax+(fr.aw-dw)/2,fr.ay+(fr.ah-dh)/2,dw,dh);
}
async function encodeCanvas(c){
  const w=c.width, h=c.height;
  if(typeof CompressionStream!=='undefined'){
    const px=c.getContext('2d').getImageData(0,0,w,h).data; const rgb=new Uint8Array(w*h*3);
    for(let i=0,j=0;i<px.length;i+=4){ rgb[j++]=px[i]; rgb[j++]=px[i+1]; rgb[j++]=px[i+2]; }
    const st=new Blob([rgb]).stream().pipeThrough(new CompressionStream('deflate'));
    return {w,h,filter:'/FlateDecode',data:new Uint8Array(await new Response(st).arrayBuffer())};
  }
  const bl=await new Promise(r=>c.toBlob(r,'image/jpeg',0.92)); if(!bl) throw new Error('jpeg');
  return {w,h,filter:'/DCTDecode',data:new Uint8Array(await bl.arrayBuffer())};
}
function pdfHex(s){ let o='FEFF'; for(const ch of s){ const cp=ch.codePointAt(0);
  if(cp>0xffff){ const v=cp-0x10000; o+=(0xD800+(v>>10)).toString(16).padStart(4,'0')+(0xDC00+(v&0x3ff)).toString(16).padStart(4,'0'); } else o+=cp.toString(16).padStart(4,'0'); }
  return '<'+o.toUpperCase()+'>'; }
function buildPDF(pages){
  const enc=new TextEncoder(), parts=[], offs=[]; let len=0;
  const add=x=>{ const b=typeof x==='string'?enc.encode(x):x; parts.push(b); len+=b.length; };
  const obj=(n,body)=>{ offs[n]=len; add(`${n} 0 obj\n`); body(); add('\nendobj\n'); };
  const f=v=>(+v).toFixed(2), d=new Date(), p2=v=>String(v).padStart(2,'0');
  const N=pages.length, info=3+N*3;
  add('%PDF-1.4\n'); add(new Uint8Array([37,226,227,207,211,10]));
  obj(1,()=>add('<< /Type /Catalog /Pages 2 0 R /PageLayout /SinglePage >>'));
  obj(2,()=>add(`<< /Type /Pages /Kids [${pages.map((_,i)=>`${3+i*3} 0 R`).join(' ')}] /Count ${N} >>`));
  pages.forEach((p,i)=>{ const po=3+i*3, io=po+1, co=po+2;
    obj(po,()=>add(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${f(p.pw)} ${f(p.ph)}] /Resources << /XObject << /Im${i+1} ${io} 0 R >> >> /Contents ${co} 0 R >>`));
    obj(io,()=>{ add(`<< /Type /XObject /Subtype /Image /Width ${p.img.w} /Height ${p.img.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter ${p.img.filter} /Length ${p.img.data.length} >>\nstream\n`); add(p.img.data); add('\nendstream'); });
    const content=`q ${f(p.pw)} 0 0 ${f(p.ph)} 0 0 cm /Im${i+1} Do Q`;
    obj(co,()=>add(`<< /Length ${content.length} >>\nstream\n${content}\nendstream`)); });
  obj(info,()=>add(`<< /Title ${pdfHex(TITLE)} /Subject ${pdfHex(state.tree.name||TITLE)} /Creator ${pdfHex('Sơ đồ tư duy tương tác')} /CreationDate (D:${d.getFullYear()}${p2(d.getMonth()+1)}${p2(d.getDate())}${p2(d.getHours())}${p2(d.getMinutes())}${p2(d.getSeconds())}) >>`));
  const xref=len, size=info+1; let x=`xref\n0 ${size}\n0000000000 65535 f \n`;
  for(let n=1;n<size;n++) x+=String(offs[n]).padStart(10,'0')+' 00000 n \n';
  add(`${x}trailer\n<< /Size ${size} /Root 1 0 R /Info ${info} 0 R >>\nstartxref\n${xref}\n%%EOF\n`);
  return new Blob(parts,{type:'application/pdf'});
}
let pdfBusy=false;
async function exportPDF(key){
  if(pdfBusy) return; pdfBusy=true; const size=PAGES[key];
  try{
    await mapReady(); const s=buildSVGPrint(); const plan=planPages(size,s); const out=[]; let preview=null;
    const total=plan.single?1:plan.pages.length+1;
    toast(`Đang tạo PDF khổ ${size.name} (${total} trang)…`);
    if(plan.single){
      const pg=plan.pages[0], fr=frame(size,pg.fit.portrait,true); const {c,g}=newCanvas(fr);
      drawFullHeader(g,fr); await drawDiagram(g,s,pg.box,fr,pg.fit.sc); drawFooter(g,fr,1,1,size);
      preview=c.toDataURL('image/png'); out.push({img:await encodeCanvas(c),pw:fr.pw,ph:fr.ph});
    } else {
      const fr=frame(size,true,true); const {c,g}=newCanvas(fr); let y=drawFullHeader(g,fr)+18*fr.u; const {u,m}=fr;
      g.fillStyle=LIGHT.ink; g.font=`600 ${12*u}px ${SERIF}`; g.fillText('Mục lục',m,y); y+=8*u;
      g.font=`400 ${8.6*u}px ${SANS}`; g.fillStyle=LIGHT.muted;
      g.fillText('Sơ đồ đang mở quá lớn để in trên một trang, nên được chia theo nhánh để chữ đủ to để đọc.',m,y+10*u);
      g.fillText('Luồng liên hệ nối hai trang khác nhau chỉ hiện khi xem sơ đồ trên màn hình.',m,y+22*u); y+=34*u;
      const lineH=14*u, colW=(fr.pw-2*m-16*u)/2; let col=0, yy=y;
      plan.pages.forEach((pg,i)=>{ if(yy>fr.ph-m-30*u){ col++; yy=y; } if(col>1) return;
        const x=m+col*(colW+16*u), gi=groupIndex(pg.nodes[0].data.id); g.fillStyle=gi>=0?LIGHT.g[gi%7]:LIGHT.accent; g.fillRect(x,yy-7*u,3*u,9*u);
        g.fillStyle=LIGHT.ink; g.font=`500 ${8.6*u}px ${SANS}`; const full=(pg.path.length?pg.path.join(' › '):state.tree.name)+(pg.label?` (${pg.label})`:''); let name=full;
        while(g.measureText(name).width>colW-40*u&&name.length>8) name=name.slice(0,-2); if(name!==full) name+='…';
        g.fillText(name,x+8*u,yy); g.textAlign='right'; g.fillStyle=LIGHT.muted; g.fillText(String(i+2),x+colW,yy); g.textAlign='left'; yy+=lineH; });
      drawFooter(g,fr,1,total,size); preview=c.toDataURL('image/png'); out.push({img:await encodeCanvas(c),pw:fr.pw,ph:fr.ph});
      for(let i=0;i<plan.pages.length;i++){ const pg=plan.pages[i]; const f2=frame(size,pg.fit.portrait,false); const cv=newCanvas(f2);
        drawSmallHeader(cv.g,f2,pg,groupIndex(pg.nodes[0].data.id)); await drawDiagram(cv.g,s,pg.box,f2,pg.fit.sc,new Set(pg.nodes.flatMap(n=>n.descendants().map(x=>x.data.id)))); drawFooter(cv.g,f2,i+2,total,size);
        out.push({img:await encodeCanvas(cv.c),pw:f2.pw,ph:f2.ph}); }
    }
    const pdf=buildPDF(out); const name=`${slug()}-${size.name}.pdf`;
    offer(name,pdf,()=>{ const o=overlay(`<h2>PDF khổ ${size.name}</h2><p>Trang này chưa được phép tải file. Đây là bản xem trước trang 1; nhấn giữ hoặc bấm chuột phải để lưu ảnh, hoặc dùng “Ảnh PNG”.</p><img alt="Bản xem trước PDF"><div class="row"><button data-x>Đóng</button></div>`);
      o.querySelector('img').src=preview; o.querySelector('[data-x]').onclick=()=>o.remove(); }, `Đã lưu ${name} (${total} trang)`);
  }catch(e){ toast('Không tạo được PDF; hãy thử xuất ảnh PNG'); }
  finally{ pdfBusy=false; mapDone(); }
}
async function offer(filename,data,fallback,okMsg){
  if(dl){ try{ await dl.save({filename,data}); toast(okMsg||('Đã lưu '+filename)); return; }
    catch(e){ const c=e&&e.code; if(c==='declined'){ toast('Đã huỷ lưu file'); return; } if(c==='rate_limited'){ toast('Đang có một hộp lưu file mở, thử lại sau giây lát'); return; } } }
  fallback();
}
function textFallback(title,txt,note){ const o=overlay(`<h2>${esc(title)}</h2><p>${note||'Trang này chưa được phép tải file. Sao chép nội dung dưới đây và lưu lại.'}</p><textarea readonly></textarea><div class="row"><button data-copy>Sao chép</button><button data-x>Đóng</button></div>`);
  const ta=o.querySelector('textarea'); ta.value=txt; ta.focus(); ta.select();
  o.querySelector('[data-copy]').onclick=()=>{ try{ navigator.clipboard.writeText(txt).then(()=>toast('Đã sao chép'),()=>{ ta.select(); toast('Hãy bấm Ctrl/Cmd+C'); }); }catch(err){ ta.select(); } };
  o.querySelector('[data-x]').onclick=()=>o.remove(); }
function imageFallback(title,url){ const o=overlay(`<h2>${esc(title)}</h2><p>Trang này chưa được phép tải file. Nhấn giữ hoặc bấm chuột phải vào ảnh để lưu.</p><img alt="Ảnh sơ đồ"><div class="row"><button data-x>Đóng</button></div>`);
  o.querySelector('img').src=url; o.querySelector('[data-x]').onclick=()=>o.remove(); }
$('btn-export').onclick=()=>{
  const o=overlay(`<h2>Xuất sơ đồ</h2><p>PDF và ảnh chụp phần sơ đồ đang mở (mở ít nhánh hơn thì chữ to hơn); PDF luôn dùng nền sáng để in. JSON giữ đầy đủ dữ liệu để nhập lại; Markdown và OPML mở được trong Xmind, MindNode, MindMeister, Markmap.</p>
  <div class="grid">
    <button data-f="pdf-a4"><b>PDF khổ A4</b><small>In, gửi email; tự chia trang khi chữ quá nhỏ</small></button>
    <button data-f="pdf-a3"><b>PDF khổ A3</b><small>Trang lớn, ít phải chia trang hơn</small></button>
    <button data-f="png"><b>Ảnh PNG</b><small>Chèn vào báo cáo, slide</small></button>
    <button data-f="svg"><b>Ảnh SVG</b><small>Phóng to không vỡ nét</small></button>
    <button data-f="md"><b>Markdown</b><small>Dàn ý thụt lề + luồng</small></button>
    <button data-f="opml"><b>OPML</b><small>Lưu dạng .opml.txt, bỏ đuôi .txt khi mở</small></button>
    <button data-f="json"><b>JSON</b><small>Sao lưu đầy đủ, nhập lại được</small></button>
  </div><div class="row"><button data-x>Đóng</button></div>`);
  o.querySelector('[data-x]').onclick=()=>o.remove();
  o.querySelectorAll('[data-f]').forEach(b=>b.onclick=async()=>{ const f=b.dataset.f; o.remove();
    if(f==='pdf-a4') exportPDF('a4');
    if(f==='pdf-a3') exportPDF('a3');
    if(f==='json') offer(slug()+'.json',toJSON(),()=>textFallback('Xuất JSON',toJSON()));
    if(f==='md') offer(slug()+'.md',toMarkdown(),()=>textFallback('Xuất Markdown',toMarkdown()));
    if(f==='opml') offer(slug()+'.opml.txt',toOPML(),()=>textFallback('Xuất OPML',toOPML(),'Sao chép nội dung, lưu thành tệp có đuôi .opml rồi mở trong Xmind, MindNode hoặc MindMeister.'));
    if(f==='svg'){ await mapReady(); const s=buildSVG(); mapDone(); offer(slug()+'.svg',s.text,()=>imageFallback('Ảnh SVG','data:image/svg+xml;charset=utf-8,'+encodeURIComponent(s.text))); }
    if(f==='png'){ await mapReady(); const s=buildSVG(); mapDone(); try{ const bl=await svgToPNG(s); offer(slug()+'.png',bl,()=>imageFallback('Ảnh PNG',URL.createObjectURL(bl))); }catch(e){ toast('Không tạo được ảnh PNG; hãy thử SVG'); } }
  });
};

/* ---------- Nhập: JSON, Markdown, OPML ---------- */
function parseMarkdown(txt){
  const lines=txt.replace(/\r/g,'').split('\n'); let root=null; const stack=[]; let last=null; let headLv=0; let inFlows=false; const flowLines=[];
  const keys=TAGS.map(t=>t.key.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|'); const tagRe=keys?new RegExp('^\\[('+keys+')\\]\\s*'):null;
  const mk=s=>{ let tag=''; const m=tagRe&&s.match(tagRe); if(m){ tag=m[1]; s=s.slice(m[0].length); } return {id:'n'+(++uid),name:s.trim(),tag,note:'',children:[]}; };
  const attach=(node,lv)=>{ while(stack.length&&stack[stack.length-1].lv>=lv) stack.pop(); const par=stack.length?stack[stack.length-1].n:null;
    if(!par){ if(!root){ root=node; } else root.children.push(node); } else par.children.push(node); stack.push({n:node,lv}); last=node; };
  for(const raw of lines){
    if(!raw.trim()) continue;
    const h=raw.match(/^(#{1,6})\s+(.*)$/);
    if(h&&/^luồng liên hệ$/i.test(h[2].trim())){ inFlows=true; continue; }
    if(inFlows){ const f=raw.match(/^\s*[-*]\s+(.+?)\s*(→|↔|⊣)\s*(.+?)(?:\s*:\s*(.+))?$/); if(f) flowLines.push(f); continue; }
    if(h){ headLv=h[1].length; attach(mk(h[2]),headLv*100); continue; }
    const q=raw.match(/^\s*>\s?(.*)$/); if(q){ if(last) last.note=(last.note?last.note+' ':'')+q[1].trim(); continue; }
    const li=raw.match(/^(\s*)(?:[-*+]|\d+[.)])\s+(.*)$/);
    if(li){ const ind=li[1].replace(/\t/g,'  ').length; attach(mk(li[2]),headLv*100+1+Math.floor(ind/2)); continue; }
    if(last) last.note=(last.note?last.note+' ':'')+raw.trim();
  }
  if(!root) return null;
  if(!root.name) root.name=TITLE;
  const byName=new Map(); walk(root,n=>{ if(!byName.has(n.name)) byName.set(n.name,n.id); });
  const flows=[]; flowLines.forEach(f=>{ const a=byName.get(f[1].trim()), b=byName.get(f[3].trim()); if(a&&b) flows.push({id:'f'+(++fuid),from:a,to:b,label:(f[4]||'').trim(),kind:f[2]==='↔'?'mutual':(f[2]==='⊣'?'oppose':'cause')}); });
  return {tree:root,flows};
}
function parseOPML(txt){
  const doc=new DOMParser().parseFromString(txt,'text/xml'); if(doc.querySelector('parsererror')) return null;
  const body=doc.querySelector('body'); if(!body) return null;
  const conv=el=>{ const n={id:'n'+(++uid),name:el.getAttribute('text')||el.getAttribute('title')||'',tag:el.getAttribute('_tag')||'',note:el.getAttribute('_note')||'',children:[]};
    [...el.children].filter(c=>c.tagName==='outline').forEach(c=>n.children.push(conv(c))); return n; };
  const tops=[...body.children].filter(c=>c.tagName==='outline'); if(!tops.length) return null;
  const tree=tops.length===1?conv(tops[0]):{id:'n'+(++uid),name:(doc.querySelector('head>title')||{}).textContent||TITLE,tag:'',note:'',children:tops.map(conv)};
  return {tree,flows:[]};
}
function parseAny(txt){ const t=txt.trim(); if(!t) return null;
  if(t[0]==='{'){ const o=JSON.parse(t); if(!o.tree) throw new Error('json'); return {tree:o.tree,flows:o.flows||[]}; }
  if(t[0]==='<') return parseOPML(t);
  return parseMarkdown(t); }
function applyImported(obj,how){
  checkpoint();
  if(how==='replace'){ state.tree=obj.tree; state.flows=obj.flows; }
  else { index(); const target=dataById.get(selectedId)||state.tree; (target.children=target.children||[]).push(obj.tree); target._c=false; state.flows=state.flows.concat(obj.flows); }
  normalize(state); syncIds(); ensureUniqueIds(); walk(state.tree,(n,p)=>{ if(p&&p.id!==state.tree.id&&(n.children||[]).length&&n._c===undefined) n._c=true; });
  selectedId=null; matches=new Set(); save(); refresh(); if(!outlineMode) fitAll(); toast(how==='replace'?'Đã nhập sơ đồ · Ctrl+Z để hoàn tác':'Đã thêm vào sơ đồ · Ctrl+Z để hoàn tác');
}
$('btn-import').onclick=()=>{
  index(); const tgt=dataById.get(selectedId);
  const o=overlay(`<h2>Nhập dàn ý hoặc sơ đồ</h2><p>Dán JSON đã xuất, dàn ý Markdown (gạch đầu dòng thụt lề${TAGS.length?`; ghi ${TAGS.map(t=>'['+esc(t.key)+']').join(', ')} đầu dòng để gắn nhãn`:''}) hoặc OPML từ Xmind, MindNode. Hoặc chọn tệp .json, .md, .opml, .txt.</p>
  <input type="file" accept=".json,.md,.markdown,.opml,.xml,.txt" aria-label="Chọn tệp để nhập">
  <textarea placeholder="# Chủ đề&#10;- Nhánh 1&#10;  - Ý con&#10;- Nhánh 2"></textarea><p id="imp-err" hidden></p>
  <div class="row"><button data-x>Huỷ</button><button data-add>Thêm vào «${esc(short(tgt?tgt.name:state.tree.name,26))}»</button><button class="primary" data-rep>Thay toàn bộ sơ đồ</button></div>`);
  const ta=o.querySelector('textarea'), err=o.querySelector('#imp-err');
  o.querySelector('input[type=file]').onchange=e=>{ const f=e.target.files[0]; if(!f) return; const r=new FileReader(); r.onload=()=>{ ta.value=String(r.result); }; r.readAsText(f); };
  o.querySelector('[data-x]').onclick=()=>o.remove();
  const go=how=>{ let obj=null; try{ obj=parseAny(ta.value); }catch(e){ obj=null; }
    if(!obj){ err.hidden=false; err.textContent='Không đọc được nội dung. Kiểm tra lại định dạng JSON, Markdown hoặc OPML.'; return; }
    o.remove(); if(how==='replace') confirmBox('Thay toàn bộ sơ đồ?','Sơ đồ hiện tại sẽ được thay bằng nội dung vừa nhập. Có thể hoàn tác bằng Ctrl+Z.','Thay sơ đồ',()=>applyImported(obj,'replace')); else applyImported(obj,'add'); };
  o.querySelector('[data-rep]').onclick=()=>go('replace'); o.querySelector('[data-add]').onclick=()=>go('add');
  ta.focus();
};

/* ---------- Thanh công cụ ---------- */
let qT; $('q').addEventListener('input',e=>{ clearTimeout(qT); qT=setTimeout(()=>doSearch(e.target.value),180); });
function doSearch(q){ matches=new Set(); const k=norm(q.trim()); const qc=$('qcount');
  if(!k){ qc.textContent=''; refresh(); return; }
  walk(state.tree,n=>{ if(norm(n.name).includes(k)||norm(n.note||'').includes(k)) matches.add(n.id); });
  matches.forEach(id=>revealId(id)); qc.textContent=matches.size?`${matches.size}`:'0';
  save(); if(outlineMode){ renderOutline(); outlineEl.querySelectorAll('[data-txt]').forEach(el=>{ if(matches.has(el.dataset.txt)) el.style.background='var(--hl)'; }); return; }
  render(); const list=[...matches].map(id=>byId.get(id)).filter(Boolean); if(list.length) zoomTo(list,1.3); }
if($('filter')) $('filter').onchange=e=>{ filterTag=e.target.value; if(filterTag){ walk(state.tree,n=>{ if(n.tag===filterTag) revealId(n.id); }); save(); } refresh(); if(!outlineMode) fitAll(); };
$('btn-expand').onclick=()=>{ walk(state.tree,n=>{ n._c=false; }); save(); refresh(); fitAll(); };
$('btn-collapse').onclick=()=>{ walk(state.tree,(n,p)=>{ if(p&&(n.children||[]).length) n._c=true; }); state.tree._c=false; save(); refresh(); setTimeout(fitAll,0); };
$('btn-fit').onclick=fitAll;
$('btn-tidy').onclick=()=>{ checkpoint(); walk(state.tree,n=>{ delete n.ox; delete n.oy; }); save(); render(); fitAll(); toast('Đã trả về bố cục tự động'); };
$('chk-flows').onchange=e=>{ showFlows=e.target.checked; drawFlows(); };
$('btn-undo').onclick=undo;
$('btn-redo').onclick=redo;
$('btn-outline').onclick=()=>setOutline(!outlineMode);
$('btn-reset').onclick=()=>confirmBox('Khôi phục sơ đồ gốc?','Mọi ý, luồng và vị trí đã thêm hoặc sửa sẽ được thay bằng nội dung gốc của tác giả. Có thể hoàn tác bằng Ctrl+Z.','Khôi phục',()=>{
  checkpoint(); const s=seed(); state.tree=s.tree; state.flows=s.flows; state.baseRev=REV; newerRev=false; syncIds(); selectedId=null; matches=new Set(); linkFrom=null; $('q').value=''; $('qcount').textContent=''; save(); refresh(); fitAll(); toast('Đã khôi phục sơ đồ gốc · Ctrl+Z để hoàn tác'); });
document.addEventListener('keydown',e=>{
  const t=e.target, inField=!!(t.closest&&t.closest('textarea,input,select')), inOutline=!!(t.classList&&t.classList.contains('ol-txt'));
  if((e.ctrlKey||e.metaKey)&&!e.altKey&&!inField){ const k=e.key.toLowerCase();
    if(k==='z'){ e.preventDefault(); if(e.shiftKey) redo(); else undo(); if(inOutline&&selectedId) focusOutline(selectedId); return; }
    if(k==='y'){ e.preventDefault(); redo(); if(inOutline&&selectedId) focusOutline(selectedId); return; } }
  if(e.key==='Escape'){ const o=document.querySelector('.overlay'); if(o){ o.remove(); return; } if(linkFrom){ cancelLink(); return; } }
});
mobileMQ.addEventListener&&mobileMQ.addEventListener('change',()=>setHint(hintKey));

/* ---------- Khởi động ---------- */
function start(){ render({animate:false}); renderPanel(); fitAll(); updUndo(); initRemote(); initDownloads(); }
(document.fonts&&document.fonts.ready?document.fonts.ready:Promise.resolve()).then(start,start);
})();
