/* Khuôn sơ đồ tư duy kiểu K01 – k01.js (skill so-do-tu-duy)
   Đọc dữ liệu từ <script type="application/json" id="sodo-data">. Nhiều tab: sơ đồ tư duy (nhánh xen kẽ hai bên,
   hoặc bậc thang) và ma trận trên hệ trục toạ độ. Menu Chú giải / Chỉnh sửa thu gọn; đường liên kết 3 loại.
   Quyền sửa: Artifact – chỉ chủ sơ đồ, lưu bản chung (db); File HTML – ai mở cũng sửa, lưu trên trình duyệt. */
(function () {
'use strict';
const ENGINE = 'k01-1.0';
let CFG = null;
try { CFG = JSON.parse(document.getElementById('sodo-data').textContent); } catch (e) {}
const host = document.getElementById('sodo-app');
if (!host) return;
if (!CFG || !Array.isArray(CFG.tabs) || !CFG.tabs.length) { host.innerHTML = '<p style="padding:24px">Không đọc được dữ liệu sơ đồ (thẻ sodo-data).</p>'; return; }
const MODE = window.K01_MODE === 'html' ? 'html' : 'artifact';
const RM = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const MAP_ID = String(CFG.id || 'so-do').replace(/[^A-Za-z0-9_\-]/g, '-').slice(0, 80);
const REV = +CFG.rev || 1;
const LKEY = 'k01-' + MAP_ID;
const PAL = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'c8'];
const COLORS = PAL.concat(['ok', 'warn', 'info', 'bad', 'gx']);
const COLOR_NAME = { c1: 'Xanh dương', c2: 'Xanh lá', c3: 'Cam', c4: 'Hồng tím', c5: 'Xanh ngọc', c6: 'Đỏ', c7: 'Tím', c8: 'Vàng đất', ok: 'Xanh lá (an toàn)', warn: 'Vàng (lưu ý)', info: 'Xanh (thông tin)', bad: 'Đỏ (rủi ro)', gx: 'Xám (đọc thêm)' };
const cv = c => `var(--${COLORS.indexOf(c) >= 0 ? c : 'c1'})`;

/* ---------- Biểu tượng ---------- */
const P = {
  chat: '<path d="M4 5h16v11H9l-5 4z"/>', file: '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 13h6M9 17h6"/>',
  gauge: '<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>',
  layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>', folder: '<path d="M3 6h6l2 2h10v11H3z"/>',
  spark: '<path d="M12 3l2.2 5.8L20 11l-5.8 2.2L12 19l-2.2-5.8L4 11l5.8-2.2z"/>', search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  flow: '<rect x="3" y="4" width="7" height="5" rx="1"/><rect x="14" y="15" width="7" height="5" rx="1"/><path d="M6.5 9v4a2 2 0 0 0 2 2H14"/>',
  plug: '<path d="M9 3v5M15 3v5M7 8h10v3a5 5 0 0 1-10 0zM12 16v5"/>', memory: '<path d="M6 4h12v17l-6-4-6 4z"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', box: '<path d="M3 7l9-4 9 4v10l-9 4-9-4z"/><path d="M3 7l9 4 9-4M12 11v10"/>',
  cursor: '<path d="M5 3l14 7-6 2-2 6z"/>', grid: '<path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z"/>',
  mic: '<path d="M9 4a3 3 0 0 1 6 0v7a3 3 0 0 1-6 0z"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>', code: '<path d="M8 7l-5 5 5 5M16 7l5 5-5 5"/>',
  org: '<path d="M9 3h6v5H9zM4 16h6v5H4zM14 16h6v5h-6zM12 8v4M7 16v-4h10v4"/>', check: '<path d="M5 12l5 5 9-10"/>',
  swap: '<path d="M4 8h14l-3-3M20 16H6l3 3"/>', bulb: '<path d="M12 3a6 6 0 0 0-4 10.5V17h8v-3.5A6 6 0 0 0 12 3z"/><path d="M9 21h6"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>', signal: '<path d="M5 20v-4M10 20v-8M15 20V8M20 20V4"/>',
  tool: '<path d="M14.5 5.5a4 4 0 0 0 4.9 4.9L11 18.8 8.2 16l8.4-8.4"/><path d="M4 20l4-4"/>', shield: '<path d="M12 3l8 3v6c0 5-4 8-8 9-4-1-8-4-8-9V6z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/>', hosp: '<path d="M9 3h6v6h6v6h-6v6H9v-6H3V9h6z"/>',
  pen: '<path d="M4 20l4-1 11-11-3-3L5 16z"/><path d="M14 6l3 3"/>',
  cog: '<circle cx="12" cy="12" r="3.2"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/>',
  share: '<circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M8.2 10.8l7.6-3.6M8.2 13.2l7.6 3.6"/>',
  table: '<rect x="3" y="5" width="18" height="14" rx="1.5"/><path d="M3 10h18M3 14.5h18M9 5v14"/>',
  quote: '<path d="M5 17c3-1 4-3 4-6H5V6h5v5c0 4-2 7-5 8zM14 17c3-1 4-3 4-6h-4V6h5v5c0 4-2 7-5 8z"/>',
  chart: '<path d="M4 20V4M4 20h16"/><path d="M8 16v-4M12 16V8M16 16v-6"/>',
  eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.5 3.3-5.5 6.5-5.5s5.7 2 6.5 5.5"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14.8c2 .8 3.2 2.6 3.6 5.2"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>',
  heart: '<path d="M12 20s-8-5-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 9c0 6-8 11-8 11z"/>',
  pulse: '<path d="M3 12h4l2-6 4 12 2-6h6"/>', pill: '<rect x="3" y="9" width="18" height="6" rx="3" transform="rotate(-35 12 12)"/><path d="M9.5 7.5l5 7"/>',
  money: '<rect x="3" y="6" width="18" height="12" rx="2"/><circle cx="12" cy="12" r="3"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
  star: '<path d="M12 3l2.8 5.8 6.2.9-4.5 4.4 1.1 6.2L12 17.4 6.4 20.3l1.1-6.2L3 9.7l6.2-.9z"/>', flag: '<path d="M5 21V4M5 4h12l-2 4 2 4H5"/>',
  book: '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 19V5"/>', rocket: '<path d="M12 3c4 2 6 6 6 10l-3 3H9l-3-3c0-4 2-8 6-10z"/><circle cx="12" cy="10" r="2"/><path d="M9 19l-1 2M15 19l1 2"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>', lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  bell: '<path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 20a2 2 0 0 0 4 0"/>', home: '<path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/>',
  map: '<path d="M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2z"/><path d="M9 4v14M15 6v14"/>', trophy: '<path d="M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M7 6H4a3 3 0 0 0 3 4M17 6h3a3 3 0 0 1-3 4M12 14v4M8 21h8"/>',
  leaf: '<path d="M5 19c0-9 6-14 15-14 0 9-5 15-14 15z"/><path d="M5 19l8-8"/>', warn: '<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.5"/>',
  doc: '<path d="M6 3h12v18H6z"/><path d="M9 8h6M9 12h6M9 16h4"/>', mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
  phone: '<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>', cart: '<path d="M3 4h2l2 12h11l2-8H6"/><circle cx="9" cy="20" r="1.5"/><circle cx="17" cy="20" r="1.5"/>',
  link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>'
};
const ICONS = Object.keys(P);
const ico = (k, sw) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${sw || 2}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[k] || ''}</svg>`;
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const safeUrl = u => (typeof u === 'string' && /^(https:\/\/|data:image\/)/i.test(u.trim())) ? u.trim() : '';
const clone = o => JSON.parse(JSON.stringify(o));

/* chùm tia trang trí của khuôn K01 */
function burst() {
  const cols = ['#E0312F', '#E87A2A', '#E87A2A', '#1E9ACF', '#E87A2A', '#05B391', '#E87A2A', '#E0312F', '#E87A2A', '#1E9ACF', '#E87A2A', '#05B391', '#E87A2A', '#1E9ACF', '#E87A2A', '#05B391'];
  const lens = [300, 330, 270, 300, 320, 260, 330, 300, 280, 310, 270, 320, 290, 300, 260, 310];
  let out = '';
  for (let i = 0; i < 16; i++) {
    const a = (i * 360 / 16 - 80) * Math.PI / 180, w = 15, cx = 400, cy = 400, r0 = 62, L = lens[i];
    const x0 = cx + r0 * Math.cos(a), y0 = cy + r0 * Math.sin(a), x1 = cx + (r0 + L) * Math.cos(a), y1 = cy + (r0 + L) * Math.sin(a);
    const px = -Math.sin(a), py = Math.cos(a), f = n => n.toFixed(1);
    out += `<polygon points="${f(x0 + px * 2)},${f(y0 + py * 2)} ${f(x1 + px * w)},${f(y1 + py * w)} ${f(x1 - px * w)},${f(y1 - py * w)} ${f(x0 - px * 2)},${f(y0 - py * 2)}" fill="${cols[i]}"/><circle cx="${f(x1)}" cy="${f(y1)}" r="${w}" fill="${cols[i]}"/>`;
  }
  return `<svg viewBox="0 0 800 800" aria-hidden="true">${out}</svg>`;
}
const MARK = CFG.mark === 'none' ? '' : (P[CFG.mark] ? `<span class="ic">${ico(CFG.mark, 1.6)}</span>` : burst());

/* ---------- Khung trang ---------- */
const logos = (Array.isArray(CFG.logos) ? CFG.logos : []).map(l => safeUrl(l.src) ? `<img alt="${esc(l.alt || '')}" src="${esc(safeUrl(l.src))}">` : '').filter(Boolean);
const BTN = (id, title, svg, lbl, cls, aria) => `<button class="btn${cls ? ' ' + cls : ''}" id="${id}" title="${esc(title)}"${aria ? ` aria-label="${esc(aria)}"` : ''}>${svg}${lbl ? `<span class="lbl">${lbl}</span>` : ''}</button>`;
const SV = d => `<svg viewBox="0 0 24 24" fill="none" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
host.innerHTML = `<div class="app">
  <header><div class="top">
    ${MARK ? `<div class="mark" aria-hidden="true">${MARK}</div>` : ''}
    <div class="ttl">${CFG.eyebrow ? `<div class="eyebrow">${esc(CFG.eyebrow)}</div>` : ''}<h1>${esc(CFG.title || 'Sơ đồ tư duy')}</h1></div>
    ${logos.length ? `<div class="logos"><div class="pill-w">${logos.join('<div class="sep"></div>')}</div></div>` : ''}
  </div>
  <nav class="tabs" role="tablist" aria-label="Chọn tab">${CFG.tabs.map((t, i) => `<button class="tab" role="tab" data-i="${i}"><span class="no">${i + 1}</span>${esc(t.label || ('Tab ' + (i + 1)))}</button>`).join('')}</nav></header>
  <main>
    <div class="stage" id="stage" tabindex="0" aria-label="Khung sơ đồ tư duy">
      ${MARK && !P[CFG.mark] ? `<div class="watermark" aria-hidden="true">${burst()}</div>` : ''}
      <div class="world" id="world"><svg class="edges" id="edges"></svg></div>
    </div>
    <div class="matrix" id="matrix" hidden></div>
    <details class="legend" id="legend"><summary>Chú giải</summary><div class="lg" id="lg"></div></details>
    <div class="ctrl" id="ctrl">
      ${BTN('b-prev', 'Thu lại bước trước (←)', SV('<path d="M15 6l-6 6 6 6"/>'), '', '', 'Thu lại bước trước')}
      <span class="stepinfo" id="stepinfo">0/0</span>
      ${BTN('b-next', 'Mở nhánh tiếp theo (→)', SV('<path d="M9 6l6 6-6 6"/>'), 'Mở tiếp', 'pri')}
      <span class="div m"></span>
      ${BTN('b-all', 'Mở tất cả các nhánh', SV('<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>'), 'Mở tất cả')}
      ${BTN('b-none', 'Thu gọn về nhánh lớn', SV('<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>'), 'Thu gọn')}
      ${BTN('b-auto', 'Trả các nút đã kéo về vị trí tự động', SV('<path d="M4 12a8 8 0 1 0 2.3-5.6"/><path d="M4 4v4h4"/>'), 'Sắp xếp lại')}
      <span class="div m"></span>
      ${BTN('b-out', 'Thu nhỏ (−)', SV('<path d="M6 12h12"/>'), '', '', 'Thu nhỏ')}
      ${BTN('b-fit', 'Vừa màn hình (0)', SV('<rect x="4" y="6" width="16" height="12" rx="2"/><path d="M9 12h6"/>'), 'Vừa màn hình')}
      ${BTN('b-in', 'Phóng to (+)', SV('<path d="M6 12h12M12 6v12"/>'), '', '', 'Phóng to')}
      <span class="div m"></span>
      ${BTN('b-fs', 'Toàn màn hình (F)', SV('<path d="M4 9V5a1 1 0 0 1 1-1h4M15 4h4a1 1 0 0 1 1 1v4M20 15v4a1 1 0 0 1-1 1h-4M9 20H5a1 1 0 0 1-1-1v-4"/>'), '', '', 'Toàn màn hình')}
    </div>
  </main></div>`;
const world = document.getElementById('world'), svg = document.getElementById('edges'), stage = document.getElementById('stage');

/* ---------- Dữ liệu và trạng thái ---------- */
let TABS = clone(CFG.tabs);
function prep(tabs) {
  tabs.forEach((t, ti) => {
    t.kind = t.kind === 'matrix' ? 'matrix' : 'map';
    if (t.kind === 'map') {
      if (!t.root) t.root = { t: t.label || 'Chủ đề', c: [] };
      t.root.type = 'root';
      let i = 0;
      (function f(x, d) { if (!x.id) x.id = 't' + ti + '-' + i; i++; if (!x.type) x.type = d === 0 ? 'root' : d === 1 ? 'branch' : 'idea'; (x.c || []).forEach(c => f(c, d + 1)); })(t.root, 0);
      t.flows = Array.isArray(t.flows) ? t.flows : [];
    } else {
      t.x = t.x || { title: 'Trục hoành', levels: ['Thấp', 'Cao'] }; t.y = t.y || { title: 'Trục tung', levels: ['Thấp', 'Cao'] };
      t.cells = Array.isArray(t.cells) ? t.cells : [];
      t.cells.forEach((c, i) => { if (!c.id) c.id = 'm' + ti + '-' + i; if (!Array.isArray(c.sections)) c.sections = []; if (!Array.isArray(c.items)) c.items = []; });
    }
  });
  return tabs;
}
prep(TABS);
const ORIG = JSON.stringify(TABS);
let cur = 0, M = null, EDIT = false, EDOPEN = false, SEL = null, PICK = null, UNDO = [], REDO = [], DIRTY = false, BUSY = false, MSG = null, CONFIRM = 0, CAN_EDIT = MODE === 'html', REMOTE = null, uidN = 0;
const MAPS = {}, OPEN = new Set();
const newId = () => 'u' + Date.now().toString(36) + (uidN++).toString(36);
const snap = () => JSON.stringify(TABS);
const T = () => TABS[cur];
function adoptTabs(arr) { if (!Array.isArray(arr) || arr.length !== CFG.tabs.length) return false; TABS = prep(arr); Object.keys(MAPS).forEach(k => delete MAPS[k]); return true; }
try { const s = JSON.parse(localStorage.getItem(LKEY) || 'null'); if (s && s.rev === REV && s.tabs) adoptTabs(s.tabs); } catch (e) {}

/* ---------- Dựng cây ---------- */
function label(d) { return d.type === 'card' ? ((d.items && d.items[0] && d.items[0].lab) || 'Thẻ') : (d.t || ''); }
function nodeHTML(d, tab) {
  const chips = Array.isArray(d.chips) && d.chips.length ? `<div class="chips2">${d.chips.map(c => `<span class="${esc(c.tone || '')}">${esc(c.t)}</span>`).join('')}</div>` : '';
  switch (d.type) {
    case 'root': { const im = safeUrl(d.img); return `${im ? `<div class="ri"><img alt="" src="${esc(im)}"></div>` : P[d.icon] ? `<div class="ri">${ico(d.icon, 1.8)}</div>` : MARK && !P[CFG.mark] ? `<div class="bm">${burst()}</div>` : ''}<div><div class="rt">${esc(d.t)}</div>${d.sub ? `<div class="rs">${esc(d.sub)}</div>` : ''}</div>`; }
    case 'branch': return `${P[d.icon] ? `<span class="gi">${ico(d.icon, 2.2)}</span>` : ''}<span>${esc(d.t)}</span><b class="cnt">${(d.c || []).length}</b>`;
    case 'step': return `<span class="num">${esc(d.n || '')}</span><span><small>${esc(tab.stepLabel || 'Bậc')} ${esc(d.n || '')}</small><b>${esc(d.t)}</b></span>`;
    case 'card': return (d.items || []).map(it => `<div class="cc${it.safe ? ' safe' : ''}${it.dashed ? ' dsh' : ''}"><div class="lab">${ico(P[it.icon] ? it.icon : 'info', 2.2)}${esc(it.lab)}</div><p>${esc(it.t)}</p></div>`).join('');
    default: {
      if (d.tone === 'bad') return `${ico('x', 2.6)}<span>${esc(d.t)}</span>`;
      const im = safeUrl(d.img), fi = P[d.icon] ? `<span class="fi">${ico(d.icon)}</span>` : '';
      const txt = `<span><b>${esc(d.t)}</b>${d.note ? `<small>${esc(d.note)}</small>` : ''}${chips}</span>`;
      return im ? `<img class="im" alt="" src="${esc(im)}"><div class="row2">${fi}${txt}</div>` : fi + txt;
    }
  }
}
function cls(d) {
  if (d.type === 'root') return 'root'; if (d.type === 'branch') return 'group'; if (d.type === 'step') return 'step'; if (d.type === 'card') return 'card';
  if (d.tone === 'bad') return 'no-n';
  return 'idea' + (P[d.icon] ? ' ic' : '') + (safeUrl(d.img) ? ' has-im' : '');
}
function build(ti) {
  const tab = TABS[ti], nodes = [], ladder = tab.layout === 'ladder', oneSide = tab.layout === 'right';
  (function walk(d, parent, depth, side, color, dashed, idx) {
    const n = { d, parent, depth, kids: [], id: nodes.length };
    n.side = depth === 0 ? 'C' : side;
    n.dashed = !!(d.dashed || dashed);
    if (depth === 1) color = d.color ? cv(d.color) : `var(--${PAL[idx % PAL.length]})`;
    else if (depth > 1 && d.color) color = cv(d.color);
    n.color = color || 'var(--navy)';
    nodes.push(n);
    const el = document.createElement('div');
    el.className = `n ${cls(d)}${n.dashed ? ' dashed' : ''} side-${n.side}`;
    if (d.type === 'card') { const c = Math.max(1, Math.min(4, +d.cols || 2)); el.style.gridTemplateColumns = `repeat(${c},minmax(0,1fr))`; el.style.width = (c * 250) + 'px'; }
    el.style.setProperty('--c', n.color);
    el.innerHTML = nodeHTML(d, tab);
    n.el = el;
    (d.c || []).forEach((c, i) => {
      const s = depth === 0 ? ((ladder || oneSide || c.type === 'step') ? 'R' : (i % 2 ? 'L' : 'R')) : side;
      n.kids.push(walk(c, n, depth + 1, s, color, n.dashed, i));
    });
    if (n.kids.length && depth > 0) {
      el.classList.add('click');
      const b = document.createElement('button'); b.className = 'tg'; b.type = 'button'; n.tg = b; el.appendChild(b);
      el.setAttribute('role', 'button'); el.setAttribute('tabindex', '-1');
    }
    return n;
  })(tab.root, null, 0, 'R', null, false, 0);
  const m = { ti, nodes, root: nodes[0], hist: [], order: [], layer: document.createElement('div'), edgeG: document.createElementNS('http://www.w3.org/2000/svg', 'g'), flowG: document.createElementNS('http://www.w3.org/2000/svg', 'g'), view: null };
  m.layer.style.display = 'contents';
  m.byId = new Map(nodes.map(n => [n.d.id, n]));
  const open = Math.max(0, +(tab.openDepth != null ? tab.openDepth : CFG.openDepth != null ? CFG.openDepth : 1));
  nodes.forEach(n => {
    n.exp = n.depth === 0 || (n.kids.length > 0 && n.depth < open); n.cur = null;
    m.layer.appendChild(n.el);
    if (n.parent) {
      const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      p.setAttribute('stroke', n.depth === 1 ? n.color : (n.d.type === 'card' ? n.parent.color : n.color));
      p.setAttribute('stroke-width', n.depth === 1 ? 5 : n.depth === 2 ? 3.2 : 2.2);
      if (n.dashed) p.setAttribute('stroke-dasharray', '7 7');
      n.path = p; m.edgeG.appendChild(p);
    }
  });
  (function pre(n) { if (n.depth > 0 && n.kids.length) m.order.push(n); n.kids.forEach(pre); })(m.root);
  m.hist = m.order.filter(n => n.exp);
  MAPS[ti] = m;
  return m;
}

/* ---------- Bố cục ---------- */
const GX = d => (d === 0 ? 70 : d === 1 ? 46 : 36);
const GY = d => (d <= 1 ? 26 : 12);
function measure(m) { m.nodes.forEach(n => { n.w = n.el.offsetWidth; n.h = n.el.offsetHeight; }); }
function sub(n) { const vk = n.exp ? n.kids : []; if (!vk.length) return (n.sh = n.h); let s = 0; vk.forEach((k, i) => { s += sub(k) + (i ? GY(k.depth) : 0); }); return (n.sh = Math.max(n.h, s)); }
function place(n, x, cy) {
  n.tx = x; n.ty = cy - n.h / 2;
  const vk = n.exp ? n.kids : []; if (!vk.length) return;
  let tot = 0; vk.forEach((k, i) => { tot += k.sh + (i ? GY(k.depth) : 0); });
  let y = cy - tot / 2;
  vk.forEach(k => { const kc = y + k.sh / 2; const kx = n.side === 'L' ? x - GX(n.depth) - k.w : x + n.w + GX(n.depth); place(k, kx, kc); y += k.sh + GY(k.depth); });
}
function layout(m) {
  const r = m.root; r.tx = -r.w / 2; r.ty = -r.h / 2;
  ['R', 'L'].forEach(side => {
    const ks = r.kids.filter(k => k.side === side); if (!ks.length) return;
    let tot = 0; ks.forEach((k, i) => { sub(k); tot += k.sh + (i ? GY(1) + 8 : 0); });
    let y = -tot / 2;
    ks.forEach((k, i) => {
      const kc = y + k.sh / 2;
      let kx = side === 'L' ? r.tx - GX(0) - k.w : r.tx + r.w + GX(0);
      if (k.d.type === 'step' || TABS[m.ti].layout === 'ladder') kx += (side === 'L' ? -1 : 1) * (ks.length - 1 - i) * 70; // bậc thang: bậc trên lùi xa hơn
      place(k, kx, kc); y += k.sh + GY(1) + 8;
    });
  });
  // vị trí kéo tay: nút và cả nhánh con dời theo độ lệch đã lưu (ox, oy)
  (function off(n, ox, oy) { ox += +n.d.ox || 0; oy += +n.d.oy || 0; n.tx += ox; n.ty += oy; n.kids.forEach(k => off(k, ox, oy)); })(r, 0, 0);
  m.nodes.forEach(n => { n.vis = !n.parent || (n.parent.vis && n.parent.exp); });
  { const b = document.getElementById('b-auto'); if (b) b.hidden = !m.nodes.some(n => n.d.ox || n.d.oy); }
  m.nodes.forEach(n => { if (n.tg) { const c = n.kids.length; n.tg.textContent = n.exp ? '−' : '+' + c; n.tg.setAttribute('aria-label', n.exp ? 'Thu nhánh' : `Mở ${c} nhánh con`); n.el.setAttribute('aria-expanded', n.exp ? 'true' : 'false'); } });
}

/* ---------- Hoạt ảnh và khung nhìn ---------- */
function drawEdges(m) {
  m.nodes.forEach(n => {
    if (!n.path || !n.cur || !n.parent.cur) return;
    const p = n.parent, a = p.cur, b = n.cur;
    // nút con bị kéo sang phía bên kia của nút cha thì đường nối đổi phía theo
    const L = (b.x + n.w / 2) < (a.x + p.w / 2);
    const x1 = L ? a.x : a.x + p.w, y1 = a.y + p.h / 2, x2 = L ? b.x + n.w : b.x, y2 = b.y + n.h / 2, mx = (x1 + x2) / 2;
    n.path.setAttribute('d', `M${x1},${y1} C${mx},${y1} ${mx},${y2} ${x2},${y2}`); n.path.style.opacity = Math.min(a.o, b.o);
  });
}
function renderNow(m) {
  if (anim) { cancelAnimationFrame(anim); anim = null; }
  m.nodes.forEach(n => { if (!n.vis) return; n.cur = { x: n.tx, y: n.ty, o: 1 }; n.el.style.transform = `translate(${n.tx}px,${n.ty}px)`; n.el.style.opacity = 1; n.el.classList.remove('hid'); });
  drawEdges(m); drawFlows(m);
}
let anim = null;
const view = { s: 1, x: 0, y: 0 };
function applyView() { world.style.transform = `translate(${view.x}px,${view.y}px) scale(${view.s})`; }
function nearestVisAnc(n) { let p = n.parent; while (p && !p.vis) p = p.parent; return p || n; }
function animate(m, viewTo) {
  const from = new Map(), dur = RM ? 0 : 420;
  m.nodes.forEach(n => {
    const a = nearestVisAnc(n);
    const fb = { x: a.cur ? a.cur.x + (a.w - n.w) / 2 : a.tx, y: a.cur ? a.cur.y + (a.h - n.h) / 2 : a.ty, o: 0 };
    from.set(n, n.cur ? { ...n.cur } : fb);
    n.to = n.vis ? { x: n.tx, y: n.ty, o: 1 } : (() => { const p = nearestVisAnc(n); return { x: p.tx + (p.w - n.w) / 2, y: p.ty + (p.h - n.h) / 2, o: 0 }; })();
    if (n.vis) n.el.classList.remove('hid');
  });
  const v0 = { ...view }, v1 = viewTo ? { ...viewTo } : { ...view }, t0 = performance.now();
  if (anim) cancelAnimationFrame(anim);
  const step = now => {
    const t = dur ? Math.min(1, (now - t0) / dur) : 1, e = 1 - Math.pow(1 - t, 3);
    m.nodes.forEach(n => { const a = from.get(n), b = n.to; n.cur = { x: a.x + (b.x - a.x) * e, y: a.y + (b.y - a.y) * e, o: a.o + (b.o - a.o) * e }; n.el.style.transform = `translate(${n.cur.x}px,${n.cur.y}px)`; n.el.style.opacity = n.cur.o; });
    drawEdges(m);
    drawFlows(m);
    view.s = v0.s + (v1.s - v0.s) * e; view.x = v0.x + (v1.x - v0.x) * e; view.y = v0.y + (v1.y - v0.y) * e; applyView();
    if (t < 1) anim = requestAnimationFrame(step); else { anim = null; m.nodes.forEach(n => { if (!n.vis) n.el.classList.add('hid'); }); }
  };
  anim = requestAnimationFrame(step);
}
function bbox(list) { let a = Infinity, b = Infinity, c = -Infinity, d = -Infinity; list.forEach(n => { a = Math.min(a, n.tx); b = Math.min(b, n.ty); c = Math.max(c, n.tx + n.w); d = Math.max(d, n.ty + n.h); }); return { x: a, y: b, w: c - a, h: d - b }; }
function safeRect() {
  const W = stage.clientWidth, H = stage.clientHeight, narrow = W < 720;
  const top = narrow ? 60 : 24, bot = 84 + ((EDIT && ED && EDOPEN && narrow) ? ED.offsetHeight + 8 : 0);
  const lg = document.getElementById('legend');
  const lx = (!narrow && W >= 900 && lg.open) ? lg.offsetWidth + 28 : 16;
  const rx = (EDIT && ED && EDOPEN && W >= 720) ? ED.offsetWidth + 28 : 16;
  return { x: lx, y: top, w: W - lx - rx, h: H - top - bot };
}
function fitView(m, maxS) { const b = bbox(m.nodes.filter(n => n.vis)), R = safeRect(); const s = Math.min(maxS || 1.15, R.w / (b.w + 40), R.h / (b.h + 40)); return { s, x: R.x + R.w / 2 - (b.x + b.w / 2) * s, y: R.y + R.h / 2 - (b.y + b.h / 2) * s }; }
function readScale() { return Math.min(2.5, Math.max(1.1, 0.0265 * window.innerHeight / 13.5)); }
function focusView(n, leaf) {
  const list = [n]; if (!leaf) (function f(k) { if (k.exp) k.kids.forEach(c => { list.push(c); f(c); }); })(n);
  const b = bbox(list), R = safeRect(), pad = 24, fit = Math.min(R.w / (b.w + pad * 2), R.h / (b.h + pad * 2));
  const s = Math.max(readScale(), Math.min(2.6, fit)), v = { s, x: 0, y: 0 }, kids = list.slice(1), kb = kids.length ? bbox(kids) : b;
  if ((b.w + pad * 2) * s <= R.w) v.x = R.x + R.w / 2 - (b.x + b.w / 2) * s;
  else if ((kb.w + pad * 2) * s <= R.w) v.x = n.side === 'L' ? R.x + pad - kb.x * s : R.x + R.w - pad - (kb.x + kb.w) * s;
  else if (n.side === 'L') v.x = R.x + R.w - pad - (b.x + b.w) * s; else v.x = R.x + pad - b.x * s;
  if ((b.h + pad * 2) * s <= R.h) v.y = R.y + R.h / 2 - (b.y + b.h / 2) * s; else v.y = R.y + pad - b.y * s;
  return v;
}

/* ---------- Mở / thu ---------- */
function setStepInfo() { if (!M) return; document.getElementById('stepinfo').textContent = `${M.order.filter(n => n.exp).length}/${M.order.length}`; }
function toggle(n, focus) {
  if (!n.parent) { animate(M, fitView(M, 1.6)); return; }
  if (!n.kids.length) { animate(M, focusView(n, true)); return; }
  if (n.exp) collapse(n); else { n.exp = true; M.hist.push(n); }
  layout(M);
  animate(M, focus === false ? null : n.exp ? focusView(n) : (n.parent.parent ? focusView(n.parent) : fitView(M, 1.6))); setStepInfo();
}
function collapse(n) { (function f(k) { k.exp = false; k.kids.forEach(f); })(n); M.hist = M.hist.filter(h => h.exp); }
function next() { const n = M.order.find(k => !k.exp && (!k.parent || k.parent.vis && k.parent.exp)); if (!n) return; n.exp = true; M.hist.push(n); layout(M); animate(M, focusView(n)); setStepInfo(); }
function prev() { const n = M.hist.pop(); if (!n) return; collapse(n); layout(M); animate(M, n.parent && n.parent.parent ? focusView(n.parent) : fitView(M, 1.6)); setStepInfo(); }
function all(open) { M.nodes.forEach(n => { if (n.parent) n.exp = open && n.kids.length > 0; }); M.hist = open ? M.order.slice() : []; layout(M); animate(M, fitView(M, open ? 1 : 1.15)); setStepInfo(); }

/* ---------- Chuyển tab ---------- */
const isMx = () => T().kind === 'matrix';
function dropM() { if (M) { M.layer.remove(); M.edgeG.remove(); M.flowG.remove(); M = null; } }
function show(i) {
  cur = Math.max(0, Math.min(TABS.length - 1, i | 0));
  document.querySelectorAll('.tab').forEach(t => t.setAttribute('aria-selected', String(+t.dataset.i === cur)));
  if (M) { M.view = { ...view }; M.layer.remove(); M.edgeG.remove(); M.flowG.remove(); M = null; }
  SEL = null; PICK = null;
  const mx = isMx();
  document.getElementById('matrix').hidden = !mx; stage.hidden = mx;
  ['b-prev', 'b-next', 'b-all', 'b-none', 'b-out', 'b-fit', 'b-in', 'stepinfo', 'b-auto'].forEach(k => { document.getElementById(k).hidden = mx; });
  document.querySelectorAll('.ctrl .div.m').forEach(d => { d.hidden = mx; });
  document.getElementById('legend').hidden = mx;
  if (mx) { if (EDIT) setEdit(false); MXQ = null; MXED = false; renderMatrix(); }
  else {
    M = MAPS[cur] || build(cur);
    world.appendChild(M.layer); svg.appendChild(M.edgeG); FSVG.appendChild(M.flowG); world.appendChild(FSVG);
    legend(); measure(M); layout(M);
    if (!M.view) { M.nodes.forEach(n => { n.cur = null; }); M.view = fitView(M); Object.assign(view, M.view); applyView(); animate(M, null); }
    else { Object.assign(view, M.view); animate(M, null); }
    setStepInfo();
  }
  edRender();
  try { history.replaceState(null, '', '#tab-' + (cur + 1)); } catch (e) {}
}

/* ---------- Chú giải ---------- */
function legend() {
  const tab = T(), lg = document.getElementById('lg'); let h = '';
  const sw = (c, t, d) => `<div class="row"><span class="sw${d ? ' d' : ''}" style="--c:${c}"></span>${esc(t)}</div>`;
  if (Array.isArray(tab.legend) && tab.legend.length) tab.legend.forEach(x => { if (x.h) h += `<h4>${esc(x.h)}</h4>`; else if (x.icon && P[x.icon]) h += `<div class="row"><span style="width:16px;height:16px;display:inline-flex;color:var(--muted)">${ico(x.icon, 2.2)}</span>${esc(x.t)}</div>`; else h += sw(x.color ? cv(x.color) : 'var(--muted)', x.t); });
  else if (M) { h += `<h4>${esc(tab.legendTitle || 'Các nhánh')}</h4>` + M.root.kids.map(k => sw(k.color, label(k.d))).join(''); }
  h += flowLegend();
  if (M && M.nodes.some(n => n.d.dashed)) h += sw('var(--gx)', 'Nét đứt: phần đọc thêm', true);
  lg.innerHTML = h || '<div class="row" style="color:var(--muted)">Chưa có chú giải.</div>';
}

/* ---------- Đường liên kết ---------- */
const FL_KIND = { cause: 'Dẫn đến (mũi tên một đầu)', mutual: 'Tương hỗ (mũi tên hai đầu)', oppose: 'Đối lập / kìm hãm (đầu chữ T)' };
const FSVG = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
FSVG.setAttribute('class', 'edges fsvg');
FSVG.innerHTML = '<defs><marker id="fl-a" viewBox="0 0 10 10" refX="8.5" refY="5" markerUnits="userSpaceOnUse" markerWidth="13" markerHeight="13" orient="auto-start-reverse"><path class="flm" d="M0,0.8 L10,5 L0,9.2 z"/></marker><marker id="fl-t" viewBox="0 0 10 10" refX="7" refY="5" markerUnits="userSpaceOnUse" markerWidth="15" markerHeight="15" orient="auto"><path class="flt" d="M7,0.5 V9.5"/></marker></defs>';
function edgePt(n, t) { const cx = n.cur.x + n.w / 2, cy = n.cur.y + n.h / 2, dx = t.x - cx, dy = t.y - cy; if (!dx && !dy) return { x: cx, y: cy }; const k = Math.min((n.w / 2 + 6) / Math.abs(dx || 1e-9), (n.h / 2 + 6) / Math.abs(dy || 1e-9)); return { x: cx + dx * k, y: cy + dy * k }; }
function drawFlows(m) {
  if (!m || !m.flowG) return;
  let h = '';
  (TABS[m.ti].flows || []).forEach(f => {
    let a = m.byId.get(f.from), b = m.byId.get(f.to); if (!a || !b) return;
    const faint = !a.vis || !b.vis; if (!a.vis) a = nearestVisAnc(a); if (!b.vis) b = nearestVisAnc(b);
    if (a === b || !a.cur || !b.cur) return;
    const op = Math.min(a.cur.o, b.cur.o); if (op < 0.02) return;
    const ca = { x: a.cur.x + a.w / 2, y: a.cur.y + a.h / 2 }, cb = { x: b.cur.x + b.w / 2, y: b.cur.y + b.h / 2 }, pa = edgePt(a, cb), pb = edgePt(b, ca);
    const dx = pb.x - pa.x, dy = pb.y - pa.y, L = Math.hypot(dx, dy) || 1, k = Math.min(90, L * 0.18), cx = (pa.x + pb.x) / 2 - dy / L * k + (+f.bx || 0), cy = (pa.y + pb.y) / 2 + dx / L * k + (+f.by || 0);
    const d = `M${pa.x.toFixed(1)},${pa.y.toFixed(1)} Q${cx.toFixed(1)},${cy.toFixed(1)} ${pb.x.toFixed(1)},${pb.y.toFixed(1)}`;
    const mx = 0.25 * pa.x + 0.5 * cx + 0.25 * pb.x, my = 0.25 * pa.y + 0.5 * cy + 0.25 * pb.y, on = SEL && SEL.k === 'f' && SEL.id === f.id;
    let st = faint ? 'stroke-dasharray="2 6" opacity=".5"' : `stroke-dasharray="${f.kind === 'oppose' ? '11 5 2 5' : '8 6'}" ${f.kind === 'oppose' ? 'marker-end="url(#fl-t)"' : f.kind === 'mutual' ? 'marker-start="url(#fl-a)" marker-end="url(#fl-a)"' : 'marker-end="url(#fl-a)"'}`;
    h += `<g class="fl${on ? ' on' : ''}" style="opacity:${op.toFixed(3)}">${on ? `<path class="halo" d="${d}"/>` : ''}<path class="v" d="${d}" ${st}/><path class="flh" data-fid="${esc(f.id)}" d="${d}"/>${f.label && !faint ? `<text class="fll" x="${mx.toFixed(1)}" y="${(my - (on && EDIT ? 16 : 0)).toFixed(1)}" text-anchor="middle" dominant-baseline="middle">${esc(f.label)}</text>` : ''}${on && EDIT && !faint ? `<circle class="flk" data-h="from" data-fid="${esc(f.id)}" cx="${pa.x.toFixed(1)}" cy="${pa.y.toFixed(1)}" r="7"><title>Kéo để đổi ý đầu</title></circle><circle class="flk bend" data-h="bend" data-fid="${esc(f.id)}" cx="${mx.toFixed(1)}" cy="${my.toFixed(1)}" r="8"><title>Kéo để uốn đường</title></circle><circle class="flk" data-h="to" data-fid="${esc(f.id)}" cx="${pb.x.toFixed(1)}" cy="${pb.y.toFixed(1)}" r="7"><title>Kéo để đổi ý đích</title></circle>` : ''}</g>`;
  });
  if (FTMP) h += `<path class="fltmp" d="M${FTMP.a.x.toFixed(1)},${FTMP.a.y.toFixed(1)} L${FTMP.b.x.toFixed(1)},${FTMP.b.y.toFixed(1)}"/>`;
  m.flowG.innerHTML = h;
}
let FTMP = null;
const flSample = k => `<svg class="fls" viewBox="0 0 34 12" aria-hidden="true"><path style="fill:none;stroke:var(--fl);stroke-width:2.2" d="M${k === 'mutual' ? 7 : 3},6 H${k === 'oppose' ? 29 : 26}" stroke-dasharray="${k === 'oppose' ? '7 3 2 3' : '5 4'}" ${k === 'oppose' ? 'marker-end="url(#fl-t)"' : k === 'mutual' ? 'marker-start="url(#fl-a)" marker-end="url(#fl-a)"' : 'marker-end="url(#fl-a)"'}/></svg>`;
function flowLegend() { if (isMx() || !(T().flows || []).length) return ''; return '<h4>Đường liên kết</h4>' + [['cause', 'Dẫn đến'], ['mutual', 'Tương hỗ'], ['oppose', 'Đối lập / kìm hãm']].map(([k, t]) => `<div class="row">${flSample(k)}${t}</div>`).join(''); }

/* ---------- Chỉnh sửa ---------- */
let ED = null;
function findD(id, root) { let out = null; (function f(x, p, i) { if (out) return; if (x.id === id) { out = { d: x, p, i }; return; } (x.c || []).forEach((c, j) => f(c, x, j)); })(root || T().root, null, -1); return out; }
const short = (s, n) => (s = String(s || ''), s.length > n ? s.slice(0, n - 1) + '…' : s);
function rebuild() {
  if (isMx()) { renderMatrix(); return; }
  const old = M, exp = new Set(old.nodes.filter(n => n.exp).map(n => n.d.id)), pos = new Map(old.nodes.map(n => [n.d.id, n.cur]));
  OPEN.forEach(i => exp.add(i)); OPEN.clear();
  old.layer.remove(); old.edgeG.remove(); old.flowG.remove(); delete MAPS[cur];
  M = build(cur);
  M.nodes.forEach(n => { if (n.parent) n.exp = exp.has(n.d.id) && n.kids.length > 0; n.cur = pos.get(n.d.id) || null; });
  M.hist = M.order.filter(n => n.exp);
  world.appendChild(M.layer); svg.appendChild(M.edgeG); FSVG.appendChild(M.flowG); world.appendChild(FSVG);
  measure(M); layout(M); markSel(); animate(M, null); setStepInfo(); legend();
}
function mutate(fn, keepPanel) { UNDO.push(snap()); if (UNDO.length > 80) UNDO.shift(); REDO = []; fn(); DIRTY = true; MSG = null; CONFIRM = 0; Object.keys(MAPS).forEach(k => { if (+k !== cur) delete MAPS[k]; }); rebuild(); if (keepPanel) toolsState(); else edRender(); autosave(); }
/* sửa một ô nhập: không vẽ lại bảng, để cú bấm tiếp theo của người dùng không bị mất */
function toolsState() {
  if (!ED) return;
  const q = a => ED.querySelector(`[data-a="${a}"]`);
  if (q('undo')) q('undo').disabled = !UNDO.length; if (q('redo')) q('redo').disabled = !REDO.length; if (q('save')) q('save').disabled = !!BUSY || !DIRTY;
  const st = ED.querySelector('.ed-st'); if (st) { st.textContent = DIRTY ? 'Chưa lưu' : 'Đã lưu'; st.classList.toggle('dirty', DIRTY); }
  const m = ED.querySelector('.ed-body .msg'); if (m && !PICK) m.remove();
}
function restoreSnap(s) { TABS = prep(JSON.parse(s)); Object.keys(MAPS).forEach(k => { if (+k !== cur) delete MAPS[k]; }); if (!isMx()) rebuild(); else renderMatrix(); if (SEL && SEL.k === 'n' && !isMx() && !findD(SEL.id)) SEL = null; markSel(); if (M) drawFlows(M); }
function undo() { if (!UNDO.length) return; REDO.push(snap()); restoreSnap(UNDO.pop()); DIRTY = true; MSG = null; edRender(); autosave(); }
function redo() { if (!REDO.length) return; UNDO.push(snap()); restoreSnap(REDO.pop()); DIRTY = true; MSG = null; edRender(); autosave(); }
function markSel() { if (!M) return; M.nodes.forEach(n => n.el.classList.toggle('sel', !!(EDIT && SEL && SEL.k === 'n' && SEL.id === n.d.id))); }
function blank(tpl) {
  if (!tpl || tpl.type === 'root') return { type: 'idea', t: 'Ý mới', id: newId() };
  const d = clone(tpl); delete d.c; d.id = newId();
  if (d.type === 'branch') { d.t = 'Nhánh mới'; d.c = []; delete d.color; }
  else if (d.type === 'card') (d.items || []).forEach(it => { it.t = 'Nội dung mới'; });
  else if (d.type === 'step') { d.t = 'Bậc mới'; d.n = (+d.n || 0) + 1; }
  else { d.t = 'Ý mới'; d.note = ''; delete d.img; delete d.chips; }
  return d;
}
function hasOff(d) { let f = false; (function g(x) { if (x.ox || x.oy) f = true; (x.c || []).forEach(g); })(d); return f; }
function clearOff(d) { (function g(x) { delete x.ox; delete x.oy; (x.c || []).forEach(g); })(d); }
function subIds(d) { const s = new Set(); (function f(x) { s.add(x.id); (x.c || []).forEach(f); })(d); return s; }
function act(a) {
  const r = SEL && SEL.k === 'n' ? findD(SEL.id) : null, tab = T();
  if (a === 'child' && r) { mutate(() => { r.d.c = r.d.c || []; const nd = blank(r.d.c[0] || (r.d.type === 'root' ? { type: 'branch' } : null)); r.d.c.push(nd); OPEN.add(r.d.id); SEL = { k: 'n', id: nd.id }; }); focusField(); }
  else if (a === 'sib' && r && r.p) { mutate(() => { const nd = blank(r.d); r.p.c.splice(r.i + 1, 0, nd); SEL = { k: 'n', id: nd.id }; }); focusField(); }
  else if (a === 'del' && r && r.p) { mutate(() => { const ids = subIds(r.d); r.p.c.splice(r.i, 1); tab.flows = tab.flows.filter(f => !ids.has(f.from) && !ids.has(f.to)); SEL = r.p.type === 'root' ? null : { k: 'n', id: r.p.id }; }); }
  else if (a === 'link' && r) { PICK = r.d.id; MSG = null; edRender(); }
  else if (a === 'pickx') { PICK = null; edRender(); }
  else if (a === 'fdel' && SEL && SEL.k === 'f') mutate(() => { tab.flows = tab.flows.filter(f => f.id !== SEL.id); SEL = null; });
  else if (a === 'frev' && SEL && SEL.k === 'f') mutate(() => { const f = tab.flows.find(x => x.id === SEL.id); if (f) { const t = f.from; f.from = f.to; f.to = t; } });
  else if (a === 'autonode' && r) { if (CAN_EDIT) mutate(() => clearOff(r.d)); else { clearOff(r.d); layout(M); animate(M, null); } }
  else if (a === 'undo') undo(); else if (a === 'redo') redo();
  else if (a === 'save') save(); else if (a === 'reset') reset();
  else if (a === 'export') exportJson();
  else if (a === 'close') setEdit(false);
  else if (a === 'fold') { EDOPEN = !EDOPEN; edRender(); if (M) animate(M, fitView(M, 1.6)); }
  else if (a === 'open') { setEdit(true); EDOPEN = true; edRender(); if (M) animate(M, fitView(M, 1.6)); }
}
function focusField() { setTimeout(() => { const i = ED && ED.querySelector('[data-p]'); if (i) { i.focus(); if (i.select) i.select(); } }, 30); }
function edClick(t) {
  const tg = t && t.closest && t.closest('.tg'), el = t && t.closest && t.closest('.n'), fh = t && t.closest && t.closest('.flh');
  if (tg && el) { const n = M.nodes.find(k => k.el === el); if (n) toggle(n); return; }
  if (el) {
    const n = M.nodes.find(k => k.el === el); if (!n) return;
    if (PICK) { if (n.d.id === PICK) return; const from = PICK; PICK = null; mutate(() => { const f = { id: newId(), from, to: n.d.id, kind: 'cause', label: '' }; T().flows.push(f); SEL = { k: 'f', id: f.id }; }); focusField(); return; }
    SEL = { k: 'n', id: n.d.id };
  } else if (fh) SEL = { k: 'f', id: fh.getAttribute('data-fid') };
  else SEL = null;
  MSG = null; CONFIRM = 0; markSel(); drawFlows(M); edRender();
}
const COLOR_OPT = [['', '(tự động)']].concat(COLORS.map(c => [c, COLOR_NAME[c]]));
const ICON_OPT = [['', '(không)']].concat(ICONS.map(k => [k, k]));
const FIELDS = {
  root: [['t', 'Tên chủ đề'], ['sub', 'Dòng phụ', 'ta'], ['icon', 'Biểu tượng', 'sel', ICON_OPT], ['img', 'Ảnh (https://… hoặc data:image)']],
  branch: [['t', 'Tên nhánh'], ['color', 'Màu nhánh', 'sel', COLOR_OPT], ['icon', 'Biểu tượng', 'sel', ICON_OPT]],
  step: [['t', 'Tên bậc'], ['n', 'Số thứ tự'], ['color', 'Màu', 'sel', COLOR_OPT]],
  idea: [['t', 'Tên ý', 'ta'], ['note', 'Ghi chú', 'ta'], ['icon', 'Biểu tượng', 'sel', ICON_OPT], ['img', 'Ảnh minh hoạ (https://… hoặc data:image)'], ['tone', 'Kiểu ô', 'sel', [['', 'Thường'], ['bad', 'Cảnh báo đỏ (con người quyết định)']]], ['color', 'Màu riêng', 'sel', COLOR_OPT]]
};
const TYPE_NAME = { root: 'Ý gốc', branch: 'Nhánh lớn', idea: 'Ý', card: 'Thẻ nhiều ô', step: 'Bậc' };
function field(p, lab, kind, opt, val) {
  val = val == null ? '' : val;
  if (kind === 'ta') return `<label>${lab}<textarea data-p="${p}" rows="3">${esc(val)}</textarea></label>`;
  if (kind === 'sel') return `<label>${lab}<select data-p="${p}">${opt.map(([v, t]) => `<option value="${esc(v)}"${String(v) === String(val) ? ' selected' : ''}>${esc(t)}</option>`).join('')}</select></label>`;
  return `<label>${lab}<input type="text" data-p="${p}" value="${esc(val)}"></label>`;
}
const B = (a, t, c, ic, dis) => `<button type="button" class="b${c ? ' ' + c : ''}" data-a="${a}"${dis ? ' disabled' : ''}>${ic ? ico(ic, 2.4) : ''}${t}</button>`;
const SAVE_LABEL = MODE === 'html' ? 'Lưu trên trình duyệt' : 'Lưu bản chung';
function edRender() {
  if (!ED) return;
  ED.hidden = isMx();
  document.body.classList.toggle('editing', EDIT);
  document.body.classList.toggle('picking', EDIT && !!PICK);
  if (!EDIT) { ED.classList.add('mini'); ED.innerHTML = `<button type="button" class="ed-h" data-a="open" aria-expanded="false"><b>Chỉnh sửa sơ đồ</b><i class="chev" aria-hidden="true"></i></button>`; return; }
  ED.classList.toggle('mini', !EDOPEN);
  let h = `<button type="button" class="ed-h" data-a="fold" aria-expanded="${EDOPEN}"><b>Chỉnh sửa sơ đồ</b><span class="ed-st${DIRTY ? ' dirty' : ''}">${DIRTY ? 'Chưa lưu' : 'Đã lưu'}</span><i class="chev" aria-hidden="true"></i></button>`;
  if (!EDOPEN) {
    let sel = ''; if (SEL && SEL.k === 'n') { const r = findD(SEL.id); if (r) sel = 'Đang chọn: ' + short(label(r.d), 34); } else if (SEL && SEL.k === 'f') sel = 'Đang chọn: một đường liên kết';
    ED.innerHTML = h + (sel ? `<div class="ed-sel">${esc(sel)} · bấm để sửa</div>` : ''); return;
  }
  h += `<div class="ed-tools">${B('undo', 'Hoàn tác', '', 'swap', !UNDO.length)}${B('redo', 'Làm lại', '', '', !REDO.length)}${B('save', BUSY === 'save' ? 'Đang lưu…' : SAVE_LABEL, 'pri', 'check', BUSY || !DIRTY)}${B('reset', CONFIRM ? 'Bấm lần nữa để khôi phục' : 'Khôi phục gốc', 'bad', '', !!BUSY)}${B('export', 'Xuất JSON', '', 'file')}<label class="b file">Nhập JSON<input type="file" accept=".json,application/json" data-import></label>${B('close', 'Đóng', '', 'x')}</div><div class="ed-body">`;
  if (MSG) h += `<div class="msg ${MSG.c || ''}" role="status">${esc(MSG.t)}</div>`;
  if (PICK) { const r = findD(PICK); h += `<div class="msg">Nối liên kết từ «${esc(short(r ? label(r.d) : '', 40))}»: bấm vào ý đích trên sơ đồ.</div><div class="acts">${B('pickx', 'Huỷ nối')}</div>`; }
  else if (SEL && SEL.k === 'n') {
    const r = findD(SEL.id); if (!r) { SEL = null; return edRender(); }
    const d = r.d; h += `<div class="typ">${TYPE_NAME[d.type] || 'Ý'}</div>`;
    if (d.type === 'card') (d.items || []).forEach((it, i) => { h += `<div class="grp">${field('items.' + i + '.lab', 'Nhãn ô ' + (i + 1), '', null, it.lab)}${field('items.' + i + '.t', 'Nội dung ô ' + (i + 1), 'ta', null, it.t)}${field('items.' + i + '.icon', 'Biểu tượng', 'sel', ICON_OPT, it.icon)}</div>`; });
    else (FIELDS[d.type] || FIELDS.idea).forEach(([p, lab, kind, opt]) => { h += field(p, lab, kind, opt, d[p]); });
    if (r.p) h += `<label class="ck"><input type="checkbox" data-p="dashed"${d.dashed ? ' checked' : ''}>Nét đứt (phần đọc thêm)</label>`;
    if (hasOff(d)) h += `<div class="acts">${B('autonode', 'Về vị trí tự động', '', 'swap')}</div>`;
    h += `<div class="acts">${B('child', 'Thêm ý con', '', 'plus')}${r.p ? B('sib', 'Thêm ý cùng cấp', '', 'plus') : ''}${B('link', 'Nối liên kết', '', 'share')}${r.p ? B('del', 'Xoá ý', 'bad', 'x') : ''}</div>`;
    if (r.p && (d.c || []).length) h += `<p class="note">Xoá ý này sẽ xoá cả ${subIds(d).size - 1} ý con và các liên kết nối tới chúng. Có thể hoàn tác.</p>`;
  } else if (SEL && SEL.k === 'f') {
    const f = T().flows.find(x => x.id === SEL.id); if (!f) { SEL = null; return edRender(); }
    const a = findD(f.from), b = findD(f.to);
    h += `<div class="typ">Đường liên kết</div><div class="fromto">${esc(short(a ? label(a.d) : '', 46))} → ${esc(short(b ? label(b.d) : '', 46))}</div>`;
    h += field('kind', 'Loại quan hệ', 'sel', Object.keys(FL_KIND).map(k => [k, FL_KIND[k]]), f.kind);
    h += field('label', 'Nhãn (động từ ngắn, ví dụ: làm tăng, cần cho)', '', null, f.label);
    h += `<div class="acts">${B('frev', 'Đảo chiều', '', 'swap')}${B('fdel', 'Xoá liên kết', 'bad', 'x')}</div>`;
  } else h += `<p class="note">Bấm vào một ý để sửa chữ, màu, biểu tượng, ảnh; thêm ý con, ý cùng cấp; nối liên kết hoặc xoá. Bấm vào một đường liên kết để đổi loại, sửa nhãn hoặc xoá. Nút tròn ở cạnh ô vẫn dùng để mở/thu nhánh.</p><p class="note">${MODE === 'html' ? 'Thay đổi lưu trên trình duyệt này. Muốn chuyển cho người khác: Xuất JSON, người nhận mở file HTML rồi Nhập JSON.' : 'Người xem chỉ thấy thay đổi sau khi anh/chị bấm <b>Lưu bản chung</b>.'}</p>`;
  ED.innerHTML = h + '</div>';
}
function setVal(p, v) {
  if (SEL.k === 'f') { const f = T().flows.find(x => x.id === SEL.id); if (f) f[p] = v; return; }
  const r = findD(SEL.id); if (!r) return;
  const ks = p.split('.'); let o = r.d; for (let i = 0; i < ks.length - 1; i++) o = o[ks[i]];
  const k = ks[ks.length - 1];
  if (k === 'dashed') { if (v) o.dashed = true; else delete o.dashed; } else if (v === '' && ['color', 'icon', 'img', 'tone'].indexOf(k) >= 0) delete o[k]; else o[k] = v;
}
function setEdit(on) {
  EDIT = !!on && CAN_EDIT && !isMx(); EDOPEN = false; PICK = null; if (!EDIT) SEL = null; MSG = null; CONFIRM = 0;
  markSel(); edRender(); if (M) { drawFlows(M); animate(M, fitView(M, 1.6)); }
}
function initEditor() {
  if (ED || !CAN_EDIT) return;
  ED = document.createElement('div'); ED.className = 'ed mini'; ED.id = 'ed'; ED.setAttribute('aria-label', 'Bảng chỉnh sửa sơ đồ');
  document.querySelector('main').appendChild(ED);
  ED.addEventListener('click', e => { const t = e.target.closest('[data-a]'); if (t && !t.disabled) act(t.dataset.a); });
  ED.addEventListener('change', e => {
    const t = e.target;
    if (t.matches && t.matches('[data-import]')) { importJson(t.files && t.files[0]); t.value = ''; return; }
    if (!t.dataset || !t.dataset.p || !SEL) return;
    mutate(() => setVal(t.dataset.p, t.type === 'checkbox' ? t.checked : t.value), true);
  });
  ED.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && ((e.target.tagName === 'INPUT' && e.target.type === 'text') || (e.target.tagName === 'TEXTAREA' && e.target.dataset.p === 't'))) { e.preventDefault(); e.target.blur(); } });
  edRender();
}

/* ---------- Lưu ---------- */
const hhmm = () => { const t = new Date(); return String(t.getHours()).padStart(2, '0') + ':' + String(t.getMinutes()).padStart(2, '0'); };
let lastLocal = 0;
function autosave() { if (MODE !== 'html') return; try { localStorage.setItem(LKEY, JSON.stringify({ rev: REV, savedAt: Date.now(), tabs: TABS })); DIRTY = false; toolsState(); } catch (e) {} }
function save() {
  if (BUSY) return;
  if (MODE === 'html') { autosave(); MSG = { c: 'ok', t: `Đã lưu trên trình duyệt này lúc ${hhmm()}.` }; edRender(); return; }
  if (!REMOTE) { MSG = { c: 'err', t: 'Trang này chưa có kho lưu chung nên chưa lưu được.' }; edRender(); return; }
  const json = JSON.stringify(TABS);
  if (new TextEncoder().encode(json).length > 900000) { MSG = { c: 'err', t: 'Sơ đồ quá lớn để lưu chung; nên tách bớt tab hoặc bỏ ảnh nhúng.' }; edRender(); return; }
  BUSY = 'save'; MSG = null; edRender(); if (isMx()) renderMatrix();
  lastLocal = Date.now();
  REMOTE.set({ json, rev: REV, savedAt: lastLocal }).then(() => { BUSY = false; DIRTY = false; MSG = { c: 'ok', t: `Đã lưu bản chung lúc ${hhmm()}. Người xem thấy bản mới khi mở hoặc tải lại.` }; edRender(); if (isMx()) { MXMSG = MSG; renderMatrix(); } })
    .catch(() => { BUSY = false; MSG = { c: 'err', t: 'Chưa lưu được. Anh/chị thử lại.' }; edRender(); if (isMx()) { MXMSG = MSG; renderMatrix(); } });
}
function reset() {
  if (BUSY) return;
  if (!CONFIRM) { CONFIRM = 1; edRender(); setTimeout(() => { if (CONFIRM) { CONFIRM = 0; edRender(); } }, 5000); return; }
  CONFIRM = 0; UNDO.push(snap()); REDO = [];
  TABS = prep(JSON.parse(ORIG)); Object.keys(MAPS).forEach(k => delete MAPS[k]); SEL = null; PICK = null;
  if (MODE === 'html') { try { localStorage.removeItem(LKEY); } catch (e) {} DIRTY = false; MSG = { c: 'ok', t: 'Đã khôi phục sơ đồ gốc trên trình duyệt này.' }; }
  else { DIRTY = true; MSG = { c: 'ok', t: 'Đã đưa về sơ đồ gốc. Bấm Lưu bản chung để áp dụng cho mọi người (hoặc Hoàn tác).' }; }
  dropM(); show(cur);
}
function exportJson() {
  const blob = new Blob([JSON.stringify({ engine: ENGINE, id: MAP_ID, rev: REV, tabs: TABS }, null, 1)], { type: 'application/json' }), name = MAP_ID + '.json';
  const fallback = () => { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500); };
  const c = window.claude;
  if (MODE !== 'html' && c && typeof c.use === 'function') c.use('downloads').then(dl => dl ? dl.save({ filename: name, data: blob }) : fallback()).catch(() => {});
  else fallback();
}
function importJson(f) {
  if (!f) return;
  f.text().then(s => { const o = JSON.parse(s); const tabs = o && o.tabs; if (!Array.isArray(tabs) || tabs.length !== CFG.tabs.length) throw 0; mutate(() => { TABS = prep(tabs); Object.keys(MAPS).forEach(k => delete MAPS[k]); }); MSG = { c: 'ok', t: 'Đã nhập sơ đồ từ file JSON.' }; edRender(); })
    .catch(() => { MSG = { c: 'err', t: 'File JSON không đúng sơ đồ này.' }; edRender(); });
}
function toast(t) { const d = document.createElement('div'); d.className = 'toast'; d.textContent = t; document.querySelector('main').appendChild(d); setTimeout(() => d.remove(), 2600); }
async function initRemote() {
  const c = window.claude; if (MODE === 'html' || !c || typeof c.use !== 'function') return;
  try {
    const [db, user] = await Promise.all([c.use('db'), c.use('user')]);
    if (user && typeof user.isOwner === 'function') { try { CAN_EDIT = !!(await user.isOwner()); } catch (e) { CAN_EDIT = false; } }
    if (CAN_EDIT) initEditor();
    if (!db) return;
    const ref = db.doc('maps/' + MAP_ID);
    REMOTE = ref;
    const apply = d => { if (!d || d.rev !== REV || !d.json || (d.savedAt || 0) <= lastLocal) return false; let t = null; try { t = JSON.parse(d.json); } catch (e) { return false; } if (!adoptTabs(t)) return false; lastLocal = d.savedAt; dropM(); show(cur); return true; };
    const sn = await Promise.race([ref.get(), new Promise((_, rej) => setTimeout(() => rej(0), 10000))]);
    if (sn && sn.exists) apply(sn.data());
    if (ref.onSnapshot) ref.onSnapshot(s => { if (!s.exists || DIRTY || EDIT) return; if (apply(s.data())) toast('Đã cập nhật bản chung mới nhất'); }, () => {});
  } catch (e) {}
}

/* ---------- Ma trận trên hệ trục ---------- */
let MXQ = null, MXED = false, MXMSG = null;
function renderMatrix() {
  const tab = T(), box = document.getElementById('matrix'), X = tab.x.levels || [], Y = tab.y.levels || [], R = Y.length, C = X.length;
  const occ = []; for (let r = 0; r < R; r++) occ.push(new Array(C).fill(false));
  tab.cells.forEach(c => { const x = c.x || [0, 0], y = c.y || [0, 0]; for (let i = y[0]; i <= y[1]; i++) for (let j = x[0]; j <= x[1]; j++) if (occ[i] && j < C) occ[i][j] = true; });
  const pos = c => { const x = c.x || [0, 0], y = c.y || [0, 0]; return `grid-column:${x[0] + 1}/${x[1] + 2};grid-row:${R - y[1]}/${R - y[0] + 1}`; };
  const empty = c => !(c.sections || []).some(s => s.t || (s.list || []).length) && !(c.items || []).length;
  const cell = c => {
    const e = empty(c), im = safeUrl(c.img);
    return `<button type="button" class="mx2-c${e ? ' blank' : ''}" style="--qc:${cv(c.color || 'gx')};${pos(c)}" data-q="${esc(c.id)}">
      <span class="hd">${P[c.icon] ? `<span class="ci">${ico(c.icon)}</span>` : ''}<span class="nm">${esc(c.name)}</span></span>${c.axis ? `<span class="ax">${esc(c.axis)}</span>` : ''}${im ? `<img class="im" alt="" src="${esc(im)}">` : ''}
      <span class="nt">${e ? (EDITABLE() ? 'Chưa có nội dung · bấm để nhập' : 'Chưa có nội dung') : (c.items || []).length ? c.items.length + ' mục' : 'Bấm để xem chi tiết'}</span></button>`;
  };
  let free = '';
  if (EDITABLE()) for (let r = 0; r < R; r++) for (let j = 0; j < C; j++) if (!occ[r][j]) free += `<button type="button" class="mx2-c add" style="--qc:var(--gx);grid-column:${j + 1};grid-row:${R - r}" data-add="${j},${r}">+ Thêm ô (${esc(Y[r])} × ${esc(X[j])})</button>`;
  let big = '';
  const c = MXQ && tab.cells.find(x => x.id === MXQ);
  if (c) {
    if (MXED) {
      const f = (p, lab, v, ta) => `<label>${lab}${ta ? `<textarea data-m="${p}" rows="3">${esc(v || '')}</textarea>` : `<input type="text" data-m="${p}" value="${esc(v || '')}">`}</label>`;
      const sel = (p, lab, opt, v) => `<label>${lab}<select data-m="${p}">${opt.map(([k, t]) => `<option value="${esc(k)}"${k === (v || '') ? ' selected' : ''}>${esc(t)}</option>`).join('')}</select></label>`;
      const secs = (c.sections || []).concat([{ h: '', t: '' }]).map((s, i) => `<div class="grp">${f('s' + i + 'h', 'Tiêu đề mục ' + (i + 1) + (i === c.sections.length ? ' (mục mới, để trống nếu không cần)' : ''), s.h)}${f('s' + i + 't', 'Nội dung (gạch đầu dòng: mỗi dòng bắt đầu bằng "- ")', s.list ? s.list.map(x => '- ' + x).join('\n') : s.t, 1)}</div>`).join('');
      big = `<div class="quad mx2-big" style="--qc:${cv(c.color || 'gx')}"><div class="qh"><b>${esc(c.name)}</b><button type="button" class="mx2-x" data-mx="close" aria-label="Thu nhỏ">✕</button></div>
        <div class="mx2-form">${f('name', 'Tên ô', c.name)}${f('axis', 'Dòng phụ (ví dụ: Tần suất CAO × Rủi ro THẤP)', c.axis)}${sel('color', 'Màu', COLOR_OPT.slice(1), c.color)}${sel('icon', 'Biểu tượng', ICON_OPT, c.icon)}${f('img', 'Ảnh minh hoạ (https://… hoặc data:image)', c.img)}${secs}${f('items', 'Mục trong ô (mỗi dòng một mục)', (c.items || []).map(x => typeof x === 'string' ? x : x.t).join('\n'), 1)}
        <div class="acts"><button type="button" class="b pri" data-mx="apply">Xong</button><button type="button" class="b" data-mx="cancel">Huỷ</button><button type="button" class="b" data-mx="delcell" style="margin-left:auto;color:var(--bad)">Xoá ô</button></div></div></div>`;
    } else {
      const st = EDITABLE() && (DIRTY || MXMSG) ? `<div class="mx2-st${MXMSG && MXMSG.c ? ' ' + MXMSG.c : ''}">${MXMSG ? esc(MXMSG.t) : 'Có thay đổi chưa lưu.'}${DIRTY ? `<button type="button" class="b pri" data-mx="save"${BUSY ? ' disabled' : ''}>${BUSY === 'save' ? 'Đang lưu…' : SAVE_LABEL}</button>` : ''}</div>` : '';
      const secs = (c.sections || []).filter(s => s.t || (s.list || []).length);
      const its = (c.items || []).map(x => typeof x === 'string' ? { t: x } : x).map(x => `<span class="it" style="--c:${x.color ? cv(x.color) : cv(c.color || 'gx')}">${esc(x.t)}</span>`).join('');
      big = `<div class="quad mx2-big" style="--qc:${cv(c.color || 'gx')}"><div class="qh" data-mx="close" title="Bấm để thu nhỏ"><b>${esc(c.name)}</b>${c.axis ? `<span>${esc(c.axis)}</span>` : ''}<button type="button" class="mx2-x" data-mx="close" aria-label="Thu nhỏ">✕</button></div>${st}
        ${safeUrl(c.img) ? `<div class="qe"><img class="im" alt="" src="${esc(safeUrl(c.img))}"></div>` : ''}
        ${!secs.length && !its ? `<div class="qe"><p class="mx2-none">Ô này chưa có nội dung.${EDITABLE() ? ' Bấm “Sửa nội dung” để nhập.' : ''}</p></div>` : ''}
        ${secs.length ? `<div class="qb">${secs.map(s => `<div><h5>${esc(s.h || '')}</h5>${(s.list || []).length ? `<ul>${s.list.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : `<p>${esc(s.t)}</p>`}</div>`).join('')}</div>` : ''}
        ${its ? `<div class="qm"><h5>${esc(tab.itemsTitle || 'Mục trong ô')}</h5><div class="its">${its}</div></div>` : ''}
        ${EDITABLE() ? `<div class="qe mx2-ed"><button type="button" class="b" data-mx="edit">${ico('pen', 2.2)}Sửa nội dung</button></div>` : '<div></div>'}</div>`;
    }
  }
  const yl = Y.slice().reverse();
  box.innerHTML = `<div class="mx-wrap"><div class="mx-head"><div><h2>${esc(tab.title || tab.label || 'Ma trận')}</h2><p class="ds">${esc(tab.desc || `Trục tung: ${tab.y.title}. Trục hoành: ${tab.x.title}. Bấm vào một ô để phóng to, bấm lần nữa để thu nhỏ.`)}</p></div></div>
    <div class="mx2" style="--rows:${R}"><div class="mx2-y k" aria-hidden="true"><span class="t">${esc(tab.y.title)} →</span><span class="yl">${yl.map(v => `<i>${esc(v)}</i>`).join('')}</span></div>
      <div class="mx2-g${MXQ ? ' open' : ''}" style="grid-template-columns:repeat(${C},minmax(0,1fr));grid-template-rows:repeat(${R},minmax(150px,auto))">${tab.cells.map(cell).join('')}${free}${big}</div>
      <div></div><div class="mx2-h" aria-hidden="true"><div class="lv" style="grid-template-columns:repeat(${C},1fr)">${X.map(x => `<span>${esc(x)}</span>`).join('')}</div><div class="t">${esc(tab.x.title)} →</div></div>
    </div></div>`;
  const g = box.querySelector('.mx2-g'), bg = box.querySelector('.mx2-big'); if (g && bg) g.style.minHeight = Math.max(400, bg.scrollHeight) + 'px';
  if (MXED) { const i = box.querySelector('[data-m]'); if (i) i.focus(); }
}
const EDITABLE = () => CAN_EDIT;
document.getElementById('matrix').addEventListener('click', e => {
  const tab = T(), c = e.target.closest('.mx2-c[data-q]'), add = e.target.closest('[data-add]'), a = e.target.closest('[data-mx]');
  if (add && EDITABLE()) {
    const [j, r] = add.dataset.add.split(',').map(Number);
    UNDO.push(snap()); REDO = [];
    const nc = { id: newId(), name: 'Ô mới', axis: `${tab.y.title}: ${tab.y.levels[r]} × ${tab.x.title}: ${tab.x.levels[j]}`, color: 'gx', x: [j, j], y: [r, r], sections: [], items: [] };
    tab.cells.push(nc); DIRTY = true; MXQ = nc.id; MXED = true; MXMSG = null; renderMatrix(); autosave(); return;
  }
  if (c) { MXQ = MXQ === c.dataset.q ? null : c.dataset.q; MXED = false; MXMSG = null; renderMatrix(); return; }
  if (!a) return;
  const v = a.dataset.mx, cell = tab.cells.find(x => x.id === MXQ);
  if (v === 'close') { MXQ = null; MXED = false; MXMSG = null; }
  else if (v === 'edit') { MXED = true; MXMSG = null; }
  else if (v === 'cancel') MXED = false;
  else if (v === 'delcell' && cell) { UNDO.push(snap()); REDO = []; tab.cells = tab.cells.filter(x => x !== cell); DIRTY = true; MXQ = null; MXED = false; autosave(); }
  else if (v === 'apply' && cell) {
    const box = document.getElementById('matrix'), val = p => { const el = box.querySelector(`[data-m="${p}"]`); return el ? el.value : ''; };
    UNDO.push(snap()); if (UNDO.length > 80) UNDO.shift(); REDO = [];
    cell.name = val('name').trim() || cell.name; cell.axis = val('axis').trim();
    ['color', 'icon', 'img'].forEach(k => { const x = val(k).trim(); if (x) cell[k] = x; else delete cell[k]; });
    const secs = []; for (let i = 0; i <= (cell.sections || []).length; i++) {
      const h = val('s' + i + 'h').trim(), t = val('s' + i + 't').trim(); if (!h && !t) continue;
      const lines = t.split('\n').map(s => s.trim()).filter(Boolean);
      if (lines.length && lines.every(l => /^[-•*]\s*/.test(l))) secs.push({ h, list: lines.map(l => l.replace(/^[-•*]\s*/, '')) }); else secs.push({ h, t });
    }
    cell.sections = secs;
    const old = cell.items || [];
    cell.items = val('items').split('\n').map(s => s.trim()).filter(Boolean).map(t => { const o = old.find(x => (typeof x === 'string' ? x : x.t) === t); return o || t; });
    DIRTY = true; MXED = false; MXMSG = null; autosave();
  } else if (v === 'save') { MXMSG = null; save(); return; }
  renderMatrix();
});
function fitMatrix() {}

/* ---------- Sự kiện ---------- */
document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => show(+t.dataset.i)));
document.getElementById('b-next').onclick = () => next();
document.getElementById('b-prev').onclick = () => prev();
document.getElementById('b-all').onclick = () => all(true);
document.getElementById('b-none').onclick = () => all(false);
document.getElementById('b-fit').onclick = () => animate(M, fitView(M, 1.6));
document.getElementById('b-auto').onclick = () => { if (!M) return; const f = () => { clearOff(T().root); (T().flows || []).forEach(x => { delete x.bx; delete x.by; }); }; if (CAN_EDIT) mutate(f); else { f(); layout(M); animate(M, fitView(M, 1.6)); } };
const zoomBy = (f, cx, cy) => { const W = stage.clientWidth, H = stage.clientHeight; cx = cx == null ? W / 2 : cx; cy = cy == null ? H / 2 : cy; const s = Math.max(0.15, Math.min(3, view.s * f)), k = s / view.s; view.x = cx - (cx - view.x) * k; view.y = cy - (cy - view.y) * k; view.s = s; applyView(); };
document.getElementById('b-in').onclick = () => zoomBy(1.25);
document.getElementById('b-out').onclick = () => zoomBy(0.8);
document.getElementById('b-fs').onclick = () => { try { if (document.fullscreenElement) document.exitFullscreen(); else { const r = document.documentElement.requestFullscreen && document.documentElement.requestFullscreen(); if (r && r.catch) r.catch(() => {}); } } catch (e) {} };
const ptr = new Map(); let drag = null, pinch = null, lpTimer = null, viewerNote = false;
const toWorld = (cx, cy) => { const r = stage.getBoundingClientRect(); return { x: (cx - r.left - view.x) / view.s, y: (cy - r.top - view.y) / view.s }; };
function nodeOf(t) { const el = t && t.closest && t.closest('.n'); return el && M ? M.nodes.find(k => k.el === el) : null; }
function startNodeDrag(n) {
  drag.mode = 'node'; drag.n = n; drag.ox = +n.d.ox || 0; drag.oy = +n.d.oy || 0; drag.snap = CAN_EDIT ? snap() : null;
  n.el.classList.add('dragging'); stage.classList.add('drag');
  if (navigator.vibrate) try { navigator.vibrate(12); } catch (e) {}
}
stage.addEventListener('pointerdown', e => {
  if (e.button !== 0 && e.pointerType === 'mouse') return;
  ptr.set(e.pointerId, { x: e.clientX, y: e.clientY }); try { stage.setPointerCapture(e.pointerId); } catch (er) {}
  clearTimeout(lpTimer);
  if (ptr.size === 1) {
    drag = { x: e.clientX, y: e.clientY, vx: view.x, vy: view.y, moved: false, target: e.target, mode: 'pan', touch: e.pointerType === 'touch' };
    const hd = e.target.closest && e.target.closest('.flk');
    const n = !hd && !(e.target.closest && e.target.closest('.tg')) ? nodeOf(e.target) : null;
    if (hd && EDIT) { const f = T().flows.find(x => x.id === hd.dataset.fid); if (f) { drag.mode = 'flow'; drag.h = hd.dataset.h; drag.f = f; drag.bx = +f.bx || 0; drag.by = +f.by || 0; drag.snap = snap(); } }
    else if (n && n.parent) { drag.cand = n; if (drag.touch) lpTimer = setTimeout(() => { if (drag && !drag.moved && drag.cand === n) { drag.moved = true; startNodeDrag(n); } }, 450); }
  } else if (ptr.size === 2) { const [a, b] = [...ptr.values()]; pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), s: view.s }; if (drag && drag.n) drag.n.el.classList.remove('dragging'); drag = null; }
});
stage.addEventListener('pointermove', e => {
  if (!ptr.has(e.pointerId)) return; ptr.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (pinch && ptr.size === 2) { const [a, b] = [...ptr.values()], r = stage.getBoundingClientRect(); zoomBy((pinch.s * Math.hypot(a.x - b.x, a.y - b.y) / pinch.d) / view.s, (a.x + b.x) / 2 - r.left, (a.y + b.y) / 2 - r.top); return; }
  if (!drag) return;
  const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
  if (!drag.moved && Math.hypot(dx, dy) > (drag.touch ? 8 : 4)) {
    drag.moved = true; clearTimeout(lpTimer);
    if (drag.cand && !drag.touch) startNodeDrag(drag.cand);
    else if (drag.mode === 'pan') stage.classList.add('drag');
  }
  if (!drag.moved) return;
  if (drag.mode === 'pan') { view.x = drag.vx + dx; view.y = drag.vy + dy; applyView(); }
  else if (drag.mode === 'node') { drag.n.d.ox = Math.round(drag.ox + dx / view.s); drag.n.d.oy = Math.round(drag.oy + dy / view.s); layout(M); renderNow(M); }
  else if (drag.mode === 'flow') {
    if (drag.h === 'bend') { drag.f.bx = Math.round(drag.bx + 2 * dx / view.s); drag.f.by = Math.round(drag.by + 2 * dy / view.s); FTMP = null; }
    else { const w = toWorld(e.clientX, e.clientY), other = M.byId.get(drag.h === 'to' ? drag.f.from : drag.f.to); if (other && other.cur) FTMP = { a: { x: other.cur.x + other.w / 2, y: other.cur.y + other.h / 2 }, b: w }; }
    drawFlows(M);
  }
});
const up = e => {
  if (!ptr.has(e.pointerId)) return; ptr.delete(e.pointerId); clearTimeout(lpTimer);
  if (drag && e.type === 'pointerup' && M) {
    if (!drag.moved) {
      if (EDIT) edClick(drag.target);
      else { const n = nodeOf(drag.target); if (n) toggle(n); }
    } else if (drag.mode === 'node') {
      drag.n.el.classList.remove('dragging');
      if (CAN_EDIT) { UNDO.push(drag.snap); if (UNDO.length > 80) UNDO.shift(); REDO = []; DIRTY = true; MSG = null; toolsState(); edRender(); autosave(); }
      else if (!viewerNote) { viewerNote = true; toast('Vị trí vừa kéo chỉ giữ tạm trên màn hình của anh/chị'); }
    } else if (drag.mode === 'flow') {
      if (drag.h !== 'bend') {
        FTMP = null;
        const el = document.elementFromPoint(e.clientX, e.clientY), n = nodeOf(el), f = drag.f, other = drag.h === 'to' ? f.from : f.to;
        if (n && n.d.id !== other) { f[drag.h] = n.d.id; }
      }
      UNDO.push(drag.snap); REDO = []; DIRTY = true; MSG = null; edRender(); autosave(); drawFlows(M);
    }
  }
  if (ptr.size < 2) pinch = null; if (!ptr.size) { drag = null; stage.classList.remove('drag'); }
};
stage.addEventListener('pointerup', up); stage.addEventListener('pointercancel', up);
stage.addEventListener('wheel', e => { e.preventDefault(); const r = stage.getBoundingClientRect(); if (e.ctrlKey || Math.abs(e.deltaY) >= Math.abs(e.deltaX)) zoomBy(Math.exp(-e.deltaY * (e.ctrlKey ? 0.01 : 0.0015)), e.clientX - r.left, e.clientY - r.top); else { view.x -= e.deltaX; applyView(); } }, { passive: false });
stage.addEventListener('keydown', e => { if (e.key === 'Enter' && document.activeElement && document.activeElement.classList.contains('n') && M) { const n = M.nodes.find(k => k.el === document.activeElement); if (n) toggle(n); } });
document.addEventListener('keydown', e => {
  if (e.target.closest && e.target.closest('input,textarea,select')) return;
  if (EDIT) {
    const k = e.key.toLowerCase();
    if ((e.ctrlKey || e.metaKey) && k === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
    if ((e.ctrlKey || e.metaKey) && k === 'y') { e.preventDefault(); redo(); return; }
    if (e.key === 'Escape') { if (PICK) PICK = null; else SEL = null; markSel(); if (M) drawFlows(M); edRender(); return; }
    if ((e.key === 'Delete' || e.key === 'Backspace') && SEL) { e.preventDefault(); act(SEL.k === 'f' ? 'fdel' : 'del'); return; }
  }
  if (isMx()) { if (e.key === 'Escape' && MXQ && !MXED) { MXQ = null; renderMatrix(); } return; }
  if (!M) return;
  if (e.key === 'ArrowRight' || e.key === 'PageDown' || (e.key === ' ' && !e.target.closest('button'))) { e.preventDefault(); next(); }
  else if (e.key === 'ArrowLeft' || e.key === 'PageUp') { e.preventDefault(); prev(); }
  else if (e.key === '0') animate(M, fitView(M, 1.6));
  else if (e.key === '+' || e.key === '=') zoomBy(1.25);
  else if (e.key === '-') zoomBy(0.8);
  else if (e.key === 'f' || e.key === 'F') document.getElementById('b-fs').click();
  else if (/^[1-9]$/.test(e.key) && +e.key <= TABS.length) show(+e.key - 1);
});
let rt; window.addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(() => { if (!isMx() && M) animate(M, fitView(M)); }, 150); });

/* ---------- Khởi động ---------- */
if (CAN_EDIT) initEditor();
const h0 = /^#tab-(\d+)$/.exec(location.hash || '');
show(h0 ? +h0[1] - 1 : 0);
if (MODE === 'html') { try { if (localStorage.getItem(LKEY)) toast('Đã mở bản lưu trên trình duyệt này'); } catch (e) {} }
initRemote();
const fr = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve();
fr.then(() => { Object.values(MAPS).forEach(m => { if (m === M && !isMx()) { measure(m); layout(m); animate(m, fitView(m)); } else m.view = null; }); });
})();
