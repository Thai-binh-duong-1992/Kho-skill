> Tệp tra cứu của skill sang-tac-tho: phần "Gợi ý phổ nhạc" đặt cuối mỗi lần bàn giao. Mọi ý đều lấy từ `thi-luat.md` (12.2, 12.4, 12.7). Nhãn giữ như nguồn: [BC] có bằng chứng · [QU] quy ước/suy luận.

# Gợi ý phổ nhạc cho bài thơ vừa viết

## 1. Mục đích và giới hạn

Phần này chỉ là **ghi chú định hướng**, dài 5–8 dòng, giúp người dùng hoặc nhạc sĩ có điểm khởi đầu. Phần này **không** có giai điệu, hợp âm hay prompt cho công cụ AI. Những việc đó thuộc skill **sang-tac-va-phoi-khi**. Nếu skill đó đã được cài, câu cuối của phần này mời người dùng gọi nó, ví dụ: "phổ nhạc bài thơ này".

## 2. Năm mục cần ghi, mỗi mục một dòng

1. **Thể loại hợp với thể thơ.** Lấy từ cột "Dùng trong ca khúc / dân ca" ở 12.2, giữ nguyên nhãn. Ví dụ: lục bát hợp dân ca, điệu lý, hát ru [BC]; khổ 4 câu Thơ Mới hợp ballad tiền chiến [QU].
2. **Nhịp thơ sang ô nhịp.** Dùng bảng 12.4, ghi nhãn [QU] vì đây là suy luận. Ví dụ: câu lục nhịp 2/2/2 chiếm khoảng 1,5–2 ô; chữ 6 và chữ 8 câu bát ngân dài.
3. **Câu đinh làm điệp khúc.** Chọn một câu hoặc cụm có thể lặp lại làm điệp khúc. Lý do: lời ca chỉ nên có một điểm nhấn [BC, Hứa Kim Tuyền].
4. **Chỗ cần sửa khi thơ thành lời ca.** Đối chiếu bảng "Thơ và lời ca khác nhau ở năm điểm" (12.7). Đánh dấu chữ Hán Việt khó nghe, câu quá dày hình ảnh, và vần khép (-p, -t, -c, -ch) ở cuối câu dễ bị đặt nốt ngân.
5. **Cảnh báo "có sẵn nhạc".** Khi bài là lục bát chặt, ghi nhận định của Đăng Khánh [BC]: lục bát có sẵn giai điệu và vần, nên nhạc sĩ dễ chỉ "ghi lại". Nên chủ động phân câu theo quy luật âm nhạc.

## 3. Ghi chú quyền tác giả

Phần này chỉ ghi trong tài liệu đầu ra, không làm gián đoạn việc sáng tác.

- Người dùng là tác giả chính: người dùng đưa ra ý tưởng và chi tiết thật, rồi chọn lựa, sửa và duyệt bản cuối. Claude là người hỗ trợ.
- Khi phổ nhạc, ghi "Thơ: (tên người dùng)".
- Việc bảo hộ tác phẩm có AI hỗ trợ tuỳ quy định của từng nước. Trước khi đăng ký hoặc phát hành thương mại, tra `17-phap-ly-phat-hanh.md` của skill sang-tac-va-phoi-khi, hoặc hỏi luật sư.
