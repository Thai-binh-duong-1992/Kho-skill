> **Ghi chú cho skill sang-tac-tho:** tệp này là bản sao nguyên văn tệp `12-thi-luat.md` (bản 2.2) của skill sang-tac-va-phoi-khi, giữ nguyên để không lệch nguồn. Số mục "12.x" giữ như gốc. Các tệp nhắc tới mà skill này không có (`ngon-ngu/vi.md`, `dem-am-tiet.py`, `kiem-tra-thanh-nhac.py`, `04-giong-hat.md`, `07-loi-ca.md`, `17-phap-ly-phat-hanh.md`) thuộc skill sang-tac-va-phoi-khi, chỉ cần khi phổ nhạc. Khi sáng tác thơ, dùng các mục 12.1–12.3, 12.5, 12.8 (V1–V11, V13), 12.11; mục 12.4, 12.7, 12.10 dùng cho gợi ý phổ nhạc.

> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Thi luật cho lời ca Việt: vần, thể thơ, luật theo vị trí chữ, nhịp thơ → ô nhịp, tu từ, rap, phổ thơ, bộ kiểm tra V1–V16, mẫu yêu cầu, khung lời theo làn điệu (12.10), thể ngoài phạm vi lời ca (12.11). C4 = Đô giữa. Nhãn: [BC] có bằng chứng · [QU] quy ước thực hành/suy luận · [Suy luận từ nhiều nguồn] gộp từ nhiều nguồn, chưa phải quy chuẩn công bố · [Cần kiểm chứng].

# 12. Thi luật cho lời ca

**Quy tắc ưu tiên nguồn:** khi quy tắc đã kiểm chứng và quy tắc chưa kiểm chứng xung đột nhau, **dùng quy tắc đã kiểm chứng**. Mọi điểm [Cần kiểm chứng] chỉ được dùng làm ghi chú, không dùng làm quy tắc chấm lỗi.

**Hai lưới khác nhau, lời ca phải qua cả hai:**

| Câu hỏi | Lưới | Chia thanh | Tệp |
|---|---|---|---|
| **Thi luật** (số chữ, vị trí luật, vần, nhịp) | Bằng–trắc | Bằng: ngang, huyền · Trắc: sắc, hỏi, ngã, nặng | Tệp này |
| **Cao độ hát** (hướng nốt) | Nhóm thanh theo điểm kết thúc (Ladd & Kirby) | Cao: sắc, ngã · Trung: ngang · Thấp: huyền · Rất thấp: hỏi, nặng | `ngon-ngu/vi.md` (T1–T10, N1–N9) |

**Bằng/trắc KHÔNG dùng để đặt cao độ.** Đúng luật cho "chất thơ" và dễ nhớ; đúng cao độ để người nghe không nghe nhầm chữ.

**Ký hiệu:** **B** = bằng · **T** = trắc · **V** = vị trí gieo vần · **–** = tự do.

**Giới hạn nguồn:** vi.wikipedia, thivien.net, js.vnu.edu.vn và nhiều trang soạn bài không truy cập được trong phiên nghiên cứu; SGK tiếp cận qua tài liệu soạn bài, đề cương trường học. Sách gốc (Bùi Văn Nguyên & Hà Minh Đức, *Thơ ca Việt Nam, hình thức và thể loại*; Lê Bá Hán – Trần Đình Sử – Nguyễn Khắc Phi, *Từ điển thuật ngữ văn học*; Mai Ngọc Chừ, Nguyễn Phan Cảnh, Lam Giang) chỉ tiếp cận gián tiếp. [Cần kiểm chứng] dùng cho bảng dựng lại từ quy tắc hoặc kiến thức giáo khoa chưa đối chiếu nguyên văn.

**Bổ sung 11/2026 (rà soát đủ thể thơ):** bản PDF *Việt Nam văn học sử yếu* (DQH) chỉ trích được khoảng tr. 1–34 (lời tựa, ca dao); các chương về thể văn chỉ được xác nhận gián tiếp qua bài báo có dẫn số trang. Bài KoreaScience về hát nói là bản tiếng Anh, thuật ngữ đã qua dịch. Bài HCMUE có số thứ tự trích dẫn không khớp danh mục, nên nhận định gán cho Lam Giang, Nguyễn Phan Cảnh cần kiểm lại tác giả gốc. Nguồn mới dùng ở 12.2, 12.3, 12.10, 12.11:
- Nguyễn Bảo Lan 2025 (lý Nam Bộ): https://vjol.info.vn/tcgiaoducnghethuat/article/view/138938 · PDF: https://vjol.info.vn/tcgiaoducnghethuat/article/download/138938/113570/
- Ngô Thị Thanh Hằng 2012 (từ đệm quan họ): https://vjol.info.vn/index.php/NNDS/article/download/16443/14728
- Viện Âm nhạc, Nguyễn Trung 2019 (đặt lời mới quan họ): https://www.vienamnhac.vn/heritage/quan-ho-singing/articles/exploiting-and-using-ancient-features-of-quan-ho-singing-for-new-songs
- Báo Nghệ An (ví giặm): https://baonghean.vn/en/doi-net-ve-dan-ca-vi-giam-nghe-tinh-10267292.html
- Nguyễn Duy Cường 2025, VASS (ví giặm): https://storage-vnportal.vnpt.vn/vass/5927/FileQuanTriTinTuc/Dân%20ca%20ví%20giặm%20Nghệ%20Tĩnh.pdf
- Nguyễn Nhã Bản & Phan Xuân Đạm 2015 (giặm, ví, "giặm vè"): https://vjol.info.vn/index.php/NNDS/article/download/21533/18403
- RFA, soạn giả Nguyễn Phương 2006 (vọng cổ): https://www.rfa.org/vietnamese/news/programs/TraditionalMusic/OldVongCoWith2-8-32Beats_NPhuong-20060319.html
- Đỗ Quốc Dũng 2019 (vọng cổ nhịp 32): https://vjol.info.vn/vhu/article/view/55507
- Wikipedia: Vọng cổ: https://en.wikipedia.org/wiki/V%E1%BB%8Dng_c%E1%BB%95
- Đào Thị Như Mì 2025 (nói lối, hát Nam hát bội): https://vjol.info.vn/tcvanhoanghethuat/article/download/138718/113396/
- UNESCO ICH, bài chòi: https://ich.unesco.org/en/RL/art-of-bai-choi-in-central-viet-nam-01222
- Nguyễn Quốc Khánh 2021 (lục bát, biến thể, hát ru, hò lao động): https://vjol.info.vn/index.php/khxhvn/article/download/75412/64136/
- ĐH Long An 2024 (Đường luật, dẫn *Từ điển thuật ngữ văn học* tr. 265): https://tcktcn.daihoclongan.edu.vn/index.php/ktcn/article/download/362/59/608
- Lê Thị Huyền Trang 2019 (niêm *Qua Đèo Ngang*, nhịp *Tự thán*, Hàn luật theo Lã Nhâm Thìn): https://js.vnu.edu.vn/FS/article/view/4428/4079
- Trần Trọng Dương 2013 (câu sáu chữ *Quốc âm thi tập*): https://storage-vnportal.vnpt.vn/vass/hannom/images_upload/pdf_2264.pdf
- VnExpress 2005 (Hàn luật): https://vnexpress.net/nguyen-thuyen-va-van-hoc-nom-1974289.html
- Dương Quảng Hàm, *Việt Nam văn học sử yếu* (lục bát biến thức, nói lối): https://thuvienlamdong.org.vn/Files/Books/73521.pdf
- Võ Thị Ngọc Thúy và cộng sự 2025, ĐHSP Huế (thủ vĩ ngâm, thể hiếm): https://tckhgd.dhsphue.edu.vn/index.php/jse/article/download/53/41/142
- Hà Xuân Hương 2018 (thơ Tày): https://tckh.daihoctantrao.edu.vn/index.php/sjttu/article/download/201/126/324
- Lê Thị Thanh Hồng & Trần Văn Tuấn 2017, ĐH Đồng Tháp (vè): https://dthujs.vn/index.php/dthujs/article/download/700/630/1272
- Nguyễn Thị Thanh Nguyên & Huỳnh Sơn Lâm 2023 (thơ 8 chữ): https://dthujs.vn/index.php/dthujs/article/download/1292/1200
- Asian Cha 2014 (Tân hình thức): https://www.asiancha.com/content/view/1659/437/ · Nguyễn Thị Tuyết 2020: https://vjol.info.vn/vhu/article/view/55440
- Triều Nguyên 2018 (biền văn): https://js.vhu.edu.vn/index.php/vhujs/article/download/115/23/42 · Nguyễn Thị Hải Vân 2025 (phú): https://vjol.info.vn/hannom/article/download/139851/114362/ · VietJack (văn tế): https://vietjack.com/ngu-van-11/van-te-nghia-si-can-giuoc.jsp

Tệp liên quan: `ngon-ngu/vi.md` · `13-nghe-viet-loi.md` (L1–L12) · `07-loi-ca.md` · `17-phap-ly-phat-hanh.md`.

---

## 12.1. Vần: phần vần + nhóm thanh

### Cấu trúc âm tiết [BC]

- Âm tiết tối đa 5 thành phần, hai bậc. **Thanh điệu phủ toàn âm tiết.** Bậc dưới: âm đầu + **vần**; **vần = âm đệm + âm chính + âm cuối**.
- Mỗi thành phần phân biệt nghĩa: *toán/toàn* (thanh), *toán/hoán* (âm đầu), *toán/tán* (âm đệm), *túy/túi* (âm chính), *bàn/bài* (âm cuối) (Mai Ngọc Chừ 1997, qua ngonngu.net).
- Khi hiệp vần **không tính âm đầu**. Hai tiếng hiệp vần giống hoặc gần nhau ở phần vần (nhất là âm chính + âm cuối), **phải cùng nhóm bằng hoặc trắc, không cần cùng thanh**.
- **Vần giàu**: cùng nhóm thanh, cùng nguyên âm (*xanh/cành*). **Vần nghèo**: cùng nhóm thanh, nguyên âm hơi khác (*thêu/trèo*). Vần bằng: êm, nhẹ; vần trắc: gồ ghề, động (Huỳnh Sanh Thông 1996, qua Wikipedia).

### Bảng thuật ngữ vần

| Thuật ngữ | Định nghĩa thực hành | Ví dụ | Nhãn |
|---|---|---|---|
| **Vần chính** (vần giàu, vần chỉnh) | Trùng âm chính và âm cuối, cùng nhóm thanh | xanh/cành; mây/bay | "Vần giàu" [BC]; tên "vần chính" [QU] |
| **Vần thông** (vần nghèo, vần gần) | Cùng nhóm thanh; phần vần (bỏ âm đệm) không trùng nhưng gần: **âm cuối cùng nhóm** {n, ng, nh} · {t, c, ch} · {m} · {p}, hoặc cùng không có phụ âm cuối; và **chữ nguyên âm cuối của phần vần cùng nhóm** {a, ă, â} · {e, ê} · {i, y} · {o, ô, ơ} · {u, ư}. Vần kết bằng bán nguyên âm (-o, -u, -i, -y) được so theo chính bán nguyên âm đó | lâu/nhau; tóc/dốc; tre/quê | "Vần nghèo" [BC]. Bảng nhóm gần [QU], đúng bảng script dùng (`scripts/_tieng_viet.py`, hàm `so_van`, script báo "vần thông?"). Ví dụ vần nghèo *thêu/trèo* [BC] **không** lọt vào bảng này (-u khác nhóm -o) |
| **Vần bằng / vần trắc** | Tiếng hiệp vần mang ngang, huyền / mang sắc, hỏi, ngã, nặng | — | [BC] |
| **Vần chân** (cước vận) | Gieo cuối dòng | — | [BC] (Đề cương Ngữ văn 7) |
| **Vần lưng** (yêu vận) | Gieo giữa dòng; thường tiếng cuối dòng trên hiệp tiếng giữa dòng dưới | Lục bát: chữ 6 lục ↔ chữ 6 bát | [BC]. Vần lưng là "cốt lõi" của lục bát, vần chân "chỉ là sự chi viện" (HCMUE, dẫn Lam Giang) |
| **Vần liền** | Hai dòng liên tiếp hiệp vần (AABB) | — | [QU] [Cần kiểm chứng] |
| **Vần cách** (vần chéo) | Hiệp cách một dòng (ABAB) | — | [QU] [Cần kiểm chứng] |
| **Vần ôm** | Dòng 1 hiệp dòng 4, dòng 2 hiệp dòng 3 (ABBA) | — | [QU] [Cần kiểm chứng]; Wikipedia nhắc nhưng không định nghĩa |
| **Vần hỗn hợp** | Phối nhiều kiểu trong một bài/khổ | — | [QU] [Cần kiểm chứng] |
| **Lạc vận** | Vị trí bắt buộc gieo vần nhưng không hiệp (lỗi) | — | [QU]; Đường luật gọi là "thất vần" [BC] (ĐH Long An) |
| **Cưỡng vận / ép vần** | Dùng từ gượng nghĩa để có vần | — | [QU] |

### Vần khép: luôn là vần trắc

- **[BC]** Theo cách kết thúc, âm tiết chia 4 loại: **mở**; **nửa mở** (kết /j/, /w/); **nửa khép** (kết /m, n, ŋ/); **khép** (kết /p, t, k/, viết -p, -t, -c, -ch). Trong 159 vần có nghĩa có **54 vần khép (≈34%)**. **Vần khép chỉ kết hợp với thanh sắc và thanh nặng**; "sự phân bố thanh điệu hoàn toàn phụ thuộc vào phụ âm cuối" (Lê Thị Hiền 2024, dẫn Mai Ngọc Chừ).
- **[QU] Ba hệ quả:**
  1. **Mọi vần khép đều là vần trắc** → không bao giờ đặt ở vị trí bắt buộc vần bằng (chữ 6, chữ 8 lục bát; chữ cuối câu gieo vần Đường luật). Muốn vần bằng: dùng vần mở, nửa mở hoặc nửa khép.
  2. Âm tiết khép ngắn, tắc, khó ngân. N5 cấm vần khép ở nốt ngân vì phát âm; thi luật cấm vì vần. **Hai lý do độc lập cùng dẫn tới một quy tắc** → một trong những quy tắc chắc chắn nhất của bộ hướng dẫn.
  3. Vần khép hợp nốt cắt, staccato, rap dồn, câu kết dứt khoát.

### Bằng–trắc không phải là cao độ

Nhóm thi luật: Wikipedia (Vietnamese poetry) [BC]; nhóm cao độ: Ladd & Kirby [BC]; cột hệ quả [QU].

| Thanh | Nhóm thi luật | Nhóm cao độ khi hát | Hệ quả ở vị trí vần |
|---|---|---|---|
| Ngang | Bằng | Trung | Vần bằng "bổng"; hợp nốt ngân, kết lửng |
| Huyền | Bằng | Thấp | Vần bằng "trầm"; hợp nốt kết đi xuống về chủ âm |
| Sắc | Trắc | Cao | Vần trắc cao; hợp đỉnh câu |
| Ngã | Trắc | Cao (giọng Bắc có tắc giữa) | Vần trắc; giọng Bắc cần luyến đi lên |
| Hỏi | Trắc | Rất thấp | Vần trắc thấp; tránh đỉnh câu |
| Nặng | Trắc | Rất thấp, tắc | Vần trắc ngắn; tránh nốt ngân dài |

- Hai vần bằng có thể ở hai độ cao khác nhau (ngang trung, huyền thấp) → cơ chế "trầm bổng" của câu bát (12.3).
- Vần trắc trải từ nhóm cao nhất (sắc, ngã) đến thấp nhất (hỏi, nặng) → chọn nốt cẩn thận hơn; chạy lại T5–T6 cho mọi chữ vần trắc.

**Khoảng trống:** chưa có nguyên văn định nghĩa vần chính/thông/liền/cách/ôm/lạc vận từ *Từ điển thuật ngữ văn học*; chuyên khảo Mai Ngọc Chừ "Thanh điệu trong vần thơ Việt Nam" (1988) mới có siêu dữ liệu; chưa có từ điển vần hiện hành kiểm chứng được. [QU] Có thể tự dựng công cụ tra vần: tách âm tiết (âm đầu, âm đệm, âm chính, âm cuối, thanh), nhóm theo (âm chính + âm cuối) và bằng/trắc.

## 12.2. Hai mươi thể và biến thể thơ

Thứ tự từ chặt đến tự do. Ô không nhãn kế thừa nguồn của dòng. "Chưa có nguồn" = đợt rà soát chưa tìm được nguồn, không có nghĩa thể đó không có quy tắc. Khung lời theo làn điệu: 12.10. Thể ngoài phạm vi lời ca: 12.11.

| Thể | Số chữ / câu | Luật bằng–trắc | Vần | Nhịp | Biến thể | Dùng trong ca khúc / dân ca |
|---|---|---|---|---|---|---|
| **Lục bát** | Cặp 6–8 nối tiếp, không hạn số câu; mở bằng câu 6, kết bằng câu 8 [BC] | Chữ chẵn bắt buộc, lẻ tự do. Lục 2–4–6 = B–T–B; bát 2–4–6–8 = B–T–B–B. **Chữ 6 và 8 câu bát: một huyền, một ngang** [BC] (VietJack – SGK 7) | Vần bằng. Chữ 6 lục ↔ chữ 6 bát (lưng); chữ 8 bát ↔ chữ 6 lục kế tiếp (chân); khoảng cách vần luôn 6 âm tiết [BC] (HCMUE) | Lục 2/2/2, bát 2/2/2/2 [BC]; biến điệu 3/3, 4/4 [Cần kiểm chứng] | Dòng dưới | Ca dao gần như toàn bộ (≈95% trong 1.015 bài, thống kê Nguyễn Xuân Kính) [BC] (Nguyễn Quốc Khánh 2021); đại đa số điệu lý Nam Bộ, lời ví, hát Nam hát bội [BC] (12.10); mưỡu ca trù [BC] (dòng Hát nói); hát ru lấy lời chủ yếu từ ca dao, đồng dao, hò [BC]; lời quan họ và hò là lục bát [Cần kiểm chứng] (12.10); ngâm thơ, lẩy Kiều [BC] |
| **Lục bát biến thể** | Câu dôi chữ: DQH ghi lục bát có "biến thức" với câu dài hơn 6 hoặc 8 chữ [BC]; con số cụ thể "lục 7–8, bát 9–10" [Cần kiểm chứng] | Vần lưng ở chữ 4 câu bát thì 2–4–6 câu bát đổi thành T–B–T; dạng này "cổ hơn" [BC]. Phan Diễm Phương: "lục bát quãng sáu" / "lục bát quãng tư" theo vị trí vần trong câu bát [BC] (Nguyễn Quốc Khánh 2021) | Vần trắc ở chữ 6: hiếm, không kéo dài quá hai câu; vần nối chữ 6 câu lục với chữ 4 câu bát (gặp trong ca dao) [BC] (Nguyễn Quốc Khánh 2021) | Câu bát "giãn ra hoặc thu ngắn lại", tạo "phút ngập ngừng" [BC] | Gia giảm số âm tiết hoặc cách hiệp vần; thao tác: bớt âm tiết, thêm âm tiết hoặc tiếng đệm, lặp, tiểu đối ở câu lục [BC] (HCMUE) | Lý Nam Bộ: từ phụ chêm ở bất kỳ vị trí nào [BC]; ví dùng lục bát biến thể [BC] (12.10); hò [Cần kiểm chứng] |
| **Song thất lục bát** | Khổ 4 câu 7–7–6–8 [BC] | Câu thất xét chữ 3–5–7: trên T–B–T, dưới B–T–B; cặp lục bát theo luật lục bát [BC] | Cặp thất có vần lưng trắc; vần bằng nối sang lục bát; "vừa lưng vừa chân, vừa bằng vừa trắc" [BC]; sơ đồ chi tiết có mâu thuẫn nguồn (12.3) | Thất 3/4; lục bát 2/2/2(/2) [BC] | Song thất rải trong bài lục bát dài; thơ 1945–1975 niêm luật "thoáng hơn"; Tố Hữu tách câu thất thành hai dòng [BC] | *Chinh phụ ngâm*, *Cung oán ngâm khúc* [BC]; hát Nam hát bội. [QU] hợp đoạn kể, than |
| **Đường luật thất ngôn bát cú** | 8 câu × 7 chữ | Chữ 2 câu 1 là B → luật bằng, T → luật trắc; chữ 2 và 6 cùng thanh, chữ 4 ngược; chữ 1, 3, 5 "không cần theo luật" [BC] (ĐH Long An, dẫn *Từ điển thuật ngữ văn học* tr. 265). Khẩu quyết "nhị tứ lục phân minh" chưa có nguồn nguyên văn [Cần kiểm chứng], nội dung vừa nêu thì có nguồn | Một vần, đa số vần bằng, cuối câu 1, 2, 4, 6, 8 [BC] | 4/3 hoặc 2/2/3 [Cần kiểm chứng]; riêng 2/2/3 có một ví dụ có nguồn (*Tự thán*, Lê Thị Huyền Trang 2019) | Niêm 1–8, 2–3, 4–5, 6–7; đối 3–4, 5–6 [BC] (ĐH Long An; niêm xác nhận thêm qua *Qua Đèo Ngang*, Lê Thị Huyền Trang 2019); bố cục 4 phần Đề, Thực (hoặc Trạng), Luận, Kết [BC] (ĐH Long An) | Ngâm thơ. [QU] Ít phổ trực tiếp; *Qua Đèo Ngang*, *Thu điếu* là mẫu giáo khoa |
| **Tứ tuyệt** | 4 câu × 7 (hoặc 5) chữ | Như bát cú nhưng **có thể bỏ đối** [BC]; cặp niêm cụ thể 1–4, 2–3 chưa có nguồn [Cần kiểm chứng] | Cuối câu 1, 2, 4 [Cần kiểm chứng] | Tài liệu soạn *Cảnh khuya* mâu thuẫn 3/4 hay 4/3 [BC] | Tứ tuyệt hiện đại (*Cảnh khuya*, Hồ Chí Minh) | [QU] Bốn câu gọn, hợp đoạn nhạc 4 câu |
| **Ngũ ngôn Đường luật** | 8 hoặc 4 câu × 5 chữ | "Nhất tam bất luận, nhị tứ phân minh": xét chữ 2 và 4 [Cần kiểm chứng] | Như thất ngôn [Cần kiểm chứng] | 2/3 [QU] | SGK 12 có dạy, chưa lấy được chi tiết | Ngâm |
| **Thất ngôn xen lục ngôn** | Câu 6 chữ xen giữa câu 7 chữ, "ở những vị trí không cố định" [BC] (Lã Nhâm Thìn, qua Lê Thị Huyền Trang 2019); ví dụ *Mạn thuật* bài 4: câu 1–6 sáu chữ, câu 7–8 bảy chữ [BC]. *Quốc âm thi tập* có 254 bài [BC]; chưa có thống kê kiểm chứng về số bài có câu sáu chữ | Giữ vần và đối Đường luật [BC] (Lã Nhâm Thìn). 89 câu sáu chữ được khảo sát: 83 câu đúng luật, 6 câu thất luật [BC] (Trần Trọng Dương 2013) | Giữ vần Đường luật [BC] | Câu lục ngôn 3/3 [Cần kiểm chứng] | "Hàn luật" có hai định nghĩa: "thơ Nôm theo Đường luật" (VnExpress 2005) và thể có xen câu 6 tiếng (Lã Nhâm Thìn). Không coi là đồng nghĩa với thất ngôn xen lục ngôn | [QU] Tiền lệ cổ cho câu nhạc dài–ngắn xen kẽ |
| **Thủ vĩ ngâm** | Theo thể thơ luật nền; câu cuối lặp lại câu đầu [BC] (ĐHSP Huế 2025) | Theo thể nền | Theo thể nền | Theo thể nền | Được xếp vào nhóm "thể thơ hiếm gặp" cùng tứ ngôn, lục ngôn, ngũ bình ngũ trắc, thuận nghịch độc [BC] (ĐHSP Huế 2025) | [QU] Kỹ thuật hook: câu mở bài trở lại nguyên văn ở cuối, đóng khung cả bài như điệp khúc |
| **Hát nói** | Khổ đủ 11 câu (4–4–3); khổ dôi > 11 câu (có bài 76 câu); khổ thiếu < 11; câu dài 4–20 chữ; câu cuối luôn 6 chữ [BC] (KoreaScience) | Không cố định trong câu; chữ cuối câu theo chuỗi T – B B – T T – B B… [BC]; bảng 11 câu [Cần kiểm chứng] | Vần chân theo chuỗi trên + 3–4 vần lưng mỗi bài [BC] | Câu cuối 2/2/2, kết bằng; câu khác thường 3/2/2, 3/2/3, 3/3 [BC] | Mưỡu là các câu lục bát đặt trước (mưỡu đầu) hoặc sau bài (mưỡu hậu); đơn 2 câu, kép 4 câu; không bắt buộc [BC] (KoreaScience; Smithsonian Folkways) | Ca trù, di sản UNESCO. [QU] Khung nhiều khổ tự do, gần ca khúc nhiều đoạn |
| **Thất ngôn trường thiên Tày** ("thất thất lưu thủy") | Chuỗi câu 7 chữ, không giới hạn số khổ; lượn cọi, lượn then, phong slư [BC] (Hà Xuân Hương 2018) | Hai chữ hiệp vần cùng thanh: bằng với bằng, trắc với trắc [BC] | Chữ cuối dòng trên vần với chữ 5 dòng dưới, lặp suốt bài [BC]; nguồn gọi lúc "vần chân", lúc "yêu vận" | Chưa có nguồn | Lượn slương: thất ngôn tứ tuyệt, vần dòng 1, 2, 4 [BC]; lượn cọi có lúc xen câu 5 chữ [BC] | Thất ngôn ≈ 87% trong 1.464 bài dân ca trữ tình Tày khảo sát [BC]. [QU] Khuôn cho lời phỏng lượn, then; khi viết tiếng Việt, "cùng thanh" chỉ áp gần đúng |
| **Thơ 4 chữ** | 4 chữ/dòng; số dòng, khổ không hạn [BC]. Nguyễn Xuân Kính tính "bốn tiếng" là một thể riêng trong ca dao [BC] (Nguyễn Quốc Khánh 2021) | Không bắt buộc | Phối hợp vần chân và vần lưng [BC]; vần liền [Cần kiểm chứng]. Tên "vần gối" [Cần kiểm chứng]; mô tả gần nhất có nguồn là nói lối của DQH (dòng dưới) | 2/2 [BC] | Lý con rồng, Lý bông đậu, Lý cây xanh dùng 4 chữ; Lý miễu lý đình kết hợp 4 chữ với lục bát [BC] (Nguyễn Bảo Lan 2025) | [QU] Thiếu nhi, trò chơi, jingle |
| **Nói lối** (thể thức ca dao theo DQH) | Câu thường 4 chữ [BC] (DQH) | Chưa có nguồn | Chữ cuối câu trên vần với chữ thứ hai hoặc chữ cuối câu dưới [BC] (DQH) | Chưa có nguồn | Một thể thức ca dao bên cạnh lục bát, song thất lục bát, lối pha hai–ba thể [BC] (DQH). Khác nói lối hát bội, cải lương (12.10) | [QU] Khuôn cho lời 4 chữ có vần móc xích |
| **Đồng dao** | Chung thể bốn chữ với vè [BC] (ĐH Đồng Tháp 2017); số chữ, luật vần riêng [Cần kiểm chứng] | Chưa có nguồn | Vần liền [Cần kiểm chứng] | Thể 4 chữ: 2/2 [BC] | Đồng dao, tục ngữ chứa dạng song thất lục bát sơ khai [BC] (HCMUE) | [QU] Thiếu nhi, trò chơi |
| **Vè** | Bốn chữ (phổ biến nhất ở vè kể vật), năm chữ, lục bát, thể tự do [BC] (ĐH Đồng Tháp 2017) | Chưa có nguồn | Mỗi bài dùng cả vần chân lẫn vần lưng [BC] | Thể 4 chữ: 2/2 [BC] | Mở bằng công thức xưng thể loại rồi tên bài; câu đi thành cặp: mô tả vật + từ nối ("là", "đó là", "chính là") + tên vật [BC]. Nghệ Tĩnh có tên chung "giặm vè" [BC] (Nguyễn Nhã Bản & Phan Xuân Đạm 2015) | [QU] Lời kể, lời vui, jingle; xem giặm (12.10) |
| **Thơ 5 chữ** | 5 chữ/dòng, số dòng tự do [BC] | Không bắt buộc | Vần chân và vần lưng [BC] | 3/2 hoặc 2/3 [BC] | *Sang thu* (Hữu Thỉnh) là mẫu giáo khoa [BC] | Giặm Nghệ Tĩnh dùng thể 5 chữ [BC] (12.10). [QU] Câu nhạc ngắn; nhịp 2/3 hay 3/2 quyết định phách mạnh |
| **Thơ Mới 7 chữ** | Thường khổ 4 câu × 7 chữ [QU] | Không bắt buộc; giữ cảm thức bằng–trắc cuối câu [QU] | Vần chân liền, cách hoặc ôm, xen bằng và trắc, gần khổ thơ Pháp [QU] [Cần kiểm chứng] | 4/3 hoặc 3/4 | Thơ Mới (1932–1945) tiếp thu lãng mạn, tượng trưng Pháp, rời khuôn Đường luật [BC] | Tiền chiến gắn Thơ Mới. [QU] Cần nguồn cho danh mục bài tiền chiến phổ Thơ Mới |
| **Thơ 8 chữ** | 8 âm tiết mỗi dòng [BC] (Nguyễn Thị Thanh Nguyên & Huỳnh Sơn Lâm 2023); khổ 4 câu [QU] | Không tuân thủ luật nghiêm ngặt; nhấn nhạc điệu và nhịp trong dòng [BC] | Vần và nhịp khá lỏng [BC] | Danh mục 3/5, 5/3, 4/4, 3/3/2, 2/3/3 [QU] | Nhà thơ có thể co giãn số chữ [BC]. Các thể dựa trên vần chân bị Thơ Mới "phá vỡ", lục bát vẫn sống [BC] (HCMUE) | Lời dân ca 8 chữ: Lý tang tình (bài 1) [BC] (Nguyễn Bảo Lan 2025). [QU] Khổ 4 câu ≈ verse hoặc chorus 4 câu |
| **Tân hình thức** (Khế Iêm) | Có thể giữ thể 5, 7, 8 chữ hoặc lục bát ("chuỗi thơ" của Khế Iêm) [BC] (Asian Cha 2014) | Chưa có nguồn | Vần không quan trọng; **lặp lại thay cho vần** làm phương tiện cấu trúc [BC] | **Vắt dòng** (enjambment) [BC] | Kể chuyện, ngôn ngữ đời thường; tuyển tập *Thơ Không Vần* (2006) [BC] (Asian Cha); nhắm tới "người đọc phổ thông" [BC] (Nguyễn Thị Tuyết 2020) | [QU] Gần lời pop: điệp khúc lặp thay vần, câu nhạc vắt qua ô nhịp; chưa có nguồn nối hai thứ |
| **Thơ tự do** | Không cố định; phần lớn thơ Việt là thơ tự do từ thập niên 1950 [BC] | Không | Có thể không vần; nhạc tính quan trọng hơn vần [BC] (Ngô Tự Lập) | Nhịp thị giác, ngắt dòng; đọc theo câu hơn theo dòng [BC] | Song thất ẩn trong thơ tự do 1945–1975 [BC] | *Màu tím hoa sim* có ít nhất ba bản phổ [BC]; nhạc sĩ phổ thơ ưa thơ tự do [BC] |
| **Rap** | Không cố định | Không theo luật; tỉ lệ khớp thanh–nhạc thấp hơn thể loại khác (dữ liệu Thái) | Phân vần theo **số âm tiết**: đơn, đôi, ba [BC] (Vietcetera) | Flow theo beat: straight, triplet; 4/4, 6/8 [BC] | Punchline, storytelling; chơi chữ, chuyển mã Việt–Anh [BC] (Nguyễn Thùy Linh & Nguyễn Thị Thúy Huệ 2025) | Rap Việt; đoạn rap trong V-pop |

**Đọc bảng theo một trục:** từ trên xuống, ràng buộc chuyển từ **vị trí chữ** (bằng–trắc ở chữ cố định) → **vị trí vần** (vần chân trong khổ) → **số âm tiết hiệp vần** (rap). Ngô Tự Lập: chọn thể là dùng "điển tích hình thức" – lục bát tự gợi làng quê [BC].

**[QU] Chọn thể = chọn màu văn hóa:** lục bát → dân ca, ru, trữ tình quê hương · song thất → đoạn kể, than · khổ 4 câu Thơ Mới → ballad tiền chiến, pop · thơ tự do → nhạc Trịnh, indie, ballad phổ thơ · rap → kể chuyện đời thường.

## 12.3. Sơ đồ luật theo vị trí chữ

### Lục bát

| Câu | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
|---|---|---|---|---|---|---|---|---|
| Lục (6) | – | B | – | T | – | B **V** (vần với chữ 6 câu bát) | | |
| Bát (8) | – | B | – | T | – | B **V lưng**, huyền hoặc ngang | – | B **V chân**, ngược thanh với chữ 6 |

- **[BC]** "Các tiếng chẵn 2, 4, 6, 8 bắt buộc phải đúng luật; các tiếng lẻ 1, 3, 5, 7 không bắt buộc" (VietJack – Ngữ văn 7).
- **[BC] Luật trầm bổng:** "Nếu tiếng thứ 6 là thanh huyền (trầm) thì tiếng thứ 8 sẽ là thanh ngang (bổng) hoặc ngược lại" (VietJack). Bài tạp chí khác: "tiếng thứ sáu và tám trong cùng một câu bát phải khác thanh" – dẫn Bùi Văn Nguyên & Hà Minh Đức (2006), Phan Diễm Phương (1998), Lý Toàn Thắng (2015) (vjol – KHXH). Hiệu quả âm thanh của luật bằng–trắc là "độ cao – thấp, trầm – bổng" (HCMUE).
- **Ví dụ** (một dòng): "Chữ tài chữ mệnh khéo là ghét nhau" – chữ 2 "tài" B, chữ 4 "mệnh" T, chữ 6 "là" B huyền, chữ 8 "nhau" B ngang; đúng luật chữ chẵn và trầm bổng; "là" hiệp vần lưng với chữ cuối câu lục trước. (Phân tích của ghi chú gốc.)
- **[BC] Luật mềm hơn người ta tưởng:** câu lục ngắt sau chữ 3 thì chữ 2 có thể là trắc (Wikipedia); luật chữ chẵn "không được chặt chẽ cho lắm", nhất là chữ 2 (HCMUE); khảo sát *Truyện Kiều*: **chỉ 27 cặp lục bát khớp mô hình chuẩn hoàn toàn**; đa số lệch ở chữ lẻ (Lý Toàn Thắng & Hoàng Thị Nhung 2014).
- **[QU] Thứ tự ưu tiên khi viết:** (1) vần chữ 6 và chữ 8; (2) trầm bổng câu bát; (3) chữ 4 trắc; (4) chữ 2 bằng. Chữ lẻ dành cho nghĩa và thanh–nhạc.

**Bốn bước kiểm tra một câu bát:**
1. Chữ 2 B, 4 T, 6 B, 8 B.
2. Chữ 6 và 8 không cùng ngang, không cùng huyền.
3. Chữ 6 hiệp vần với chữ 6 câu lục ngay trên.
4. Chữ 8 mở vần cho chữ 6 câu lục tiếp theo.

### Song thất lục bát

| Câu | Chữ 3 | Chữ 5 | Chữ 7 | Vần |
|---|---|---|---|---|
| Thất trên | T | B | T (V trắc) | Chữ 7 vần với chữ 5 câu thất dưới |
| Thất dưới | B | T (V trắc, vần lưng) | B (V bằng) | Chữ 7 vần với chữ 6 câu lục |
| Lục | (2 B, 4 T, 6 B = V) | | | Chữ 6 vần với chữ 6 câu bát |
| Bát | (2 B, 4 T, 6 B = V, 8 B = V) | | | Chữ 8 vần với chữ 5 câu thất trên của khổ sau |

- **[BC]** Luật chữ 3–5–7: "T – B – T (câu 1) và B – T – B (câu 2)"; câu thất "thông thường là 3/4" (ĐH Phú Yên).
- Ví dụ một dòng: "Thuở trời đất nổi cơn gió bụi" (*Chinh phụ ngâm*, bản diễn Nôm) – chữ 3 "đất" T, chữ 5 "cơn" B, chữ 7 "bụi" T. Câu thất dưới: chữ 3 "hồng" B, chữ 5 "nỗi" T, chữ 7 "chuyên" B; "bụi" hiệp vần trắc với "nỗi". (Phân tích của ghi chú gốc.)
- **[Cần kiểm chứng] Xung đột nguồn – ghi cả hai:**
  - **(A) Mô tả truyền thống** (bảng trên, khớp ví dụ): chữ 7 thất trên ↔ chữ 5 thất dưới; chữ 7 thất dưới ↔ chữ 6 lục; chữ 6 lục ↔ chữ 6 bát; chữ 8 bát ↔ chữ 5 thất trên khổ sau.
  - **(B) Bài ĐH Phú Yên:** "tiếng cuối câu một vần với tiếng thứ 6 câu hai" và "tiếng thứ 8 câu hai vần với tiếng thứ 6 câu ba". Có thể đánh số câu/khổ khác, hoặc in lỗi.
  - Tạm dùng (A) cho đến khi đối chiếu được SGK Ngữ văn 10 hoặc 12.

### Đường luật thất ngôn bát cú

**[BC] Năm quy tắc nền** (ĐH Long An; Tạp chí Hán Nôm):
1. Chữ 2 câu 1 quyết định luật: bằng → **luật bằng**; trắc → **luật trắc**.
2. Mỗi câu: chữ 2 và 6 cùng thanh, chữ 4 ngược lại; chữ 1, 3, 5 "bất luận".
3. **Niêm:** hai câu niêm khi chữ 2 cùng luật; cặp niêm 1–8, 2–3, 4–5, 6–7; sai = "thất niêm".
4. **Vần** cuối câu 1, 2, 4, 6, 8, đa số vần bằng; sai = "thất vần".
5. **Đối:** câu 3–4 và 5–6 phải đối; sai = "thất đối".

- **[BC] Bố cục:** bát cú "thường được chia gồm 4 phần: Đề, Thực (hoặc Trạng), Luận, Kết" (ĐH Long An, dẫn *Từ điển thuật ngữ văn học* tr. 265). Cặp niêm 1–8, 2–3, 4–5, 6–7 được xác nhận thêm qua phân tích *Qua Đèo Ngang* (Lê Thị Huyền Trang 2019).
- Gán đề = câu 1–2, thực = 3–4, luận = 5–6, kết = 7–8 khớp hai cặp đối 3–4, 5–6 đã có nguồn nhưng chưa có trích dẫn nguyên văn [Cần kiểm chứng].
- Nhịp 4/3 [Cần kiểm chứng]; nhịp 2/2/3 có một ví dụ có nguồn (*Tự thán*, Lê Thị Huyền Trang 2019).
- Tứ tuyệt: cặp niêm 1–4, 2–3 chưa có nguồn → chỉ ghi chú, không chấm lỗi [Cần kiểm chứng].

**[Cần kiểm chứng] Bảng dựng lại từ năm quy tắc** (chỉ ghi chữ bắt buộc 2, 4, 6 và chữ 7; thanh chữ 7 ở câu không vần theo kiến thức nền):

| Câu | Phần | Luật bằng (chữ 2–4–6–7) | Luật trắc (chữ 2–4–6–7) | Vần | Niêm với |
|---|---|---|---|---|---|
| 1 | Đề | B – T – B – B | T – B – T – B | V | 8 |
| 2 | Đề | T – B – T – B | B – T – B – B | V | 3 |
| 3 | Thực | T – B – T – T | B – T – B – T | — (đối với 4) | 2 |
| 4 | Thực | B – T – B – B | T – B – T – B | V | 5 |
| 5 | Luận | B – T – B – T | T – B – T – T | — (đối với 6) | 4 |
| 6 | Luận | T – B – T – B | B – T – B – B | V | 7 |
| 7 | Kết | T – B – T – T | B – T – B – T | — | 6 |
| 8 | Kết | B – T – B – B | T – B – T – B | V | 1 |

Luật trắc = luật bằng đảo B/T ở chữ 2, 4, 6; chữ 7 giữ nguyên. **Đối chiếu chéo:** *Cảnh khuya* (tứ tuyệt, luật trắc) có chữ 2–4–6 bốn câu là T–B–T, B–T–B, B–T–B, T–B–T (Toplist) – trùng bốn câu đầu cột luật trắc → cột này đáng tin hơn bảng chỉ suy luận, vẫn cần đối chiếu sách gốc.

### Hát nói: khung 11 câu

| Câu | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Khổ | Đầu | Đầu | Đầu | Đầu | Giữa | Giữa | Giữa | Giữa | Cuối | Cuối | Cuối |
| Thanh chữ cuối [Cần kiểm chứng] | T | B | B | T | T | B | B | T | T | B | B |
| Ghi chú | | | | | Thơ chữ Hán ("dựng"), thường 7 chữ | Thơ chữ Hán ("dựng"), thường 7 chữ | | | | | 6 chữ, nhịp 2/2/2, kết bằng |

- **[BC]** Khổ đủ 11 câu: khổ đầu 4, khổ giữa 4 (câu 5–6 chữ Hán), khổ cuối 3. Vần chân bắt đầu bằng trắc rồi theo chuỗi "bằng bằng – trắc trắc – bằng bằng"; thêm 3–4 vần lưng. Câu cuối luôn 6 chữ, 2/2/2, kết bằng (KoreaScience). Mưỡu đặt trước hoặc sau (mưỡu đầu, mưỡu hậu), 2 câu (đơn) hoặc 4 câu (kép). Bản thu tiêu biểu: mưỡu và hát nói "Hồng Hồng Tuyết Tuyết" (Dương Khuê) (Smithsonian Folkways).
- Hàng "thanh chữ cuối" suy từ chuỗi trên [Cần kiểm chứng], khớp yêu cầu câu 11 kết bằng.
- Bản trước của tài liệu gốc ghi hát nói "chia 6 khổ"; đã sửa thành 4–4–3 theo nguồn có trích dẫn.
- **[QU]** Khung 4–4–3 + mưỡu ≈ intro, verse, verse, outro. Câu kết 6 chữ thanh bằng = mô hình sẵn cho tagline cuối bài.

## 12.4. Nhịp thơ → ô nhịp

**[BC]**
- Thơ Việt xây trên **chân thơ chủ yếu hai tiếng**: dòng lục "ba chân", dòng bát "bốn chân" (Lý Toàn Thắng & Hoàng Thị Nhung 2014).
- Ngữ điệu "rơi hẳn vào các âm tiết ở vị trí chẵn" (HCMUE, dẫn Nguyễn Phan Cảnh); khi ngâm "ngừng lại nhiều lần và chủ yếu ở những tiếng chẵn" (vjol – KHXH).
- Phá nhịp có chủ đích: Bùi Giáng ngắt câu bát 4/2/1/1; Tố Hữu tách câu thất thành hai dòng (Phạm Ngọc Hiền 2019). Ngô Tự Lập: nhịp gốc từ nhịp sinh lý, lao động; lặp đều có hiệu ứng "đưa nôi".

**Ba lớp nổi bật trùng nhau ở cuối câu lục bát:** chữ 6 và 8 vừa là chữ cuối ngữ đoạn (kéo dài ≈ 41%, Brunelle), vừa mang luật, vừa gieo vần. [QU] Vì thế lục bát "có sẵn nhạc" (Đăng Khánh): đặt vị trí đó vào nốt dài ở phách mạnh là câu nhạc tự thành hình.

**[QU] Bảng ánh xạ** (suy luận; chưa có nghiên cứu Việt Nam liên kết trực tiếp nhịp thơ với ô nhịp):

| Nhịp thơ | Thể | Ánh xạ gợi ý (2/4 hoặc 4/4) | Lưu ý |
|---|---|---|---|
| 2/2/2 | Câu lục | Chữ 1 làm nhịp lấy đà để chữ 2 rơi vào phách 1; ba chân ≈ 1,5–2 ô; chữ 6 ngân | Chữ chẵn vào phách mạnh hoặc nốt dài (N7) |
| 2/2/2/2 | Câu bát | Bốn chân ≈ 2 ô; chữ 6 (vần lưng) nốt dài vừa; chữ 8 ngân dài kết câu | Chữ 6 và 8 một huyền, một ngang: chọn kết lửng (ngang) hay kết về chủ âm (huyền) |
| 3/4 | Câu thất song thất | Ba chữ đầu là nhịp lấy đà hoặc một ô riêng; bốn chữ sau thành hai chân | Chữ 3 là điểm tựa hài thanh; chữ 7 là vần |
| 4/3 | Đường luật, Thơ Mới 7 chữ | Bốn chữ đầu một ô; ba chữ sau + nốt ngân một ô | Chữ 7 vần bằng ngân |
| 2/2 | Thơ 4 chữ, đồng dao | Một câu một ô 2/4 | Hợp thiếu nhi; mỗi câu trọn một ý |
| 2/3 hoặc 3/2 | Thơ 5 chữ | 2/3: chữ 5 ngân. 3/2: ba chữ đầu lấy đà | Nhịp quyết định chỗ phách mạnh |
| 3/5, 5/3, 4/4, 3/3/2 | Thơ 8 chữ | Chia theo ngữ đoạn; mỗi nửa câu một ô | Không cắt đôi từ ghép (N4) |
| Theo ngữ đoạn | Thơ tự do | Chia câu nhạc theo ranh giới nghĩa (N1), không theo dòng in | Nhạc thắng khi xung đột độ dài, nhưng không cắt từ |
| Theo flow | Rap | 2–4 âm tiết mỗi phách (N6); vần rơi phách 2 và 4 hoặc cuối ô | Xem 12.6 |

Quy tắc chung: ranh giới nhịp thơ trùng vạch nhịp hoặc điểm thở của giai điệu. Khi câu thơ không vừa câu nhạc, nhạc sĩ được phân câu theo quy luật âm nhạc (Đăng Khánh, RFA) [BC]. Phá nhịp có chủ đích (Bùi Giáng) ≈ syncopation hoặc ngắt lệch phách trong pop.

## 12.5. Tu từ và công thức ca dao

**[BC]** Nét nghệ thuật cốt lõi của ca dao (soạn bài lớp 10): **công thức mở đầu** "Thân em", "Trèo lên"; **so sánh, ẩn dụ, điệp**; **biểu tượng** khăn, đèn, mắt; lối **hứng, tỉ**. Nguồn phổ thông (độ tin cậy trung bình): mở đầu "Chiều chiều", "Ngó lên", "Rủ nhau"; xưng hô anh – em, mình – ta, thiếp – chàng; dài 2–4 dòng; đối đáp nam nữ. Mẫu "Thân em như…": bài "Thân em như tấm lụa đào" (chương trình lớp 10). Ca từ Trịnh Công Sơn dùng ẩn dụ, liên tưởng, phép đối theo lối "mở" như hội họa ấn tượng – "thơ truyền khẩu" viết cho giọng hát (Phan Đan).

**Bảng biện pháp tu từ** (danh mục theo Ngữ văn THCS–THPT [Cần kiểm chứng]; cột vai trò [QU] trừ chỗ ghi nguồn):

| Biện pháp | Nhận diện nhanh | Vai trò trong lời ca | Vị trí gợi ý |
|---|---|---|---|
| So sánh | "A như B" | Mở hình ảnh chủ đạo; ca dao dùng nhiều [BC] | Câu mở phiên khúc |
| Ẩn dụ (hình thức, cách thức, phẩm chất, chuyển đổi cảm giác) | So sánh ngầm | Một ẩn dụ trung tâm xuyên suốt giúp bài có "tứ"; ẩn dụ "mở" của Trịnh [BC] | Câu tiêu đề, điệp khúc |
| Hoán dụ (bộ phận – toàn thể, vật chứa – vật bị chứa, dấu hiệu – sự vật, cụ thể – trừu tượng) | Gọi tên bằng vật liên quan | Chi tiết cụ thể thay khái niệm (áo, khăn, đèn) [BC: biểu tượng ca dao] | Phiên khúc |
| Nhân hóa | Vật có tính người | Cảnh vật "đồng cảm" với nhân vật | Phiên khúc, bridge |
| Điệp ngữ, điệp cấu trúc | Lặp từ hoặc khung câu | **Nguyên liệu tự nhiên cho hook và điệp khúc**; ca dao dùng điệp [BC] | Điệp khúc, câu đầu mỗi phiên khúc |
| Liệt kê | Chuỗi cùng loại | Dồn cảm xúc trước cao trào; hợp rap | Pre-chorus |
| Nói quá | Phóng đại | Cao trào cảm xúc | Đỉnh điệp khúc |
| Nói giảm nói tránh | Làm nhẹ điều đau | Mất mát, chia ly | Phiên khúc 2, outro |
| Chơi chữ | Đồng âm, đa nghĩa | Punchline trong rap [BC] (Vietcetera) | Cuối câu rap |
| Đối | Hai vế cân xứng từ loại và nghĩa | Câu nhạc hỏi–đáp; Đường luật bắt buộc đối [BC] | Cặp câu trong phiên khúc |
| Câu hỏi tu từ | Hỏi không cần đáp | Mở điệp khúc, đối thoại với người nghe | Câu đầu ĐK |
| Từ láy | Láy âm, láy vần | Âm mở, dễ ngân, tạo nhạc | Nốt ngân dài |

**Công thức ca dao** ("motif mở bài" định vị dân ca, trữ tình quê hương):

| Công thức | Lối biểu đạt | Cảm xúc | Nhãn |
|---|---|---|---|
| "Thân em (như)…" | Tỉ (so sánh) | Than thân, phận người | [BC] |
| "Trèo lên…" | Hứng (mượn cảnh khơi tình) | Nhớ, mong, trách | [BC] |
| "Chiều chiều…" | Hứng | Chiều tà, nhớ quê, nhớ người | [BC] (nguồn phổ thông) |
| "Ngó lên…", "Rủ nhau…" | Hứng, kể | Nhìn cảnh, rủ rê, lao động | [BC] (nguồn phổ thông) |
| "Ai về…", "Hôm qua…" | Kể, gửi lời | Gửi gắm, hẹn hò | [QU] chưa có nguồn |
| Cặp xưng hô mình – ta, anh – em, thiếp – chàng | Đối đáp | Giao duyên | [BC] (nguồn phổ thông) |

**[QU] Phú – tỉ – hứng:** phú = kể, tả trực tiếp; tỉ = so sánh/ví ngầm; hứng = mượn cảnh khơi tình (nên đối chiếu giáo trình Đinh Gia Khánh hoặc Chu Xuân Diên). Ánh xạ: phiên khúc thường "phú", câu mở thường "hứng", điệp khúc thường "tỉ" bằng một hình ảnh trung tâm. Hứa Kim Tuyền [BC]: "một bài hát nếu chỗ nào cũng là đặc biệt thì người nghe sẽ không biết nên tập trung vào đâu" → mỗi bài một biện pháp làm điểm nhấn, còn lại hỗ trợ.

## 12.6. Rap Việt: vần theo số âm tiết

**[BC]** (Vietcetera; RFA; Nguyễn Thùy Linh & Nguyễn Thị Thúy Huệ 2025)

| Khái niệm | Nghĩa |
|---|---|
| **Vần đơn** | Một âm tiết hiệp vần |
| **Vần đôi** | Hai âm tiết hiệp vần |
| **Vần ba** | Ba âm tiết hiệp vần (khó hơn, phải bố trí các tiếng đúng chỗ) |
| Delivery | Nhấn, hơi, cảm xúc |
| Flow | Cách tương tác với beat (nhanh/dày hay thưa; straight, triplet; 4/4, 6/8) |
| Punchline | Câu đắt, thường chơi chữ đa nghĩa |
| Storytelling | Kể chuyện |

- Thơ cổ phân vần theo **vị trí** (chân, lưng); rap Việt phân theo **số âm tiết hiệp vần**.
- Ba đặc trưng ngôn ngữ nổi bật của rap Việt: **mô thức gieo vần, chơi chữ, chuyển mã Việt–Anh** (tóm tắt không có số liệu).
- Rap: trình bày "những câu gieo vần nối tiếp nhau theo một giai điệu". Khanh Nhỏ được coi là người đưa rap vào Việt Nam; sau 2006 nổi bật Andree, Đinh Tiến Đạt, LK, Lil Shady, Kyo, Suboi (RFA).
- Pop Thái: bài chịu ảnh hưởng rap có tỉ lệ khớp thanh–nhạc **dưới 50%**.

**[QU] Bốn suy luận** (chưa có thực nghiệm xác nhận):
1. **Vần đa âm tiết** = chuỗi tiếng liên tiếp có phần vần trùng tương ứng (ví dụ hai cụm hai tiếng cùng mẫu "-ay / -anh"). Tiếng Việt đơn tiết nên ghép vần theo từng tiếng (tiếng Anh dựa trọng âm từ đa tiết).
2. **Vần nội** thực chất là vần lưng lục bát mở rộng: một tiếng giữa câu hiệp tiếng cuối câu trước.
3. **Bằng–trắc nới lỏng:** beat và delivery che bớt khác biệt thanh, nên khác nhóm thanh vẫn chấp nhận được; nhưng cùng nhóm thanh, hoặc cùng thanh, nghe "đã tai" hơn. Vần khép (luôn trắc, ngắn) hợp flow dồn, nốt cắt.
4. **Chuyển mã** mở thêm kho vần (vần chéo ngôn ngữ Việt–Anh).

Rapper chuyển sang hát hook trên nốt cố định → chạy lại bộ thanh–nhạc (N8).

**Khoảng trống:** chưa có khảo cứu tiếng Việt chuyên sâu về vần đa âm tiết; chưa có bình luận kỹ thuật của giám khảo *Rap Việt* có trích dẫn; chưa có nghiên cứu cảm nhận về vần khác nhóm thanh; chưa có thống kê vần trong ca từ pop Việt.

## 12.7. Phổ thơ: từ thơ đến lời ca

### Sáu thao tác đã ghi nhận [BC]

| Thao tác | Trường hợp có nguồn |
|---|---|
| **Chọn lọc rất mạnh** | *Em ơi Hà Nội phố* (thơ Phan Vũ, **443 câu**, viết khoảng 1972): Phú Quang nghe đọc, khoảng hai ngày sau phổ, **chỉ chọn 21 câu**; hoàn thành 1986; Lệ Thu thu âm phát sóng 1987 (Báo Pháp luật) |
| **Tái cấu trúc và viết thêm** | *Bên kia sông Đuống* (Hoàng Cầm): Nguyễn Vĩnh Tiến chọn lọc, "tái cấu trúc lại", **viết thêm 2 câu mới**; dựng cấu trúc nhạc trước rồi để lời chảy vào; "tuyệt đối trân trọng nhà thơ" (Tiền Phong) |
| **Đổi tên bài và thể loại** | *Màu tím hoa sim* (Hữu Loan, 1949, thơ tự do) có ít nhất ba bản phổ: Phạm Duy *Áo anh sứt chỉ đường tà* (gần nguyên tác nhất, kể chuyện); Dzũng Chinh *Những đồi hoa sim* (bolero, lời mềm, giữ ý thơ); Anh Bằng *Chuyện hoa sim* (bolero, lời bình dị hơn) (Báo Văn hóa 2024). RFA ghi thêm bản Duy Khánh hát với tên *Màu tím hoa sim*. Các bản phổ phát thanh rộng rãi thập niên 1960 (Viet Nam News) |
| **Ghép nhiều bài thơ** | Đỗ Tiến Lập ghép *Một thoáng Quy Nhơn* và *Biển quê em* (thơ Nguyên Hùng) thành *Trầm tích trong em*; *Cánh buồm tình ái* (Nguyên Hùng) có hai bản phổ khác tên (SGGP) |
| **Đổi vài chữ** | Đăng Khánh: cần "đổi cả lời và chữ trong một vài chỗ" nhưng không sai ý thơ (RFA) |
| **Giản lược nhạc để thơ dẫn** | Phú Quang (hơn 100 ca khúc phổ thơ) giản lược tiết tấu, giai điệu đến mức gần "hát thơ": "Nhạc sĩ đừng bao giờ cậy hay chữ mà cạnh tranh với hồn vía của các nhà thơ" (Báo Văn hóa) |

- Phan Huỳnh Điểu: *Cuộc đời vẫn đẹp sao* (1971), *Nhớ* (1973, thơ Nông Quốc Chấn), *Sợi nhớ sợi thương* (1973, thơ Thúy Bắc), *Anh ở đầu sông em cuối sông* (1978, thơ Hoài Vũ), *Ở hai đầu nỗi nhớ* (1983). **Mâu thuẫn nguồn:** tác giả thơ gốc *Ở hai đầu nỗi nhớ* ghi là **Trần Hoài Thu** (Báo Văn hóa) hoặc **Trần Đình Chính** (SGGP).
- Vũ Thiết: "khi đọc, tôi cảm nhận trong thơ đã có nhạc rồi"; thường giữ nguyên tên bài thơ (Báo Lào Cai).

### Hai triết lý [QU]

| Triết lý | Đại diện | Cách làm |
|---|---|---|
| Thơ dẫn nhạc | Phú Quang | Giản lược nhạc, "hát thơ" |
| Nhạc nắn thơ | Nguyễn Vĩnh Tiến, Đăng Khánh | Dựng cấu trúc nhạc trước, nắn lời vào |

Đăng Khánh [BC]: với lục bát, giai điệu và vần **đã có sẵn trong thơ**, nhạc sĩ dễ chỉ "ghi lại" và giá trị bản nhạc "chỉ còn khoảng 20–30%". Ông ưa thơ tự do hoặc ít vần, tránh thơ quá "trúc trắc"; chọn thang âm theo nhân vật và văn hóa (phương Tây, ngũ cung miền núi phía Bắc, ngũ cung Tây Nguyên, blues). *Màu tím hoa sim* đi từ bản kể chuyện sang hai bản bolero → cùng văn bản có thể đi nhiều thể loại, lời được "bình dân hóa" dần.

### Thơ và lời ca khác nhau ở năm điểm

| Tiêu chí | Thơ | Lời ca | Nhãn và nguồn |
|---|---|---|---|
| Cách tiếp nhận | Đọc, đọc lại được | Nghe một lần theo thời gian thực; phải dễ hiểu, tránh chữ khó | [BC] Nguyễn Văn Hoàn |
| Đơn vị tổ chức | Dòng, khổ, nhịp thơ | Câu nhạc, đoạn nhạc; độ dài câu theo quy luật âm nhạc | [BC] Đăng Khánh |
| Mật độ | Hình ảnh, Hán Việt dày được | Thấp hơn, lặp nhiều hơn, thuần Việt, khẩu ngữ ở chỗ cần nghe rõ | [QU] |
| Điểm nhấn | Có thể dày | Một hook duy nhất; phần khác hỗ trợ | [BC] Hứa Kim Tuyền |
| Vai trò vần và thanh | Ghi nhớ, nhạc tính | Giai điệu đảm nhận ghi nhớ; thanh phải khớp hướng giai điệu | [BC] Phan Đan; Ladd & Kirby |

Nguyễn Văn Chung: người viết cần tự trải nghiệm chủ đề (trước *Viết tiếp câu chuyện hòa bình* ông thăm di tích, gặp cựu chiến binh) (Nhân Dân). Nguyễn Văn Hoàn khi viết thơ để phổ chú trọng ngôn từ dễ hiểu, tứ thơ, vần, liên kết giữa các khổ.

### Quy trình 12 bước chuyển thơ thành lời ca [QU]

| Bước | Việc cần làm | Kiểm tra đi kèm |
|---|---|---|
| 1. Ghi nhận nguồn thơ | Ghi tên bài thơ, tác giả vào brief; không dừng sáng tác để hỏi về giấy phép – việc xin phép nhà thơ hoặc người thừa kế (phạm vi sửa lời, cách ghi danh) được ghi vào tài liệu đầu ra ở bước 12 | V16 |
| 2. Tìm tứ và câu đắt | Đọc to; xác định tứ trung tâm và một câu/cụm có thể làm hook (Hứa Kim Tuyền) | V13 |
| 3. Nhận diện thể thơ | Xác định thể, nhịp, sơ đồ vần (12.2–12.3). Nếu là lục bát "có sẵn nhạc", chủ động tránh chỉ "ghi lại" (Đăng Khánh) | V1 |
| 4. Chọn thể loại và thang âm | Theo nhân vật, vùng miền, khán giả (Đăng Khánh); chọn "hệ" hòa âm | `11-nhac-viet-the-loai.md`, `14-hoa-am-viet-bai-mau.md` |
| 5. Dựng khung hình thức trước | Verse–chorus, AABA hoặc strophic; dựng nhạc rồi để lời chảy vào (Nguyễn Vĩnh Tiến) | `ngon-ngu/vi.md` mục Hình thức |
| 6. Chọn và cắt câu | Chỉ giữ câu phục vụ tứ; chấp nhận cắt rất mạnh (Phú Quang: 21/443) | V14 |
| 7. Sắp xếp và viết thêm | Đảo thứ tự; viết câu nối hoặc điệp khúc nếu cần (Nguyễn Vĩnh Tiến: +2 câu); đổi càng ít chữ càng tốt, không sai ý (Đăng Khánh); ghi mọi chỗ đổi để nhà thơ duyệt | V5–V9 |
| 8. Đánh dấu lời | Gạch ranh giới ngữ đoạn; gán nhóm thanh từng chữ | N1, T1 |
| 9. Đặt nhịp | Ánh xạ nhịp thơ vào ô nhịp (12.4); chữ cuối ngữ đoạn và chữ mang luật vào phách mạnh | N2–N7, V11 |
| 10. Phác giai điệu | Không đi ngược hướng thanh; chọn nốt cao trào | T2–T10 |
| 11. Kiểm tra thi luật lời mới | Vị trí vần, vần khép, ép vần, cách gieo vần; đối chiếu bằng–trắc với cao độ | V1–V16 |
| 12. Hoàn tất và ghi danh | Đặt tên bài (có thể khác tên thơ); ghi "Thơ: …" hoặc "Ý thơ: …"; làm demo. Ghi vào tài liệu đầu ra (gói bàn giao mục 9 và 11): cần văn bản cho phép của nhà thơ hoặc người thừa kế trước khi phát hành, gửi nhà thơ duyệt bản cuối, thỏa thuận nhuận bút | V16; `17-phap-ly-phat-hanh.md` |

### Bản quyền khi phổ thơ

Chi tiết pháp lý, đăng ký, VCPMC, split sheet: **`references/17-phap-ly-phat-hanh.md`**.

- **[BC]** Luật SHTT 2005, Điều 4 khoản 8: **tác phẩm phái sinh** gồm dịch, phóng tác, cải biên, chuyển thể, biên soạn, chú giải, tuyển chọn. Điều 14 và NĐ 22/2018/NĐ-CP: phái sinh được bảo hộ khi (1) không phương hại quyền tác giả gốc, (2) được chủ thể quyền cho phép, (3) có tính sáng tạo. **Làm phái sinh không xin phép là xâm phạm (Điều 28)** → cần thỏa thuận bằng văn bản. Luật sửa đổi 2022 (Luật 07/2022/QH15) và 2025 (Luật 131/2025). Bảo hộ suốt đời + 50 năm → nhà thơ đã mất trong thời hạn thì xin phép người thừa kế.
- **[BC] Thực tiễn còn tranh luận:** hội thảo 2024 (Trương Tuyết Mai): tên nhà thơ có đứng trước nhạc sĩ; trích bao nhiêu thì ghi "phỏng thơ", "trích thơ" hay "ý thơ"; nhạc sĩ có được sửa lời thơ không hỏi. Bích Ngân: giải thưởng không nên chỉ vinh danh nhạc sĩ. SGGP: một đợt Giải thưởng Nhà nước có **10/15 nhạc sĩ được giải nhờ tác phẩm phổ thơ**; Lê Thiếu Nhơn coi ghi tên tác giả là "điều bắt buộc". Giá thị trường: 2004 công ty karaoke trả **100 triệu đồng** cho *Màu tím hoa sim*; 2013 MASECO trả **300 triệu đồng** cho *Ở hai đầu nỗi nhớ*. Phú Quang ghi nguồn và trả thù lao ngay cả khi chỉ mượn một ý thơ.
- **[QU] Quy trình an toàn 4 bước:**
  1. Xin phép bằng văn bản nhà thơ, hoặc người thừa kế.
  2. Thỏa thuận phạm vi sửa lời và cách ghi danh ("Thơ: …", "Ý thơ: …").
  3. Thỏa thuận chia nhuận bút, kể cả phần thu qua VCPMC.
  4. Lưu thỏa thuận để đăng ký quyền tác giả và ủy thác VCPMC; ghi đồng tác giả lời vào split sheet.
- Ca dao không rõ tác giả: theo chế độ tác phẩm dân gian (xem 17-phap-ly-phat-hanh.md).
- **[Cần kiểm chứng]** (1) Chưa có nguồn pháp lý nói rõ bài phổ thơ là "tác phẩm phái sinh" hay "tác phẩm âm nhạc có lời trích từ tác phẩm văn học". (2) Chưa đọc toàn văn Điều 20 (quyền làm phái sinh) và Điều 25 (ngoại lệ). (3) Số điều theo bản 2005/2022 chưa đối chiếu Luật 131/2025. (4) Chưa rõ các bản phổ *Màu tím hoa sim* trước 1975 có xin phép Hữu Loan. → Hỏi luật sư hoặc Cục Bản quyền tác giả trước khi phát hành thương mại.

## 12.8. Bộ kiểm tra thi luật V1–V16

Chạy **sau khi có bản lời hoàn chỉnh, trước khi phác giai điệu** (bước 11 ở 12.7); chạy lại sau khi chỉnh lời theo giai điệu. Bổ sung cho T1–T10 và N1–N9 (`ngon-ngu/vi.md`) và L1–L12 (`13-nghe-viet-loi.md`).

| # | Kiểm tra | Cách làm | Cờ đỏ | Cơ sở |
|---|---|---|---|---|
| V1 | Thể và khung | Ghi rõ lời theo thể nào (lục bát, song thất, 4/5/7/8 chữ, tự do, rap) hoặc theo làn điệu nào (12.10), và mức tuân thủ (chặt, vừa, tự do) | Trộn thể không chủ ý giữa các phiên khúc | [QU] |
| V2 | Số chữ | Đếm chữ mỗi dòng, không tính tiếng đệm `{…}`; phiên khúc 1 và 2 cùng vị trí phải bằng số chữ để hát chung giai điệu | Phiên khúc 2 dư hoặc thiếu chữ so với phiên khúc 1 | [QU] |
| V3 | Bằng–trắc ở vị trí bắt buộc | Lục bát: chữ 2–4–6–8. Song thất: chữ 3–5–7. Đường luật: chữ 2–4–6 và niêm | Chữ 4 câu lục bát là bằng; chữ 6 hoặc 8 là trắc | [BC] (12.3) |
| V4 | Trầm bổng câu bát | Chữ 6 và chữ 8 câu bát: một huyền, một ngang | Cả hai cùng ngang hoặc cùng huyền | [BC] (VietJack; vjol – KHXH) |
| V5 | Vị trí vần | Đánh dấu V ở mọi vị trí phải gieo vần theo sơ đồ; kiểm từng cặp | Lạc vận ở vị trí bắt buộc | [BC] sơ đồ; tên lỗi [QU] |
| V6 | Cùng nhóm thanh | Hai tiếng hiệp vần cùng bằng hoặc cùng trắc | Vần bằng gặp vần trắc ở thể truyền thống | [BC] (Wikipedia: Vietnamese poetry) |
| V7 | Độ giàu và độ tự nhiên của vần | Vần chính ở câu tiêu đề và cuối điệp khúc; vần thông dùng ở phiên khúc. Đọc to từng câu: nếu bỏ yêu cầu vần, có ai nói câu này không? | Ép vần: từ gượng nghĩa chỉ để có vần | [QU] |
| V8 | Vần khép | Tiếng kết -p, -t, -c, -ch không đặt ở vị trí vần bằng, không đặt ở nốt ngân cuối câu | Vần khép ở cuối điệp khúc hoặc ở chữ 6, chữ 8 lục bát | [BC] vần khép chỉ mang sắc, nặng (Lê Thị Hiền); hệ quả [QU] |
| V9 | Cách gieo vần trong khổ | Chọn liền, cách hoặc ôm cho phiên khúc và giữ nhất quán; điệp khúc có thể đổi để tạo tương phản | Mỗi khổ một kiểu vần không có lý do | [QU] [Cần kiểm chứng] |
| V10 | Niêm và đối (nếu dùng) | Đường luật: niêm 1–8, 2–3, 4–5, 6–7; đối 3–4, 5–6. Tứ tuyệt: niêm 1–4, 2–3 chỉ ghi chú [Cần kiểm chứng]. Song thất: cặp thất T–B–T / B–T–B | Thất niêm, thất đối khi tuyên bố theo Đường luật | [BC] (ĐH Long An) |
| V11 | Nhịp và ranh giới từ | Ngắt nhịp thơ trùng ranh giới ngữ đoạn; không cắt đôi từ ghép hoặc từ láy qua vạch nhịp | Nhịp 3/3 cắt giữa một từ ghép | [BC] chân thơ song tiết; quy tắc [QU] (12.4, N4) |
| V12 | Bằng–trắc gặp cao độ | Với mỗi chữ vần, ghi thêm nhóm cao độ: ngang trung, huyền thấp, sắc/ngã cao, hỏi/nặng rất thấp; chọn hướng nốt tương ứng | Vần huyền đặt trên nốt đỉnh; vần hỏi hoặc nặng ở nốt cao nhất | [BC] hai lưới (12.1); hệ quả [QU] |
| V13 | Tu từ và hook | Một hình ảnh hoặc ẩn dụ trung tâm; điệp ngữ hoặc điệp cấu trúc mang hook; không quá một "điểm đặc biệt" mỗi đoạn | "Chỗ nào cũng đặc biệt" | [BC] Hứa Kim Tuyền; vai trò điệp ngữ [QU] |
| V14 | Dễ hiểu khi nghe | Đọc to cho người chưa xem lời; đánh dấu chữ Hán Việt khó, đảo ngữ khó nghe, cặp chữ chỉ khác một dấu (T4) | Người nghe không nhắc lại được câu điệp khúc sau một lần nghe | [BC] Nguyễn Văn Hoàn |
| V15 | Rap | Đánh dấu vần đơn, đôi, ba và vần nội; vần rơi phách 2, 4 hoặc cuối ô; hook hát phải chạy T2–T6 | Vần chỉ ở cuối câu, flow đều đều; hook hát ngược thanh | [BC] thuật ngữ (Vietcetera); quy tắc [QU] |
| V16 | Nguồn thơ và quyền | Nếu lời dùng thơ người khác: có văn bản cho phép; ghi "Thơ:" hoặc "Ý thơ:"; liệt kê chỗ đã sửa; thỏa thuận nhuận bút | Phát hành bài phổ thơ chưa có văn bản đồng ý | [BC] Điều 28 Luật SHTT; [Cần kiểm chứng] với phổ thơ |

**Công cụ:**
- `scripts/kiem-tra-thi-luat.py`: thi luật theo thể – **V3** (bằng–trắc ở vị trí bắt buộc), **V4** (trầm bổng câu bát), **V9** (cách gieo vần trong khổ), **V10** (niêm; đối phải tự soát), kèm vị trí vần theo sơ đồ của từng thể.
- `scripts/dem-am-tiet.py`: đếm âm tiết từng câu và so số chữ giữa các đoạn cùng loại (**V2**); báo vần cuối câu, vần thông gợi ý, vần trộn bằng/trắc (**V5**, **V6**), vần khép -p/-t/-c/-ch ở cuối câu (**V8**); `--bo-ngoac` bỏ phần trong ngoặc đơn khi đếm; `--chi-tiet` in nhóm cao độ từng chữ. Script này **không** kiểm V4. Xem `ngon-ngu/vi.md` mục cuối.

**Tiếng đệm:** lời theo làn điệu chêm từ đệm ở bất kỳ vị trí nào (12.10). Khi chạy `kiem-tra-thi-luat.py`, **viết tiếng đệm trong ngoặc nhọn**, ví dụ `{ơ}`, `{hỡi mà}`: phần trong `{…}` bị loại khỏi phép đếm chữ và vị trí luật. Lời gốc không đổi; ngoặc nhọn chỉ là ký hiệu khi kiểm tra.

**Chế độ `--the` của `kiem-tra-thi-luat.py`:**

| Chế độ | Dùng cho | Ghi chú |
|---|---|---|
| `luc-bat` | Lục bát chính thể | Chữ 2–4–6–8, trầm bổng, vần lưng, vần chân |
| `luc-bat-bt` | Lục bát biến thể | Chấp nhận câu dôi chữ; tìm chữ hiệp vần với chữ cuối câu trên ở vị trí trôi trong câu dưới, báo vị trí; không chấm luật chữ chẵn |
| `song-that` | Song thất lục bát | Chữ 3–5–7 câu thất; cặp 6–8 theo lục bát; sơ đồ vần câu thất chỉ báo [Cần kiểm chứng] |
| `duong-luat` | Bát cú và tứ tuyệt, câu 5 hoặc 7 chữ | Niêm tứ tuyệt chỉ là ghi chú [Cần kiểm chứng] |
| `xen-luc-ngon` | Thất ngôn xen lục ngôn | Chấp nhận câu 6 chữ ở mọi vị trí |
| `hat-noi` | Hát nói | Theo khung 12.3 |
| `4-chu`, `5-chu` | Thơ 4 chữ, 5 chữ, vè, đồng dao, giặm | Đếm chữ, gợi ý nhịp, báo vần |
| `tu-do` | Thơ tự do, lời pop | In nhóm bằng–trắc, vần cuối dòng, vần khép |

**Tự nhận thể không còn gán Đường luật:** khổ 4 hoặc 8 câu toàn câu 7 chữ được chạy như `tu-do`, kèm gợi ý dùng `--the duong-luat` nếu đúng là bài Đường luật (Thơ Mới 7 chữ "rời khuôn Đường luật" [BC], 12.2). Theo quy tắc ưu tiên nguồn, mọi kiểm tra dựa trên điểm [Cần kiểm chứng] chỉ ra ghi chú, không ra lỗi.

## 12.9. Mẫu yêu cầu

Người không chuyên sao chép mẫu, điền mục cần thiết rồi gửi cho Claude. Mục để trống thì Claude tự chọn và ghi rõ lựa chọn. Mục 5 ↔ V1–V3; mục 6 ↔ V2; mục 10 ↔ thể loại và bộ T/N + âm vực; mục 11 ↔ mức áp dụng V3–V10.

```text
YÊU CẦU SÁNG TÁC THƠ / LỜI CA

1. Nội dung, chủ đề: (viết về ai, về điều gì; 1–3 câu)
2. Cảm xúc chủ đạo: (vui / thương / nhớ / biết ơn / tự hào / buồn / hài hước / khác: …)
3. Mục đích và nơi dùng: (tặng riêng / đọc ở sự kiện / hát ở sự kiện /
   đăng mạng xã hội / quảng bá / khác: …)
4. Người nghe hoặc người đọc: (độ tuổi, mối quan hệ, vùng miền)
5. Thể thơ mong muốn: (lục bát / song thất lục bát / 4 chữ / 5 chữ /
   7 chữ / 8 chữ / thơ tự do / rap / để Claude chọn)
6. Độ dài: (số câu hoặc số khổ; nếu để hát: thời lượng mong muốn, ví dụ 3 phút)
7. Giọng văn và xưng hô: (trang trọng / thân mật / dí dỏm;
   anh – em, con – mẹ, mình – ta, tôi – bạn, chúng ta…)
8. Chi tiết riêng bắt buộc phải có: (tên người, địa danh, kỷ niệm, con số, câu nói quen)
9. Điều cần tránh: (từ ngữ, chủ đề, so sánh không muốn dùng)
10. Có phổ nhạc không?  [ ] Không   [ ] Có
    Nếu có: thể loại nhạc (bolero / ballad / dân ca / thiếu nhi / pop / rap / khác: …)
            giọng hát (nam / nữ / trẻ em / song ca / hợp xướng),
            phương ngữ của người hát (Bắc / Trung / Nam),
            cần điệp khúc dễ nhớ không, có câu tiêu đề mong muốn không
11. Mức tuân thủ luật thơ: (chặt – đúng luật bằng trắc và vần /
    vừa – đúng vần, nhịp tự nhiên / tự do – ưu tiên cảm xúc)
12. Có dựa trên bài thơ của người khác không?  [ ] Không
    [ ] Có – tên bài, tác giả: …; đã xin phép tác giả chưa: …
13. Đầu ra mong muốn: (chỉ lời / lời + giải thích luật và vần /
    lời + bảng kiểm V1–V16 / lời + gợi ý hợp âm và nhịp / lời + prompt cho công cụ AI làm demo)
```

**Ví dụ điền ngắn:** Mục 1: bài hát mừng thọ mẹ 70 tuổi. Mục 2: biết ơn, ấm áp. Mục 3: con cháu hát trong tiệc gia đình. Mục 5: lục bát cho phiên khúc, để Claude chọn cho điệp khúc. Mục 6: hai phiên khúc + một điệp khúc, khoảng 3 phút. Mục 8: quê Nam Định, mẹ từng bán hàng ở chợ. Mục 10: có; dân ca mới; song ca nam nữ, giọng Bắc. Mục 11: vừa. Mục 13: lời, bảng kiểm V1–V16, gợi ý hợp âm.

**Claude trả lại theo thứ tự:**
1. Lời hoặc bài thơ hoàn chỉnh.
2. Bảng đánh dấu B/T và vị trí vần ở các câu theo thể truyền thống.
3. Kết quả V1–V16 (và T1–T10, N1–N9 nếu phổ nhạc), ghi rõ chỗ cố ý phá luật và lý do.
4. Nếu phổ nhạc: gợi ý thể loại, nhịp, tông theo giọng hát (`04-giong-hat.md`, `ngon-ngu/vi.md` mục 8) và vòng hợp âm theo "hệ" thể loại (`14-hoa-am-viet-bai-mau.md`).

Người dùng nên đọc to bản nháp, đánh dấu chỗ khó hát hoặc nghe không rõ, gửi lại để chỉnh vòng hai.

## 12.10. Khung lời theo làn điệu

Các mục trước xét lời theo **thể thơ**. Khi viết lời theo một làn điệu dân ca hay sân khấu, câu hỏi còn lại là **lời được đặt vào khung nhạc của làn điệu như thế nào**: số chữ, tiếng đệm, cách lời co giãn. Bảng dưới chỉ ghi điều có nguồn; điều chưa có nguồn nằm riêng ở cột "Chưa kiểm chứng" và không được dùng làm quy tắc.

| Làn điệu | Thể lời (có nguồn) | Tiếng đệm / co giãn | Quan hệ lời – khung nhạc | Chưa kiểm chứng | Nguồn |
|---|---|---|---|---|---|
| **Lý Nam Bộ** | "Đại đa số điệu Lý Nam Bộ sử dụng thể thơ lục bát", ít nhất 1 cặp, nhiều nhất 28 cặp (Lý đi cấy). Ngoài ra: song thất lục bát (Lý đất giồng, Lý kéo chài); 4 chữ (Lý con rồng, Lý bông đậu, Lý cây xanh); 7 chữ (Lý bốn mùa); 8 chữ (Lý tang tình); 4 chữ kết hợp lục bát (Lý miễu lý đình); hỗn hợp (Lý chim sắt). Cá biệt có bài chỉ dựa vào một câu thơ sáu chữ (Lý con sáo Gò Công, Lý mù u Bến Tre, Lý con kiến, Lý vo gạo Đồng Tháp) | Từ phụ một âm (a, ơ, ớ…) hoặc cụm ("hỡi mà", "khoan hố khoan tình", "xự xế xang ú liu", "ý lý bằng răng"). Từ phụ "có thể được thêm vào ở bất kỳ vị trí nào như trước, giữa hoặc cuối câu thơ", để "đệm lót, đưa hơi, mở rộng hay kéo dài câu nhạc", và giúp khớp dấu giọng của lời với hướng giai điệu. Lý xang xế xang chỉ có 1 cặp lục bát mà thành bài đầy đặn nhờ từ phụ | Hình thức phổ biến nhất là 1 đoạn đơn, sau đó là 2 đoạn đơn; 3 đoạn "hầu như hiếm gặp". Lý đi cấy được hát trên 14 đoạn nhạc ngắn gần giống nhau, mỗi đoạn ứng với một khổ 2 cặp lục bát | Lý có điệp khúc hay câu xướng–câu xô; lý Huế, lý miền Trung; tiếng đệm "tình bằng" | Nguyễn Bảo Lan 2025 |
| **Quan họ** | Thể thơ của lời cổ chưa có nguồn (xem cột "Chưa kiểm chứng") | Từ đệm lót, đưa hơi được dùng "đậm đặc vào bậc nhất"; tiếng đệm có khi mang nghĩa, có khi không hoặc đã mất nghĩa; nhiều làn điệu lấy tiếng đệm điển hình để đặt tên. Thành ngữ "thường được tách ra đối xứng với nhau (tức là tách 2/2)", "chêm xen vào giữa là các hư từ luyến láy" | Đặt lời mới: Xuân Tứ rút gọn một bài cổ và viết lại một số câu cho giai điệu mềm hơn. Quan họ cổ hay kéo dài phần kết và dùng nhịp hỗn hợp 2/4 với 3/4; bài mới phần lớn dùng 2/4 hoặc 4/4 | Lời cổ là lục bát (tỷ lệ); "câu đôi", "giọng vặt", "lời chính/lời phụ"; các tiếng đệm cụ thể như "i hi", "ư hư", "tình rằng" | Ngô Thị Thanh Hằng 2012 (khảo sát 100 lời cổ); Viện Âm nhạc, Nguyễn Trung 2019 |
| **Ví Nghệ Tĩnh** | Lục bát, lục bát biến thể và song thất lục bát (7-7-6-8); ví "thường dùng thể thơ lục bát để diễn tả tình cảm, đặc biệt là tình yêu đôi lứa" | Chưa có nguồn | Nhịp tự do; giai điệu theo lời, ngữ cảnh và tâm trạng người hát. Hát phường vải có "thủ tục chặt chẽ, ổn định", lời "chải chuốt, bóng bẩy", nhiều điển cố và từ Hán Việt | Cách luyến và kéo dài chữ cuối nhịp | Báo Nghệ An; Nguyễn Duy Cường 2025, VASS; Nguyễn Nhã Bản & Phan Xuân Đạm 2015 |
| **Giặm Nghệ Tĩnh** | Câu 5 chữ; giặm "sử dụng thể thơ 5 chữ để kể lể, tự sự, khuyên răn" | Chưa có nguồn | Giặm "có tiết tấu rõ ràng, phách mạnh, phách nhẹ với nhịp 3/4 và 6/8". Trừ một số câu đầu và cuối, bài "chủ yếu gồm nhiều đoạn giống nhau", các đoạn "nối lại bằng vần"; lời theo "lối kể chuyện", "không câu nệ nghiêm ngặt vào luật lệ"; giặm và vè gần nhau đến mức có tên chung "giặm vè" | Khổ 5 câu; câu 5 láy lại câu 4; vần chân câu 1–2–4; các tiểu loại; nghĩa chữ "giặm" | Nguyễn Duy Cường 2025, VASS; Báo Nghệ An; Nguyễn Nhã Bản & Phan Xuân Đạm 2015 |
| **Vọng cổ nhịp 32** (cải lương) | Lời viết theo khung câu nhạc, số chữ mỗi câu tăng khi khung nhịp mở rộng: câu 1 nguyên thủy có 5 chữ; trong tuồng *Khúc oan vô lượng*, hai câu đầu lên 10 và 12 chữ. Ở nhịp 32, "có nhiều âm tiết trong ca từ sẽ miêu tả vấn đề chi tiết hơn" | Nếu phần đờn giữ nguyên trong từng khung nhạc thì lời có thể dài thêm. Soạn giả viết được lời buồn, hùng hay hài trên cùng một giai điệu | Nhịp 32 rút còn 6 câu, mỗi câu 32 nhịp. Chữ nhạc kết câu: câu 1 cống, câu 2 xang; "dứt câu 3, câu 4, câu 6 cũng bằng âm hò"; câu 5 là câu duy nhất kết bằng xê (xề). Trước câu vọng cổ thường có phần nói lối không theo nhịp, hát mỗi chữ một nốt với trường độ đều | Chữ dứt câu ở âm hò phải mang thanh bằng; luật vần của lời; khái niệm "lớp"; nói lối cải lương; thơ ngâm trước vọng cổ | RFA, soạn giả Nguyễn Phương 2006; Đỗ Quốc Dũng 2019; Wikipedia: Vọng cổ |
| **Nói lối và hát Nam** (hát bội) | Nói lối "thường được viết bằng thể thơ biền ngẫu đối xứng từ 3 đến 10 chữ", chia thành câu trống và câu mái. Hát Nam "dựa trên thể loại thơ lục bát, lục bát biến thể hoặc song thất" | Nói lối dẫn sang hát Nam bằng "thủ": người hát luyến một chữ cuối câu để báo dàn nhạc | Nói lối "thuộc làn điệu không nhịp" (Lối Xuân, Lối Ai, Lối Xuân Nữ); hát Nam có nhịp | Thể lời của các lối bạch, xướng, thán, khách, oán | Đào Thị Như Mì 2025 |
| **Hát ru** | Lời lấy chủ yếu từ ca dao, đồng dao và hò dân gian | Hát ru Nam Bộ có mô thức mở đầu "ầu ơ", "ví dầu" (`11-nhac-viet-the-loai.md`) | Chưa có nguồn | Cấu trúc câu và cách kéo dài chữ khi ru | Nguyễn Quốc Khánh 2021 |
| **Hò** (Huế, Nam Bộ) | **Chưa có khuôn lời đã kiểm chứng; tạm dùng khung lục bát ở mức gợi ý** | Chưa có nguồn | Hò lao động (hò kéo chài, hò khoan, hò mái nhì) gắn với tiếng hô nhịp "dô ta" và được coi là một nguồn gốc sớm của mô hình vần–nhịp lục bát | Câu kể, câu xô, câu mở "Hò ơ…"; độ dài câu | Nguyễn Quốc Khánh 2021 |
| **Bài chòi** (câu thai) | **Chưa có khuôn lời đã kiểm chứng; tạm dùng khung lục bát ở mức gợi ý** | Chưa có nguồn | Chưa có nguồn. Trang UNESCO chỉ xác nhận vị thế di sản (2017), không mô tả thể thơ | Thể thơ của câu thai | UNESCO ICH |
| **Hát xoan** | **Chưa có khuôn lời đã kiểm chứng; tạm dùng khung lục bát ở mức gợi ý** | Chưa có nguồn | Chưa có nguồn | Lời quả cách, lời hát hội | Chưa có nguồn trong đợt rà soát |

**[Suy luận từ nhiều nguồn] Nhạc cố định, lời co giãn.** Gộp các dòng lý, quan họ, vọng cổ, ví và giặm ở trên thì thấy một nguyên tắc chung cho lời đặt theo làn điệu: **khung nhạc là phần cố định, lời là phần thích ứng**. Lời thích ứng bằng ba cách: (1) thêm hoặc bớt từ đệm (lý, quan họ); (2) co giãn số chữ trong khung câu (vọng cổ); (3) giữ đúng thể của làn điệu (lục bát cho ví, 5 chữ cho giặm). Đây là suy luận gộp từ các nguồn trong bảng, **không phải quy chuẩn đã được công bố**. Nguyên tắc này bổ sung cho quy trình phổ thơ ở 12.7. Nó cũng là lý do bộ kiểm tra cần ký hiệu riêng cho tiếng đệm (12.8; `scripts/kiem-tra-thi-luat.py`): với lời theo làn điệu, tiếng đệm và việc co giãn số chữ là công cụ chính chứ không phải lỗi.

## 12.11. Phụ lục: các thể ngoài phạm vi lời ca

Các thể dưới đây có trong văn học Việt nhưng **không được dùng làm khuôn viết lời** trong bộ hướng dẫn này. Mỗi dòng chỉ ghi phần định nghĩa có nguồn, để người dùng biết các thể này tồn tại.

| Thể | Định nghĩa có nguồn | Nguồn |
|---|---|---|
| **Biền văn** | "Biền văn là một thể văn, trong đó, mỗi câu được chia làm hai vế đối nhau" (dẫn Đào Duy Anh). Biền lệ quy định mỗi vế 4–6 tiếng; đời Tống thêm niêm và đưa vào văn trường ốc thì gọi là tứ lục | Triều Nguyên 2018 |
| **Năm lối đặt câu biền văn** | **Tứ tự**: mỗi vế bốn tiếng. **Bát tự**: mỗi vế tám tiếng, chia hai phân vế bằng nhau. **Song quan**: mỗi vế từ năm đến chín tiếng, đặt liền mạch. **Cách cú**: mỗi vế gồm hai phân vế. **Gối hạc** (hạc tất): mỗi vế gồm ba phân vế, phân vế giữa thường ngắn. Triều Nguyên cho rằng thực chất chỉ có ba kiểu (tứ tự là dạng đặc biệt của song quan, bát tự là dạng đặc biệt của cách cú) | Dương Quảng Hàm 1943, tr. 128–130 và Bùi Văn Nguyên & Hà Minh Đức 2003, tr. 142–143, dẫn qua Triều Nguyên 2018 |
| **Cổ thể và cận thể** | "Kinh nghĩa, văn sách, phú, văn tế, câu đối,... sử dụng cổ thể"; "chiếu, dụ, cáo, hịch, biểu, văn, thư,... sử dụng cận thể" | Triều Nguyên 2018 |
| **Phú** | Vần "luôn gieo ở cuối câu biền thể". Theo phân loại Trung Hoa có cổ phú, bài phú, luật phú, văn phú. Phú là "phô bày", "tả vật nói chí"; *Quần hiền phú tập* lưu phú đời Trần, Hồ, Hậu Lê | Triều Nguyên 2018; Nguyễn Thị Hải Vân 2025 |
| **Văn tế** | Bố cục bốn phần: lung khởi (cảm tưởng khái quát), thích thực (hồi tưởng cuộc đời, công đức), ai vãn (thương tiếc), kết (tình cảm của người đứng tế); ví dụ *Văn tế nghĩa sĩ Cần Giuộc*. Bố cục này chỉ có nguồn cho văn tế, không gán cho phú | VietJack, Ngữ văn 11 |
| **Câu đối** | Loại biền văn đặc biệt, "mỗi văn bản chỉ một câu"; thuộc nhóm cổ thể. Luật thanh của câu đối chưa có nguồn | Triều Nguyên 2018 |
| **Hịch, cáo, chiếu** | Thuộc nhóm cận thể. Bố cục chưa có nguồn | Triều Nguyên 2018 |
| **Kinh nghĩa** | Thuộc nhóm cổ thể. Cấu trúc chưa có nguồn | Triều Nguyên 2018 |
| **Bài luật** | Phép Đường cho phép thể dài không hạn định bên cạnh bát cú và tuyệt cú | Wikipedia: Vietnamese poetry |
| **Tứ ngôn, lục ngôn có luật** | Tứ ngôn thường ngắt 2/2, luật thanh đặt ở chữ 2 và 4, vần ở cuối hoặc giữa câu. Lục ngôn thể luật ngắt 2/2/2; thể cổ phong thường 3/3 | Võ Thị Ngọc Thúy và cộng sự 2025, ĐHSP Huế |
| **Thuận nghịch độc (hồi văn), ngũ bình ngũ trắc** | Thuận nghịch độc: đọc xuôi và đọc ngược đều phải có vần, có nghĩa; nếu là thơ luật thì cả hai chiều phải đúng luật thanh. Ngũ bình ngũ trắc: các câu luân phiên toàn thanh bằng và toàn thanh trắc | Võ Thị Ngọc Thúy và cộng sự 2025, ĐHSP Huế |
| **Cổ phong, từ khúc, liên hoàn, yết hậu, vĩ tam thanh, triệt hạ, họa vận** | Chưa có định nghĩa có nguồn trong đợt rà soát; không mô tả | — |

**Vì sao không dùng cho lời ca.** Đợt rà soát kết luận các thể này "không đáng bổ sung thành quy tắc viết lời", và một phụ lục định nghĩa là đủ. **[Quy ước/Suy luận]** Lý do thực hành: biền văn lấy vế đối dài làm đơn vị và gắn với tế lễ, nghị luận hay khoa cử, không có khung câu và nhịp để đặt vào câu nhạc; các thể chơi chữ (thuận nghịch độc, ngũ bình ngũ trắc) ràng buộc chiều đọc hoặc chuỗi thanh, mâu thuẫn với yêu cầu khớp thanh–nhạc ở `ngon-ngu/vi.md`. Người viết lời chỉ nên mượn thủ pháp, ví dụ đối hai vế cho một câu chốt, chứ không mượn thể.
