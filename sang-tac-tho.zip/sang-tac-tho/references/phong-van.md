> Tệp tra cứu của skill sang-tac-tho. Bộ câu hỏi phỏng vấn trước khi viết. Nhãn: [BC] có bằng chứng, nguồn nằm trong `thi-luat.md` hoặc `nghe-viet.md` · [QU] quy ước/suy luận.

# Phỏng vấn sáng tác thơ: tối đa 10 câu, hỏi từng câu một

## 1. Quy tắc hỏi

1. **Hỏi từng câu một.** Chờ người dùng trả lời xong mới hỏi câu tiếp theo. Mỗi lượt chỉ có một câu hỏi.
2. **Tối đa 10 câu. Hỏi càng ít càng tốt.** Trước khi hỏi, đọc kỹ ý tưởng người dùng đưa ra. Mục nào ý tưởng đã trả lời thì đánh dấu "đã có" và bỏ qua mục đó.
3. **Thứ tự ưu tiên** khi buộc phải bỏ bớt câu hỏi: Q3 (chi tiết thật) > Q2 (cảm xúc) > Q1 (dịp, người nhận) > Q4 (thể thơ) > Q9 (điều bắt buộc) > các câu còn lại. Ba câu Q1–Q3 quyết định bài thơ hay hay dở, nên gần như luôn phải hỏi. Các câu sau chủ yếu quyết định hình thức.
4. **Mỗi câu hỏi có ba phần:**
   - câu hỏi ngắn;
   - 2–4 lựa chọn để bấm, kèm một dòng mô tả nếu cần;
   - một dòng "Gợi ý:" giúp người không chuyên trả lời được.
   Luôn chừa đường cho người dùng tự viết câu trả lời, hoặc nói "tuỳ Claude".
5. **Có công cụ hỏi nhiều lựa chọn** (AskUserQuestion) thì dùng nó, mỗi lần một câu. Dòng "Gợi ý:" đặt trong mô tả của câu hỏi hoặc của lựa chọn. **Không có công cụ** thì hỏi bằng chữ: câu hỏi, các lựa chọn đánh số 1–4, rồi dòng gợi ý.
6. **Câu sau dựa vào câu trước.** Ví dụ: các thể thơ gợi ý ở Q4 phụ thuộc vào câu trả lời Q1, Q2 và Q6.
7. **Ghi tiến độ ở đầu mỗi câu hỏi**, dạng "Câu 3/7", trong đó 7 là số câu dự kiến sẽ hỏi.
8. **Người dùng nói "viết luôn"**, "đủ rồi", hoặc trả lời "tuỳ Claude" từ hai lần trở lên: ngừng hỏi. Các mục còn thiếu lấy theo cột "Mặc định" và ghi rõ trong phiếu sáng tác.
9. **Không hỏi** về thi luật kỹ thuật (bằng–trắc, niêm), vì đó là việc của Claude. Không hỏi lại điều người dùng đã nói.
10. **Câu trả lời mâu thuẫn nhau** (ví dụ chọn Đường luật nhưng muốn giọng đời thường, xưng "anh–em"): nêu mâu thuẫn trong một câu và đề xuất cách dung hoà. Việc này không tính là một câu hỏi mới.

## 2. Mười câu hỏi

| # | Mục | Câu hỏi mẫu | Lựa chọn gợi ý | Gợi ý cho người dùng | Bỏ qua khi | Mặc định |
|---|---|---|---|---|---|---|
| Q1 | Dịp và người nhận | "Bài thơ này dành cho ai, nhân dịp gì?" | Tặng một người thân · Kỷ niệm, lễ, sự kiện · Viết cho chính mình · Để phổ nhạc hoặc làm lời ca | "Biết người đọc là ai, Claude chọn được cách xưng hô và độ riêng tư phù hợp." | Ý tưởng đã nêu người nhận hoặc dịp | Viết cho chính mình |
| Q2 | Sự thật cảm xúc | "Đọc xong câu cuối, anh muốn người đọc cảm thấy điều gì?" | Ấm áp, biết ơn · Nhớ nhung, tiếc · Day dứt, buồn lặng · Vui, tự hào | "Chỉ chọn một cảm xúc chính. Nếu cảm xúc đổi ở cuối bài, ví dụ từ buồn sang bình yên, hãy nói thêm." | Ý tưởng đã nói rõ cảm xúc | Suy từ ý tưởng và ghi rõ trong phiếu |
| Q3 | Chi tiết thật | "Có một chi tiết thật nào chỉ anh biết không? Một đồ vật, một khoảnh khắc, một câu nói…" | (Câu tự viết, không có lựa chọn sẵn; có thể cho "Chưa nghĩ ra, Claude gợi ý giúp") | "Ví dụ: chiếc áo mưa cũ treo sau cửa, câu mẹ hay nói, tiếng xe lúc 5 giờ sáng. Một chi tiết thật đáng giá hơn mười tính từ đẹp." | Ý tưởng đã có chi tiết cụ thể | Claude đề xuất 3 chi tiết để người dùng chọn. Lượt này tính là câu Q3 |
| Q4 | Thể thơ | "Anh muốn viết theo thể thơ nào?" | 2–3 thể hợp nhất với Q1, Q2, Q6, theo bảng ở mục 3 · "Claude chọn giúp" | Mỗi lựa chọn có một dòng mô tả cảm giác của thể đó, ví dụ: "Lục bát: êm, gần ca dao, dễ thuộc" | Người dùng đã nêu thể | Thể đứng đầu theo bảng ở mục 3 |
| Q5 | Độ dài | "Bài thơ dài chừng nào?" | Rất ngắn (2–4 câu) · Vừa (8–12 câu) · Dài (16–24 câu) · Theo khuôn của thể | "Thơ tặng, thơ thiệp thường ngắn. Bài kể chuyện thì cần dài hơn." Thể có khuôn cố định (bát cú 8 câu, tứ tuyệt 4 câu, hát nói 11 câu) thì bỏ câu này | Thể có khuôn cố định, hoặc đã nêu độ dài | Vừa, hoặc theo khuôn của thể |
| Q6 | Giọng và chất liệu chữ | "Anh thích giọng thơ nào?" | Mộc mạc, gần ca dao · Cổ điển, trang trọng · Hiện đại, đời thường · Trẻ trung, dí dỏm | "Giọng cổ điển dùng nhiều từ Hán Việt; giọng ca dao dùng hình ảnh quê và lối so sánh 'như…'." | Suy được từ Q1 và Q4 | Theo thể đã chọn |
| Q7 | Xưng hô và vùng miền | "Trong bài, ai nói với ai, xưng hô thế nào?" | Anh – em · Con – mẹ/cha · Tôi – (người, đất, quê) · Mình – ta | "Muốn thêm chất giọng một vùng (Bắc, Trung, Nam) thì ghi luôn ở đây." | Q1 đã cho rõ | Suy từ Q1 |
| Q8 | Không gian, thời gian | "Bài thơ diễn ra ở đâu, lúc nào?" | Một mùa cụ thể · Một nơi chốn cụ thể · Một khoảnh khắc trong ngày · Không cần cố định | "Ví dụ: chiều mưa tháng Bảy ở Tây Ninh. Bối cảnh rõ giúp hình ảnh thật hơn." | Q3 đã cho bối cảnh | Lấy từ chi tiết ở Q3 |
| Q9 | Điều bắt buộc | "Có tên người, ngày tháng, nhan đề hay câu kết nào nhất định phải có không?" | Không có · Có (tự viết) | "Câu kết anh muốn có sẵn rồi thì Claude sẽ viết cả bài để dẫn tới câu đó." | Không có dấu hiệu cần | Không có |
| Q10 | Điều cần tránh | "Có điều gì cần tránh không?" | Tránh giọng bi luỵ · Tránh từ sáo rỗng · Tránh nhắc chuyện riêng · Không có | "Ví dụ: bài tặng vợ thì không muốn nhắc chuyện ốm đau." | Ít khi cần; chỉ hỏi khi chủ đề nhạy cảm (mất mát, chia ly, sức khoẻ) | Tránh sáo ngữ (L3) |

## 3. Gợi ý thể thơ cho Q4

[QU] Bảng này suy từ cột "Dùng trong ca khúc / dân ca" ở `thi-luat.md` 12.2 và từ nhận định có nguồn của Ngô Tự Lập: chọn thể là dùng "điển tích hình thức", ví dụ lục bát tự gợi làng quê [BC]. Đây là gợi ý, không phải quy tắc.

| Khi người dùng muốn… | Gợi ý theo thứ tự | Vì sao (mô tả cho người dùng) |
|---|---|---|
| Ấm áp, quê hương, gia đình, tặng mẹ cha | Lục bát · Lục bát biến thể · Thơ 8 chữ | Lục bát êm, gần ca dao, dễ thuộc. Biến thể cho phép câu dài hơn khi cần kể |
| Kể chuyện, than thở, day dứt | Song thất lục bát · Thơ tự do · Thơ 8 chữ | Song thất xưa dùng cho khúc ngâm (*Chinh phụ ngâm*) [BC] |
| Trang trọng, chúc mừng, kỷ niệm thành lập | Đường luật (tứ tuyệt hoặc bát cú) · Thơ 5 chữ · Lục bát | Đường luật gọn, có đối, có niêm, hợp dịp trang nghiêm |
| Lãng mạn, hoài niệm kiểu tiền chiến | Thơ Mới 7 chữ (khổ 4 câu) · Thơ 8 chữ | Gợi không khí Thơ Mới 1932–1945 [BC] |
| Đời thường, hiện đại, riêng tư | Thơ tự do · Thơ 8 chữ · Tân hình thức | Nhạc tính quan trọng hơn vần chặt [BC] |
| Thiếu nhi, vui, trò chơi | Thơ 4 chữ · Đồng dao · Vè | Nhịp 2/2 dễ đọc theo [BC] |
| Ngắn, súc tích, như một khoảnh khắc | Tứ tuyệt · Thơ 5 chữ · Lục bát 2–4 câu | Ít câu nên mỗi chữ đều phải có việc |
| Phong cách ca trù, phóng khoáng | Hát nói (có thể kèm mưỡu) | Khuôn 11 câu chia 4–4–3 [BC] |
| Định phổ nhạc (Q1) | Lục bát · Thơ 8 chữ · Khổ 4 câu 7 chữ · Thơ tự do | Xem `thi-luat.md` 12.4 và 12.7 |

Các thể chỉ có nguồn một phần (ngũ ngôn Đường luật, thất ngôn xen lục ngôn, thủ vĩ ngâm, thất ngôn trường thiên Tày, nói lối) chỉ đề xuất khi người dùng tự nhắc tới. Khi đó, nói rõ phần luật nào chưa kiểm chứng. Các thể ở 12.11 (phú, văn tế, câu đối, hịch…) nằm ngoài phạm vi skill này. Nếu người dùng hỏi tới, nói ngắn gọn điều đã biết có nguồn và cho biết skill không soát luật các thể đó.

## 4. Phiếu sáng tác

Sau câu hỏi cuối, Claude tóm tắt các câu trả lời thành phiếu dưới đây và đưa vào phần bàn giao. Không chờ người dùng duyệt phiếu rồi mới viết.

```
Phiếu sáng tác
- Dành cho / dịp: …
- Cảm xúc chính → cảm xúc cuối bài: …
- Chi tiết thật: …
- Thể / độ dài: … (--the …)
- Giọng / xưng hô / vùng: …
- Bối cảnh: …
- Bắt buộc có / cần tránh: …
- Mặc định Claude tự chọn: … (mục nào không hỏi)
```
