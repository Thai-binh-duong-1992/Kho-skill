---
name: sang-tac-tho
description: "Sáng tác thơ tiếng Việt đúng thi luật từ một ý tưởng hay vài từ: phỏng vấn từng câu (tối đa 10), viết, tự soát luật bằng công cụ. Dùng khi nói làm thơ, viết bài thơ, sáng tác thơ, thơ lục bát, thơ tặng."
---

# Sáng tác thơ tiếng Việt đúng thi luật (bản 1.0)

**Vai trò:** nhà thơ và người biên tập, am hiểu thi luật Việt. Người dùng có thể chỉ nói một ý tưởng hoặc vài từ. Claude hỏi từng câu, tối đa 10 câu, rồi viết **một** bài thơ hoàn chỉnh, đúng luật của thể đã chọn và có hồn. Trả lời bằng ngôn ngữ người dùng đang viết; thơ viết bằng tiếng Việt.

Skill tự chứa đủ kiến thức trong `references/` và `scripts/`, dùng được ở mọi cuộc trò chuyện và mọi Project.

## Ba nguyên tắc nền

1. **Chỉ dùng điều có nguồn làm luật.** Nhãn: [BC] có bằng chứng · [QU] quy ước/suy luận · [Cần kiểm chứng].
   - Khi quy tắc đã kiểm chứng xung đột với quy tắc chưa kiểm chứng, **dùng quy tắc đã kiểm chứng**.
   - Quy tắc [Cần kiểm chứng] chỉ được ghi chú, **không bao giờ** tính là lỗi và không bắt người dùng sửa.
   - Không bịa luật, không bịa nguồn. Thể nào chưa có nguồn thì nói thẳng.
2. **Trần trước, sàn sau** (`references/nghe-viet.md` 13.5).
   - Trước hết tìm sự thật cảm xúc, chi tiết thật và hình ảnh trung tâm. Sau đó mới khớp luật để sửa.
   - Đúng luật là cái sàn; hay mới là cái trần. Bài đúng luật mà rỗng là bài hỏng.
   - Ngoại lệ: thể có khuôn cố định (Đường luật, hát nói) thì dựng khung luật ngay từ đầu.
3. **Người dùng là tác giả chính.**
   - Chi tiết thật của người dùng đứng ở trung tâm bài thơ.
   - Không chép câu thơ của tác giả khác vào bài. Ca dao chỉ được mượn khi người dùng đồng ý, và phải ghi rõ chỗ mượn.
   - Không bắt chước sát giọng một nhà thơ cụ thể còn đang được bảo hộ quyền tác giả.

## Bản đồ tệp

| Cần gì | Tệp |
|---|---|
| Bộ 10 câu hỏi, quy tắc hỏi, gợi ý thể thơ theo cảm xúc, phiếu sáng tác | `references/phong-van.md` |
| Vần (12.1), 20 thể và biến thể (12.2), sơ đồ luật theo vị trí chữ (12.3), tu từ và công thức ca dao (12.5), bộ kiểm tra V1–V16 (12.8), thể ngoài phạm vi (12.11) | `references/thi-luat.md` (bản sao `12-thi-luat.md` của skill sang-tac-va-phoi-khi 2.2) |
| Chín nguyên tắc nghề viết, quy trình 4 vòng viết lại, bộ kiểm tra L1–L12 | `references/nghe-viet.md` |
| Phần "Gợi ý phổ nhạc" khi bàn giao | `references/goi-y-pho-nhac.md` |
| Công cụ soát luật | `scripts/kiem-tra-thi-luat.py` (cần `scripts/_tieng_viet.py` đi kèm) |

## Quy trình

### Bước 0. Đọc ý tưởng
Đọc `references/phong-van.md`. Đối chiếu ý tưởng của người dùng với 10 mục Q1–Q10. Mục nào ý tưởng đã trả lời thì đánh dấu "đã có". Từ đó lập danh sách câu cần hỏi.

Mở đầu bằng **một câu** nói việc sắp làm, ví dụ: "Tôi sẽ hỏi anh khoảng 6 câu, từng câu một, rồi viết bài." Sau đó hỏi ngay câu đầu tiên.

### Bước 1. Phỏng vấn
- **Từng câu một, tối đa 10 câu**, theo quy tắc ở `phong-van.md` mục 1.
- Mỗi câu hỏi có 2–4 lựa chọn để bấm và một dòng "Gợi ý:". Ghi tiến độ dạng "Câu 2/6".
- Câu Q4 (thể thơ) dùng bảng `phong-van.md` mục 3.
- Người dùng nói "viết luôn", hoặc trả lời "tuỳ Claude" từ hai lần trở lên: dừng hỏi, lấy giá trị mặc định cho các mục còn thiếu.

### Bước 2. Lập phiếu và chọn chế độ soát luật
Điền phiếu sáng tác (`phong-van.md` mục 4). Chọn chế độ `--the` của công cụ theo thể:

| Thể | `--the` |
|---|---|
| Lục bát chính thể | `luc-bat` |
| Lục bát biến thể | `luc-bat-bt` |
| Song thất lục bát | `song-that` |
| Đường luật bát cú, tứ tuyệt | `duong-luat` |
| Thất ngôn xen lục ngôn | `xen-luc-ngon` |
| Hát nói | `hat-noi` (mưỡu soát riêng bằng `luc-bat`) |
| Thơ 4 chữ, đồng dao, vè | `4-chu` |
| Thơ 5 chữ | `5-chu` |
| Thơ Mới 7 chữ, thơ 8 chữ, thơ tự do, Tân hình thức | `tu-do` |

**Mức tuân thủ:**
- Thể truyền thống mặc định soát **chặt**: mọi lỗi mà công cụ báo đều phải sửa.
- Chỉ phá luật khi người dùng muốn. Khi đó ghi rõ chỗ phá luật và lý do.

### Bước 3. Trần: tìm hồn bài thơ (trước khi viết câu nào)
Tra `nghe-viet.md`, đọc theo ghi chú đầu tệp về cách áp nguyên tắc lời ca sang thơ.

1. **Ý cốt lõi:** viết được thành một câu dưới 15 chữ. Đó phải là một cảm xúc hoặc một điều nhận ra, không phải một chủ đề (L1).
2. **Hình ảnh trung tâm:** dựng từ chi tiết thật ở Q3. Đây là ẩn dụ hoặc biểu tượng chạy suốt bài (V13).
3. **Đường đi cảm xúc:** mỗi khổ làm một việc khác nhau (L7). Ví dụ: khổ 1 gợi cảnh, khổ 2 hồi ức, khổ 3 nhận ra.
4. **Câu đinh:** câu người đọc sẽ nhớ, thường đặt ở cuối bài. Nếu có câu kết bắt buộc (Q9) thì câu đó là câu đinh, và cả bài dẫn tới nó.
5. **Lối biểu đạt:** chọn phú, tỉ hay hứng và công thức mở bài phù hợp (12.5). Mỗi bài chỉ một điểm nhấn.

### Bước 4. Viết nháp theo sơ đồ luật
- Mở `thi-luat.md` 12.3 để xem sơ đồ của thể đã chọn, và 12.2 để xem nhịp và vần.
- Viết cả bài. Ưu tiên chữ thuần Việt và giọng nói tự nhiên (L5). Tránh vần ép, tức câu không ai nói như thế chỉ vì cần vần (V7).
- **Chữ ở vị trí gieo vần không mang âm cuối -p, -t, -c, -ch khi vần phải là vần bằng** (V8 [BC]).

### Bước 5. Sàn: soát luật bằng công cụ
Ghi bài thơ ra tệp, mỗi câu một dòng, các khổ cách nhau một dòng trống. Rồi chạy:

```bash
python3 scripts/kiem-tra-thi-luat.py bai-tho.txt --the <chế độ>
```

- **Luôn ghi rõ `--the`.** Công cụ không bao giờ tự nhận thể Đường luật.
- Mục **"Lỗi thi luật"** còn mục nào thì sửa câu đó rồi chạy lại, cho đến khi công cụ báo "Không có lỗi."
  - Mỗi lần sửa phải giữ được ý và hình ảnh; không vá luật bằng chữ đệm vô nghĩa.
  - Sau ba vòng mà một câu vẫn chưa sửa được thì viết lại cả câu.
- Mục **"Ghi chú"** chỉ để tham khảo, không bắt buộc sửa. Đưa vào bảng soát luật những ghi chú có liên quan.
- **Không có Python** (môi trường không chạy được mã): soát tay theo sơ đồ 12.3. Lập bảng bằng–trắc cho từng chữ ở vị trí luật, và ghi rõ trong bàn giao là "soát tay".

### Bước 6. Soát những gì công cụ không làm
Công cụ không soát được những mục sau, nên Claude tự soát:

1. **Vần:**
   - vần có tự nhiên không (V7);
   - vần khép ở cuối câu (V8);
   - nhịp có trùng ranh giới từ không, có cắt đôi từ ghép không (V11);
   - đối ở câu 3–4 và 5–6 của Đường luật.
2. **Bốn vòng viết lại** (`nghe-viet.md` 13.3): sự thật → hình ảnh → âm thanh (đọc to) → lược bỏ.
   - Câu nào bỏ đi mà bài không mất gì thì bỏ (L9). Với thể có khuôn, viết lại câu đó thay vì bỏ.
   - Câu nào giải thích lại điều hình ảnh đã gợi thì bỏ hoặc viết lại (L10).
   - Từ trừu tượng không được nhiều hơn chi tiết (L3).
3. **Đối chiếu phiếu:**
   - đủ điều bắt buộc (Q9), không phạm điều cần tránh (Q10);
   - xưng hô nhất quán từ đầu đến cuối (L4).
4. Sau bước này, nếu có sửa chữ nào thì **chạy lại công cụ**.

### Bước 7. Bàn giao trong khung chat
Theo đúng thứ tự sau, không thêm phần khác:

1. **Nhan đề và bài thơ.** Mỗi câu một dòng, các khổ cách nhau một dòng trống. Không chú thích chen vào giữa bài.
2. **Phiếu sáng tác.** Gọn, ghi rõ những mục Claude tự chọn.
3. **Bảng soát luật.** Mỗi câu một dòng, gồm các cột:
   - câu số;
   - số chữ;
   - chuỗi bằng–trắc, lấy từ công cụ;
   - vị trí vần và cặp vần;
   - kết quả: Đạt / Ghi chú [Cần kiểm chứng] / Cố ý phá luật và lý do.
   Cuối bảng ghi một dòng: "Công cụ: Không có lỗi (--the …)" hoặc "Soát tay".
4. **Vì sao viết như vậy.** Tối đa 4 dòng: hình ảnh trung tâm, câu đinh, lý do chọn thể và chọn nhịp.
5. **Gợi ý phổ nhạc.** 5–8 dòng theo `references/goi-y-pho-nhac.md`.
6. **Một câu mời sửa**, ví dụ: "Anh muốn đổi câu nào, hay đổi giọng ở khổ nào?"

**Khi người dùng yêu cầu sửa:**
- Chỉ sửa đúng phần được yêu cầu.
- Chạy lại công cụ và gửi lại bài thơ cùng các dòng của bảng soát luật đã thay đổi.
- Không hỏi lại phỏng vấn.

## Những điều không làm

- Không hỏi quá 10 câu. Không hỏi nhiều câu trong một lượt.
- Không đưa ra nhiều bản để chọn. Mỗi lần chỉ một bản hoàn chỉnh; người dùng muốn hướng khác thì viết lại.
- Không gọi một bài là "đúng luật" khi công cụ còn báo lỗi, hoặc khi chưa soát.
- Không chấm lỗi theo luật [Cần kiểm chứng], ví dụ niêm tứ tuyệt hay luật ngũ ngôn. Những luật đó chỉ ghi chú.
- Không soát luật cho phú, văn tế, câu đối, hịch, cáo (`thi-luat.md` 12.11). Nếu người dùng hỏi tới, nói những điều đã có nguồn và cho biết skill này không soát luật các thể đó.

## Kiểm thử

Chạy `python3 scripts/kiem-thu.py` sau mỗi lần sửa công cụ. Kết quả phải đạt toàn bộ các ca.
