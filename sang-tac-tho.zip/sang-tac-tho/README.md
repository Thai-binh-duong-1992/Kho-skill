# Skill sang-tac-tho – bản 1.0 (04/11/2026)

Sáng tác thơ tiếng Việt đúng thi luật từ một ý tưởng hoặc vài từ. Claude hỏi **từng câu một, tối đa 10 câu**, rồi viết **một bài hoàn chỉnh**. Bài được tự soát luật bằng công cụ và bàn giao ngay trong khung chat, kèm gợi ý phổ nhạc.

## Cấu trúc

| Tệp | Nội dung |
|---|---|
| `SKILL.md` | Quy trình 8 bước (0–7), nguyên tắc nguồn, những điều không làm |
| `references/phong-van.md` | 10 câu hỏi (Q1–Q10) kèm lựa chọn, gợi ý, điều kiện bỏ qua, giá trị mặc định; bảng gợi ý thể thơ; phiếu sáng tác |
| `references/thi-luat.md` | Bản sao nguyên văn `12-thi-luat.md` của skill sang-tac-va-phoi-khi 2.2 (20 thể có nguồn, sơ đồ luật, V1–V16) |
| `references/nghe-viet.md` | Bản sao `13-nghe-viet-loi.md` (9 nguyên tắc, 4 vòng viết lại, L1–L12), kèm ghi chú cách áp sang thơ |
| `references/goi-y-pho-nhac.md` | Năm mục ghi chú phổ nhạc và ghi chú quyền tác giả |
| `scripts/kiem-tra-thi-luat.py`, `scripts/_tieng_viet.py` | Công cụ soát luật (bản 2.2, dùng chung với skill sáng tác nhạc) |
| `scripts/kiem-thu.py` | 15 ca kiểm thử hồi quy |

## Nguyên tắc nguồn

- Chỉ quy tắc đã kiểm chứng mới được chấm là lỗi. Quy tắc [Cần kiểm chứng] chỉ được ghi chú.
- Khi hai quy tắc xung đột, dùng quy tắc đã kiểm chứng.

## Đồng bộ với skill sang-tac-va-phoi-khi

- `thi-luat.md`, `nghe-viet.md` và hai tệp công cụ là bản sao. Khi bên skill sáng tác nhạc cập nhật các tệp này, chép lại sang đây và giữ phần ghi chú đầu tệp.
- Riêng `kiem-tra-thi-luat.py` có một chỗ khác bản gốc: câu lưu ý cuối không nhắc tới `kiem-tra-thanh-nhac.py`.
