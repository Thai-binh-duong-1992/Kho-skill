#!/usr/bin/env python3
"""Thư viện dùng chung cho các script tiếng Việt của skill sang-tac-va-phoi-khi 2.1.

Chỉ dùng thư viện chuẩn Python 3. Không chạy trực tiếp; các script khác import:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from _tieng_viet import phan_tich, NHOM_TEN, ...

Quy tắc áp dụng (references/ngon-ngu/vi.md, references/12-thi-luat.md):
- Nhóm cao độ của thanh theo ĐIỂM KẾT THÚC [BC] (Kirby & Ladd):
    sắc, ngã = 3 (cao) · ngang = 2 (trung) · huyền = 1 (thấp) · hỏi, nặng = 0 (rất thấp)
- Bằng = ngang, huyền; trắc = sắc, hỏi, ngã, nặng (thi luật; KHÔNG dùng để đặt cao độ).
- Vần khép: âm cuối -p, -t, -c, -ch → chỉ mang sắc/nặng → luôn là vần trắc [BC] (Lê Thị Hiền 2024).
- Vần = phần vần (âm đệm + âm chính + âm cuối) + nhóm thanh; âm đệm không tính khi so vần.
"""
import re
import unicodedata

# Dấu thanh dạng tổ hợp (NFD)
DAU_THANH = {"̀": "huyền", "́": "sắc", "̉": "hỏi", "̃": "ngã", "̣": "nặng"}
NHOM_CAO_DO = {"sắc": 3, "ngã": 3, "ngang": 2, "huyền": 1, "hỏi": 0, "nặng": 0}
NHOM_TEN = {3: "cao", 2: "trung", 1: "thấp", 0: "rất thấp"}
BANG = {"ngang", "huyền"}

PHU_AM_DAU = ["ngh", "ng", "nh", "ch", "gh", "gi", "kh", "ph", "th", "tr", "qu",
              "b", "c", "d", "đ", "g", "h", "k", "l", "m", "n", "p", "r", "s", "t", "v", "x"]
AM_CUOI = ["ch", "nh", "ng", "c", "m", "n", "p", "t"]
AM_CUOI_KHEP = {"p", "t", "c", "ch"}
NGUYEN_AM = "aăâeêioôơuưy"

DAU_VIET = re.compile(r"[ăâđêôơưàáảãạằắẳẵặầấẩẫậèéẻẽẹềếểễệìíỉĩịòóỏõọồốổỗộờớởỡợùúủũụừứửữựỳýỷỹỵ]", re.I)
TU = re.compile(r"[^\W\d_]+(?:['’][^\W\d_]+)?", re.U)

# Cặp chữ dễ nghe nhầm đã được ghi nhận (references/ngon-ngu/vi.md, mục lỗi nghe nhầm)
CAP_DE_NHAM_DA_GHI_NHAN = [("lả", "là"), ("đắm", "đắng"), ("say", "cay"), ("trăng", "trâu"),
                            ("suốt", "xuống")]


def tach_thanh(tu):
    """Trả (thanh, phần không dấu thanh) – giữ các dấu mũ, móc, trăng."""
    nfd = unicodedata.normalize("NFD", tu.lower())
    thanh = "ngang"
    for ch, t in DAU_THANH.items():
        if ch in nfd:
            thanh = t
    goc = unicodedata.normalize("NFC", "".join(c for c in nfd if c not in DAU_THANH))
    return thanh, goc


def la_tieng_viet(tu):
    t = tu.lower()
    return bool(DAU_VIET.search(t)) or bool(re.fullmatch(r"[a-zđ]+", t))


def phan_tich(tu):
    """Phân tích một âm tiết: dict(chu, thanh, nhom, bang_trac, dau, van, am_cuoi, khep, van_so_sanh)."""
    thanh, goc = tach_thanh(tu)
    dau, phan_van = "", goc
    for pa in PHU_AM_DAU:
        if goc.startswith(pa) and len(goc) > len(pa):
            dau, phan_van = pa, goc[len(pa):]
            if pa == "gi" and phan_van[0] not in NGUYEN_AM:
                phan_van = "i" + phan_van
            break
    am_cuoi = ""
    for ac in AM_CUOI:
        if phan_van.endswith(ac) and len(phan_van) > len(ac):
            am_cuoi = ac
            break
    # bỏ âm đệm khi so vần: o trước a/ă/e; u trước ê/y/â/ơ (không áp dụng cho "qu" vì đã tách)
    so_sanh = phan_van
    if len(so_sanh) > 1 and ((so_sanh[0] == "o" and so_sanh[1] in "aăe") or
                             (so_sanh[0] == "u" and so_sanh[1] in "êyâơ" and not so_sanh.startswith("uơ"))):
        so_sanh = so_sanh[1:]
    return {
        "chu": tu, "thanh": thanh, "nhom": NHOM_CAO_DO[thanh],
        "bang_trac": "B" if thanh in BANG else "T",
        "dau": dau, "van": phan_van, "am_cuoi": am_cuoi,
        "khep": am_cuoi in AM_CUOI_KHEP, "van_so_sanh": so_sanh,
    }


_NHOM_NGUYEN_AM = [set("aăâ"), set("eê"), set("iy"), set("oôơ"), set("uư")]
_NHOM_AM_CUOI = [{"n", "ng", "nh"}, {"t", "c", "ch"}, {"m"}, {"p"}]


def _nhom(x, nhom_list):
    for i, g in enumerate(nhom_list):
        if x in g:
            return i
    return x


def so_van(a, b):
    """So vần hai âm tiết đã phân tích. Trả 'chinh' | 'thong?' | 'khong', kèm cùng/khác nhóm bằng–trắc.

    'chinh' = phần vần (bỏ âm đệm) trùng hẳn. 'thong?' = gần âm (cùng nhóm âm cuối, nguyên âm gần)
    – định nghĩa vần thông là [QU]/[Cần kiểm chứng], script chỉ gợi ý.
    """
    cung_bt = a["bang_trac"] == b["bang_trac"]
    if a["van_so_sanh"] == b["van_so_sanh"]:
        return "chinh", cung_bt
    va, vb = a["van_so_sanh"], b["van_so_sanh"]
    ca, cb = a["am_cuoi"], b["am_cuoi"]
    na = va[: len(va) - len(ca)] if ca else va
    nb = vb[: len(vb) - len(cb)] if cb else vb
    if na and nb and _nhom(ca, _NHOM_AM_CUOI) == _nhom(cb, _NHOM_AM_CUOI) and \
            _nhom(na[-1], _NHOM_NGUYEN_AM) == _nhom(nb[-1], _NHOM_NGUYEN_AM):
        return "thong?", cung_bt
    return "khong", cung_bt


def tach_tu(dong):
    return TU.findall(dong)


# ---------- Bản 2.1: phương ngữ, kiểm tra âm tiết, viết tắt ----------
PHUONG_NGU = ("bac", "trung", "nam")


def nhom_phuong_ngu(pt, phuong_ngu="bac"):
    """Nhóm cao độ của âm tiết theo phương ngữ (T10).

    bac  : lưới Kirby & Ladd (ngã = 3).
    nam  : hỏi và ngã gộp ở mức thấp (ngã = 0) [QU].
    trung: giữ lưới chuẩn; script so hướng sẽ bỏ qua cặp hỏi–ngã [QU].
    """
    if phuong_ngu == "nam" and pt["thanh"] == "ngã":
        return 0
    return pt["nhom"]


_AM_TIET_VIET = re.compile(
    r"(ngh|ng|nh|ch|gh|gi|kh|ph|th|tr|qu|[bcdđghklmnprstvx])?"
    r"[aăâeêioôơuưy]{1,3}(ch|nh|ng|[cmnpt])?")


def la_am_tiet_viet(tu):
    """True nếu chữ có cấu trúc một âm tiết tiếng Việt hợp lệ (phụ âm đầu + vần).

    Dùng để phát hiện từ mượn (Honda, show…) mà khi hát có thể thành 2 âm tiết trở lên.
    """
    _, goc = tach_thanh(tu)
    return bool(_AM_TIET_VIET.fullmatch(goc))


# Chữ viết tắt hay gặp trong lời gõ nhanh (đồng bộ với dong-goi-ai.py)
VIET_TAT = {"ko", "k", "dc", "đc", "j", "vs", "mik", "mn", "bt", "ntn", "trc", "hk", "hok", "cx", "nma", "ny"}


# ---------- Cao độ nốt nhạc ----------
_TEN_NOT = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}
_SOLFEGE = {"do": "C", "đô": "C", "re": "D", "rê": "D", "mi": "E", "fa": "F", "pha": "F",
            "sol": "G", "son": "G", "la": "A", "si": "B", "ti": "B"}


def not_sang_midi(not_nhac):
    """'C4', 'F#3', 'Bb4', 'Sol4', 'Đô5' → số MIDI (C4 = 60). Trả None nếu không đọc được."""
    s = not_nhac.strip()
    m = re.fullmatch(r"([A-Za-zÀ-ỹđĐ]+?)([#b♯♭]?)(-?\d)", s)
    if not m:
        return None
    ten, dau, quang = m.group(1), m.group(2), int(m.group(3))
    ten_l = ten.lower()
    if ten_l in _SOLFEGE:
        ten = _SOLFEGE[ten_l]
    ten = ten.upper()
    if ten not in _TEN_NOT:
        return None
    so = _TEN_NOT[ten] + {"#": 1, "♯": 1, "b": -1, "♭": -1, "": 0}[dau]
    return 12 * (quang + 1) + so


def dau_hieu(x):
    return (x > 0) - (x < 0)
