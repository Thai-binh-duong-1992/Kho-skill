#!/usr/bin/env python3
"""Bộ kiểm thử hồi quy cho công cụ soát luật của skill sang-tac-tho (bản 1.0).

Chạy: python3 scripts/kiem-thu.py        (in ĐẠT/LỖI từng ca, mã thoát 1 nếu có ca lỗi)
Mỗi ca ghi lại một lỗi đã từng gặp hoặc một hành vi phải giữ. Thêm ca mới khi sửa script.
Chỉ dùng thư viện chuẩn; tạo tệp tạm trong thư mục tạm của hệ thống.
"""
import os, subprocess, sys, tempfile, zipfile

TM = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable
CA = []


def chay(script, *args):
    r = subprocess.run([PY, os.path.join(TM, script), *args], capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


def ca(ten):
    def dk(f):
        CA.append((ten, f)); return f
    return dk


def tep(thu_muc, ten, noi_dung):
    p = os.path.join(thu_muc, ten)
    open(p, "w", encoding="utf-8").write(noi_dung)
    return p


def main():
    loi = 0
    with tempfile.TemporaryDirectory() as d:
        for ten, f in CA:
            try:
                ok, ghi_chu = f(d)
            except Exception as e:  # noqa: BLE001
                ok, ghi_chu = False, f"ngoại lệ: {e}"
            print(f"{'ĐẠT' if ok else 'LỖI'}  {ten}" + ("" if ok else f"  → {ghi_chu}"))
            loi += not ok
    print(f"\nTổng: {len(CA) - loi}/{len(CA)} ca đạt.")
    sys.exit(1 if loi else 0)


# ---------- Các ca ----------
@ca("Mọi script chạy được -h")
def _(d):
    hong = [s for s in sorted(os.listdir(TM)) if s.endswith(".py") and not s.startswith("_")
            and s != "kiem-thu.py" and chay(s, "-h")[0] != 0]
    return not hong, f"lỗi: {hong}"


@ca("Thi luật: lục bát chuẩn không lỗi")
def _(d):
    p = tep(d, "lb.txt", "Trâu ơi ta bảo trâu này\nTrâu ra ngoài ruộng trâu cày với ta\n")
    return "Không có lỗi" in chay("kiem-tra-thi-luat.py", p)[1], "báo lỗi sai"


@ca("Thi luật: bắt lỗi chữ 4 câu bát là bằng")
def _(d):
    p = tep(d, "lb.txt", "Trâu ơi ta bảo trâu này\nTrâu ra ngoài đồng trâu cày với ta\n")
    return "chữ 4 «đồng»" in chay("kiem-tra-thi-luat.py", p)[1], "không bắt lỗi"


@ca("Thi luật: bỏ qua dòng M: và HA: (khi dán lời có ký hiệu nhạc)")
def _(d):
    p = tep(d, "lb.txt", "HA: C | G\nTrâu ơi ta bảo trâu này\nM: C4 C4 C4 C4 C4 C4\nTrâu ra ngoài ruộng trâu cày với ta\n")
    out = chay("kiem-tra-thi-luat.py", p, "--the", "luc-bat")[1]
    return "HA:" not in out and "Không có lỗi" in out, out[-300:]


@ca("Thi luật 2.2: khổ Thơ Mới 7 chữ không bị tự nhận là Đường luật (Đây thôn Vĩ Dạ)")
def _(d):
    p = tep(d, "vi.txt", "Sao anh không về chơi thôn Vĩ\nNhìn nắng hàng cau nắng mới lên\n"
                          "Vườn ai mướt quá xanh như ngọc\nLá trúc che ngang mặt chữ điền\n")
    out = chay("kiem-tra-thi-luat.py", p)[1]
    return "Thể thơ: tu-do" in out and "Không có lỗi" in out and "--the duong-luat" in out, out[:300]


@ca("Thi luật 2.2: lục bát biến thể nhận vần nhà–bà ở chữ 7 câu 9 chữ")
def _(d):
    p = tep(d, "nl.txt", "Ngó lên nuộc lạt mái nhà\nBao nhiêu nuộc lạt nhớ ông bà bấy nhiêu\n")
    out = chay("kiem-tra-thi-luat.py", p)[1]
    return "luc-bat-bt" in out and "chữ 7" in out and "«nhà» – «bà»" in out, out[:300]


@ca("Thi luật 2.2: niêm tứ tuyệt chỉ là ghi chú, không thành lỗi")
def _(d):
    p = tep(d, "tt.txt", "Sao anh không về chơi thôn Vĩ\nNhìn nắng hàng cau nắng mới lên\n"
                          "Vườn ai mướt quá xanh như ngọc\nLá trúc che ngang mặt chữ điền\n")
    out = chay("kiem-tra-thi-luat.py", p, "--the", "duong-luat")[1]
    loi = out.split("## Lỗi thi luật")[1]
    return "Thất niêm" not in loi and "Niêm tứ tuyệt" in out, out[-400:]


@ca("Thi luật 2.2: tiếng đệm trong {…} không được đếm chữ")
def _(d):
    p = tep(d, "dem.txt", "Con cò {ơ} bay lả bay la\nBay qua {tình bằng} cửa phủ bay về Đồng Đăng\n")
    out = chay("kiem-tra-thi-luat.py", p)[1]
    return "Thể thơ: luc-bat" in out and "[6]" in out and "[8]" in out, out[:300]


@ca("Thi luật 2.2: hát nói bắt câu cuối không phải 6 chữ thanh bằng")
def _(d):
    cau = ["Nghĩ đời người như giấc mộng"] * 10 + ["Cuộc vui này còn mãi nữa đây"]
    p = tep(d, "hn.txt", "\n".join(cau) + "\n")
    out = chay("kiem-tra-thi-luat.py", p, "--the", "hat-noi")[1]
    return "Khổ đủ 11 câu" in out and "câu 6 chữ" in out, out[-400:]



QDN = ("Bước tới Đèo Ngang bóng xế tà\nCỏ cây chen đá lá chen hoa\nLom khom dưới núi tiều vài chú\n"
       "Lác đác bên sông chợ mấy nhà\nNhớ nước đau lòng con quốc quốc\nThương nhà mỏi miệng cái gia gia\n"
       "Dừng chân đứng lại trời non nước\nMột mảnh tình riêng ta với ta\n")


@ca("Thơ: Đường luật bát cú chuẩn (Qua Đèo Ngang) không lỗi")
def _(d):
    p = tep(d, "qdn.txt", QDN)
    out = chay("kiem-tra-thi-luat.py", p, "--the", "duong-luat")[1]
    return "Không có lỗi" in out, out[-400:]


@ca("Thơ: Đường luật bắt lỗi khi chữ 2 câu 2 sai luật")
def _(d):
    p = tep(d, "qdn2.txt", QDN.replace("Cỏ cây chen đá", "Cỏ lá chen đá"))
    out = chay("kiem-tra-thi-luat.py", p, "--the", "duong-luat")[1]
    return "Không có lỗi" not in out.split("## Lỗi thi luật")[1], out[-400:]


@ca("Thơ: song thất lục bát chuẩn (Chinh phụ ngâm) không lỗi")
def _(d):
    p = tep(d, "st.txt", "Thuở trời đất nổi cơn gió bụi\nKhách má hồng nhiều nỗi truân chuyên\n"
                          "Xanh kia thăm thẳm tầng trên\nVì ai gây dựng cho nên nỗi này\n")
    out = chay("kiem-tra-thi-luat.py", p, "--the", "song-that")[1]
    return "Không có lỗi" in out, out[-400:]


@ca("Thơ: lục bát bắt lỗi vần khép ở vị trí vần bằng")
def _(d):
    p = tep(d, "vk.txt", "Trâu ơi ta bảo trâu này\nTrâu ra ngoài ruộng trâu cày với tát\n")
    out = chay("kiem-tra-thi-luat.py", p, "--the", "luc-bat")[1]
    return "Không có lỗi" not in out.split("## Lỗi thi luật")[1], out[-400:]


@ca("Thơ: thơ 4 chữ và 5 chữ được tự nhận đúng thể")
def _(d):
    a = chay("kiem-tra-thi-luat.py", tep(d, "a.txt", "Bé ơi bé à\nMẹ đi chợ xa\n"))[1]
    b = chay("kiem-tra-thi-luat.py", tep(d, "b.txt", "Sương chùng chùng nhoà trắng\nNgõ nhỏ ai đi về\n"))[1]
    return "Thể thơ: 4-chu" in a and "Thể thơ: 5-chu" in b, a[:80] + b[:80]


@ca("Thơ: thông điệp cuối không nhắc công cụ của skill khác")
def _(d):
    out = chay("kiem-tra-thi-luat.py", tep(d, "c.txt", "Trâu ơi ta bảo trâu này\nTrâu ra ngoài ruộng trâu cày với ta\n"))[1]
    return "kiem-tra-thanh-nhac" not in out, out[-200:]


if __name__ == "__main__":
    main()
