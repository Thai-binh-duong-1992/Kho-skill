/* VietTTS – đọc tiếng Việt trong Artifact của Claude, miễn phí, không cần tài khoản.
 * Tầng 1: giọng tiếng Việt có sẵn trên máy (speechSynthesis); từ tiếng Anh đọc bằng giọng tiếng Anh của máy.
 * Tầng 2: máy không có giọng Việt -> giọng gắn sẵn Piper vi_VN vais1000 chạy ngay trong trình duyệt;
 *         từ tiếng Anh tách âm theo tiếng Anh Mỹ nhưng cùng một giọng.
 * Cần: ort.min.js (onnxruntime-web 1.18.0) và createPiperPhonemize (phonemize.js) nạp trước tệp này,
 *      cùng các tệp giọng nằm cạnh trang: voice.json, espeak-data.wasm, piper_phonemize.wasm,
 *      ort-wasm-simd.wasm, voice0.wasm … voice4.wasm.
 * Dữ liệu giọng: VAIS-1000 (CC BY 4.0). Mô hình: rhasspy/piper-voices (MIT).
 *
 * API:
 *   VietTTS.speak(text, {onStart, onEnd, onSentence(line), onProgress(pct)})  -> Promise (xong hoặc bị dừng)
 *   VietTTS.stop()
 *   VietTTS.unlock()                 gọi trong một lần chạm/bấm (tự gắn sẵn vào lần chạm đầu)
 *   VietTTS.setMode("auto"|"device"|"builtin")   mặc định "auto" (2 tầng)
 *   VietTTS.preload(onProgress)      tải trước giọng gắn sẵn
 *   VietTTS.voices()                 {vi:[tên], en:[tên], device: tên đang dùng|null}
 *   VietTTS.setDeviceVoice(name)
 *   VietTTS.splitLang(text)          [{lang:"vi"|"en", t}]  (để kiểm tra)
 *   VietTTS.addEnglish(words[]) / addVietnamese(words[])   bổ sung danh sách từ
 *   VietTTS.addSay(regex, viText)    ép cách đọc tiếng Việt cho một cụm (vd P.R.O.M.P.T)
 */
(function(){
  const BASE=new URL("./",location.href).href;
  const FILES={"espeak-data.wasm":964544,"piper_phonemize.wasm":635212,"ort-wasm-simd.wasm":10595041,
    "voice0.wasm":14000000,"voice1.wasm":14000000,"voice2.wasm":14000000,"voice3.wasm":14000000,"voice4.wasm":7149198};
  const TOTAL=Object.values(FILES).reduce((a,b)=>a+b,0);

  /* ---------- nhận diện từ tiếng Anh ---------- */
  const VI_SYL=/^(ngh|ng|nh|ch|gh|gi|kh|ph|qu|th|tr|[bcdghklmnprstvx])?(uye|uya|uyu|uoi|uou|ieu|yeu|oai|oay|uay|oeo|ai|ao|au|ay|eo|eu|ia|ie|iu|oa|oe|oi|oo|ua|ue|ui|uo|uu|uy|ye|[aeiouy])(ch|nh|ng|[cmnpt])?$/;
  const VI_DIA=/[àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđ]/i;
  const EN_FORCE=new Set("chat bot pin pro hot top set tag mac ok okay hi tab mic cut ping test team gem".split(" "));
  const VI_FORCE=new Set("zalo mi a o e i u y".split(" "));
  const EN_ACR=new Set("AI API PDF KPI CSV URL IT HR CEO CFO CTO SOP SBAR PDSA SWOT USB PC IOS HTML CSS JS QR OCR LLM GPT UI UX FAQ PNG JPG MP3 MP4 RAG MCP SQL ERP HIS LIS PACS EMR EHR OKR ROI SMART".split(" "));
  const EN_CAPSWORD=new Set("PROMPT CLAUDE PROJECT PROJECTS ARTIFACT ARTIFACTS SKILL SKILLS MEMORY STYLE CONNECTOR CONNECTORS OPUS SONNET HAIKU".split(" "));
  /* cụm ép đọc tiếng Việt: [regex, cách đọc] */
  const VI_SAY=[[/P\.R\.O\.M\.P\.T/g,"pê, e rờ, o, em mờ, pê, tê"]];

  function wordLang(w){
    if(!w)return null;
    if(VI_DIA.test(w))return "vi";
    if(/^[0-9]+([.,][0-9]+)*$/.test(w))return "vi";
    if(!/^[A-Za-z]+$/.test(w))return null;
    if(w.length===1)return "vi";
    const lw=w.toLowerCase(),up=w.toUpperCase();
    if(EN_ACR.has(up)&&w===up)return "en";
    if(EN_CAPSWORD.has(up))return "en";
    if(w===up)return "vi";                       /* viết tắt tiếng Việt: BV, KHTH, CNTT… */
    if(VI_FORCE.has(lw))return "vi";
    if(EN_FORCE.has(lw))return "en";
    return VI_SYL.test(lw)?"vi":"en";
  }
  function splitLang(text){
    const segs=[];let cur=null;
    const push=(t,lang)=>{if(cur&&(cur.lang===lang||lang===null)){cur.t+=t;return}
      if(!cur&&lang===null){cur={lang:"vi",t};segs.push(cur);return}cur={lang,t};segs.push(cur)};
    text.split(/(\s+)/).forEach(tok=>{
      if(!tok)return;
      if(/^\s+$/.test(tok)){push(tok,null);return}
      if(VI_SAY.some(([re])=>{re.lastIndex=0;return re.test(tok)})){push(tok,"vi");return}
      tok.split(/(?<=\p{Ll})(?=\p{Lu})|(?<=\p{L})(?=\p{N})|(?<=\p{N})(?=\p{L})|([^\p{L}\p{N}]+)/u).filter(Boolean).forEach(pt=>{
        const core=pt.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu,"");push(pt,core?wordLang(core):null)});
    });
    return segs;
  }
  function enSay(t){
    return t.replace(/[A-Za-z]+/g,w=>{const up=w.toUpperCase();if(EN_CAPSWORD.has(up))return w.toLowerCase();
      if(EN_ACR.has(up)&&w===up||(w.length>1&&w.length<=4&&w===up))return w.split("").join(" ");return w})
      .replace(/(?<=[A-Za-z])\.(?=[A-Za-z])/g," ");
  }
  function viSay(t){VI_SAY.forEach(([re,s])=>{t=t.replace(re,s)});return t.replace(/(?<=\p{L})\.(?=[\p{L}\p{N}])/gu," ")}
  const hasWord=s=>/[\p{L}\p{N}]/u.test(s);
  function sentences(t){
    const out=[];(t.replace(/\s+/g," ").trim().match(/.+?(?:[.!?…;:]+(?=\s|$)|$)/g)||[]).forEach(s=>{s=s.trim();if(!s)return;
      while(s.length>220){let k=s.lastIndexOf(",",220);if(k<60)k=s.lastIndexOf(" ",220);if(k<1)k=220;out.push(s.slice(0,k+1).trim());s=s.slice(k+1).trim()}
      if(s)out.push(s)});
    return out;
  }

  /* ---------- tầng 1: giọng của máy ---------- */
  const hasSS="speechSynthesis" in window;
  let viVoice=null,enVoice=null,wantedVi=null,mode="auto";
  const rankVi=v=>{const n=v.name;return /Microsoft.*HoaiMy.*(Natural|Online)/i.test(n)?0:/Microsoft.*NamMinh.*(Natural|Online)/i.test(n)?1:/Microsoft.*(Natural|Online)/i.test(n)?2:/Microsoft/i.test(n)?3:/Google/i.test(n)?4:/Linh/i.test(n)?5:6};
  const rankEn=v=>{const n=v.name;return /Microsoft.*(Aria|Jenny|Ava|Emma).*(Natural|Online)/i.test(n)?0:/Microsoft.*(Natural|Online)/i.test(n)?1:/Google US English/i.test(n)?2:/Samantha|Ava|Allison|Susan|Karen/i.test(n)?3:/en-US/i.test(v.lang)?4:5};
  function pickVoices(){
    if(!hasSS)return;let all=[];try{all=speechSynthesis.getVoices()}catch(e){}
    const vis=all.filter(v=>/^vi/i.test(v.lang)||/vietnam|tiếng việt|hoaimy|namminh|linh\b/i.test(v.name)).sort((a,b)=>rankVi(a)-rankVi(b));
    viVoice=vis.find(v=>v.name===wantedVi)||vis[0]||null;
    enVoice=all.filter(v=>/^en/i.test(v.lang)).sort((a,b)=>rankEn(a)-rankEn(b))[0]||null;
  }
  if(hasSS){pickVoices();speechSynthesis.onvoiceschanged=pickVoices;setTimeout(pickVoices,800);setTimeout(pickVoices,2500)}

  /* ---------- tầng 2: giọng gắn sẵn ---------- */
  let PE=null,PL=null,ctx=null,src=null,gen=0,loaded=0,keep=null;
  function audioCtx(){try{ctx=ctx||new (window.AudioContext||window.webkitAudioContext)();if(ctx.state==="suspended")ctx.resume()}catch(e){ctx=null}return ctx}
  async function getFile(name,onp){
    const r=await fetch(BASE+name);if(!r.ok)throw new Error("thiếu tệp "+name);
    const rd=r.body&&r.body.getReader?r.body.getReader():null;
    if(!rd){const b=await r.arrayBuffer();loaded+=b.byteLength;onp&&onp(Math.round(loaded/TOTAL*100));return b}
    const ch=[];let n=0;for(;;){const {done,value}=await rd.read();if(done)break;ch.push(value);n+=value.length;loaded+=value.length;onp&&onp(Math.min(99,Math.round(loaded/TOTAL*100)))}
    const out=new Uint8Array(n);let o=0;for(const c of ch){out.set(c,o);o+=c.length}return out.buffer;
  }
  function preload(onp){
    if(PL)return PL;
    PL=(async()=>{
      if(typeof ort==="undefined"||typeof createPiperPhonemize==="undefined")throw new Error("thiếu thư viện giọng đọc");
      ort.env.wasm.numThreads=1;ort.env.wasm.proxy=false;ort.env.wasm.wasmPaths=BASE;
      const cfg=await fetch(BASE+"voice.json").then(r=>r.json());
      const [esp,pw,...parts]=await Promise.all(Object.keys(FILES).filter(n=>n!=="ort-wasm-simd.wasm").map(n=>getFile(n,onp)));
      loaded+=FILES["ort-wasm-simd.wasm"];
      const model=new Uint8Array(parts.reduce((a,b)=>a+b.byteLength,0));let o=0;for(const p of parts){model.set(new Uint8Array(p),o);o+=p.byteLength}
      const wasmMod=await WebAssembly.compile(pw);
      const session=await ort.InferenceSession.create(model,{executionProviders:["wasm"],graphOptimizationLevel:"all"});
      onp&&onp(100);PE={cfg,esp,wasmMod,session};return PE;
    })();
    PL.catch(()=>{PL=null;loaded=0});
    return PL;
  }
  function ids(lang,text){
    return new Promise((resolve,reject)=>{let got=false;
      createPiperPhonemize({
        print:d=>{try{const j=JSON.parse(d);got=true;resolve(j.phoneme_ids)}catch(x){}},printErr:()=>{},
        getPreloadedPackage:()=>PE.esp.slice(0),locateFile:u=>BASE+u,
        instantiateWasm:(imports,cb)=>{WebAssembly.instantiate(PE.wasmMod,imports).then(i=>cb(i));return {}}
      }).then(m=>{m.callMain(["-l",lang,"--input",JSON.stringify([{text}]),"--espeak_data","/espeak-ng-data"]);setTimeout(()=>{if(!got)reject(new Error("không tách được âm"))},4000)}).catch(reject);
    });
  }
  async function synth(text){
    const all=[1];
    for(const sg of splitLang(text)){
      const say=(sg.lang==="en"?enSay(sg.t):viSay(sg.t)).trim();if(!hasWord(say))continue;
      const r=await ids(sg.lang==="en"?"en-us":PE.cfg.espeak.voice,say);
      if(all.length>1)all.push(3);all.push(...r.slice(1,-1));
    }
    all.push(2);if(all.length<4)return new Float32Array(0);
    const inf=PE.cfg.inference;
    const out=await PE.session.run({
      input:new ort.Tensor("int64",BigInt64Array.from(all.map(BigInt)),[1,all.length]),
      input_lengths:new ort.Tensor("int64",BigInt64Array.from([BigInt(all.length)]),[1]),
      scales:new ort.Tensor("float32",Float32Array.from([inf.noise_scale,inf.length_scale,inf.noise_w]),[3])});
    return out.output.data;
  }
  function play(pcm){
    return new Promise(res=>{const a=audioCtx();if(!a||!pcm.length){res();return}
      const b=a.createBuffer(1,pcm.length,PE.cfg.audio.sample_rate);b.copyToChannel(pcm,0);
      const s=a.createBufferSource();s.buffer=b;s.connect(a.destination);s.onended=()=>{if(src===s)src=null;res()};src=s;s.start()});
  }

  /* ---------- điều khiển chung ---------- */
  function stop(){gen++;if(src){try{src.stop()}catch(e){}src=null}clearInterval(keep);if(hasSS){try{speechSynthesis.cancel()}catch(e){}}}
  let unlocked=false;
  function unlock(){
    if(unlocked)return;unlocked=true;
    const a=audioCtx();if(a){try{const b=a.createBuffer(1,1,22050),s=a.createBufferSource();s.buffer=b;s.connect(a.destination);s.start()}catch(e){}}
    if(hasSS){try{const u=new SpeechSynthesisUtterance(" ");u.volume=0;u.lang="vi-VN";speechSynthesis.speak(u);speechSynthesis.resume()}catch(e){}pickVoices()}
    setTimeout(()=>{if(useBuiltin())preload().catch(()=>{})},2500);
  }
  ["pointerdown","touchend","keydown"].forEach(ev=>document.addEventListener(ev,unlock,{capture:true,passive:true}));
  function useBuiltin(){if(mode==="builtin")return true;if(!hasSS)return true;if(!viVoice)pickVoices();return mode==="auto"?!viVoice:false}

  function speakDevice(text,o,my){
    return new Promise(resolve=>{
      const items=[];
      sentences(text).forEach(line=>{splitLang(line).forEach((sg,j)=>{const en=sg.lang==="en"&&enVoice;const say=(en?enSay(sg.t):viSay(sg.t)).trim();
        if(hasWord(say))items.push({line,say,en,first:j===0})})});
      if(!items.length||!viVoice){resolve();return}
      speechSynthesis.cancel();
      items.forEach((it,i)=>{
        const u=new SpeechSynthesisUtterance(it.say);
        if(it.en){u.voice=enVoice;u.lang=enVoice.lang||"en-US";u.rate=0.95}else{u.voice=viVoice;u.lang=viVoice.lang||"vi-VN";u.rate=1;u.pitch=1.05}
        u.onstart=()=>{if(my===gen&&it.first)o.onSentence&&o.onSentence(it.line)};
        u.onend=()=>{if(i===items.length-1){clearInterval(keep);resolve()}};
        u.onerror=e=>{if(i===items.length-1||e.error==="interrupted"||e.error==="canceled"){clearInterval(keep);resolve()}};
        speechSynthesis.speak(u);
      });
      try{speechSynthesis.resume()}catch(e){}
      clearInterval(keep);
      if(/Chrome/.test(navigator.userAgent)&&!/Edg\//.test(navigator.userAgent)&&!viVoice.localService)
        keep=setInterval(()=>{if(!speechSynthesis.speaking){clearInterval(keep);return}speechSynthesis.pause();speechSynthesis.resume()},10000);
    });
  }
  async function speakBuiltin(text,o,my){
    const parts=sentences(text);if(!parts.length)return;
    if(!PE){await preload(o.onProgress);if(my!==gen)return}
    let next=synth(parts[0]);
    for(let i=0;i<parts.length;i++){
      const pcm=await next;if(my!==gen)return;
      if(i+1<parts.length)next=synth(parts[i+1]);
      o.onSentence&&o.onSentence(parts[i]);
      await play(pcm);if(my!==gen)return;
    }
  }
  async function speak(text,o={}){
    stop();const my=gen;
    const t=String(text||"").replace(/[*#_`>|]/g,"").replace(/anh\/chị/gi,"anh chị").replace(/\s+/g," ").trim();
    if(!t)return;
    o.onStart&&o.onStart();
    try{ if(useBuiltin())await speakBuiltin(t,o,my); else await speakDevice(t,o,my); }
    finally{ if(my===gen)o.onEnd&&o.onEnd(); }
  }
  window.VietTTS={speak,stop,unlock,preload:p=>preload(p),splitLang,
    setMode:m=>{mode=m},
    voices:()=>{let all=[];try{all=hasSS?speechSynthesis.getVoices():[]}catch(e){}
      return {vi:all.filter(v=>/^vi/i.test(v.lang)).map(v=>v.name),en:all.filter(v=>/^en/i.test(v.lang)).map(v=>v.name),device:viVoice&&viVoice.name}},
    setDeviceVoice:n=>{wantedVi=n;pickVoices()},
    addEnglish:ws=>ws.forEach(w=>{EN_FORCE.add(String(w).toLowerCase());if(String(w)===String(w).toUpperCase())EN_CAPSWORD.add(String(w))}),
    addVietnamese:ws=>ws.forEach(w=>VI_FORCE.add(String(w).toLowerCase())),
    addSay:(re,s)=>VI_SAY.push([re,s])};
})();
