---
name: "doc-tieng-viet-artifact"
description: "Gắn giọng đọc tiếng Việt miễn phí (2 tầng, tự đọc đúng từ tiếng Anh) vào một Artifact/ứng dụng tạo trong Claude. Dùng khi muốn ứng dụng đọc to câu trả lời, câu hỏi, thông báo bằng tiếng Việt."
---

# Giọng đọc tiếng Việt cho Artifact (VietTTS)

Thêm chức năng đọc to tiếng Việt vào một trang Artifact: miễn phí, không cần tài khoản, không tốn credit, người dùng không phải cài gì. Bộ đọc đã chạy thật trong Mi A (lớp Claude.HongHung.K01) trên máy tính và điện thoại.

## Nguyên tắc bắt buộc

1. **Không dùng dịch vụ đọc trên đám mây** (Azure, Google Cloud TTS, TTSForFree, ElevenLabs…). Trang Artifact chặn mọi kết nối và mọi tệp âm thanh từ máy chủ bên ngoài, và khóa API nằm trong trang thì ai cũng lấy được. Nếu người dùng đề nghị, giải thích ngắn rồi dùng skill này.
2. **Hai tầng, tự động:**
   - Tầng 1: máy có giọng tiếng Việt (Linh, Google Tiếng Việt, Microsoft HoaiMy/An…) thì dùng giọng đó; từ tiếng Anh đọc bằng giọng tiếng Anh của máy.
   - Tầng 2: máy không có giọng Việt thì dùng giọng gắn sẵn Piper vi_VN vais1000 (giọng nữ giọng Bắc) chạy ngay trong trình duyệt; từ tiếng Anh tách âm theo tiếng Anh Mỹ nhưng vẫn cùng một giọng. Lần đầu tải khoảng 76 MB, trình duyệt giữ lại cho lần sau.
3. **Nhận diện từ tiếng Anh**: từ có dấu là tiếng Việt; từ không dấu không ghép được vần tiếng Việt (Claude, prompt, artifact, connector, Settings…) là tiếng Anh; viết tắt tiếng Anh (AI, PDF, KPI, SOP, API…) đánh vần kiểu Anh; viết tắt tiếng Việt (CNTT, KHTH, BV…) và chữ cái đơn (đáp án A, B, C, D) đọc tiếng Việt. "P.R.O.M.P.T" đọc tiếng Việt có ngắt nhịp "pê, e rờ, o, em mờ, pê, tê"; "prompt"/"PROMPT" đọc tiếng Anh. Không đổi các quy tắc này nếu người dùng không yêu cầu.
4. **Ghi công giọng gắn sẵn** ở chân trang hoặc phần thông tin: "Dữ liệu giọng: VAIS-1000 (CC BY 4.0). Mô hình: rhasspy/piper-voices (MIT)."
5. Không bắt người dùng cài Microsoft Edge hay giọng đọc; chỉ được gợi ý thêm.

## Nguồn tệp (đã có sẵn trong Mi A của người dùng)

Artifact nguồn: `https://claude.ai/artifact/A1SiMwwTPSN5BNkHyGjZ1n`

| Tệp | Dùng để |
|---|---|
| `tts/viet-tts.js` | Thư viện VietTTS (tách tiếng Anh, 2 tầng, phát âm thanh) – **chèn inline** vào trang |
| `tts/phonemize.js` | Bộ tách âm espeak-ng (đã rút gọn chỉ còn tiếng Việt + tiếng Anh) – **chèn inline** |
| `voice.json`, `espeak-data.wasm`, `piper_phonemize.wasm`, `ort-wasm-simd.wasm`, `voice0.wasm` … `voice4.wasm` | Dữ liệu giọng – **sao chép phía máy chủ**, đặt ở thư mục gốc cạnh trang |

## Các bước gắn vào một Artifact mới

1. Đọc 2 tệp thư viện về máy làm việc: `Artifact` action `read`, `url` = artifact nguồn, `path` = `tts/viet-tts.js`, rồi lần nữa với `tts/phonemize.js`. Kết quả cho biết đường dẫn tệp đã lưu.
2. Trong trang HTML, đặt theo đúng thứ tự (trước script của ứng dụng):
   ```html
   <script src="https://cdn.jsdelivr.net/npm/onnxruntime-web@1.18.0/dist/ort.min.js"></script>
   <script>/* toàn bộ nội dung phonemize.js */</script>
   <script>/* toàn bộ nội dung viet-tts.js */</script>
   ```
   Không nạp hai tệp này bằng `src` tương đối; luôn chèn inline (dùng script Python ghép tệp, không gõ lại nội dung).
3. Gọi trong ứng dụng:
   ```js
   VietTTS.speak(text, {
     onStart: () => {/* hiện trạng thái "Đang đọc…" */},
     onSentence: line => {/* phụ đề câu đang đọc */},
     onProgress: pct => {/* "Đang tải giọng đọc lần đầu… pct%" */},
     onEnd: () => {/* về trạng thái sẵn sàng */}
   });
   VietTTS.stop();                 // nút dừng, hoặc trước khi đọc nội dung khác
   VietTTS.setMode("builtin");     // tùy chọn: mọi máy cùng một giọng gắn sẵn (mặc định "auto" = 2 tầng)
   VietTTS.voices();               // {vi:[…], en:[…], device} để làm ô chọn giọng
   VietTTS.setDeviceVoice(name);
   VietTTS.addEnglish(["Copilot"]); VietTTS.addVietnamese(["Zalo"]); VietTTS.addSay(/HSBA/g, "hồ sơ bệnh án");
   ```
   Thư viện tự mở khóa âm thanh ở lần chạm/bấm đầu tiên (bắt buộc với iPhone, iPad, ứng dụng Claude). Chỉ gọi `speak` sau khi người dùng đã tương tác. Luôn hiện nội dung bằng chữ song song với giọng đọc.
4. Xuất bản trang, rồi sao chép dữ liệu giọng từ artifact nguồn bằng `files` dạng `{"artifact": "https://claude.ai/artifact/A1SiMwwTPSN5BNkHyGjZ1n", "path": "<tên tệp>"}`, **chia 2 lần xuất bản** vì mỗi lần sao chép tối đa 64 MB:
   - Lần 1: `voice.json`, `espeak-data.wasm`, `piper_phonemize.wasm`, `ort-wasm-simd.wasm`, `voice0.wasm`, `voice1.wasm`, `voice2.wasm`
   - Lần 2 (cùng `file_path`/`url`): `voice3.wasm`, `voice4.wasm`
   Tên tệp phải giữ nguyên và nằm ở thư mục gốc (thư viện tìm theo `./`).
5. Kiểm tra trước khi giao:
   - Chạy thử cục bộ bằng Playwright với máy chủ `python3 -m http.server` chạy trong cùng lệnh, thay `ort.min.js` bằng bản npm `onnxruntime-web@1.18.0` nếu không tải được CDN; trang thử phải có `<meta charset="utf-8">` (thiếu là các regex tiếng Việt hỏng).
   - Thử cả 2 tầng: giả lập `speechSynthesis.getVoices()` có giọng `vi-VN` + `en-US` (kiểm tra đoạn nào giọng nào đọc), và không có giọng (kiểm tra có `AudioContext.createBuffer` với độ dài > 0).
   - Không tự nghe được âm thanh: nói rõ với người dùng và nhờ họ nghe thử trên máy tính và điện thoại.

## Bản sao thư viện đi kèm skill

Thư mục `assets/` của skill có sẵn `viet-tts.js` và `phonemize.js` (giống bản trong artifact nguồn). Nếu không đọc được hai tệp này từ artifact nguồn (ví dụ người dùng khác không mở được artifact), chèn inline từ `assets/`. Dữ liệu giọng (khoảng 76 MB) không đi kèm: sao chép từ artifact nguồn nếu mở được, nếu không thì dựng lại theo mục dưới.

## Khi artifact nguồn không còn

Dựng lại bộ tệp:
- `npm pack @mintplex-labs/piper-tts-web@1.0.4 @diffusionstudio/piper-wasm@1.0.0 onnxruntime-web@1.18.0`.
- Bộ tách âm: lấy `dist/piper-o91UDS6e.js` của piper-tts-web, bỏ khối `export { createPiperPhonemize };` cuối tệp; rút gọn `build/piper_phonemize.data` của piper-wasm chỉ giữ các tệp không phải `*_dict` (bỏ cả `mbrola_ph/`) cộng `vi_dict`, `en_dict`, ghi lại offset mới vào khối `loadPackage({"files":[…],"remote_package_size":…})`; lưu dữ liệu thành `espeak-data.wasm`. `piper_phonemize.wasm` lấy nguyên từ piper-wasm.
- Giọng: tải `https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-vi_VN-vais1000-medium.tar.bz2`, lấy `vi_VN-vais1000-medium.onnx` (cắt thành các phần 14 000 000 byte tên `voice0.wasm`…`voice4.wasm`) và `.onnx.json` (đổi tên `voice.json`). Hugging Face thường bị chặn từ máy làm việc; GitHub và npm thì được.
- `ort-wasm-simd.wasm` lấy từ `onnxruntime-web/dist`.
- Tệp hỗ trợ của Artifact phải có đuôi được phục vụ: dữ liệu nhị phân đặt đuôi `.wasm`.
- Kích thước phần trong `viet-tts.js` (hằng `FILES`) phải khớp kích thước tệp thật.