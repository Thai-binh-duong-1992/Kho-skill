﻿# EviCase - cài đặt lối tắt dạng ứng dụng trên Windows 10/11.
# Tạo biểu tượng EviCase trên Desktop và Start Menu, mở trang trong cửa sổ riêng (Edge hoặc Chrome).
# Không cần quyền quản trị: mọi thứ nằm trong hồ sơ người dùng hiện tại.
param([switch]$Uninstall)

$ErrorActionPreference = 'Stop'
$AppName    = 'EviCase'
$Url        = 'https://script.google.com/macros/s/AKfycbwxOQkdeN10YS-n9ffWBXhcFgKcXczEd7vaS5U75CHLYZ_yoWiHA6OmkCo2LqLiNgWF/exec'
$InstallDir = Join-Path $env:LOCALAPPDATA $AppName
$IconPath   = Join-Path $InstallDir 'EviCase.ico'
$Desktop    = [Environment]::GetFolderPath('Desktop')
$StartMenu  = [Environment]::GetFolderPath('Programs')
$Links      = @(
    (Join-Path $Desktop   "$AppName.lnk"),
    (Join-Path $StartMenu "$AppName.lnk"),
    (Join-Path $Desktop   "$AppName.url"),
    (Join-Path $StartMenu "$AppName.url")
)

if ($Uninstall) {
    foreach ($l in $Links) { if (Test-Path $l) { Remove-Item $l -Force } }
    if (Test-Path $InstallDir) { Remove-Item $InstallDir -Recurse -Force }
    Write-Host ''
    Write-Host 'Đã gỡ EviCase khỏi máy này.' -ForegroundColor Green
    exit 0
}

function Find-Browser {
    foreach ($exe in 'msedge.exe', 'chrome.exe') {
        foreach ($root in 'HKCU:', 'HKLM:') {
            $key = "$root\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\$exe"
            $val = (Get-ItemProperty -Path $key -ErrorAction SilentlyContinue).'(default)'
            if ($val) {
                $val = $val.Trim('"')
                if (Test-Path $val) { return $val }
            }
        }
    }
    $fallback = @(
        "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
        "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
        "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
    )
    foreach ($p in $fallback) { if ($p -and (Test-Path $p)) { return $p } }
    return $null
}

try {
    $srcIcon = Join-Path $PSScriptRoot 'EviCase.ico'
    if (-not (Test-Path $srcIcon)) {
        throw 'Không thấy file EviCase.ico cạnh file cài đặt. Hãy GIẢI NÉN toàn bộ file zip ra một thư mục rồi chạy lại.'
    }

    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
    Copy-Item $srcIcon $IconPath -Force

    # Xoá bản cài cũ (nếu có) để không bị trùng biểu tượng.
    foreach ($l in $Links) { if (Test-Path $l) { Remove-Item $l -Force } }

    $browser = Find-Browser
    if ($browser) {
        $shell = New-Object -ComObject WScript.Shell
        foreach ($folder in $Desktop, $StartMenu) {
            $lnk = $shell.CreateShortcut((Join-Path $folder "$AppName.lnk"))
            $lnk.TargetPath       = $browser
            $lnk.Arguments        = "--app=`"$Url`""
            $lnk.WorkingDirectory = Split-Path $browser
            $lnk.IconLocation     = "$IconPath,0"
            $lnk.Description      = 'EviCase - Phân tích ca bệnh'
            $lnk.Save()
        }
        $how = if ($browser -like '*msedge*') { 'Microsoft Edge' } else { 'Google Chrome' }
        Write-Host ''
        Write-Host 'Đã cài EviCase thành công.' -ForegroundColor Green
        Write-Host "- Biểu tượng EviCase đã có trên Desktop và trong Start Menu."
        Write-Host "- EviCase mở trong cửa sổ riêng bằng $how."
    }
    else {
        # Không tìm thấy Edge/Chrome: tạo lối tắt web thường, mở bằng trình duyệt mặc định.
        $content = "[InternetShortcut]`r`nURL=$Url`r`nIconFile=$IconPath`r`nIconIndex=0`r`n"
        foreach ($folder in $Desktop, $StartMenu) {
            [IO.File]::WriteAllText((Join-Path $folder "$AppName.url"), $content, [Text.Encoding]::ASCII)
        }
        Write-Host ''
        Write-Host 'Đã cài EviCase (dạng lối tắt web).' -ForegroundColor Yellow
        Write-Host '- Máy không có Edge hoặc Chrome nên EviCase sẽ mở trong trình duyệt mặc định.'
    }
    Write-Host '- Muốn ghim vào thanh tác vụ: chuột phải biểu tượng EviCase trên Desktop > Hiển thị thêm tùy chọn > Ghim vào thanh tác vụ.'
}
catch {
    Write-Host ''
    Write-Host 'Cài đặt KHÔNG thành công:' -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
