# Thuật ngữ chuẩn đa chuyên ngành & bẫy "bạn giả"

Đọc ở Bước 3 khi tài liệu là y khoa. Thứ tự ưu tiên: glossary dự án người dùng cung cấp → glossary DrKun (skill tra-thuat-ngu-drkun; xem references/glossary-drkun.md) → Bộ Y tế / Dược thư Quốc gia / đồng thuận Hội chuyên ngành → bảng dưới đây.

## HỆ THỐNG THUẬT NGỮ CHUẨN ĐA CHUYÊN NGÀNH & BẪY "BẠN GIẢ" (FALSE FRIENDS)

### II.1. Bảng Thuật ngữ Cốt lõi Đa chuyên khoa (Nội - Ngoại - Sản - Nhi - HSCC - GMHS - Cận lâm sàng)

| Chuyên khoa | Thuật ngữ Tiếng Anh | Thuật ngữ Tiếng Việt chuẩn hóa | Ghi chú áp dụng |
|---|---|---|---|
| **Giải phẫu học** | Anterior / Posterior cruciate ligament (ACL / PCL) | Dây chằng chéo trước / Dây chằng chéo sau | Chuẩn Giải phẫu học GS. Nguyễn Quang Quyền |
| **Giải phẫu học** | Circle of Willis / Subarachnoid space / Meninges | Đa giác Willis / Khoang dưới nhện / Màng não | |
| **Giải phẫu học** | Left anterior descending (LAD) / Circumflex artery (LCx) | Động mạch liên thất trước (LAD) / Động mạch mũ (LCx) | |
| **Giải phẫu học** | Common bile duct / Peritoneum / Pleura / Pericardium | Ống mật chủ / Phúc mạc / Màng phổi / Màng ngoài tim | |
| **Giải phẫu học** | Intervertebral foramen / Transverse & spinous process / Lamina | Lỗ liên đốt sống / Mỏm ngang & mỏm gai / Mảnh sống | |
| **Tim mạch học** | ST-elevation / Non-ST-elevation MI (STEMI / NSTEMI) | Nhồi máu cơ tim có / không có ST chênh lên | Chuẩn Hội Tim mạch học Việt Nam |
| **Tim mạch học** | Heart failure with reduced / preserved EF (HFrEF / HFpEF) | Suy tim phân suất tống máu giảm / bảo tồn | |
| **Tim mạch học** | Atrial fibrillation (AF) / Ventricular tachycardia (VT) / VF | Rung nhĩ / Nhanh thất / Rung thất | |
| **Tim mạch học** | Cardiac tamponade / Aortic dissection / Infective endocarditis | Chèn ép tim cấp / Lóc tách động mạch chủ / Viêm nội tâm mạc nhiễm khuẩn | |
| **Hô hấp học** | Acute respiratory distress syndrome (ARDS) | Hội chứng suy hô hấp cấp tiến triển (ARDS) | |
| **Hô hấp học** | Chronic obstructive pulmonary disease (COPD) | Bệnh phổi tắc nghẽn mạn tính (COPD) | |
| **Hô hấp học** | Pulmonary embolism (PE) / Pneumothorax / Pleural effusion | Thuyên tắc phổi / Tràn khí màng phổi / Tràn dịch màng phổi | |
| **Tiêu hóa - Gan mật** | Gastroesophageal reflux disease (GERD) / Peptic ulcer | Bệnh trào ngược dạ dày - thực quản / Loét dạ dày - tá tràng | |
| **Tiêu hóa - Gan mật** | Inflammatory bowel disease (IBD) / Ulcerative colitis / Crohn's | Bệnh viêm ruột mạn / Viêm loét đại trực tràng chảy máu / Bệnh Crohn | |
| **Tiêu hóa - Gan mật** | Acute pancreatitis / Cirrhosis / Hepatic encephalopathy | Viêm tụy cấp / Xơ gan / Bệnh não gan | |
| **Thận - Tiết niệu** | Acute kidney injury (AKI) / Chronic kidney disease (CKD) | Tổn thương thận cấp (AKI) / Bệnh thận mạn (CKD) | Chuẩn KDIGO |
| **Thận - Tiết niệu** | Nephrotic syndrome / Glomerulonephritis / ESRD | Hội chứng thận hư / Viêm cầu thận / Bệnh thận giai đoạn cuối | |
| **Thận - Tiết niệu** | Hemodialysis / Peritoneal dialysis / CRRT | Thận nhân tạo (lọc máu ngắt quãng) / Lọc màng bụng / Lọc máu liên tục | |
| **Thần kinh học** | Ischemic stroke / Hemorrhagic stroke / TIA | Đột quỵ thiếu máu não cục bộ / Đột quỵ xuất huyết não / Cơn thiếu máu não thoáng qua | |
| **Thần kinh học** | Status epilepticus / Multiple sclerosis / Myasthenia gravis | Trạng thái động kinh / Xơ cứng rải rác / Bệnh nhược cơ | |
| **Nội tiết** | Diabetic ketoacidosis (DKA) / Hyperosmolar state (HHS) | Nhiễm toan ceton do đái tháo đường / Tăng áp lực thẩm thấu máu do tăng đường huyết | |
| **Nội tiết** | Thyroid storm / Myxedema coma / Pheochromocytoma | Cơn bão giáp / Hôn mê phù niêm / U tủy thượng thận | |
| **Hồi sức cấp cứu** | Sepsis / Septic shock / Cardiogenic shock / Anaphylactic shock | Nhiễm khuẩn huyết / Sốc nhiễm khuẩn / Sốc tim / Sốc phản vệ | Chuẩn Sepsis-3 & Thông tư 51/2017/TT-BYT |
| **Hồi sức cấp cứu** | Positive end-expiratory pressure (PEEP) / Tidal volume (Vt) | Áp lực dương cuối thì thở ra (PEEP) / Thể tích khí lưu thông (Vt) | |
| **Gây mê - Giảm đau** | General anesthesia / Regional anesthesia / Neuraxial anesthesia | Gây mê toàn thân / Gây tê vùng / Gây tê trục thần kinh | **Tuyệt đối không** dịch "gây mê vùng" |
| **Gây mê - Giảm đau** | Fascial plane block / Paraspinal block / ESP block / TAP block | Phong bế mặt phẳng cân / Phong bế cạnh cột sống / Phong bế mặt phẳng cơ dựng sống (ESP) / cơ ngang bụng (TAP) | |
| **Gây mê - Giảm đau** | Local anesthetic systemic toxicity (LAST) / Malignant hyperthermia | Ngộ độc toàn thân do thuốc tê (LAST) / Tăng thân nhiệt ác tính | |
| **Gây mê - Giảm đau** | Multimodal analgesia / Opioid-sparing / ERAS | Giảm đau đa mô thức / Giảm sử dụng opioid / Tăng cường hồi phục sau phẫu thuật | |
| **Ngoại - Sản - Ung bướu** | Radical surgery / Debulking surgery / Conservative management | Phẫu thuật triệt căn (tận gốc) ⚠ / Phẫu thuật giảm tổng khối u / Điều trị bảo tồn | |
| **Dược lâm sàng** | Direct oral anticoagulants (DOACs) / LMWH / Narrow therapeutic index | Thuốc chống đông đường uống trực tiếp / Heparin trọng lượng phân tử thấp / Khoảng điều trị hẹp | |

### II.2. Danh mục 30+ Bẫy "Bạn giả" (False Friends) Bắt buộc Kiểm soát trong Sách Y khoa

| Từ gốc Tiếng Anh | Lỗi dịch máy / Sai nghĩa (CẤM DÙNG) | Thuật ngữ Y khoa Tiếng Việt Chuẩn | Chuyên ngành / Ngữ cảnh |
|---|---|---|---|
| `presentation` | bài thuyết trình, sự trình bày | **bệnh cảnh khởi phát / triệu chứng biểu hiện** (hoặc **ngôi thai** trong Sản khoa) | Lâm sàng chung & Sản khoa |
| `tender / tenderness` | dịu dàng, mềm mại | **ấn đau / đau khi sờ nắn** | Khám thực thể |
| `rebound tenderness` | đau nảy lại, dịu dàng nảy bật | **dấu hiệu cảm ứng phúc mạc (dấu Blumberg / ấn đau dội)** | Khám bụng ngoại khoa |
| `guarding` | bảo vệ, canh gác, phòng vệ | **đề kháng thành bụng (co cứng thành bụng)** | Khám bụng ngoại khoa |
| `distention / distended` | căng phồng, giãn rộng | **bụng chướng** (*abdominal distention*) / **tĩnh mạch cổ nổi** (*JVD*) | Khám thực thể |
| `unremarkable` | không đáng chú ý, tầm thường | **không ghi nhận bất thường / trong giới hạn bình thường** | Bệnh án & Cận lâm sàng |
| `compromised` | bị thỏa hiệp, nhượng bộ | **bị đe dọa / suy giảm** (*compromised airway* = đường thở bị đe dọa; *immunocompromised* = suy giảm miễn dịch) | Hồi sức cấp cứu & Miễn dịch |
| `history of present illness (HPI)` | lịch sử của bệnh hiện tại | **bệnh sử** (*past medical history* = **tiền sử**) | Hồ sơ bệnh án |
| `physical examination` | kiểm tra thể chất, khám thể lực | **khám thực thể / thăm khám lâm sàng** | Lâm sàng chung |
| `diagnostic workup` | làm việc lên chẩn đoán, quy trình làm việc | **thăm dò chẩn đoán / bilan chẩn đoán** | Chẩn đoán y khoa |
| `conservatively managed` | quản lý bảo thủ | **điều trị bảo tồn** (nội khoa, theo dõi, chưa can thiệp phẫu thuật) | Điều trị học |
| `cold / hot nodule` | nốt lạnh / nốt nóng | **nhân lạnh / nhân nóng** (trên xạ hình tuyến giáp) | Nội tiết & Y học hạt nhân |
| `murmur` | tiếng thì thầm, tiếng lẩm bẩm | **tiếng thổi** (tiếng thổi tâm thu / tâm trương) | Tim mạch học |
| `thrill` | sự rùng mình, hồi hộp | **rung miu** (dấu hiệu rung sờ thấy trên thành ngực/mạch máu) | Tim mạch học |
| `crackles / rales` | tiếng răng rắc, lách tách | **ran nổ / ran ẩm** (nghe phổi) | Hô hấp học |
| `consolidation` | sự củng cố, hợp nhất | **đông đặc phổi / hội chứng đông đặc** | Hô hấp & Chẩn đoán hình ảnh |
| `cardiac / respiratory arrest` | bắt giữ tim / bắt giữ hô hấp | **ngừng tuần hoàn (ngừng tim) / ngừng thở** | Hồi sức cấp cứu |
| `failure (heart, renal, liver)` | thất bại (thất bại tim, thất bại thận) | **suy (suy tim, suy thận, suy gan)** | Nội khoa & Hồi sức |
| `diagnostic yield` | năng suất / sản lượng chẩn đoán | **hiệu suất chẩn đoán / tỷ lệ phát hiện bệnh** | Y học chứng cứ |
| `insidious onset` | khởi đầu xảo quyệt, gian trá | **khởi phát âm thầm / tiến triển từ từ** | Triệu chứng học |
| `fulminant` | bùng nổ, rực rỡ | **tối cấp** (ví dụ: *fulminant hepatitis* = viêm gan tối cấp) | Truyền nhiễm & Hồi sức |
| `refractory` | bướng bỉnh, ương ngạnh | **kháng trị / trơ với điều trị** (ví dụ: *refractory shock* = sốc kháng trị) | Điều trị học |
| `morbid obesity` | béo phì bệnh hoạn | **béo phì bệnh lý** | Nội tiết & Chu phẫu |
| `benign / malignant` | tử tế, hiền lành / độc ác, hiểm ác | **lành tính / ác tính** | Ung bướu & Giải phẫu bệnh |
| `blood / urine culture` | văn hóa máu / văn hóa nước tiểu | **cấy máu / cấy nước tiểu (nuôi cấy vi sinh)** | Vi sinh lâm sàng |
| `urinary casts` | dàn diễn viên nước tiểu | **trụ niệu** (trụ hồng cầu, trụ bạch cầu, trụ hạt, trụ trong) | Thận học & Xét nghiệm |
| `clearance (creatinine)` | sự dọn dẹp, thông quan | **độ thanh thải (độ thanh thải creatinin)** | Dược động học & Thận học |
| `vital signs` | các dấu hiệu quan trọng | **dấu hiệu sinh tồn (sinh hiệu)** | Thăm khám lâm sàng |
| `silent ischemia` | thiếu máu im lặng | **thiếu máu cơ tim thầm lặng (không triệu chứng)** | Tim mạch học |
| `compliance` | sự bằng lòng, tuân thủ pháp luật | **độ giãn nở (độ đàn hồi phổi/thành ngực)** hoặc **sự tuân thủ điều trị** | Hô hấp & Dược lâm sàng |
| `shunt` | sự chuyển hướng, đường rẽ | **luồng thông (shunt)** | Tim mạch & Hô hấp |
| `dead space` | không gian chết | **khoảng chết** (khoảng chết giải phẫu / sinh lý) | Sinh lý hô hấp |
| `triage` | tam giác | **phân loại cấp cứu (sàng lọc ưu tiên cấp cứu)** | Cấp cứu & Thảm họa |
| `fluid challenge` | thách thức chất lỏng | **nghiệm pháp truyền dịch thử tải** | Hồi sức cấp cứu |
| `treatment-naive` | ngây thơ trong điều trị | **chưa từng điều trị / chưa từng tiếp xúc thuốc trước đây** | Nội khoa & Ung bướu |
| `patency (airway / graft)` | bằng sáng chế | **sự thông thoáng (đường thở) / sự thông thương (lòng mạch, cầu nối)** | Cấp cứu & Ngoại mạch máu |
| `innervate` | chi phối cảm giác (thu hẹp) | **chi phối thần kinh** (trừ khi bản gốc ghi rõ *sensory* hoặc *motor*) | Giải phẫu & Thần kinh |
| `sensible / aggressive / dramatic` | nhạy cảm / hung hăng / kịch tính | **hợp lý / tích cực (điều trị tích cực) / rõ rệt, đáng kể** | Văn phong y học chung |

