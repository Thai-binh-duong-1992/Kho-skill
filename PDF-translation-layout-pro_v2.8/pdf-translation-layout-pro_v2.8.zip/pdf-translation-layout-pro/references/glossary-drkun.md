# Glossary DrKun → skill `tra-thuat-ngu-drkun`

Từ v2.4, Master Glossary DrKun (v3.0, 614 thuật ngữ) chỉ nằm trong skill `tra-thuat-ngu-drkun`, nguồn dùng chung cho mọi skill dịch/hiệu đính. Ở bước 3, nạp skill đó (Skill tool) và dùng scripts trong thư mục của nó:

- Tra lô: `python3 <tra-thuat-ngu-drkun>/scripts/lookup_glossary.py --batch work/terms.txt --out work/terms-found.json`
- Quét bản dịch: `python3 <tra-thuat-ngu-drkun>/scripts/scan_text.py --vi work/tr_p*.json --en work/src_p*.txt --out work/term-scan.json`

Tiện dùng: `scripts/lookup_glossary.py` của skill này chuyển tiếp lệnh sang đó (`lookup_glossary.py scan …` = scan_text). Quy tắc mức LOCKED/PREFERRED/CONTEXT và thuật ngữ mới: xem `references/` của skill glossary.
