# Mẫu brief cho agent song song (tài liệu > 4 trang)

Đặt `<WORK>` = thư mục làm việc tuyệt đối (vd. /home/claude/job/work), `<SKILL>` = thư mục skill. Lưu brief thành file trong `<WORK>` rồi giao mỗi agent: "Đọc và làm đúng theo <WORK>/BRIEF.md. Trang được giao: …". Chia cụm ~4.000–5.000 từ/agent (SSC 2026: 36.000 từ → 9 agent dịch, 6 agent hiệu đính, 2 agent bảng ảnh, 1 agent hình).

Trước khi giao: tạo `<WORK>/src_units.json` = {"trang": [{id, merged, size, fam, bold, nlines, width, en}]} (đã gộp theo merges.json, bỏ keep.json, làm sạch U+00AD/U+200B/\x07). Mảnh vụn nằm giữa câu của khối khác: cho phép agent gộp nghĩa vào khối chính và để mảnh = "" (render bỏ qua khối rỗng, chỉ xóa chữ gốc).

---
## A. Brief dịch (BRIEF.md)
Bạn dịch một phần của "<TÊN TÀI LIỆU>" sang tiếng Việt y khoa chuẩn (người đọc: <ĐỐI TƯỢNG>). Bản dịch đặt đúng vào vị trí chữ gốc trong PDF → **độ dài ≤ ~110% số ký tự gốc**.
- Đầu vào: `<WORK>/RULES.md` (thuật ngữ, mức khuyến cáo KHÓA — sai = lỗi nghiêm trọng); `<WORK>/src_units.json`.
- Đầu ra: mỗi trang được giao → `<WORK>/tr_p<trang>.json` {id: bản dịch}. Khối có `merged` nhiều id: bản dịch ở id đầu, id còn lại = "". Mọi id phải có mặt; kiểm JSON bằng python.
- Quy tắc: giữ `<b>`/`<i>` cân bằng; giữ mọi số, %, khoảng, số trích dẫn (12) [n]; thập phân dấu phẩy, nghìn dấu chấm; min→phút, h→giờ. Khung khuyến cáo đánh số: giữ số đầu; dòng mức khuyến cáo trong ngoặc → `<brn>(khuyến cáo …)`; nhãn New/Revisited/Carryover/Changed → Mới/Xem lại/Kế thừa/Thay đổi. Khối cắt giữa cột/trang: dịch nối liền (đọc khối trước/sau). Đoạn mới rõ ràng trong khối dài: `<br>`; tiêu đề tiểu mục đầu khối: `<b>…</b><brn>`. Không thêm/bớt ý, **không tự viết câu bù chỗ nguồn bị mất chữ** (ghi chú lại), không sửa kiến thức tác giả. Tên thử nghiệm/tổ chức/URL/DOI giữ nguyên; "Table/Figure N" → "Bảng/Hình N".
- Khi xong: in số id mỗi trang và ≤ 10 điểm phân vân.

## B. Brief hiệu đính độc lập (BRIEF_REVIEW.md)
Bạn là người hiệu đính độc lập (chuyên gia <CHUYÊN NGÀNH>), không tham gia dịch. Đọc `<SKILL>/references/review-5-layers.md`, `<WORK>/RULES.md`, file song ngữ được giao (`### id` / EN / VI).
- Trọng tâm lớp 1: số, liều, đơn vị, ngưỡng, CI, phủ định, **mức khuyến cáo**; câu không có trong EN (bịa) hay ý EN bị bỏ → A/B. Liệt kê sẵn các khối nghi vấn mà người dịch tự báo (vd. tự viết câu nối, tự sửa lỗi gốc).
- Lớp 3: thống nhất nhãn và thuật ngữ toàn văn (liệt kê các biến thể đã thấy giữa các agent dịch).
- Lỗi của bản gốc: chỉ ghi trong "reason"; sửa lỗi đánh máy hiển nhiên thì gắn flag.
- Đầu ra: `<WORK>/review_<cụm>.json` = [{id, level A|B|C|D, layer 1–5, before, after, reason, flag?}]; "before" là chuỗi con nguyên văn, duy nhất trong VI của id; kiểm bằng python. Trả lời: số mục A/B/C/D + mọi mục A, B.
- Gộp: nối các review_*.json → review.json → `apply_review.py`.

## C. Brief bảng/khung chữ dạng ảnh (BRIEF_TABLE.md) — sau `raster_labels.py propose-par`
Mỗi nhãn là một đoạn OCR (câu khuyến cáo, Remark, tiêu đề dải màu, nhãn nhỏ). Script tự xuống dòng trong bề rộng khung, không thêm dòng ngoài chiều cao khung → bản dịch ≤ ~105% ký tự.
- Đầu vào: `<WORK>/raster/table_src.json` ({"trang": {"image", "labels":[{idx, box, nlines, en}]}}), RULES.md, **bản dịch thân bài tr_p*.json + src_units.json**: câu trong bảng trùng câu trong thân bài → dùng lại bản dịch (bỏ số thứ tự, bỏ dòng mức khuyến cáo nếu bảng dùng biểu tượng). Sửa lỗi OCR theo thân bài hoặc Read ảnh; không đoán số.
- Đầu ra: `<WORK>/raster/vi_p<trang>.json` {"idx": vi | null (rác/biểu tượng)}.
- Định dạng: `<b>` cho động từ mức khuyến cáo và nhãn in đậm; `<i>` nhãn nghiêng; `\n` ép xuống dòng; tiêu đề dải màu chữ hoa ngắn gọn, thống nhất với tiêu đề chương trong thân bài.
- Gộp vào spec: labels[int(idx)]["vi"] = vi (giải mã &lt; &gt; &amp;); nhãn màu nhấn (vd. "GOOD PRACTICE STATEMENT" màu xanh) bọc `<c>…</c>` để vẽ bằng màu nhấn lấy mẫu từ ảnh.

## D. Brief hình/lưu đồ phức tạp (agent có xem ảnh)
Giao spec nháp (propose-par --simple) + ảnh gốc + ảnh đánh số khung (overlay) + script dựng thử `test_fig.sh <spec>` (copy spec vào thư mục tạm, chạy `raster_labels.py apply src.pdf tmp.pdf tmp/`, xem `tmp/raster/<xref>_cmp.png`). Yêu cầu agent: mỗi nhãn = 1 ô/khung (box = vùng được vẽ, chừa lề viền), `words` = hộp sát từng dòng chữ gốc cần xóa (không bao ✓✗, mũi tên, viền), align center/left, size/h_med/pitch đo từ ảnh, `ink` [255,255,255] cho chữ trắng trên ô đậm; lặp ≤ 4 vòng tới khi không còn chữ Anh, không vết cũ, không đè hình. Báo cáo số nhãn/hình và chỗ chưa hoàn hảo.

## E. Brief rút gọn cho vừa khung (BRIEF_FIT.md) — khi `build_pipeline.sh` thoát 10 (v2.8)
Một số đoạn dịch đúng nhưng dài hơn khung, nên bị co chữ quá giới hạn (thân bài 12,5% · ô bảng 10% · loại khác 15%). Nhiệm vụ: viết lại **cho gọn**, không bỏ ý.
- Đầu vào: `<WORK>/overflow.json` = [{id, page, loai, co_pct, gioi_han_pct, can_rut_gon_pct, so_chu_hien_tai, so_chu_muc_tieu, en, vi}], `<WORK>/RULES.md`.
- Đầu ra: thêm vào `<WORK>/review.json` mỗi id một mục `{id, level: "D", layer: 5, before: <toàn bộ vi hiện tại>, after: <bản gọn>, reason: "vừa khung: rút ~X%"}`; số chữ `after` ≤ `so_chu_muc_tieu`. Rồi `apply_review.py` → `build_pipeline.sh`.
- Thứ tự cách rút gọn: (1) bỏ từ đệm, từ lặp ("hết sức", "một cách", "đã được", "tiến hành", "thực hiện việc"); (2) dùng chữ số thay chữ ("mười hai giờ" → "12 giờ") nếu RULES.md cho phép; (3) chữ viết tắt đã giới thiệu ở trước thì không nhắc lại tiếng Anh đầy đủ; (4) gộp mệnh đề, đổi bị động thành chủ động; (5) dấu chấm phẩy thay liên từ dài.
- **Cấm:** bỏ số, liều, đơn vị, ngưỡng, phủ định, điều kiện, mức khuyến cáo (may/should/must), tên thuốc, trích dẫn (12) [n]; đổi nghĩa để cho ngắn. Không rút được đến mục tiêu mà vẫn giữ đủ ý → giữ bản gọn nhất đạt được và ghi `"flag": "không_đủ_gọn"`.
- Tối đa 2 vòng. Sau vòng 2 còn unit trong overflow.json: báo người dùng từng trang/unit, hai lựa chọn — (a) cho co thêm (ghi id vào `"allow"` của `<WORK>/shrink.json`), (b) chấp nhận lược bớt chi tiết phụ (người dùng chỉ rõ). Không tự chọn.
