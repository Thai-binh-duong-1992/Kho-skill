# Runbook sản xuất PDF dịch giữ bố cục

Dùng runbook này cùng `SKILL.md` khi thực hiện dự án thực tế. Giữ nguyên file nguồn; làm việc trên bản sao và ghi rõ phạm vi trang cần bàn giao.

## A. Khởi tạo và kiểm kê

1. Tải PDF nguồn vào workspace dự án; lưu URL nguồn, tên file, ngày nhận, checksum và bản gốc không chỉnh sửa.
2. Xác nhận **số trang thực tế** và kích thước trang bằng `pdfinfo`; không giả định tài liệu có trang mang số cao nhất được người dùng nhắc đến. Ghi rõ phạm vi bàn giao.
3. Kiểm tra font, encoding, subset, embedding, ảnh, vector và annotation bằng `pdffonts`, `pdfimages -list` và PDF parser.
4. Trích xuất text có cấu trúc theo trang/khối/dòng/span. Lưu bbox, baseline, font, cỡ, màu, weight, style và reading order; ghi riêng hình, bảng, link, footer và page number.
5. Render toàn bộ trang làm montage; render riêng các trang nhiều cột, trang mở chương, bảng/infographic và trang tài nguyên ở độ phân giải đọc được.

## B. Dịch và khóa thuật ngữ

1. Tạo glossary trước khi dịch. Mỗi mục có: thuật ngữ nguồn, bản dịch ưu tiên, khi nào giữ tiếng Anh, ví dụ ngữ cảnh và các biến thể không chấp nhận.
2. Bảo toàn cấu trúc theo page/block; đánh dấu title, section heading, subheading, paragraph, callout, label, caption, CTA, hyperlink và inline emphasis.
3. Chia việc dịch theo trang hoặc nhóm trang có ranh giới rõ; cung cấp cùng glossary và ngữ cảnh liền kề cho mọi đơn vị dịch.
4. Sau khi ghép, rà nhất quán xuyên suốt tài liệu, đặc biệt thuật ngữ xuất hiện lần đầu, viết hoa agent/agents, tên sản phẩm, pháp nhân, số liệu, acronym và thuật ngữ buy-side.
5. Nếu đổi thuật ngữ đã khóa, sửa tất cả các trang liên quan rồi mới dàn lại.

## C. Quyết định font và typography

1. Thử dùng font gốc nếu PDF chứa đầy đủ glyph và license cho phép. Font subset/Type 3 không đồng nghĩa có thể tái sử dụng làm font tiếng Việt đầy đủ.
2. Nếu cần fallback, chọn font Unicode có cảm giác và metrics gần nguồn; dùng đúng family/weight cho heading, body, bold, italic và sans/serif. Nhúng font đầu ra.
3. Lập style map riêng theo vai trò. Đo từng dòng bằng đúng font/size/weight mục tiêu; tính ascent, descent, dấu tiếng Việt, leading và padding.
4. Giữ nhấn mạnh inline ở đúng cụm từ. Không làm mất định dạng khi chuyển block thành text; không giả lập bold/italic nếu có weight thật.
5. Với văn xuôi, justify chỉ các dòng đầy đủ; dòng cuối căn trái. Với tiêu đề, link ngắn, label, caption và CTA, dùng căn trái hoặc căn theo mẫu gốc.
6. Khi dựng text theo từng word-run để điều khiển justify, ghi khoảng trắng thật vào text object hoặc xác nhận text extraction khôi phục khoảng trắng; không chỉ dựa vào khoảng cách thị giác. Thử bằng `pdftotext`/`get_text()` và kiểm tra copy-paste.

## D. Dàn trang và xử lý hình

1. Giữ kích thước trang, nền, illustration, logo, vector, biểu đồ và thứ tự layer gốc khi có thể. Ưu tiên thay đúng vùng text thay vì phủ cả trang.
2. Trích màu từ vector hoặc pixel vùng nền; không đoán màu. Khi che chữ trong badge/capsule, chỉ phủ phần ruột bằng đúng màu nền trang, để lại stroke/viền; tránh hình chữ nhật vượt khỏi outline hoặc tạo mảng trắng.
3. Đo bbox outline gốc và baseline dòng nhãn. Căn nhãn dịch theo tâm capsule bằng advance width của font đích; không giữ nguyên tọa độ trái hoặc baseline cứng nếu độ rộng/font thay đổi. Nếu trang có nền màu, dùng màu đó cho miếng che trong ruột capsule.
4. Xác định safe zone theo nội dung nguồn. Nếu thiếu dữ liệu, dùng tối thiểu 4% kích thước trang ở cả bốn cạnh hoặc lề gốc lớn hơn. Với mọi text frame, đặt inset riêng và bảo đảm glyph nằm trọn trong frame inset.
5. Ngắt dòng theo từ và cụm nghĩa. Đo heading tiếng Việt trong đúng cột; nếu dài, wrap bên trong khung trước khi giảm size. Không để heading lấn sang cột kế, đè hình, link, footer hoặc CTA.
6. Nếu bản dịch dài hơn: nới khung trong giới hạn lưới, tinh chỉnh leading/paragraph gap có kiểm soát, rút gọn câu không mất ý, rồi mới giảm font nhẹ. Ghi lại ngoại lệ trên trang.
7. Với trang mở chương, giữ đúng màu nền, vị trí hình minh họa, nhãn chương, tỷ lệ heading và khoảng trắng. Với infographic, giữ artwork, palette, thứ tự tiến triển và đặt lại nhãn theo hình gốc.

## E. Bảo toàn hyperlink và reading order

1. Trước khi redaction hoặc thay chữ, lưu toàn bộ annotation: URI/action, bbox, page, text anchor gần nhất và reading order.
2. Ghép nhãn dịch với URI theo **cột rồi thứ tự đọc trong cột**; không sắp tất cả link toàn trang chỉ theo tọa độ Y nếu có nhiều cột.
3. Sau khi dàn lại, thêm annotation mới bao quanh chính xác nhãn dịch; nếu link là một phần CTA, chỉ gắn annotation vào cụm liên kết.
4. So sánh từng URI nguồn với URI đầu ra, đếm số link trên mỗi trang và thử mở link. Giữ nguyên link thương hiệu/URL khi được thiết kế chủ ý.
5. Vẽ underline theo độ rộng text thực, không ước lượng; kiểm tra không chạm heading, dòng kề hoặc mép cột.

## F. Kiểm định lặp theo vòng

Chạy các lượt theo thứ tự, sửa lỗi rồi chạy lại các phép kiểm liên quan:

1. **Cơ khí:** page count, page size, output file size, font embedding, text extraction, link count/URI, image/vector presence.
2. **Hình học:** bbox từng span/dòng trong safe zone; kiểm tra tràn ngang/dọc, margin, padding 4 cạnh, khoảng cách tới footer, cột và khung. Riêng badge, so tâm text với tâm outline và baseline nguồn; kiểm tra patch nền khớp màu, outline còn nguyên.
3. **Nội dung:** đối chiếu từng block với bản dịch đã duyệt; phát hiện text thiếu/thừa, English sót ngoài tên riêng/thuật ngữ được giữ, lỗi dấu và từ bị dính/mất khoảng trắng.
4. **Trực quan:** render montage toàn bộ; xem 100% tất cả trang và phóng đại các trang dày, mở chương, bảng/figure, capsule, trang tài nguyên/link và các trang từng báo lỗi. So sánh song song với nguồn; kiểm tra tất cả chapter dividers lẫn badge lặp ở trang nội dung.
5. **Lặp lại:** sau bất kỳ thay đổi font, text, leading, safe zone, overlay hoặc link, render lại trang bị ảnh hưởng và chạy lại text/bbox/link checks.
6. Chặn phát hành nếu còn lỗi tràn, clip, va chạm, viền trắng/màu vá lệch, link sai, dấu lỗi hoặc text extraction mất khoảng trắng.

## G. Bàn giao và hồ sơ

Bàn giao PDF cuối cùng có text layer tìm kiếm được; kèm glossary, source-to-target style map, ghi chú font/fallback, trạng thái hyperlink, checklist QA và danh sách ngoại lệ. Nêu rõ những gì đã giữ nguyên và những khác biệt còn lại; không mô tả là pixel-perfect nếu còn font thay thế hoặc tái dàn. Ghi checksum và lưu file đầu ra theo phiên bản.

## H. Bài học từ dự án thực tế (05/11/2026 — "Build Your Own Skill Library", 10 trang, 811 unit)

1. **Unit phải tách tới ô bảng.** PyMuPDF hay gộp hai ô cùng hàng thành một dòng (span khoảng trắng tổng hợp rộng). `extract_units.py` tách theo khe hở ký tự và span trắng rộng > 3 pt với chữ < 9,5 pt.
2. **Dòng đổi kiểu chữ trọn dòng = ranh giới tiêu đề.** Nhưng một dòng in đậm nằm giữa đoạn văn (vd. câu kết in đậm) cũng bị tách → ghép lại bằng `merges.json`.
3. **Đoạn dàn đều bị tách từng từ** khi khoảng cách từ lớn: phát hiện unit 1 dòng, rộng < 120 pt, cỡ thân bài, không phải tiêu đề → đưa vào `merges.json`.
4. **Đo bằng chính bộ dàn**, không ước lượng: dàn vào trang nháp, đọc lại bbox dòng, kiểm đủ ký tự (insert_htmlbox âm thầm bỏ chữ khi một từ dài hơn khung).
5. **Round-trip tiếng Anh trước:** dàn lại bản Anh; tỉ lệ co nhỏ nhất phải ≥ 0,97. Nếu thấp hơn là lỗi hình học, sửa trước khi dàn bản dịch.
6. **Ô bảng được xuống dòng** vào khoảng trống của hàng (tới hàng kế/đường kẻ), thay vì thu nhỏ chữ.
7. **Ô tiêu đề hẹp** được mượn khoảng trống bên trái trong cùng cột.
8. **Đồng nhất cỡ chữ thân bài theo trang** (co tối đa ~12,5%); ô bảng đồng nhất theo trang (co tối đa 10%).
9. **Chia dịch song song theo cụm trang** cho nhiều agent với chung một `RULES.md` (glossary + quy ước), rồi một agent hiệu đính độc lập không xem quá trình dịch.
10. **Sửa tay sau hiệu đính phải đưa vào `review.json`**, vì `apply_review.py` luôn áp lại từ `draft/` — sửa trực tiếp `tr_p*.json` sẽ mất ở lần chạy sau.

## I. Bài học từ dự án thực tế (05/11/2026 — Wahib et al., BMC Anesthesiology, 7 trang, 205 unit, 4 hình raster)

1. **Đoạn văn bị gộp thành một unit nhiều đoạn** (Springer/InDesign): xác định đầu đoạn qua dòng thụt (x0 > lề cột + 5 pt) hoặc dòng trước kết thúc sớm; trong bản dịch đánh `<br>` (đoạn mới, thụt) và `<brn>` (xuống dòng không thụt cho tiêu đề tiểu mục in đậm nằm cùng unit).
2. **Gạch mềm U+00AD và zero-width space** trong chữ nguồn làm bộ đo đếm thiếu ký tự → NOFIT giả hàng loạt; render_layout/check_numbers đã tự làm sạch.
3. **Cỡ thân bài khác 10,5 pt** (BMC: 9,8 pt; bảng 8,0 pt): render_layout tự dò BODY/CELL; ghi đè trong `columns.json` khi cần.
4. **Giữ nguyên chữ gốc** cho tên tác giả, header tạp chí, tài liệu tham khảo bằng `keep.json` (không redaction, không dàn lại) — tránh mất ngắt dòng giữa các mục TLTK.
5. **Khung có viền (Keywords, Abstract)**: giới hạn phải bên trong viền 3,5 pt; tựa bài nhiều dòng không được nới sang phải (tránh đè biểu tượng Crossmark).
6. **Link nội bộ named-dest (CRn, FigN, TabN)** bị mất khi redaction; chèn lại nguyên tọa độ cũ sẽ lệch chữ và nhân đôi link → dùng `relink.py` (gắn theo chữ đã dịch, số link phải khớp nguồn). URI mã hóa %26 phải giải mã trước khi tìm.
7. **Số thập phân 3 chữ số** (p = 0,606) bị check_numbers báo nhầm là "phẩy nghìn" → chỉ báo khi nguồn không có đúng số đó dạng chấm thập phân. Ô "275 (0,500)" (trung vị; tứ phân vị) phải viết "275 (0, 500)" sau khi đổi dấu thập phân.
8. **Chữ trong ảnh raster** (CONSORT, nhãn trục, chú giải): `raster_labels.py` — mặt nạ chỉ trên nét chữ (loại đường kẻ dài hơn hẳn nét chữ), inpaint TELEA, cỡ chữ khớp bề rộng nét EN gốc và lấy trung vị theo nhóm, vẽ lại cùng màu/góc. Lỗi đã gặp: kernel loại "đường kẻ" quá ngắn xóa luôn nét dọc chữ đậm (chữ cũ còn sót); box cắt mất phần đuôi chữ (g, p) → nới box xuống.
9. **Lưu lại PDF bằng garbage=4 đổi số xref** của ảnh → raster_labels tìm ảnh theo trang + kích thước pixel, không tin xref cũ.
10. **qa_layout** phải đọc cột "emb" của pdffonts (cột "sub = no" không phải lỗi); lề an toàn đặt theo lề header gốc (vd. 30 pt).

## J. Bài học từ dự án lớn (06/11/2026 — SSC 2026, Crit Care Med, 88 trang, 36.000 từ, Bảng 1 dạng ảnh 8 trang)

1. **Chốt phạm vi trước** khi tài liệu > 30 trang hoặc có bảng ảnh dày: hỏi (cốt lõi trước / toàn văn / chỉ bảng). Ghi rõ phần giữ nguyên (TLTK, đơn vị công tác).
2. **Font thương mại**: Akzidenz Grotesk BE, Minion "-Md"/"-It" trước đây bị nhận nhầm serif/thường → extract_units v2.2 nhận đúng; luôn kiểm bảng (size, fam, b) của 10 kiểu phổ biến trước khi dịch.
3. **Khung khuyến cáo** bị tách thành dòng đầu (cạnh nhãn "New") + phần còn lại: tự dò bằng mẫu "^\d+\. " + khối ngay dưới lệch phải 8–30 pt → merges; render tách dòng (SPLIT) cho dòng 2+ dùng hết khung. Vẫn quá chật → rút gọn diễn đạt (vd. "nhiễm khuẩn huyết/sốc nhiễm khuẩn") bằng mục review mức D lớp 5 "vừa khung".
4. **Chia việc**: 9 agent dịch song song theo cụm trang + cùng RULES.md (references/agent-briefs.md A); 6 agent hiệu đính độc lập (B); gộp review_*.json. Các agent hay lệch nhãn ("Xem lại" / "Xem xét lại" / "Rà soát") → liệt kê biến thể cho người hiệu đính thống nhất.
5. **Agent tự viết câu bù chỗ nguồn mất chữ** (đã gặp) → brief cấm rõ; hiệu đính đối chiếu ảnh trang gốc, dùng […] và ghi 10.5.
6. **Bảng khuyến cáo dạng ảnh**: propose-par + agent dịch dùng lại bản dịch thân bài (C) → nhất quán và sửa được lỗi OCR. Chú giải ký hiệu lặp mỗi trang: dựng 1 lần ở trang đầu rồi ánh xạ theo 2 neo ("Strength of Recommendation", "Type of Recommendation") cho từng trang (ảnh mỗi trang có thể co giãn khác ~2%).
7. **Tiêu đề dải màu**: phạm vi xóa lấy theo dải pixel trắng liên tục (dừng ở khoảng trống > 45 px), không theo hộp OCR (hộp OCR có thể ngắn hơn chữ thật → sót chữ).
8. **Lưu đồ/hình nhiều ô**: OCR gộp nhầm cột → giao agent có xem ảnh tự dựng spec (D) với script dựng thử; kết quả tốt sau ~4 vòng.
9. **Dung lượng**: ảnh thay thế PNG làm PDF từ 14 → 36 MB; lưu JPEG q92 → 22 MB.
10. **QA dương tính giả** cần ghi rõ trong báo cáo: header gốc sát mép trên; chữ hoa đầu bài (drop cap) làm hộp dòng cao → "chồng lấn".

## K. Bài học (07/11/2026 — Bo et al., Anesthesiol Perioper Sci 4:55, 13 trang, 255 unit; sửa bản dàn trang "chưa đẹp")

1. **Nhận diện bản không dàn trên nền gốc**: `pdfinfo` Producer = WeasyPrint/Word/Chrome, số trang khác gốc, mất logo/header → đó là bản dựng lại (reflow), không sửa được bằng tinh chỉnh; phải dựng lại trên PDF gốc.
2. **Tái dùng bản dịch đã duyệt**: `pdftotext vi.pdf` → agent căn chỉnh từng unit, dùng nguyên văn, cấm tự viết lại; khung "Khuyến cáo n" tách riêng trong bản cũ được trả về liền trong đoạn như bản gốc. 3 agent cho 13 trang, ~2–3 phút/agent.
3. **Lưới cột**: để lưới mặc định IEEE Letter trên trang A4 Springer làm round-trip tụt 0,887; đo lại `columns.json` [[56,7–293,4],[304,9–541,4]].
4. **Font thay thế có chữ ghép** (ﬀ, f_t) → `insert_htmlbox` vẽ chữ ghép, bộ đếm thiếu ký tự → NOFIT giả hàng loạt và lớp chữ sao chép ra sai ("draj" thay "draft"). Sửa: `prep_font.py` + đo NFKC.
5. **Cả unit bị gắn in đậm** (nhãn "Abbreviations" đậm + chữ viết tắt mảnh): sửa `b: false` trong `units.json`, giữ `<b>` cho nhãn. `<span style>` không đi qua được `<brn>`.
6. **QA dương tính giả**: tựa 24 pt có dấu tiếng Việt → "chồng lấn" giữa các dòng tựa; dòng tác giả có biểu tượng ORCID → "cắt đường kẻ". Xem ảnh xác nhận rồi ghi vào báo cáo.
7. **Khoảng trắng dưới đoạn** khi bản Việt ngắn hơn khung: chấp nhận được (giữ vị trí đoạn như gốc); không kéo giãn cỡ chữ để lấp.

## L. Tự dàn trang khi chữ tiếng Việt dài hơn khung (v2.8, 16/11/2026)
1. **Thứ tự xử lý của render_layout:** dùng khoảng trống dưới khung (≤ 2 pt với thân bài; ô bảng tới hàng/đường kẻ kế, tối đa 2,3 lần chiều cao) → chảy dòng 2+ sang bề ngang khung (khung khuyến cáo) → mượn khoảng trống bên trái (tiêu đề hẹp) → mỗi bước co 1,25% cỡ chữ và khít dòng 0,008 → đồng nhất thân bài theo trang.
2. **Cổng cỡ chữ từng unit** (trước v2.8 chỉ giới hạn khi đồng nhất trang, một đoạn riêng lẻ vẫn co tới 50% mà pipeline báo ĐẠT): thân bài ≤ 12,5%, ô bảng ≤ 10%, loại khác ≤ 15%. Vượt → `overflow.json` + mã thoát 10. PDF vẫn được dựng để xem.
3. **Ước lượng % rút gọn:** thân bài nhiều dòng = 1 − ngân sách cao / chiều cao đo ở cỡ giới hạn; nhãn một dòng = 1 − bề rộng khung / bề rộng chữ đo ở cỡ giới hạn; cộng 3% dự phòng. Ví dụ thử nghiệm: đoạn 86 chữ co 27,5% → cần rút ~41% (86 → 50 chữ); rút xong cỡ chữ về 98,8%.
4. **Sàn khoảng cách dòng 1,18** cho bản Việt (bản Anh giữ 1,10). Đo pixel 600 dpi dòng chữ hạ (gặp, ỵ, ợ) trên dòng chữ hoa dấu chồng (Ẩ Ễ Ỗ Ặ): Liberation Serif 1,10 → chạm (−0,24 pt), 1,14 → +0,24 pt, 1,18 → +0,60 pt; Liberation Sans 1,10 → chạm, 1,18 → +0,84 pt. Bản gốc vốn khít hơn 1,18 thì giữ đúng khoảng cách gốc, không nén thêm.
5. **Ô bảng không tràn qua đầu phải đường kẻ hàng** (trước v2.8 nhãn ô căn trái được kéo tới lề cột, chữ dài thò ra ngoài bảng). Nay giới hạn tới đầu phải đường kẻ ngay trên/dưới − 2 pt; dài hơn thì vào cổng cỡ chữ ô bảng.
6. **Ngoại lệ có duyệt:** người dùng đồng ý cho một unit co thêm → ghi id vào `work/shrink.json` {"allow": [...]}; đổi giới hạn chung: {"body": 0.15} (phải hỏi trước, xem mục Bảo vệ của SKILL.md).
