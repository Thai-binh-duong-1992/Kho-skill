# Hiệu đính 5 lớp & chấm điểm lỗi

Đọc trước Bước 4 của SKILL.md. Với tài liệu không phải y khoa, Lớp 1 đổi thành **an toàn dữ kiện**: số liệu, ngưỡng (≤, ≥, ~, ×), phủ định, tên file/đường dẫn/lệnh/code.

## Hiệu đính Hiệu đính Chuyên môn 5 Lớp (Tích hợp `hieu-dinh-sach-y-khoa` cho mọi chuyên ngành)

Sau khi có bản dịch nháp, **bắt buộc** đóng vai người hiệu đính chuyên môn độc lập để đối chiếu bản dịch với bản gốc tiếng Anh qua 5 lớp theo đúng thứ tự:

1. **Lớp 1 - An toàn lâm sàng (Bắt buộc kiểm 100% từng ký tự):**
   - Liều lượng, nồng độ (`%`, `mg/mL`, `mmol/L`), thể tích (`mL`, `mL/kg`), tốc độ truyền (`mL/giờ`, `mcg/kg/phút`), liều nạp (*loading dose*), liều duy trì (*maintenance dose*), liều tối đa và hiệu chỉnh liều theo mức lọc cầu thận (`eGFR` / `CrCl`).
   - Đơn vị: `mg` khác `mcg` (`µg`) khác `ng`; `mL` khác `L`; `mmol` khác `mEq`; `IU`. **Mọi lỗi nhầm `mg <-> mcg`, sai con số liều lượng hoặc sai dấu thập phân đều xếp Mức A.**
   - Đường dùng (`PO`, `IV`, `IM`, `SC`, `IT`, `epidural`, `inhalation`, `sublingual`, `topical`...), khoảng cách liều (`q6h` = mỗi 6 giờ, `PRN` = khi cần), vị trí giải phẫu (bên phải/trái, tầng đốt sống, vùng cơ thể).
   - Chỉ định, chống chỉ định, cảnh báo hộp đen (*black box warning*), tương tác thuốc và biến chứng.
   - Phủ định không bị đảo nghĩa (*"not recommended"*, *"should not"*, *"avoid"*, *"contraindicated"*, *"unless"*, *"except"*, *"rule out"*).
   - So sánh và ngưỡng cắt chẩn đoán/điều trị không bị đảo chiều (*"more/less than"*, `>= / <=`, *increase/decrease*, `SpO2`, `PaO2/FiO2`, `MAP`, `GCS`, `NYHA`, `Child-Pugh`, `MELD`, `SOFA`, `APACHE II`, `ASA`, `TNM`, `BI-RADS`...).

2. **Lớp 2 - Chính xác nghĩa:**
   - Phát hiện dịch sai nghĩa, dịch sót (bỏ câu, bỏ mệnh đề điều kiện, bỏ từ hạn định như *"usually"*, *"may"*, *"rarely"*, *"can and does"*) và tự ý thêm/thu hẹp ý không có trong bản gốc.
   - Giữ nguyên mức độ chắc chắn và phân cấp khuyến cáo: *may* -> có thể; *should* -> nên (khuyến cáo); *must* -> phải (bắt buộc); *is associated with* -> có liên quan với (**tuyệt đối không** dịch thành *"gây ra"*).
   - Dịch đầy đủ tiêu đề bảng, chú thích bảng (`footnotes`), chú thích hình/sơ đồ và các câu bình luận trong danh mục Tài liệu tham khảo (giữ nguyên tên tác giả/bài báo/tạp chí/DOI quốc tế để tra cứu).

3. **Lớp 3 - Thuật ngữ Đa chuyên ngành & Quy tắc viết tắt:**
   - Kiểm soát chặt toàn bộ **Bẫy "Bạn giả" (False Friends)** trong khám lâm sàng, cận lâm sàng và điều trị (xem Phần II.2: tuyệt đối không dịch máy *tender* = dịu dàng, *guarding* = canh gác, *rebound tenderness* = đau nảy lại, *murmur* = thì thầm, *thrill* = hồi hộp, *consolidation* = củng cố, *cardiac arrest* = bắt giữ tim, *renal failure* = thất bại thận, *urinary casts* = dàn diễn viên nước tiểu, *blood culture* = văn hóa máu, *clearance* = dọn dẹp, *patency* = bằng sáng chế, *treatment-naive* = ngây thơ điều trị, *unremarkable* = không đáng chú ý...).
   - Lần đầu xuất hiện trong bài/chương: ghi thuật ngữ tiếng Việt kèm thuật ngữ gốc tiếng Anh và chữ viết tắt trong ngoặc, ví dụ: *"tổn thương thận cấp (acute kidney injury - AKI)"*, *"nhồi máu cơ tim có ST chênh lên (ST-elevation myocardial infarction - STEMI)"*. Từ lần sau chỉ dùng tiếng Việt hoặc chữ viết tắt quốc tế đã định nghĩa.
   - Tên thuốc/hoạt chất: dùng đúng tên hoạt chất quốc tế (INN) hoặc theo Dược thư Quốc gia Việt Nam. Không tự đổi tên hoạt chất sang biệt dược thương mại.
   - Mỗi khái niệm giải phẫu/bệnh học chỉ dùng **một** cách dịch thống nhất trong toàn bộ cuốn sách/tài liệu.

4. **Lớp 4 - Văn phong tiếng Việt học thuật:**
   - Khử giọng dịch máy: chuyển bị động kiểu Anh (*"bị chống chỉ định"*, *"được thực hiện bởi"*) sang cách diễn đạt tự nhiên (*"có chống chỉ định"*); tránh lặp từ (*"người bệnh người lớn"* -> *"người bệnh trưởng thành"*); thay từ khẩu ngữ bằng thuật ngữ y học chuẩn.
   - Dùng *"người bệnh"* theo chuẩn Bộ Y tế (chỉ dùng *"bệnh nhân"* khi Glossary dự án quy định).
   - Số thập phân trong văn bản tiếng Việt dùng dấu phẩy (`0,5 mg`, `0,9%`, `0,2-0,3 mL/kg`). Không thêm số 0 thừa (`1 mg`, không viết `1,0 mg`). Luôn có số 0 phía trước (`0,5`, không viết `,5`).

5. **Lớp 5 - Hình thức, cấu trúc & trích xuất OCR/PDF:**
   - Đánh số chương, mục, bảng, hình, lưu đồ và tài liệu tham khảo khớp 100% với bản gốc.
   - Bảo toàn đúng ký hiệu y học và toán học: `µ`, `>=`, `<=`, `°C`, `±`, `alpha`, `beta`, chỉ số trên/dưới (`SpO2`, `EtCO2`, `PaCO2`, `HCO3-`, `Na+`, `K+`, `Ca2+`).
   - Sửa triệt để các lỗi do ngắt dòng PDF gốc (như từ tiếng Anh bị dính hoặc thừa khoảng trắng sau dấu gạch nối/dấu hai chấm trong trích dẫn và DOI).

## Chấm điểm & đồng bộ Chấm điểm Hiệu đính, Tạo Bản sạch & Tự động Đồng bộ (Post-Proofreading Sync)

- Phân loại mọi lỗi phát hiện ở bản dịch nháp theo 4 mức:
  - **Mức A (Nghiêm trọng - 10 điểm/lỗi):** Có thể gây hại người bệnh (nhầm `mg <-> mcg`, sai liều/nồng độ/đường dùng/vị trí giải phẫu, đảo chỉ định/chống chỉ định, sai ngưỡng chẩn đoán).
  - **Mức B (Lớn - 5 điểm/lỗi):** Sai hoặc thiếu nghĩa chuyên môn, mắc bẫy "bạn giả" lâm sàng làm sai triệu chứng/chẩn đoán, thêm/bớt ý giải phẫu, làm lệch mức độ khuyến cáo.
  - **Mức C (Trung bình - 2 điểm/lỗi):** Thuật ngữ sai chuẩn hoặc không nhất quán giữa các trang, thiếu định nghĩa từ viết tắt lần đầu.
  - **Mức D (Nhỏ - 1 điểm/lỗi):** Văn phong dịch máy, lặp từ, dấu câu, định dạng khoảng trắng.
- Tính **Điểm lỗi/1.000 từ = `(10*A + 5*B + 2*C + 1*D) / (Số từ / 1.000)`**.
- **Tự động chỉnh sửa theo hiệu đính (Bắt buộc):**
  - Áp dụng **100% các chỉnh sửa Mức A, B, C, D** vào **Bản sạch** (đánh dấu `[đã sửa #n]` trong Báo cáo Hiệu đính để tra cứu, và đưa văn bản sạch không còn thẻ đánh dấu vào bộ dàn trang PDF) để điểm lỗi của bản PDF xuất ra đạt **0,00 lỗi/1.000 từ**.
  - Với các thuật ngữ có nhiều cách gọi theo vùng miền/trường phái (ví dụ: *triệt căn* vs *tận gốc*, *vô căn* vs *nguyên phát*), chọn phương án chuẩn nhất để dàn trang đồng thời gắn cờ `⚠ CẦN CHUYÊN GIA XÁC NHẬN` trong báo cáo. Khi người dùng phản hồi về mục `⚠`, cập nhật lại ngay vào PDF.
  - Không tự ý sửa kiến thức y khoa của tác giả trong thân bài nếu guideline hiện hành đã thay đổi; mọi cập nhật y văn mới phải đặt riêng tại mục **10.5 Ghi chú của người hiệu đính**.


## Bổ sung từ thực tế (05/11/2026)
- **Dấu phân cách hàng nghìn** trong văn bản tiếng Việt là dấu chấm (36.000; 790.000; 1.024). Viết "36,000" sẽ bị đọc thành 36 → xếp **Mức A**. Ngoại lệ: số dạng mã/dữ liệu kỹ thuật giữ như bản gốc (185.7K, phiên bản 2.5).
- Ngoặc kép: văn xuôi và ô bảng dùng “ ”; code, lệnh, JSON giữ ".
- Đổi tháng tiếng Anh sang dạng "tháng 10/2025".
