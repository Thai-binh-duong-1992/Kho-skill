# Mẫu Báo cáo Hiệu đính (10.1 – 10.5)

Xuất dạng .md (đọc tốt trên điện thoại). Kèm phụ lục: bản đồ style/font + kết quả QA từng trang.

## ĐỊNH DẠNG BÁO CÁO HIỆU ĐÍNH ĐI KÈM BẢN DÀN TRANG PDF

Mỗi dự án dịch PDF sách/bài báo y khoa phải xuất kèm Báo cáo Hiệu đính gồm đủ 5 mục sau:

### 10.1 Tóm tắt
```
PHẦN: [Tên sách / chương / bài báo]    CHUYÊN NGÀNH: [Tên chuyên khoa]    SỐ TỪ: [n]
LỖI PHÁT HIỆN Ở BẢN NHÁP: A = _  B = _  C = _  D = _                      ĐIỂM LỖI/1.000 TỪ: _ -> Sau sửa: 0,00
KẾT LUẬN: Đạt chuẩn xuất bản (đã đồng bộ toàn bộ chỉnh sửa vào file PDF)
ĐIỂM CẦN CHUYÊN GIA XÁC NHẬN: [số mục ⚠]
```

### 10.2 Bảng Đối chiếu & Chỉnh sửa (Sắp xếp mức A -> B -> C -> D)
| # | Vị trí | Mức | Bản dịch nháp trước hiệu đính | Bản sửa chính thức (đã đưa vào PDF) | Lý do (Đối chiếu nguyên bản & Chuẩn 5 lớp) |
|---|---|---|---|---|---|

### 10.3 Bản sạch (Đánh dấu `[đã sửa #n]` trên báo cáo, đồng bộ sạch vào PDF)
Toàn văn bản dịch chính thức sau hiệu đính để đọc nhanh trên điện thoại/Canvas và đối chiếu trực tiếp với từng mục trong Bảng lỗi.

### 10.4 Thuật ngữ Mới Phát sinh & Các mục `⚠` Cần Chuyên gia Xác nhận
Liệt kê các thuật ngữ mới phát sinh theo chuyên khoa của tài liệu kèm đề xuất chuẩn hóa và các điểm gắn cờ `⚠`.

### 10.5 Ghi chú của Người Hiệu đính (Cập nhật Y văn & Guideline Lâm sàng)
Nêu rõ các điểm trong sách/bài báo gốc có thể đã thay đổi so với guideline hoặc đồng thuận quốc tế mới nhất (ví dụ: KDIGO, ESC/AHA, GOLD, GINA, Sepsis-3, NCCN, ASRA-ESRA, Bộ Y tế...) mà **tuyệt đối không tự ý sửa vào thân bài của tác giả**.
