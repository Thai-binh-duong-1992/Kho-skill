#!/usr/bin/env python3
"""Chuyển tiếp sang glossary dùng chung (skill tra-thuat-ngu-drkun). Từ v2.4 skill này không còn bản sao glossary.
Dùng như cũ: python3 lookup_glossary.py "regional anesthesia" [--limit 10] | --batch terms.txt [--out f.json]
Quét bản dịch: python3 lookup_glossary.py scan --vi ... --en ... (chuyển sang scan_text.py).
Thoát 3 nếu chưa cài skill tra-thuat-ngu-drkun.
"""
import os
import subprocess
import sys
from pathlib import Path

cands = [Path(os.environ["DRKUN_GLOSSARY"])] if os.environ.get("DRKUN_GLOSSARY") else []
cands.append(Path(__file__).resolve().parents[2] / "tra-thuat-ngu-drkun")
root = next((c for c in cands if (c / "scripts" / "lookup_glossary.py").exists()), None)
if root is None:
    print("THIẾU skill tra-thuat-ngu-drkun (glossary DrKun dùng chung). Tải gói tra-thuat-ngu-drkun lên mục Skills,"
          " hoặc đặt DRKUN_GLOSSARY=<thư mục skill>.", file=sys.stderr)
    sys.exit(3)
args = sys.argv[1:]
tool = "lookup_glossary.py"
if args[:1] == ["scan"]:
    tool, args = "scan_text.py", args[1:]
sys.exit(subprocess.call([sys.executable, str(root / "scripts" / tool)] + args))
