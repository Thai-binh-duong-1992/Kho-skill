#!/usr/bin/env python3
"""Dàn lớp chữ tiếng Việt lên nền vector gốc của PDF (PyMuPDF redaction + insert_htmlbox có đo kiểm).
Dùng: python render_layout.py source.pdf output.pdf --work workdir/ [--mode vi|en] [--title ...] [--author ...]
- workdir/units.json (từ extract_units.py), workdir/tr_p*.json = {unit_id: bản dịch HTML <b>/<i>/<code>/<br>}
- workdir/merges.json (tùy chọn): [["2.42","2.50",...]] gộp các unit bị tách giữa một đoạn.
- --mode en: dàn lại chính bản Anh để kiểm hình học (round-trip) trước khi dàn bản dịch.
Ra report_<mode>.json; thoát mã 4 nếu thiếu bản dịch hoặc unit không vừa khung;
  mã 10 (v2.8) nếu có unit phải co quá giới hạn (thân bài 12,5% · ô bảng 10% · khác 15%) → work/overflow.json.
- work/shrink.json (tùy chọn): đổi giới hạn hoặc "allow" các unit người dùng đã đồng ý co thêm.
"""
import argparse
import pymupdf, json, sys, html, re, statistics, glob, os

ap = argparse.ArgumentParser(); ap.add_argument("src"); ap.add_argument("out"); ap.add_argument("--work", default=".")
ap.add_argument("--mode", default="vi", choices=["vi", "en"]); ap.add_argument("--title", default=""); ap.add_argument("--author", default="")
A = ap.parse_args(); SRC, OUT, MODE, WORK = A.src, A.out, A.mode, A.work
U = json.load(open(os.path.join(WORK, "units.json")))
import re as _re
def _clean(t): return _re.sub(r"\u00ad\s?", "", t).replace("\u200b", "").replace("\x07", "")
for _u in U: _u["en"] = _clean(_u["en"])
TR = {}
if MODE == "vi":
    for f in sorted(glob.glob(os.path.join(WORK, "tr_p*.json"))):
        TR.update(json.load(open(f)))
KP = os.path.join(WORK, "keep.json")
KEEP = set(json.load(open(KP))) if os.path.exists(KP) else set()
MP = os.path.join(WORK, "merges.json")
MERGES = json.load(open(MP)) if os.path.exists(MP) else []
for grp in MERGES:
    us = [u for u in U if u["id"] in grp]
    if not us: continue
    f = us[0]
    f["bb"] = [min(u["bb"][0] for u in us), min(u["bb"][1] for u in us), max(u["bb"][2] for u in us), max(u["bb"][3] for u in us)]
    ls = []
    for u in us:
        for l in u["lines"]:
            if ls and abs(ls[-1][1] - l[1]) < 2:
                ls[-1] = [min(ls[-1][0], l[0]), ls[-1][1], max(ls[-1][2], l[2]), ls[-1][3]]
            else: ls.append(l)
    f["lines"] = ls; f["nlines"] = len(ls); f["align"] = "justify"
    if len(ls) > 1 and ls[0][0] < min(l[0] for l in ls[1:]) - 4:
        f["hang"] = min(l[0] for l in ls[1:]) - ls[0][0]  # thụt treo (số mục khuyến cáo)
    f["en"] = " ".join(u["en"] for u in us)
    if MODE == "vi":
        TR[f["id"]] = " ".join(TR.get(u["id"], "") for u in us).replace("  ", " ").replace("</b> <b>", " ")
    for u in us[1:]: U.remove(u)
from collections import Counter as _C
_bc = _C(); _cc = _C()
for _u in U:
    if _u["nlines"] > 1 and not _u["mono"]: _bc[round(_u["size"], 1)] += _u["nlines"]
    if _u["nlines"] == 1 and _u["size"] < 9.5 and not _u["mono"]: _cc[round(_u["size"], 1)] += 1
BODY = _bc.most_common(1)[0][0] if _bc else 10.5
CELL = _cc.most_common(1)[0][0] if _cc else 8.89
_CF = os.path.join(WORK, "columns.json")
if os.path.exists(_CF):
    _cj = json.load(open(_CF)); BODY = _cj.get("body", BODY); CELL = _cj.get("cell", CELL)
# v2.8 — Sàn khoảng cách dòng: 1,10 làm dấu chồng (Ẩ Ễ Ỗ) chạm chữ hạ dòng trên (đo pixel: serif −0,24 pt; 1,18: +0,60 pt).
# Không nén dưới 1,18 trừ khi bản gốc vốn đã khít hơn (khi đó giữ đúng khoảng cách gốc).
LH_MIN = 1.18 if MODE == "vi" else 1.10
# v2.8 — Cổng cỡ chữ từng unit: thân bài ≤ 12,5%, ô bảng ≤ 10%, loại khác ≤ 15%.
# work/shrink.json (tùy chọn): {"body": 0.125, "cell": 0.10, "other": 0.15, "allow": ["3.12", ...]}  — "allow" = unit người dùng đã đồng ý co thêm.
_SJ = os.path.join(WORK, "shrink.json")
SHRINK = {"body": 0.125, "cell": 0.10, "other": 0.15, "allow": []}
if os.path.exists(_SJ): SHRINK.update(json.load(open(_SJ)))
OVERFLOW = []
def curly(t):
    out=[]; openq=True
    for ch in t:
        if ch=='"':
            out.append('“' if openq else '”'); openq = not openq
        else: out.append(ch)
    return "".join(out)
if MODE == "vi":
    for u in U:
        if not u["mono"] and u["id"] in TR and TR[u["id"]].count('"') % 2 == 0:
            TR[u["id"]] = curly(TR[u["id"]])
# Font: mặc định Liberation; đổi bằng work/fonts.json {"dir": "...", "sans": ["SourceSans3", "Regular","Bold","It","BoldIt"], "serif": [...]}
FONTDIR = "/usr/share/fonts/truetype/liberation"
_FM = {"serif": ["LiberationSerif", "Regular", "Bold", "Italic", "BoldItalic"], "sans": ["LiberationSans", "Regular", "Bold", "Italic", "BoldItalic"], "mono": ["LiberationMono", "Regular", "Bold", "Italic", "BoldItalic"]}
_FJ = os.path.join(WORK, "fonts.json")
if os.path.exists(_FJ):
    _fj = json.load(open(_FJ)); FONTDIR = _fj.get("dir", FONTDIR)
    for _k in ("serif", "sans", "mono"):
        if _k in _fj: _FM[_k] = _fj[_k]
ARCH = pymupdf.Archive(FONTDIR)
FACES = ""
for fam, spec in _FM.items():
    base = spec[0]
    for (w, st), suf in zip((("normal", "normal"), ("bold", "normal"), ("normal", "italic"), ("bold", "italic")), spec[1:]):
        FACES += f"@font-face {{font-family: {fam}; src: url({base}-{suf}.ttf); font-weight: {w}; font-style: {st};}}\n"

# Lưới cột mặc định (IEEE 2 cột, Letter). Chỉnh theo PDF nguồn nếu khác: đo từ units.json (x0/x1 thân bài).
COLS = [(45.0, 296.1), (315.9, 567.0)]
FULL = (45.0, 567.0)
CP = os.path.join(WORK, "columns.json")
if os.path.exists(CP):
    _c = json.load(open(CP)); COLS = [tuple(x) for x in _c["cols"]]; FULL = tuple(_c["full"])

def col_of(bb):
    x0, y0, x1, y1 = bb
    cx = (x0 + x1) / 2
    if len(COLS) < 2: return FULL
    g0, g1 = COLS[0][1], COLS[1][0]; mid = (g0 + g1) / 2
    if (x0 < g0 + 4 and x1 > g1 - 4) or g0 < cx < g1: return FULL
    return COLS[0] if x0 < mid else COLS[1]

def boxes_for(page):
    rs = []
    for d in page.get_drawings():
        r = d["rect"]
        if r.width > 20 and r.height > 8 and r.width * r.height < 612 * 792 / 4:
            rs.append(r)
    return rs

def leading(u):
    ys = [l[1] for l in u["lines"]]
    if len(ys) >= 2:
        ds = [b - a for a, b in zip(ys, ys[1:]) if b - a > 0]
        if ds: return statistics.median(ds) / u["size"]
    return 1.22

def to_html(u, text):
    if u["mono"]:
        lines = text.split("\n")
        out = []
        for ln in lines:
            ln2 = ln if "&" in ln or "<" in ln else html.escape(ln, quote=False)
            ln2 = ln2.replace("  ", "&nbsp; ").replace("&nbsp;  ", "&nbsp;&nbsp; ")
            if ln2.startswith(" "): ln2 = "&nbsp;" + ln2[1:]
            out.append(ln2)
        return "<br>".join(out)
    return text.replace("<brn>", "</div><div class='n'>").replace("<br>", "</div><div class='p'>")

def css_for(u, fs, lh, align, indent):
    w = "bold" if u["b"] else "normal"; st = "italic" if u["i"] else "normal"
    return FACES + f"""
* {{margin:0; padding:0;}}
div {{font-family:{u['fam']}; font-size:{fs:.2f}pt; line-height:{lh:.3f}; color:{u['color']};
 font-weight:{w}; font-style:{st}; text-align:{align}; text-indent:{indent - u.get('hang', 0):.1f}pt; padding-left:{u.get('hang', 0):.1f}pt;}}
code {{font-family:mono; font-size:{fs*0.92:.2f}pt;}}
b {{font-weight:bold;}} i {{font-style:italic;}}
div.p {{text-indent:{fs*0.82:.2f}pt;}} div.n {{text-indent:0;}}
"""

def unit_rect(u, page_units, boxes):
    x0, y0, x1, y1 = u["bb"]
    c0, c1 = col_of(u["bb"])
    single = u["nlines"] == 1
    # containing box
    box = None
    for r in boxes:
        if r.x0 - 0.5 <= x0 and r.x1 + 0.5 >= x1 and r.y0 - 0.5 <= y0 and r.y1 + 0.5 >= y1:
            if box is None or r.width * r.height < box.width * box.height: box = r
    center = u.get("_center", False)
    if box is not None and (box.width < 200 or u["mono"]):
        lim0, lim1 = box.x0 + 2.5, box.x1 - 2.5
        if u["mono"]:
            return pymupdf.Rect(x0, y0 - 1, lim1, box.y1 - 1.5), "left", box
        cx = (x0 + x1) / 2
        if abs(cx - (box.x0 + box.x1) / 2) < 4: center = True
    else:
        lim0, lim1 = c0, c1
        # right neighbour
        for v in page_units:
            if v is u: continue
            vx0, vy0, vx1, vy1 = v["bb"]
            if vy1 > y0 + 1 and vy0 < y1 - 1 and vx0 >= x1 - 1:
                lim1 = min(lim1, vx0 - 2.5)
            if vy1 > y0 + 1 and vy0 < y1 - 1 and vx1 <= x0 + 1:
                lim0 = max(lim0, vx1 + 2.5)
    if box is not None: lim1 = min(lim1, box.x1 - 3.5)
    if abs(u["size"] - BODY) < 0.35 and u["nlines"] > 1: u["align"] = "justify"
    if u["align"] == "justify":
        return pymupdf.Rect(x0, y0, x1 + 0.3, y1), "justify", box
    if center or u["align"] == "center":
        cx = (x0 + x1) / 2
        half = min(cx - lim0, lim1 - cx)
        half = max(half, (x1 - x0) / 2 + 2)
        return pymupdf.Rect(cx - half, y0, cx + half, y1), "center", box
    # left aligned: allow extension to the right limit
    if u["nlines"] > 1 and u["size"] > 15: return pymupdf.Rect(x0, y0, x1 + 1.5, y1), "left", box
    return pymupdf.Rect(x0, y0, max(x1 + 1.5, lim1), y1), "left", box

SCR = pymupdf.open(); SCP = SCR.new_page(width=612, height=2000)
def measure(x0, x1, htm, css):
    global SCR, SCP
    SCP.clean_contents()
    SCR.delete_page(0); SCP = SCR.new_page(width=612, height=2000)
    SCP.insert_htmlbox(pymupdf.Rect(x0, 100, x1, 1900), htm, css=css, archive=ARCH, scale_low=1)
    ls = [l["bbox"] for b in SCP.get_text("dict")["blocks"] if b["type"] == 0 for l in b["lines"]]
    if not ls: return 0, 9999, 0, x1
    import unicodedata as _ud
    nch = len("".join(_ud.normalize("NFKC", SCP.get_text("text")).split()))  # NFKC: tách chữ ghép ﬀ/ﬁ của font thay thế
    exp = len("".join(html.unescape(re.sub(r"<[^>]+>", "", htm.replace("&nbsp;", " "))).split()))
    if nch < exp: return 0, 9999, 0, x1
    t0 = min(l[1] for l in ls); tb = max(l[3] for l in ls)
    ys = sorted(set(round(l[1]) for l in ls))
    return t0 - 100, tb - t0, len(ys), max(l[2] for l in ls)

def detect_center(u):
    if u["nlines"] != 1 or u["mono"]: return False
    x0, _, x1, _ = u["bb"]
    c0, c1 = col_of(u["bb"])
    return abs((x0 + x1) / 2 - (c0 + c1) / 2) < 3 and x0 - c0 > 8

src = pymupdf.open(SRC)
# remember links
links = {i: [l for l in pg.get_links()] for i, pg in enumerate(src)}
report = []
for pno, page in enumerate(src):
    pu_all = [u for u in U if u["page"] == pno + 1]
    pu = [u for u in pu_all if u["id"] not in KEEP]
    boxes = boxes_for(page)
    hlines = []
    for d in page.get_drawings():
        for it in d["items"]:
            if it[0] == "l" and abs(it[1].y - it[2].y) < 0.5:
                hlines.append(pymupdf.Rect(min(it[1].x, it[2].x), it[1].y, max(it[1].x, it[2].x), it[1].y))
            if it[0] == "re" and it[1].height < 1.5 and it[1].width > 30:
                hlines.append(it[1])
    for u in pu:
        for l in u["lines"]:
            page.add_redact_annot(pymupdf.Rect(l).irect if False else pymupdf.Rect(l[0] - 0.3, l[1] + 0.5, l[2] + 0.3, l[3] - 0.5))
    page.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_NONE, graphics=pymupdf.PDF_REDACT_LINE_ART_NONE,
                          text=pymupdf.PDF_REDACT_TEXT_REMOVE)
    plan = []
    for u in pu:
        u["_center"] = detect_center(u)
        text = TR.get(u["id"], u["en"]) if MODE == "vi" else u["en"]
        if MODE == "vi" and u["id"] not in TR and u["id"] not in KEEP: report.append(("MISSING", u["id"]))
        if MODE == "vi" and not re.sub(r"<[^>]+>", "", text).strip():
            continue  # mảnh đã gộp nghĩa vào khối khác: chỉ xóa chữ gốc, không vẽ
        rect, align, box = unit_rect(u, pu_all, boxes)
        # v2.8 — ô bảng căn trái không được tràn qua đầu phải của đường kẻ hàng ngay dưới/trên (trước đây tràn tới lề cột)
        if not u["mono"] and u["size"] < 9.5 and u["nlines"] == 1 and align == "left":
            _x0, _y0, _x1, _y1 = u["bb"]
            for hl in hlines:
                if hl.x0 <= _x0 + 1 and hl.x1 >= _x1 - 1 and (0 <= hl.y0 - _y1 < 8 or 0 <= _y0 - hl.y0 < 8):
                    rect = pymupdf.Rect(rect.x0, rect.y0, min(rect.x1, hl.x1 - 2), rect.y1)
        lh = leading(u)
        indent = u["indent"] if (u["nlines"] > 1 and u["indent"] > 5) else 0
        htm = "<div>" + to_html(u, text) + "</div>"
        # vertical budget: down to next obstacle below (other unit overlapping horizontally)
        top = u["bb"][1]; bot = u["bb"][3]
        lim = 792
        for v in pu_all:
            if v is u: continue
            vx0, vy0, vx1, vy1 = v["bb"]
            if vy0 >= bot - 0.5 and min(vx1, rect.x1) - max(vx0, rect.x0) > 1:
                lim = min(lim, vy0)
        if box is not None:
            lim = min(lim, box.y1 - 1.2)
        for hl in hlines:
            if hl.y0 >= bot - 0.3 and hl.x0 < rect.x1 and hl.x1 > rect.x0:
                lim = min(lim, hl.y0)
        if u["size"] < 9.5 and not u["mono"] and lim < 792 and u["fam"] != "sans" or (u["fam"]=="sans" and u["size"]<8 and u["b"] and lim < 792 and u["bb"][3]-u["bb"][1] < 10 and any(h.y0>=u["bb"][3]-0.3 and h.y0-u["bb"][3]<8 for h in hlines)):
            # table cell: may grow down to the next row / rule
            budget_cell = max(0, lim - 1.5 - top)
        else:
            budget_cell = None
        slack = 1.0 if u["mono"] else min(2.0, max(0.0, lim - bot - 1.0))
        budget = (bot - top) + slack
        if budget_cell is not None: budget = max(budget, min(budget_cell, (bot - top) * 2.3))
        fs0 = u["size"]
        if u["mono"]:
            mx = max(len(html.unescape(ln)) for ln in text.split("\n"))
            fs0 = min(fs0, max(u["size"] * 0.85, (rect.width - 4) / (0.6002 * max(mx, 1))))
        X2 = None
        if u.get("hang") and box is not None and box.x1 - 4 > rect.x1 + 10 and "<br" not in text:
            X2 = box.x1 - 4   # dòng 2+ của khung khuyến cáo được dùng hết bề ngang khung (dòng 1 nhường chỗ nhãn "Mới")
        plan.append(dict(u=u, htm=htm, rect=rect, lh=lh, fs0=fs0, align=align, indent=indent, top=top, budget=budget, raw=text, X2=X2))
    def trial(P, k):
        u = P["u"]; sc = 1 - 0.0125 * k
        lhx = max(min(P["lh"], LH_MIN), P["lh"] - 0.008 * k) if u["nlines"] > 1 else P["lh"]
        fs = P["fs0"] * sc
        css = css_for(u, fs, lhx, P["align"], P["indent"] * sc).replace("line-height:%.3f;" % lhx, "line-height:%.2fpt;" % (lhx * fs))
        off, h, n, xr = measure(P["rect"].x0, P["rect"].x1, P["htm"], css)
        return off, h, n, css
    def _bal(t): return all(t.count(f"<{g}>") == t.count(f"</{g}>") for g in ("b", "i", "code"))
    def trial_split(P, k):
        u = P["u"]; sc = 1 - 0.0125 * k
        lhx = max(min(P["lh"], LH_MIN), P["lh"] - 0.008 * k); fs = P["fs0"] * sc
        u1 = dict(u, hang=0); u2 = dict(u, hang=u["hang"] * sc)
        css1 = css_for(u1, fs, lhx, "left", 0).replace("line-height:%.3f;" % lhx, "line-height:%.2fpt;" % (lhx * fs))
        css2 = css_for(u2, fs, lhx, "justify", u["hang"] * sc).replace("line-height:%.3f;" % lhx, "line-height:%.2fpt;" % (lhx * fs))
        words = P["raw"].split(" "); best = 0; off1 = 0
        lo, hi = 1, len(words)
        while lo <= hi:
            mid = (lo + hi) // 2; part = " ".join(words[:mid])
            o, h1, n1, _ = measure(P["rect"].x0, P["rect"].x1, "<div>" + part + "</div>", css1)
            if n1 == 1 and h1 < 9000: best = mid; off1 = o; lo = mid + 1
            else: hi = mid - 1
        while best > 0 and not _bal(" ".join(words[:best])): best -= 1
        if best == 0 or best >= len(words): return None
        first = "<div>" + " ".join(words[:best]) + "</div>"; rest = "<div>" + " ".join(words[best:]) + "</div>"
        o2, h2, n2, _ = measure(P["rect"].x0, P["X2"], rest, css2)
        if h2 >= 9000: return None
        return off1, lhx * fs + h2, first, rest, css1, css2, lhx * fs
    for P in plan:
        if P.get("X2"):
            for k in range(0, 24):
                r = trial_split(P, k)
                if r and r[1] <= P["budget"] + 0.05: P["split"] = (k, r); break
    for P in plan:
        k = 0
        while True:
            off, h, n, css = trial(P, k)
            if h <= P["budget"] + 0.05 or k >= 40: break
            k += 1
        if k > 3 and P["u"]["nlines"] == 1 and not P["u"]["mono"] and P["u"]["b"] and P["u"]["size"] < 8 and P["align"] in ("left", "center"):
            # try borrowing free space on the left (narrow header/number columns)
            x0 = P["u"]["bb"][0]; y0, y1 = P["u"]["bb"][1], P["u"]["bb"][3]
            left = max(x0 - 12, col_of(P["u"]["bb"])[0] + 1)
            for v in pu:
                if v is P["u"]: continue
                if v["bb"][3] > y0 + 1 and v["bb"][1] < y1 - 1 and v["bb"][2] <= x0 + 1:
                    left = max(left, v["bb"][2] + 3)
            if left < x0 - 2:
                old = P["rect"]; P["rect"] = pymupdf.Rect(left, old.y0, old.x1, old.y1)
                k2 = 0
                while k2 < k:
                    off, h, n, css = trial(P, k2)
                    if h <= P["budget"] + 0.05: break
                    k2 += 1
                k = k2
        if k >= 40: report.append(("NOFIT", P["u"]["id"]))
        P["k"] = k; report.append(("RAW", P["u"]["id"], k))
    # harmonise body paragraphs on the page
    # cỡ thân bài = cỡ phổ biến nhất (theo số dòng) của các unit nhiều dòng trên toàn tài liệu
    body = [P for P in plan if not P["u"]["mono"] and abs(P["u"]["size"] - BODY) < 0.2 and P["u"]["nlines"] > 1]
    if body:
        kb = min(max(P["k"] for P in body), 10)
        for P in body: P["k"] = max(P["k"], kb)
    cells = [P for P in plan if not P["u"]["mono"] and abs(P["u"]["size"] - CELL) < 0.1 and P["u"]["nlines"] == 1 and P["budget"] > (P["u"]["bb"][3] - P["u"]["bb"][1]) + 2.5]
    if cells:
        kb = min(max(P["k"] for P in cells), 8)
        for P in cells: P["k"] = max(P["k"], kb)
    for P in plan:
        if P.get("split") and P["split"][0] <= P["k"]:
            k2, (off, h, first, rest, css1, css2, lpt) = P["split"]
            y0 = P["top"] - off
            page.insert_htmlbox(pymupdf.Rect(P["rect"].x0, y0, P["rect"].x1, y0 + lpt + 12), first, css=css1, archive=ARCH, scale_low=1)
            page.insert_htmlbox(pymupdf.Rect(P["rect"].x0, y0 + lpt, P["X2"], y0 + h + 20), rest, css=css2, archive=ARCH, scale_low=1)
            report.append(("U", P["u"]["id"], round(1 - 0.0125 * k2, 3), round(h - P["budget"], 2))); report.append(("SPLIT", P["u"]["id"], k2))
            continue
        off, h, n, css = trial(P, P["k"])
        y0 = P["top"] - off
        page.insert_htmlbox(pymupdf.Rect(P["rect"].x0, y0, P["rect"].x1, y0 + h + off + 20), P["htm"], css=css, archive=ARCH, scale_low=1)
        report.append(("U", P["u"]["id"], round(1 - 0.0125 * P["k"], 3), round(h - P["budget"], 2)))
    # v2.8 — cổng cỡ chữ từng unit + ước lượng % cần rút gọn
    if MODE == "vi":
        for P in plan:
            u = P["u"]
            if u["id"] in SHRINK["allow"] or u["mono"]: continue
            kk = P["split"][0] if (P.get("split") and P["split"][0] <= P["k"]) else P["k"]
            co = 0.0125 * kk
            if abs(u["size"] - BODY) < 0.35 and u["nlines"] > 1: loai = "body"
            elif abs(u["size"] - CELL) < 0.1 and u["nlines"] == 1: loai = "cell"
            else: loai = "other"
            lim_k = int(round(SHRINK[loai] / 0.0125))
            if kk <= lim_k: continue
            # đo ở cỡ chữ giới hạn: còn dài hơn khung bao nhiêu
            off, h, n, css = trial(P, lim_k)
            if u["nlines"] > 1 or n > 1 and P["budget"] > 1.6 * u["size"]:
                can = 1 - P["budget"] / h if h < 9000 else 0.5
            else:
                o, hw, nw, xr = measure(P["rect"].x0, P["rect"].x0 + 1500, P["htm"], css)
                can = 1 - P["rect"].width / max(1.0, xr - P["rect"].x0)
            can = min(0.6, max(0.03, can + 0.03))  # +3% dự phòng
            txt = re.sub(r"<[^>]+>", "", P["raw"])
            OVERFLOW.append(dict(id=u["id"], page=pno + 1, loai=loai, co_pct=round(co * 100, 1),
                                 gioi_han_pct=round(SHRINK[loai] * 100, 1), can_rut_gon_pct=round(can * 100),
                                 so_chu_hien_tai=len(txt.split()), so_chu_muc_tieu=max(1, int(len(txt.split()) * (1 - can))),
                                 en=u["en"], vi=P["raw"]))
    # restore links if lost
    have = page.get_links()
    if len(have) < len(links[pno]):
        for l in links[pno]:
            if l.get("kind") not in (pymupdf.LINK_URI, pymupdf.LINK_GOTO): continue
            l2 = {k: v for k, v in l.items() if k in ("kind", "from", "uri", "page", "to")}
            page.insert_link(l2)
md = dict(src.metadata or {})
if A.title: md["title"] = A.title
if A.author: md["author"] = A.author
src.set_metadata({k: v for k, v in md.items() if k in ("title", "author", "subject", "keywords", "creator", "producer")})
src.subset_fonts()
src.save(OUT, garbage=4, deflate=True)
json.dump(report, open(os.path.join(WORK, f"report_{MODE}.json"), "w"))
from collections import Counter
print(Counter(r[0] for r in report))
raw = sorted([r for r in report if r[0] == "RAW" and r[2] > 2], key=lambda r: -r[2]); print("raw k>2:", raw[:25])
sc = [r[2] for r in report if r[0] == "U"]
print("min scale", min(sc), "units<0.9:", sum(1 for s in sc if s < 0.9))
bad = [r for r in report if r[0] in ("MISSING", "NOFIT")]
if MODE == "vi":
    json.dump(OVERFLOW, open(os.path.join(WORK, "overflow.json"), "w"), ensure_ascii=False, indent=1)
    print(f"cổng cỡ chữ: {len(OVERFLOW)} unit co quá giới hạn" + (" → xem overflow.json" if OVERFLOW else ""))
    for o in OVERFLOW[:15]: print(f"  CO-QUÁ trang {o['page']} unit {o['id']} ({o['loai']}): co {o['co_pct']}% > {o['gioi_han_pct']}% → rút gọn ~{o['can_rut_gon_pct']}% ({o['so_chu_hien_tai']}→{o['so_chu_muc_tieu']} chữ)")
if bad:
    print("CHẶN:", bad[:20]); sys.exit(4)
if MODE == "vi" and OVERFLOW: sys.exit(10)
