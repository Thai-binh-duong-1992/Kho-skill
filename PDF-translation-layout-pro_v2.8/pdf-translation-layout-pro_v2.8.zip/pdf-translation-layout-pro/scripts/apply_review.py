#!/usr/bin/env python3
"""Áp toàn bộ chỉnh sửa hiệu đính vào bản dịch. Bản nháp gốc được giữ ở workdir/draft/ (không ghi đè lần 2).
review.json: [{"id","level":"A|B|C|D","layer":1-5,"before","after","reason","flag"?}] — "before" phải có nguyên văn trong bản dịch của unit.
Dùng: python apply_review.py workdir/   → ghi tr_p*.json đã sửa + review_numbered.json; thoát mã 7 nếu có mục không áp được.
Lưu ý: chạy lại sẽ áp từ draft/, nên sửa tay sau đó phải đưa vào review.json chứ không sửa trực tiếp tr_p*.json.
"""
import sys, os
os.chdir(sys.argv[1] if len(sys.argv) > 1 else ".")
import json, glob, os, shutil
os.makedirs("draft", exist_ok=True)
for f in glob.glob("tr_p*.json"):
    if not os.path.exists("draft/" + f):
        shutil.copy(f, "draft/" + f)
files = {f: json.load(open("draft/" + f)) for f in sorted(glob.glob("tr_p*.json"))}
where = {k: f for f, d in files.items() for k in d}
R = json.load(open("review.json"))
order = {"A": 0, "B": 1, "C": 2, "D": 3}
R.sort(key=lambda r: (order.get(r["level"], 9), [int(x) for x in r["id"].split(".")]))
applied, failed = [], []
for n, r in enumerate(R, 1):
    r["n"] = n
    f = where.get(r["id"])
    if not f:
        failed.append(r); continue
    s = files[f][r["id"]]
    if r["before"] in s:
        files[f][r["id"]] = s.replace(r["before"], r["after"], 1); applied.append(r)
    else:
        failed.append(r)
for f, d in files.items():
    json.dump(d, open(f, "w"), ensure_ascii=False, indent=0)
json.dump(R, open("review_numbered.json", "w"), ensure_ascii=False, indent=1)
from collections import Counter
print("applied", len(applied), Counter(r["level"] for r in applied), "failed", [(r["id"], r["before"][:40]) for r in failed])
if failed: sys.exit(7)
