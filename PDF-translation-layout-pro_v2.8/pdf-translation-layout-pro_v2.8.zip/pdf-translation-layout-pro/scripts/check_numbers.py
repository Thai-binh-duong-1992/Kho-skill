#!/usr/bin/env python3
"""Lớp 1 tự động: đối chiếu số liệu, phủ định, dấu phân cách nghìn và thẻ HTML giữa nguồn và bản dịch theo từng unit.
Dùng: python check_numbers.py workdir/   → in danh sách nghi vấn (JSON); thoát mã 6 nếu có lỗi chặn (thiếu id, thẻ lệch, số lệch).
Kết quả là tín hiệu cho người hiệu đính, không thay lượt rà ngữ nghĩa.
"""
import json, glob, re, sys, os
W = sys.argv[1] if len(sys.argv) > 1 else "."
U = json.load(open(os.path.join(W, "units.json")))
TR = {}
for f in sorted(glob.glob(os.path.join(W, "tr_p*.json"))): TR.update(json.load(open(f)))
def strip(s): return re.sub(r"<[^>]+>", " ", s)
def nums(s, vi):
    s = strip(s)
    s = re.sub(r"(?<=\d)\.(?=\d{3}\b)", "", s) if vi else re.sub(r"(?<=\d),(?=\d{3}\b)", "", s)
    s = s.replace(",", ".") if vi else s
    return sorted(re.findall(r"\d+(?:\.\d+)?", s))
NEG_EN = r"\b(never|not|no|nothing|none|nobody|without|cannot|can't|don't|doesn't|isn't|won't|avoid|contraindicated|unless|except)\b"
NEG_VI = r"(không|chưa|đừng|chẳng|thiếu|chớ|cấm|tránh|trừ khi|ngoại trừ|chống chỉ định)"
block, warn = [], []
KP = os.path.join(W, "keep.json"); KEEP = set(json.load(open(KP))) if os.path.exists(KP) else set()
MP = os.path.join(W, "merges.json"); MERGES = json.load(open(MP)) if os.path.exists(MP) else []
OK = set(json.load(open(os.path.join(W, "num_ok.json")))) if os.path.exists(os.path.join(W, "num_ok.json")) else set()  # id đã soát tay
_by = {u["id"]: u for u in U}
for grp in MERGES:  # gộp nguồn + bản dịch theo nhóm merges để so số
    if grp[0] in _by:
        _by[grp[0]] = dict(_by[grp[0]], en=" ".join(_by[i]["en"] for i in grp if i in _by))
        TR[grp[0]] = " ".join(TR.get(i, "") for i in grp)
    for i in grp[1:]: KEEP.add(i)
U = [_by[u["id"]] for u in U]
for u in U:
    k = u["id"]; en = re.sub(r"\u00ad\s?", "", u["en"]).replace("\u200b", "").replace("\x07", "")
    if k in KEEP or k in OK: continue
    if k not in TR: block.append({"id": k, "loi": "thiếu bản dịch"}); continue
    vi = TR[k]
    for tg in ("b", "i", "code"):
        if vi.count(f"<{tg}>") != vi.count(f"</{tg}>"): block.append({"id": k, "loi": f"thẻ <{tg}> lệch"})
    if any(f"{a}.{b}" not in en for a, b in re.findall(r"(\d{1,3}),(\d{3})\b", strip(vi))) and not u["mono"]:
        block.append({"id": k, "loi": "dấu phẩy phân cách nghìn (sẽ bị đọc là thập phân) — mức A", "vi": strip(vi)[:80]})
    a, b = nums(en, False), nums(vi, True)
    if a != b:
        miss = [x for x in a if x not in b]
        (block if miss else warn).append({"id": k, "loi": "số lệch", "thieu": miss, "thua": [x for x in b if x not in a]})
    if len(re.findall(NEG_EN, strip(en), re.I)) > len(re.findall(NEG_VI, strip(vi), re.I)):
        warn.append({"id": k, "loi": "có thể mất phủ định", "en": strip(en)[:80], "vi": strip(vi)[:80]})
print(json.dumps({"chan": block, "canh_bao": warn}, ensure_ascii=False, indent=1))
sys.exit(6 if block else 0)
