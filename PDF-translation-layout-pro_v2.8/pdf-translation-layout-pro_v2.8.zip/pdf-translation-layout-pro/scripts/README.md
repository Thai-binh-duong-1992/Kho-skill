# Scripts — chạy theo thứ tự (Python 3, PyMuPDF; poppler-utils cho pdffonts)

| Bước | Lệnh | Ra | Mã thoát ≠ 0 |
|---|---|---|---|
| 1 | `python extract_units.py src.pdf work/` | units.json, src_pN.txt | 3 = có trang không có lớp chữ (scan) → HOLD |
| 2 | (agent dịch) ghi `work/tr_pN.json` | {id: HTML} | |
| 3 | `python check_numbers.py work/` | JSON nghi vấn | 6 = thiếu id / thẻ lệch / số lệch / phẩy nghìn |
| 4 | (agent hiệu đính) ghi `work/review.json` → `python apply_review.py work/` | tr đã sửa, draft/ | 7 = mục không áp được |
| 5 | `python render_layout.py src.pdf work/en.pdf --work work --mode en` | round-trip | 4 = unit không vừa |
| 6 | `python render_layout.py src.pdf out.pdf --work work --title "…" --author "…"` | PDF dịch + `overflow.json` | 4 = thiếu dịch/không vừa · 10 = unit co quá giới hạn (v2.8) |
| 7 | `python relink.py src.pdf out.pdf out_link.pdf` | khôi phục URI + link nội bộ ([n], (Hình n), (Bảng n)) | 9 = thiếu URI |
| 8 | `python raster_labels.py propose src.pdf work/` → điền `vi` trong `work/raster/spec.json` → `python raster_labels.py apply in.pdf out.pdf work/` | chữ trong ảnh raster đã dịch + `work/raster/*_cmp.png` | 8 = nhãn không vừa |
| 8b | `python raster_labels.py propose-par src.pdf work/ --pages 3,4 [--simple]` | OCR theo đoạn cho bảng/khung chữ dày trong ảnh, lưu đồ | — |
| 9 | `python qa_layout.py out.pdf [--margin 30] [--bottom 12]` | QA từng trang | 5 = còn lỗi |
| ★ | `bash build_pipeline.sh src.pdf work/ out.pdf "title" "author" [margin] [bottom]` | dựng lại toàn bộ (render → ảnh → link → QA → số → cỡ chữ) sau mỗi lần sửa | 4/5/6/8/9/10 |

Tùy chọn trong `work/`: `merges.json` (gộp unit bị tách), `columns.json` ({"cols": [[x0,x1],[x0,x1]], "full": [x0,x1], "body": 9.8, "cell": 8.0}) khi lưới cột khác mặc định Letter 2 cột (body/cell tự dò nếu bỏ trống), `keep.json` (["1.1", …] unit giữ nguyên chữ gốc, không redaction: tên tác giả, header tạp chí, tài liệu tham khảo).
Đánh dấu trong bản dịch: `<br>` = sang đoạn mới có thụt đầu dòng; `<brn>` = xuống dòng không thụt (tiêu đề tiểu mục in đậm `<b>…</b><brn>`).
Ký tự gạch mềm (U+00AD) và zero-width space trong nguồn được làm sạch tự động trước khi đo.
raster_labels.py cần tesseract (OCR, chỉ để đề xuất box) + opencv-python-headless + Pillow; nhãn chữ xiên (vd. trục 45°) dùng "rot": 45, "align": "right", "cap_hint" = chiều cao chữ hoa px.
`lookup_glossary.py "term"` chuyển tiếp sang skill `tra-thuat-ngu-drkun` (glossary dùng chung; `lookup_glossary.py scan …` = quét bản dịch). Thoát 3 nếu chưa cài skill đó.
Scripts chỉ đọc/ghi file cục bộ, không gọi mạng.

v2.2: `merges.json` có thể gộp khung khuyến cáo dòng đầu + phần còn lại (thụt treo tự nhận → "hang"); khi khung có viền rộng hơn dòng 1, render tách dòng 1 (nhường nhãn "Mới") và cho dòng 2+ dùng hết bề ngang khung. Khối dịch rỗng ("") chỉ bị xóa chữ gốc, không vẽ. `check_numbers.py` gộp theo merges và bỏ qua id trong `num_ok.json` (đã soát tay). `relink.py --work work/` giữ link nội bộ trong vùng keep.json và gắn link trích dẫn kiểu "(12)", "(26–29, 108)". `extract_units.py` nhận diện sans/đậm/nghiêng cho font thương mại (Akzidenz, Minion -Md/-It, Myriad…).

v2.5: `work/fonts.json` = {"dir": "/đường/dẫn/font", "sans": ["SourceSans3","Regular","Bold","It","BoldIt"], "serif": [...], "mono": [...]} (tên tệp = <base>-<hậu tố>.ttf; thiếu khóa nào dùng Liberation). `python prep_font.py IN.ttf OUT.ttf …` bỏ chữ ghép f khỏi GSUB, giữ dấu tiếng Việt, báo glyph thiếu (thoát 3). Bộ đo của render_layout chuẩn hóa NFKC trước khi đếm ký tự.

v2.8: cổng cỡ chữ từng unit (thân bài ≤ 12,5% · ô bảng ≤ 10% · khác ≤ 15%) → `work/overflow.json` [{id, page, loai, co_pct, gioi_han_pct, can_rut_gon_pct, so_chu_hien_tai, so_chu_muc_tieu, en, vi}], render thoát 10, pipeline dựng xong rồi thoát 10. `work/shrink.json` {"body","cell","other","allow":[id]} đổi giới hạn / ngoại lệ đã duyệt. Sàn khoảng cách dòng bản Việt 1,18 (dấu chồng không chạm dòng trên). Ô bảng căn trái không tràn qua đầu phải đường kẻ hàng. Rút gọn theo mẫu E trong `references/agent-briefs.md`.
