#!/usr/bin/env python3
"""Tách PDF nguồn thành các "unit" chữ (đoạn, ô bảng, nhãn hình, khối code) kèm bbox/style.
Dùng: python extract_units.py source.pdf workdir/
Ra: workdir/units.json và workdir/src_pN.txt (theo thứ tự đọc: toàn trang → cột trái → cột phải) để dịch.
Thoát mã 3 nếu có trang không có lớp chữ (PDF scan) → HOLD, cần OCR trước.
"""
import pymupdf, json, sys, html, re, os
WORK = sys.argv[2] if len(sys.argv) > 2 else "."
os.makedirs(WORK, exist_ok=True)
doc = pymupdf.open(sys.argv[1])

SANS = ('Sans', 'Arial', 'Helvetica', 'Grotesk', 'Akzidenz', 'Myriad', 'Frutiger', 'Univers', 'Futura', 'Gotham', 'Calibri', 'Segoe', 'Verdana', 'Tahoma', 'Roboto', 'Lato', 'OpenSans')
def style(f):
    base = f.split('+')[-1]
    b = any(k in base for k in ('Bold', 'Black', 'Heavy', 'Semibold', 'SemiBold', 'Demi', '-Md', 'Medium'))
    i = any(k in base for k in ('Italic', 'Oblique', '-It', 'Ital'))
    fam = 'mono' if ('Mono' in base or 'Courier' in base) else ('sans' if any(k in base for k in SANS) else 'serif')
    return fam, b, i

units = []
for pno, page in enumerate(doc):
    d = page.get_text("rawdict")
    pagesegs = []
    for bi, b in enumerate(d["blocks"]):
        if b["type"] != 0:
            continue
        segs = []
        for l in b["lines"]:
            cur = None; prev = None
            for s in l["spans"]:
                st = "".join(c["c"] for c in s["chars"])
                if st.strip() == "" and s["bbox"][2] - s["bbox"][0] > 3 and s["size"] < 9.5:
                    if cur: segs.append(cur); cur = None
                    prev = None; continue
                for ch in s["chars"]:
                    c = ch["c"]
                    split = (cur is not None and prev is not None and prev["c"] != " " and c != " "
                             and ch["bbox"][0] - prev["bbox"][2] > 2.5 and s["size"] < 9.5)
                    if split:
                        segs.append(cur); cur = None
                    if cur is None:
                        cur = {"x0": ch["bbox"][0], "y0": s["bbox"][1], "x1": ch["bbox"][2], "y1": s["bbox"][3], "spans": []}
                    if not cur["spans"] or cur["spans"][-1]["_id"] != id(s):
                        cur["spans"].append({"_id": id(s), "font": s["font"], "size": s["size"], "color": s["color"], "text": ""})
                    cur["spans"][-1]["text"] += c
                    cur["x1"] = max(cur["x1"], ch["bbox"][2])
                    prev = ch
            if cur: segs.append(cur)
        segs = [s for s in segs if "".join(x["text"] for x in s["spans"]).strip()]
        mono = all('Mono' in sg["spans"][0]["font"] for sg in segs) if segs else False
        for sg in segs:
            sg["mono"] = mono; sg["blk"] = bi
            sg["sz"] = max(x["size"] for x in sg["spans"])
        pagesegs.extend(segs)
    pagesegs.sort(key=lambda s: (round(s["y0"]), s["x0"]))
    groups = []
    for s in pagesegs:
        sz = s["sz"]; placed = False
        for g in reversed(groups):
            L = g["segs"][-1]
            if s["mono"] or g["mono"]:
                if s["mono"] and g["mono"] and g["blk"] == s["blk"]:
                    g["segs"].append(s); placed = True; break
                continue
            if abs(sz - L["sz"]) > 0.8: continue
            gap = s["y0"] - L["y1"]
            if gap > 0.25 * sz or s["y0"] < L["y0"] + 2: continue
            if min(s["x1"], L["x1"]) - max(s["x0"], L["x0"]) < -2: continue
            if abs(s["x0"] - g["segs"][0]["x0"]) > 16 and abs(s["x0"] - L["x0"]) > 16:
                cL = (L["x0"] + L["x1"]) / 2; cs = (s["x0"] + s["x1"]) / 2
                if abs(cL - cs) > 4: continue
            def sig(x):
                fs=[sp["font"] for sp in x["spans"] if sp["text"].strip()]
                return (all('Bold' in f for f in fs), all('Italic' in f for f in fs))
            if sig(s) != sig(L) and (sig(L)!=(False,False) or sig(s)!=(False,False)) and (sig(L)[0] or sig(L)[1] or sig(s)[0] or sig(s)[1]):
                # style changes at a line boundary -> heading/subheading boundary
                if not (sig(L)==(False,False) and not (sig(s)[0] or sig(s)[1])):
                    break
            g["segs"].append(s); placed = True; break
        if not placed:
            groups.append({"segs": [s], "mono": s["mono"], "blk": s["blk"]})
    for ui, g in enumerate(groups):
        S = g["segs"]; mono = g["mono"]
        x0 = min(s["x0"] for s in S); x1 = max(s["x1"] for s in S)
        y0 = min(s["y0"] for s in S); y1 = max(s["y1"] for s in S)
        parts = []
        for s in S:
            line = ""
            for sp in s["spans"]:
                fam, bo, it = style(sp["font"]); t = html.escape(sp["text"], quote=False)
                if not mono:
                    if fam == 'mono': t = f"<code>{t}</code>"
                    if bo: t = f"<b>{t}</b>"
                    if it: t = f"<i>{t}</i>"
                line += t
            parts.append(line)
        if mono:
            text = "\n".join(parts)
        else:
            text = ""
            for p in parts:
                if text.endswith("-") and not text.endswith(" -"): text += p.lstrip()
                else: text += (" " if text else "") + p.strip()
            for tg in ("b", "i"):
                text = re.sub(rf"</{tg}>(\s*)<{tg}>", r"\1", text)
            text = re.sub(r"\s+", " ", text)
        sp0 = max((sp for s in S for sp in s["spans"]), key=lambda sp: len(sp["text"]))
        fam, bo, it = style(sp0["font"])
        align = "left"
        if len(S) >= 3 and max(s["x1"] for s in S[:-1]) - min(s["x1"] for s in S[:-1]) < 3:
            align = "justify"
        elif len(S) >= 1 and not mono:
            cs = [(s["x0"] + s["x1"]) / 2 for s in S]
            if len(S) >= 2 and max(cs) - min(cs) < 3 and max(s["x0"] for s in S) - min(s["x0"] for s in S) > 5:
                align = "center"
        ind = round(S[0]["x0"] - min(s["x0"] for s in S[1:]), 1) if len(S) > 1 else 0
        units.append({"id": f"{pno+1}.{ui}", "page": pno + 1,
                      "bb": [round(x0, 1), round(y0, 1), round(x1, 1), round(y1, 1)],
                      "fam": fam, "b": bo, "i": it, "size": round(sp0["size"], 2), "color": "#%06x" % sp0["color"],
                      "align": align, "indent": ind, "nlines": len(S), "mono": mono, "en": text,
                      "lines": [[round(s["x0"], 1), round(s["y0"], 1), round(s["x1"], 1), round(s["y1"], 1)] for s in S]})
empty = [p + 1 for p in range(len(doc)) if not any(u["page"] == p + 1 for u in units)]
assert units, "Không trích được chữ nào"
json.dump(units, open(os.path.join(WORK, "units.json"), "w"), ensure_ascii=False, indent=1)
def col(u):
    x0, y0, x1, y1 = u["bb"]; w = doc[u["page"] - 1].rect.width; cx = (x0 + x1) / 2
    if (x0 < w / 2 - 6 and x1 > w / 2 + 6) or abs(cx - w / 2) < 10: return 0
    return 1 if cx < w / 2 else 2
for p in range(1, len(doc) + 1):
    us = sorted([u for u in units if u["page"] == p], key=lambda u: (col(u), u["bb"][1], u["bb"][0]))
    with open(os.path.join(WORK, f"src_p{p}.txt"), "w") as f:
        for u in us:
            f.write(f"### {u['id']}  [{'mono' if u['mono'] else u['fam']} {u['size']}pt, {u['nlines']} dòng, rộng {u['bb'][2]-u['bb'][0]:.0f}pt]\n{u['en']}\n")
print(json.dumps({"units": len(units), "pages": len(doc), "pages_without_text": empty}, ensure_ascii=False))
if empty: sys.exit(3)
