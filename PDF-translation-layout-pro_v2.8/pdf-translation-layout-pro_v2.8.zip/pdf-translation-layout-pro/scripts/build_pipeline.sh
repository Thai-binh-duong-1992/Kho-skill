#!/bin/bash
# Dựng lại toàn bộ đầu ra sau mỗi lần sửa: dàn trang → chữ trong ảnh → link → QA → số.
# Dùng: bash build_pipeline.sh <src.pdf> <work_dir> <out.pdf> "<title>" "<author>" [margin=36] [bottom=12]
# Cần: <work>/tr_p*.json (đã apply_review). Chữ trong ảnh: <work>/raster/spec.json (raster_labels đã điền vi);
#      spec ở thư mục khác → đặt biến RASTER_WORK=<thư mục chứa raster/>.
# Thoát: 0 đạt · 2 thiếu tham số · 4 render · 8 raster · 9 link · 5 QA bố cục/font · 6 số liệu chặn
#        · 10 cỡ chữ: unit co quá giới hạn (v2.8) — PDF vẫn được dựng để xem, nhưng chưa đạt.
set -uo pipefail
[ $# -ge 5 ] || { echo "Dùng: build_pipeline.sh src.pdf work/ out.pdf \"title\" \"author\" [margin] [bottom]"; exit 2; }
SRC="$1"; W="$2"; OUT="$3"; TITLE="$4"; AUTH="$5"; MARGIN="${6:-36}"; BOTTOM="${7:-12}"
RW="${RASTER_WORK:-$W}"
D="$(cd "$(dirname "$0")" && pwd)"
python3 "$D/render_layout.py" "$SRC" "$W/_b1.pdf" --work "$W" --title "$TITLE" --author "$AUTH" > "$W/_render.log" 2>&1; RC=$?
SHR=0
if [ $RC -eq 10 ]; then SHR=1; grep -E "cổng cỡ chữ|CO-QUÁ" "$W/_render.log" | head -16
elif [ $RC -ne 0 ]; then tail -5 "$W/_render.log"; exit 4; fi
grep -E "min scale" "$W/_render.log" | tail -1
if [ -f "$RW/raster/spec.json" ]; then
  python3 "$D/raster_labels.py" apply "$W/_b1.pdf" "$W/_b2.pdf" "$RW/" > "$W/_raster.log" 2>&1 || { tail -5 "$W/_raster.log"; exit 8; }
  echo "raster: đã áp $RW/raster/spec.json"
else
  echo "raster: KHÔNG có $RW/raster/spec.json → bỏ qua chữ trong ảnh (nếu tài liệu có ảnh chứa chữ: chưa xong)"
  cp "$W/_b1.pdf" "$W/_b2.pdf"
fi
python3 "$D/relink.py" "$SRC" "$W/_b2.pdf" "$OUT" --work "$W" > "$W/_link.log" 2>&1 || { echo "relink: thiếu link"; grep -v "0→0  nội bộ 0→0" "$W/_link.log" | head; exit 9; }
python3 "$D/qa_layout.py" "$OUT" --margin "$MARGIN" --bottom "$BOTTOM" > "$W/_qa.log" 2>&1; QA=$?
grep -v "ngoài_vùng_an_toàn=0 chồng_lấn=0 cắt_đường_kẻ=0" "$W/_qa.log" | grep -E "^Trang|TOTAL|CHƯA" || true
python3 "$D/check_numbers.py" "$W" > "$W/_check.json"; NUM=$?
[ $NUM -ne 0 ] && echo "check_numbers: còn mục chặn → xem $W/_check.json"
[ $QA -ne 0 ] && { echo "PIPELINE: TRƯỢT QA (xem $W/_qa.log)"; exit 5; }
[ $NUM -ne 0 ] && { echo "PIPELINE: TRƯỢT SỐ LIỆU"; exit 6; }
[ $SHR -ne 0 ] && { echo "PIPELINE: TRƯỢT CỠ CHỮ — rút gọn theo $W/overflow.json (mẫu E trong agent-briefs.md), apply_review, chạy lại"; exit 10; }
echo "PIPELINE: ĐẠT"; exit 0
