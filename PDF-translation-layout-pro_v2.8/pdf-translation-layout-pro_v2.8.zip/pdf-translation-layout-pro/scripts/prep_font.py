#!/usr/bin/env python3
"""Chuẩn bị font thay thế cho render_layout: bỏ chữ ghép f (fi/fl/ff/ft/fj…) khỏi GSUB để
lớp chữ sao chép/tìm kiếm đúng và bộ đo đếm đủ ký tự; giữ nguyên ccmp/mark (dấu tiếng Việt).
Dùng: python prep_font.py IN.ttf OUT.ttf [IN2.ttf OUT2.ttf ...]
"""
import sys
from fontTools.ttLib import TTFont

LIG = ("fi", "fl", "ff", "ffi", "ffl", "ft", "fj", "t_t")


def strip(src, dst):
    f = TTFont(src)
    n = 0
    if "GSUB" in f:
        for lk in f["GSUB"].table.LookupList.Lookup:
            for st in lk.SubTable:
                t = st.ExtSubTable if lk.LookupType == 7 else st
                if not hasattr(t, "ligatures"):
                    continue
                for first in list(t.ligatures):
                    keep = [l for l in t.ligatures[first] if not (l.LigGlyph.startswith("f_") or l.LigGlyph in LIG)]
                    n += len(t.ligatures[first]) - len(keep)
                    if keep:
                        t.ligatures[first] = keep
                    else:
                        del t.ligatures[first]
    cmap = f.getBestCmap()
    miss = [c for c in "ăâđêôơưạảấầẩẫậắằẳẵặẹẻẽếềểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ≥≤μβ–—’“”†‡±×" if ord(c) not in cmap]
    f.save(dst)
    print(f"{dst}: bỏ {n} chữ ghép; thiếu glyph: {''.join(miss) or 'không'}")
    return not miss


if __name__ == "__main__":
    a = sys.argv[1:]
    if len(a) < 2 or len(a) % 2:
        sys.exit(__doc__)
    ok = all(strip(a[i], a[i + 1]) for i in range(0, len(a), 2))
    sys.exit(0 if ok else 3)
