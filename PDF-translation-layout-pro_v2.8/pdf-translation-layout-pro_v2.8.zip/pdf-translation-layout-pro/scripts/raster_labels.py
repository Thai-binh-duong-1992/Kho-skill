#!/usr/bin/env python3
"""Dịch chữ nằm TRONG ảnh raster của PDF (lưu đồ, biểu đồ, hình chú thích) — inpaint cục bộ + vẽ nhãn tiếng Việt.

Hai bước:
  1) propose: OCR (tesseract) mọi ảnh có chữ → work/raster/spec.json (nháp: box pixel, chữ EN, góc, cỡ, đậm, nền)
       python raster_labels.py propose src.pdf work/ [--min-px 120]
     Người dịch điền trường "vi" cho từng nhãn (để "vi": null = giữ nguyên, vd. số, ký hiệu †‡*).
     Sửa box/rot/font nếu OCR sai; thêm nhãn OCR bỏ sót bằng tay (box theo pixel ảnh gốc).
  2) apply: xóa chữ cũ bằng cv2.inpaint (TELEA) chỉ trên mặt nạ nét chữ, vẽ nhãn VI cùng màu/góc/căn lề,
     tự co cỡ để vừa "fit" (mặc định = box nới theo "grow"), thay ảnh trong PDF (replace_image), giữ nguyên trang.
       python raster_labels.py apply in.pdf out.pdf work/
     Ra work/raster/<xref>_vi.png và <xref>_cmp.png (gốc | dịch) để soát bằng mắt. Thoát 8 nếu nhãn không vừa.

Trường của một nhãn:
  box [x0,y0,x1,y1] pixel ảnh gốc · en · vi · rot 0|90 (90 = chữ dọc đọc từ dưới lên) · align center|left|right
  font serif|sans · bold · size (px, chiều cao chữ hoa ước lượng; null = đo từ nét gốc) · fit [x0,y0,x1,y1] (vùng được phép vẽ)
  grow (px nới mỗi bên khi không có fit, mặc định 0.6×chiều cao box) · lines (tách dòng bằng \\n trong vi)
Không bao giờ: phủ hộp màu bệt lên ảnh y khoa (X-quang/siêu âm…) — chỉ inpaint trên mặt nạ nét chữ.

Chế độ ĐOẠN (v2.2) cho ảnh chữ dày — bảng khuyến cáo, khung văn bản, lưu đồ:
  python raster_labels.py propose-par src.pdf work/ --pages 3,4,5 [--simple] [--min-px 300]
    OCR tesseract psm 3 theo dòng → tự gộp thành đoạn (cùng lề trái, khoảng dòng < 1,45× chiều cao dòng; đoạn căn giữa;
    nhãn treo GOOD PRACTICE/IN OUR PRACTICE); bỏ biểu tượng đầu dòng (dấu ✓✗ màu, ⊕○, viên số thứ tự bên trái cột "Remark");
    chữ trắng trên dải màu đậm được đảo màu để OCR. --simple: tắt luật biểu tượng/viên số (dùng cho hình, lưu đồ).
  Nhãn đoạn: type "par", box (vùng được vẽ; x1 = giới hạn xuống dòng), words (hộp từng dòng/chữ gốc cần xóa), first_x/body_x
    (x dòng đầu/dòng sau), nlines, pitch (khoảng dòng gốc, px), h_med, align left|center, font, bold, italic, size?, ink? [r,g,b],
    accent? [r,g,b], text_top?, grow_y? (px cho phép tràn xuống). Trong vi: <b>, <i>, <c> (màu nhấn), \\n (ép xuống dòng).
  apply: mặt nạ = pixel khác nền trong words (nền lấy quanh chính vùng chữ gốc), giãn 3 vòng, inpaint TELEA; màu chữ = trung vị
    pixel đậm nhất (bỏ pixel màu nhấn), chữ sáng trên nền đậm tự nhận; cỡ = pitch/1,18 (trung vị theo ảnh) hoặc h_med;
    thử nén ngang 4–14% trước khi giảm cỡ; ảnh màu lưu JPEG q92 (giữ dung lượng PDF).
"""
import sys, os, json, argparse, re, statistics
import numpy as np, cv2, pymupdf
from PIL import Image, ImageDraw, ImageFont

FD = "/usr/share/fonts/truetype/liberation"
FONTS = {("serif", False): "LiberationSerif-Regular.ttf", ("serif", True): "LiberationSerif-Bold.ttf",
         ("sans", False): "LiberationSans-Regular.ttf", ("sans", True): "LiberationSans-Bold.ttf"}

def load_gray(doc, xref):
    pix = pymupdf.Pixmap(doc, xref)
    if pix.alpha: pix = pymupdf.Pixmap(pix, 0)
    if pix.colorspace is None or pix.colorspace.n not in (1, 3): pix = pymupdf.Pixmap(pymupdf.csRGB, pix)
    a = np.frombuffer(pix.samples, np.uint8).reshape(pix.height, pix.width, pix.n)
    return a.copy()

def ocr_lines(img, rot):
    import pytesseract
    g = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) if img.shape[2] == 3 else np.ascontiguousarray(img[..., 0])
    if rot == 90: g = cv2.rotate(g, cv2.ROTATE_90_CLOCKWISE)
    sc = 2 if max(g.shape) < 2500 else 1
    g2 = cv2.resize(g, None, fx=sc, fy=sc, interpolation=cv2.INTER_CUBIC)
    bw = cv2.threshold(g2, 140, 255, cv2.THRESH_BINARY)[1]  # nền xám nhạt (hộp tiêu đề) → trắng
    d = pytesseract.image_to_data(bw, config="--psm 11", output_type=pytesseract.Output.DICT)
    words = [dict(t=d["text"][i], x=d["left"][i] / sc, y=d["top"][i] / sc, w=d["width"][i] / sc, h=d["height"][i] / sc, c=float(d["conf"][i]))
             for i in range(len(d["text"])) if d["text"][i].strip() and float(d["conf"][i]) > 55]
    # gộp thành dòng: cùng hàng, khoảng cách ngang < 1.2×cao chữ
    words.sort(key=lambda w: (round(w["y"] / max(w["h"], 1)), w["x"]))
    lines = []
    for w in words:
        for L in lines:
            if abs((L["y0"] + L["y1"]) / 2 - (w["y"] + w["h"] / 2)) < 0.45 * max(L["y1"] - L["y0"], w["h"]) and 0 <= w["x"] - L["x1"] < 1.2 * w["h"]:
                L["t"] += " " + w["t"]; L["x1"] = w["x"] + w["w"]; L["y0"] = min(L["y0"], w["y"]); L["y1"] = max(L["y1"], w["y"] + w["h"]); break
        else:
            lines.append(dict(t=w["t"], x0=w["x"], y0=w["y"], x1=w["x"] + w["w"], y1=w["y"] + w["h"]))
    H = g.shape[1] if rot == 90 else g.shape[0]  # chiều cao ảnh GỐC
    out = []
    for L in lines:
        if not any(ch.isalpha() for ch in L["t"]): continue
        b = [L["x0"], L["y0"], L["x1"], L["y1"]]
        if rot == 90:  # ảnh đã xoay CW: (x,y) rot → gốc (y, Wr-1-x) với Wr = chiều rộng ảnh xoay = H gốc
            b = [b[1], H - b[2], b[3], H - b[0]]
        out.append(dict(box=[round(v) - 3 if i < 2 else round(v) + 3 for i, v in enumerate(b)], en=L["t"], vi=None, rot=rot))
    return out

def propose(src, work, min_px):
    doc = pymupdf.open(src); os.makedirs(os.path.join(work, "raster"), exist_ok=True)
    spec = {"images": []}; seen = set()
    for pno, page in enumerate(doc):
        for info in page.get_image_info(xrefs=True):
            x = info["xref"]
            if not x or x in seen: continue
            seen.add(x)
            try: img = load_gray(doc, x)
            except Exception: continue  # stencil/mask không có không gian màu
            if min(img.shape[:2]) < min_px: continue
            labs = ocr_lines(img, 0)
            vert = [l for l in ocr_lines(img, 90) if (l["box"][3] - l["box"][1]) > 2 * (l["box"][2] - l["box"][0])]
            labs += vert
            for l in labs:
                l.update(align="center", font="serif", bold=False, size=None)
            if labs:
                spec["images"].append(dict(page=pno + 1, xref=x, size=[img.shape[1], img.shape[0]], labels=labs))
                Image.fromarray(img.squeeze()).save(os.path.join(work, "raster", f"{x}_src.png"))
    p = os.path.join(work, "raster", "spec.json")
    json.dump(spec, open(p, "w"), ensure_ascii=False, indent=1)
    print(p, sum(len(i["labels"]) for i in spec["images"]), "nhãn trong", len(spec["images"]), "ảnh")


ICONISH = re.compile(r"^[\W_]*(?:iv|iV|Vv|Viv|vy|OOO|OO|O|QB|OI|oO|B|a3|ep|Ls|it|@+O*|O+@*)[\W_]*$")
def propose_par(src, work, pages, min_px, simple=False):
    """OCR theo đoạn (tesseract psm 3) cho ảnh bảng/khung chữ dày: mỗi đoạn = 1 nhãn wrap, bỏ token biểu tượng."""
    import pytesseract
    doc = pymupdf.open(src); os.makedirs(os.path.join(work, "raster"), exist_ok=True)
    sp = os.path.join(work, "raster", "spec.json")
    spec = json.load(open(sp)) if os.path.exists(sp) else {"images": []}
    spec["images"] = [i for i in spec["images"] if i["page"] not in pages]
    for pno in pages:
        page = doc[pno - 1]
        for info in page.get_image_info(xrefs=True):
            x = info["xref"]
            try: img = load_gray(doc, x)
            except Exception: continue
            if min(img.shape[:2]) < min_px: continue
            g = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) if img.shape[2] == 3 else np.ascontiguousarray(img[..., 0])
            blur = cv2.GaussianBlur(g, (51, 51), 0); dark = blur < 110
            g2 = g.copy(); g2[dark] = 255 - g2[dark]   # chữ trắng trên nền đậm → đảo để OCR
            d = pytesseract.image_to_data(g2, config="--psm 3", output_type=pytesseract.Output.DICT)
            lines = {}
            for i, t in enumerate(d["text"]):
                if not t.strip(): continue
                k = (d["block_num"][i], d["par_num"][i], d["line_num"][i])
                lines.setdefault(k, []).append(dict(t=t, c=float(d["conf"][i]), b=[d["left"][i], d["top"][i], d["left"][i] + d["width"][i], d["top"][i] + d["height"][i]]))
            L = []
            spread = (img.max(2).astype(int) - img.min(2).astype(int)) if img.shape[2] == 3 else np.zeros(g.shape, int)
            raw = []
            for k, ws in lines.items():
                ws.sort(key=lambda w: w["b"][0])
                y0l = min(w["b"][1] for w in ws); y1l = max(w["b"][3] for w in ws)
                raw.append((ws, y0l, y1l))
            rem = [w["b"][0] for ws, _, _ in raw for w in ws if w["t"].startswith("Remark")]
            R = statistics.median(rem) if (rem and not simple) else 0   # mép trái cột chữ; bên trái là viên thuốc số thứ tự
            raw2 = []
            for ws, y0l, y1l in raw:
                cy = (y0l + y1l) // 2
                on_dark = dark[min(cy, dark.shape[0] - 1), min(max(0, ws[0]["b"][0]), dark.shape[1] - 1)]
                ws2 = ws if on_dark else [w for w in ws if w["b"][2] >= R - 4]
                if ws2: raw2.append((ws2, min(w["b"][1] for w in ws2), max(w["b"][3] for w in ws2)))
            raw = raw2
            def good(w):
                t = w["t"]
                if re.fullmatch(r"\d{4}", t): return True
                return bool(re.fullmatch(r"[“\"(]?[A-Za-z][A-Za-z\-]+[,.;:”\")]*", t)) and (w["c"] >= 75 and len(re.sub(r"[^A-Za-z]", "", t)) >= 2) and not ICONISH.match(t)
            # T = cột bắt đầu chữ sau biểu tượng (trung vị vị trí từ "tốt" đầu tiên trên các dòng có biểu tượng màu)
            cands = []
            for ws, y0l, y1l in raw:
                gw = next((w for w in ws if good(w)), None)
                if gw and gw["b"][0] > ws[0]["b"][0] + 60:
                    band = spread[max(0, y0l - 4):y1l + 4, ws[0]["b"][0] - 40:gw["b"][0] - 6]
                    if band.size and (band > 40).sum() > 100: cands.append(gw["b"][0])
            T = statistics.median(cands) if (cands and not simple) else 0
            for ws, y0l, y1l in raw:
                gw = next((w for w in ws if good(w) and (not T or w["b"][0] >= T - 40 or w["b"][0] - ws[0]["b"][0] < 30)), None)
                x_start = ws[0]["b"][0]
                band = spread[max(0, y0l - 4):y1l + 4, max(0, x_start - 40):int(max(T, x_start + 1)) - 6]
                cyl = (y0l + y1l) // 2
                on_dark_l = dark[min(cyl, dark.shape[0] - 1), min(max(0, x_start + 5), dark.shape[1] - 1)]
                icon_line = (not simple) and (not on_dark_l) and band.size > 0 and (band > 40).sum() > 100
                if icon_line and gw is not None:
                    ws = [w for w in ws if w["b"][0] >= min(gw["b"][0], max(T - 10, 0))]
                    while ws and not good(ws[0]) and (ICONISH.match(ws[0]["t"]) or len(re.sub(r"[^A-Za-z]", "", ws[0]["t"])) < 3): ws = ws[1:]
                else:
                    j = 0
                    while j < len(ws) and (ICONISH.match(ws[j]["t"]) or re.fullmatch(r"[\W_]+", ws[j]["t"])
                                           or (ws[j]["c"] < 40 and not re.fullmatch(r"[A-Za-z][a-z]*[,.;:]?", ws[j]["t"]))):
                        j += 1
                    ws = ws[j:]
                if not ws or not any(re.search(r"[A-Za-z]{3,}", w["t"]) for w in ws): continue
                cur = [ws[0]]
                for w in ws[1:]:
                    hh = max(8, w["b"][3] - w["b"][1])
                    if w["b"][0] - cur[-1]["b"][2] > 6 * hh: L.append(cur); cur = [w]
                    else: cur.append(w)
                L.append(cur)
            for l in L:
                l_top = min(w["b"][1] for w in l)
            L.sort(key=lambda l: (min(w["b"][1] for w in l), l[0]["b"][0]))
            tops = [min(w["b"][1] for w in l) for l in L]
            hts = sorted(max(w["b"][3] for w in l) - min(w["b"][1] for w in l) for l in L)
            H = hts[len(hts) // 2] if hts else 26  # chiều cao dòng (gồm phần trên/dưới chữ)
            pars_l = []
            for l in L:
                t0 = min(w["b"][1] for w in l); x0l = l[0]["b"][0]; txt = " ".join(w["t"] for w in l)
                starter = re.match(r"(Remark|Remarks|2021 STATEMENT|GOOD PRACTICE|IN OUR PRACTICE|There is)", txt)
                hit = None
                for P in pars_l[::-1]:
                    last = P[-1]; lt = min(w["b"][1] for w in last); lx0 = last[0]["b"][0]; lx1 = max(w["b"][2] for w in last)
                    p0 = " ".join(w["t"] for w in P[0])
                    hang_lbl = re.match(r"(GOOD PRACTICE|IN OUR PRACTICE)", p0) and lx0 < x0l < lx1 and (len(P) == 1 or abs(x0l - P[1][0]["b"][0]) < 15)
                    lcx = (lx0 + lx1) / 2; cx = (x0l + max(w["b"][2] for w in l)) / 2
                    centered = abs(cx - lcx) < 25 and abs(x0l - lx0) >= 15
                    if 0 < t0 - lt < 1.45 * H and not starter and centered and (len(P) == 1 or P[0][0].get("_c")):
                        P[0][0]["_c"] = True; hit = P; break
                    if 0 < t0 - lt < 1.45 * H and not starter and (abs(x0l - lx0) < 15 or hang_lbl or (len(P) == 1 and x0l < lx0 and x0l > lx0 - 320 and abs(x0l - P[0][0]["b"][0]) > 15)) and x0l < lx1:
                        hit = P; break
                    if t0 - lt > 2.5 * H: break
                if hit is not None: hit.append(l)
                else: pars_l.append([l])
            pars = {i: P for i, P in enumerate(pars_l)}
            labs = []
            for k, ls in pars.items():
                ls.sort(key=lambda l: l[0]["b"][1])
                words = [w for l in ls for w in l]
                x0 = min(w["b"][0] for w in words); y0 = min(w["b"][1] for w in words)
                x1 = max(w["b"][2] for w in words); y1 = max(w["b"][3] for w in words)
                tops = [min(w["b"][1] for w in l) for l in ls]
                pitch = statistics.median([b - a for a, b in zip(tops, tops[1:])]) if len(tops) > 1 else None
                hts = sorted(w["b"][3] - w["b"][1] for w in words)
                al = "center" if ls[0][0].get("_c") else "left"
                labs.append(dict(type="par", align=al, box=[x0 - 2, y0 - 2, x1 + 2, y1 + 2], first_x=ls[0][0]["b"][0], body_x=min(l[0]["b"][0] for l in ls[1:]) if len(ls) > 1 else x0,
                                 nlines=len(ls), pitch=pitch, h_med=hts[len(hts) // 2], words=[w["b"] for w in words],
                                 en="\n".join(" ".join(w["t"] for w in l) for l in ls), vi=None, font="sans", bold=False, italic=False))
            spec["images"].append(dict(page=pno, xref=x, size=[img.shape[1], img.shape[0]], mode="par", labels=labs))
            Image.fromarray(img.squeeze()).save(os.path.join(work, "raster", f"{x}_src.png"))
            print("trang", pno, "ảnh", x, "đoạn", len(labs))
    json.dump(spec, open(sp, "w"), ensure_ascii=False, indent=1)

def runs_of(htm):
    """'a <b>b</b> <i>c</i> <c>d</c>' → [(word, bold, italic, accent)]"""
    out = []; st = {"b": False, "i": False, "c": False}
    for tok in re.split(r"(</?[bic]>)", htm):
        m = re.fullmatch(r"<(/?)([bic])>", tok)
        if m: st[m.group(2)] = not m.group(1); continue
        for wd in re.split(r"(\s+)", tok):
            if wd: out.append((wd, st["b"], st["i"], st["c"]))
    return out

def face(fam, b, it, size):
    key = {(False, False): "Regular", (True, False): "Bold", (False, True): "Italic", (True, True): "BoldItalic"}[(bool(b), bool(it))]
    base = {"sans": "LiberationSans", "serif": "LiberationSerif"}[fam]
    return ImageFont.truetype(os.path.join(FD, f"{base}-{key}.ttf"), max(6, int(round(size))))

def _layout(lab, size, sx, fx, bx, x1):
    fam = lab.get("font", "sans")
    runs = runs_of(lab["vi"].replace("\n", " \n "))
    lines = [[]]; widths = [x1 - fx]; cur = 0
    for wd, b, it, c in runs:
        if "\n" in wd:
            lines.append([]); widths.append(x1 - bx); cur = 0; continue
        f = face(fam, b or lab.get("bold"), it or lab.get("italic"), size)
        w = f.getlength(wd) * sx
        if wd.isspace():
            if lines[-1]: lines[-1].append((wd, b, it, c, w)); cur += w
            continue
        if cur + w > widths[-1] and lines[-1]:
            while lines[-1] and lines[-1][-1][0].isspace(): cur -= lines[-1].pop()[4]
            lines.append([]); widths.append(x1 - bx); cur = 0
        lines[-1].append((wd, b, it, c, w)); cur += w
    return lines

def draw_par(canvas, lab, ink, size):
    """Vẽ đoạn tự xuống dòng; ưu tiên nén ngang chữ (tối đa 14%) trước khi giảm cỡ; dòng 1 ở first_x, các dòng sau ở body_x."""
    x0, y0, x1, y1 = lab["box"]; fx = lab.get("first_x", x0); bx = lab.get("body_x", x0)
    if lab.get("align") == "center": fx = bx = x0
    ymax = y1 + lab.get("grow_y", 0)
    fam = lab.get("font", "sans")
    pitch_ratio = (lab["pitch"] / size) if lab.get("pitch") else 1.18
    ok = False
    for _ in range(40):
        for sx in (1.0, 0.96, 0.92, 0.88, 0.86):
            lines = _layout(lab, size, sx, fx, bx, x1)
            lh = size * pitch_ratio
            if y0 + lh * (len(lines) - 1) + size * 1.15 <= ymax + 1: ok = True; break
        if ok: break
        size *= 0.975
    if not ok: return False
    accent = tuple(lab.get("accent") or ink) if isinstance(ink, tuple) else ink
    top0 = lab.get("text_top", y0)
    for i, ln in enumerate(lines):
        lw = sum(t[4] for t in ln)
        x = fx if i == 0 else bx
        if lab.get("align") == "center": x = (x0 + x1) / 2 - lw / 2
        y = top0 + i * lh
        W = int(lw / sx) + 6; Ht = int(size * 1.6) + 4
        tiles = {}
        cx = 2
        for wd, b, it, c, w in ln:
            if not wd.isspace():
                t = tiles.setdefault(c, Image.new("L", (W, Ht), 0))
                ImageDraw.Draw(t).text((cx, 2), wd, font=face(fam, b or lab.get("bold"), it or lab.get("italic"), size), fill=255)
            cx += w / sx
        for c, t in tiles.items():
            if sx != 1.0: t = t.resize((max(1, int(W * sx)), Ht), Image.LANCZOS)
            col = accent if c else ink
            canvas.paste(Image.new(canvas.mode, t.size, col), (int(x - 2 * sx), int(y - 2)), t)
    return True

def text_mask(g, box, bg):
    x0, y0, x1, y1 = box
    roi = g[y0:y1, x0:x1].astype(int)
    m = (np.abs(roi - bg) > 22).astype(np.uint8) * 255
    # bỏ các đường kẻ dài (viền hộp, trục, mũi tên) khỏi mặt nạ — chỉ giữ nét chữ
    w, h = x1 - x0, y1 - y0
    # chỉ coi là "đường kẻ" khi dài hơn hẳn một nét chữ: theo trục ngắn phải xuyên hết box, theo trục dài ≥ 3× trục ngắn
    kx, ky = (max(40, 3 * h), h) if w >= h else (w, max(40, 3 * w))
    for k in ((min(kx, w), 1), (1, min(ky, h))):
        ln = cv2.morphologyEx(m, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, k))
        m = cv2.subtract(m, ln)
    m = cv2.dilate(m, np.ones((3, 3), np.uint8), iterations=2)
    full = np.zeros(g.shape[:2], np.uint8); full[y0:y1, x0:x1] = m
    return full

def ring_bg(g, box):
    x0, y0, x1, y1 = box
    r = np.concatenate([g[y0:y1, x0:x0 + 2].ravel(), g[y0:y1, x1 - 2:x1].ravel(), g[y0:y0 + 2, x0:x1].ravel(), g[y1 - 2:y1, x0:x1].ravel()])
    return int(np.median(r))

def draw_label(canvas, lab, ink, cap_px):
    rot = lab.get("rot", 0)
    x0, y0, x1, y1 = lab["box"]
    if "fit" in lab: fx0, fy0, fx1, fy1 = lab["fit"]
    else:
        gr = lab.get("grow", int(0.6 * (min(x1 - x0, y1 - y0))))
        fx0, fy0, fx1, fy1 = (x0 - gr, y0, x1 + gr, y1) if rot == 0 else (x0, y0 - gr, x1, y1 + gr)
    fx0, fy0 = max(0, fx0), max(0, fy0); fx1, fy1 = min(canvas.width, fx1), min(canvas.height, fy1)
    lines = lab["vi"].split("\n")
    import math
    if rot in (0, 90): fw, fh = (fx1 - fx0, fy1 - fy0) if rot == 0 else (fy1 - fy0, fx1 - fx0)
    else:  # chữ xiên: chiều dài cho phép = đường chéo của vùng fit
        fw, fh = math.hypot(fx1 - fx0, fy1 - fy0), 10 ** 6
    fpath = os.path.join(FD, FONTS[(lab.get("font", "serif"), bool(lab.get("bold")))])
    size = lab.get("size") or cap_px / 0.70  # chiều cao chữ hoa ≈ 0.70 em (Liberation)
    for _ in range(60):
        f = ImageFont.truetype(fpath, max(6, int(round(size))))
        asc, desc = f.getmetrics(); lh = int((asc + desc) * 1.08)
        widths = [f.getlength(t) for t in lines]
        if max(widths) <= fw and lh * len(lines) <= fh + 0.25 * lh: break
        size *= 0.97
    else:
        return False
    tw, th = int(max(widths)) + 4, lh * len(lines) + 4
    tile = Image.new("L", (tw, th), 0); d = ImageDraw.Draw(tile)
    for i, t in enumerate(lines):
        al = lab.get("align", "center")
        x = 2 if al == "left" else (tw - widths[i]) / 2 if al == "center" else tw - widths[i] - 2
        d.text((x, 2 + i * lh), t, font=f, fill=255)
    if rot: tile = tile.rotate(rot, expand=True, resample=Image.BICUBIC)
    bx0, by0, bx1, by1 = x0, y0, x1, y1
    al = lab.get("align", "center")
    if rot == 0:
        px = bx0 if al == "left" else (bx0 + bx1 - tile.width) // 2 if al == "center" else bx1 - tile.width
        px = min(max(px, fx0), fx1 - tile.width)
        py = (by0 + by1 - tile.height) // 2
    elif rot == 90:
        px = (bx0 + bx1 - tile.width) // 2
        py = (by0 + by1 - tile.height) // 2 if al == "center" else by1 - tile.height if al == "left" else by0
        py = min(max(py, fy0), fy1 - tile.height)
    else:  # chữ xiên (vd. nhãn trục 45°): neo theo góc trên-phải nếu align=right, ngược lại theo tâm
        px, py = (bx1 - tile.width, by0) if al == "right" else ((bx0 + bx1 - tile.width) // 2, (by0 + by1 - tile.height) // 2)
    solid = Image.new(canvas.mode, tile.size, ink)
    canvas.paste(solid, (int(px), int(py)), tile)
    return True

def apply(src, out, work):
    spec = json.load(open(os.path.join(work, "raster", "spec.json")))
    doc = pymupdf.open(src); bad = []
    for im in spec["images"]:
        x = im["xref"]
        # xref có thể đổi sau khi lưu lại PDF (garbage) → tìm ảnh cùng kích thước pixel trên cùng trang
        cand = [i["xref"] for i in doc[im["page"] - 1].get_image_info(xrefs=True) if i["xref"] and (i["width"], i["height"]) == tuple(im["size"])]
        if cand: x = cand[0]
        a = load_gray(doc, x)
        color = a.ndim == 3 and a.shape[2] == 3
        g = cv2.cvtColor(a, cv2.COLOR_RGB2GRAY) if color else a.squeeze()
        work_img = a.copy() if color else g.copy()
        labs = [l for l in im["labels"] if l.get("vi")]
        if im.get("mode") == "par":
            clean_img, canvas_mode = work_img.copy(), ("RGB" if color else "L")
            mask_all = np.zeros(g.shape, np.uint8); inks = []
            for l in labs:
                wb_ = l["words"]; ub = [max(0, min(w[0] for w in wb_) - 4), max(0, min(w[1] for w in wb_) - 4), min(g.shape[1] - 1, max(w[2] for w in wb_) + 4), min(g.shape[0] - 1, max(w[3] for w in wb_) + 4)]
                bg = ring_bg(g, ub); m = np.zeros(g.shape, np.uint8)   # nền lấy quanh chính vùng chữ gốc
                for wb in l["words"]:
                    bx0, by0, bx1, by1 = max(0, wb[0] - 3), max(0, wb[1] - 3), wb[2] + 3, wb[3] + 3
                    roi = g[by0:by1, bx0:bx1].astype(int)
                    m[by0:by1, bx0:bx1] |= ((np.abs(roi - bg) > 12).astype(np.uint8) * 255)
                core = m > 0
                px = work_img[core]; gv = g[core]
                lighter = len(gv) and gv.mean() > bg   # chữ sáng trên nền đậm (dải tiêu đề)
                q = 92 if lighter else 8
                if len(px):
                    sel = px[(gv >= np.percentile(gv, 85)) if lighter else (gv <= np.percentile(gv, 15))]
                    if color and not lighter:
                        sp2 = sel.max(1).astype(int) - sel.min(1).astype(int)
                        if (sp2 < 40).sum() > 20: sel = sel[sp2 < 40]   # chữ xám; bỏ nhãn màu (accent)
                    ink = tuple(int(v) for v in np.median(sel.reshape(-1, 3 if color else 1), axis=0))
                else: ink = (60, 60, 60)
                if l.get("ink"): ink = tuple(l["ink"])
                if color and not l.get("accent") and len(px):
                    sp_ = px.max(1).astype(int) - px.min(1).astype(int)
                    if (sp_ > 60).sum() > 30: l["accent"] = [int(v) for v in np.median(px[sp_ > 60], axis=0)]
                m = cv2.dilate(m, np.ones((3, 3), np.uint8), iterations=3)
                inks.append(ink if color else ink[0]); mask_all |= m
            clean = cv2.inpaint(work_img, mask_all, 3, cv2.INPAINT_TELEA)
            canvas = Image.fromarray(clean, canvas_mode)
            sizes = []
            for l in labs:
                if l.get("pitch"): sizes.append(l["pitch"] / 1.18)
            base = statistics.median(sizes) if sizes else 30
            for l, ink in zip(labs, inks):
                caps = re.sub(r"[^A-Za-z]", "", l["en"]).isupper()
                sz = l.get("size") or ((l["h_med"] / 0.74) if caps and not l.get("pitch") else (min(base, l["h_med"] * 1.25) if not l.get("pitch") else min(base * 1.05, l["pitch"] / 1.18)))
                if l.get("text_top") is None: l["text_top"] = l["box"][1] - 0.18 * sz
                if not draw_par(canvas, l, ink, sz): bad.append((x, l["en"][:40]))
            p = os.path.join(work, "raster", f"{x}_vi." + ("jpg" if canvas.mode == "RGB" else "png")); canvas.save(p, quality=92) if canvas.mode == "RGB" else canvas.save(p)
            o = Image.fromarray(a.squeeze()).convert("RGB"); n = canvas.convert("RGB")
            cmp_ = Image.new("RGB", (o.width * 2 + 10, o.height), "white"); cmp_.paste(o, (0, 0)); cmp_.paste(n, (o.width + 10, 0))
            cmp_.save(os.path.join(work, "raster", f"{x}_cmp.png"))
            doc[im["page"] - 1].replace_image(x, filename=p); print("ảnh", x, "trang", im["page"], "đoạn", len(labs)); continue
        inks, caps = [], []
        mask_all = np.zeros(g.shape, np.uint8)
        for l in labs:
            bg = ring_bg(g, l["box"]); m = text_mask(g, l["box"], bg)
            ys, xs = np.where(m > 0)
            px = work_img[m > 0]
            ink = tuple(int(v) for v in np.percentile(px.reshape(-1, 3 if color else 1), 10, axis=0)) if len(px) else ((0, 0, 0) if color else (0,))
            core = (np.abs(g.astype(int) - bg) > 90) & (m > 0)
            cy, cx = np.where(core)
            fpath = os.path.join(FD, FONTS[(l.get("font", "serif"), bool(l.get("bold")))])
            f100 = ImageFont.truetype(fpath, 100)
            r = l.get("rot", 0) or 0
            if len(cy) and l.get("en"):
                if r == 0: ink_len = cx.max() - cx.min()
                elif r == 90: ink_len = cy.max() - cy.min()
                else:
                    import math
                    ink_len = math.hypot(cx.max() - cx.min(), cy.max() - cy.min()) - 1.0 * l.get("cap_hint", 20)
                longest = max(l["en"].split("\n"), key=lambda t: f100.getlength(t))
                cap = 100 * ink_len / f100.getlength(longest) * 0.70  # cỡ chữ (em) khớp bề rộng nét EN gốc
            else:
                cap = (l["box"][3] - l["box"][1]) * 0.5
            nl = 1
            inks.append(ink); caps.append(cap / nl); mask_all |= m
        # đồng nhất cỡ chữ theo nhóm (cùng ảnh, cùng font/đậm, cùng hướng): dùng trung vị

        grp = {}
        for i, l in enumerate(labs): grp.setdefault((l.get("font"), bool(l.get("bold")), l.get("rot", 0) or 0, l.get("group", 0)), []).append(i)
        for ids in grp.values():
            med = statistics.median(caps[i] for i in ids)
            for i in ids: caps[i] = med
        clean = cv2.inpaint(work_img, mask_all, 3, cv2.INPAINT_TELEA)
        canvas = Image.fromarray(clean if color else clean, "RGB" if color else "L")
        for l, ink, cap in zip(labs, inks, caps):
            if not draw_label(canvas, l, ink if color else ink[0], cap): bad.append((x, l["en"]))
        p = os.path.join(work, "raster", f"{x}_vi." + ("jpg" if canvas.mode == "RGB" else "png")); canvas.save(p, quality=92) if canvas.mode == "RGB" else canvas.save(p)
        o = Image.fromarray(a.squeeze()).convert("RGB"); n = canvas.convert("RGB")
        cmp_ = Image.new("RGB", (o.width * 2 + 10, o.height), "white"); cmp_.paste(o, (0, 0)); cmp_.paste(n, (o.width + 10, 0))
        cmp_.save(os.path.join(work, "raster", f"{x}_cmp.png"))
        doc[im["page"] - 1].replace_image(x, filename=p)
        print("ảnh", x, "trang", im["page"], "nhãn", len(labs))
    doc.save(out, garbage=4, deflate=True)
    if bad: print("KHÔNG VỪA:", bad); sys.exit(8)

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("mode", choices=["propose", "propose-par", "apply"]); ap.add_argument("a"); ap.add_argument("b")
    ap.add_argument("--pages", default=""); ap.add_argument("--simple", action="store_true")
    ap.add_argument("c", nargs="?"); ap.add_argument("--min-px", type=int, default=120)
    A = ap.parse_args()
    if A.mode == "propose": propose(A.a, A.b, A.min_px)
    elif A.mode == "propose-par": propose_par(A.a, A.b, [int(v) for v in A.pages.split(",") if v], A.min_px, A.simple)
    else: apply(A.a, A.b, A.c)
