#!/usr/bin/env python3
"""Khôi phục hyperlink sau khi dàn trang: bỏ link trùng, gắn lại URI vào đúng chữ đã dịch, gắn lại link nội bộ
(trích dẫn [n], (Hình n), (Bảng n)) theo đích của PDF nguồn.
Dùng: python relink.py src.pdf in.pdf out.pdf [--fig "Hình" --tab "Bảng"]
- URI: giữ link nằm ngoài vùng chữ đã dịch; với link mất/trùng, tìm chữ hiển thị của URI (bỏ http(s)://, mailto:)
  trên trang đích rồi gắn lại; URL bị ngắt dòng được gắn theo từng mảnh.
- Nội bộ: đọc đích từ nameddest kiểu InDesign/Springer (CRn, FigN, TabN); số trong nhóm [ … ] → CRn.
In số link trước/sau theo trang; thoát 9 nếu số link URI đầu ra < nguồn.
"""
import pymupdf, sys, re, argparse
ap = argparse.ArgumentParser(); ap.add_argument("src"); ap.add_argument("inp"); ap.add_argument("out")
ap.add_argument("--fig", default="Hình"); ap.add_argument("--tab", default="Bảng"); ap.add_argument("--work", default="")
A = ap.parse_args()
import json, os
KEEPB = {}
if A.work and os.path.exists(os.path.join(A.work, "keep.json")):
    _K = set(json.load(open(os.path.join(A.work, "keep.json"))))
    for _u in json.load(open(os.path.join(A.work, "units.json"))):
        if _u["id"] in _K: KEEPB.setdefault(_u["page"] - 1, []).append(pymupdf.Rect(_u["bb"]))
src = pymupdf.open(A.src); d = pymupdf.open(A.inp)
T = {}
for pg in src:
    for l in pg.get_links():
        nd = l.get("nameddest") or l.get("name") or ""
        m = re.search(r"(CR\d+|Fig\d+|Tab\d+)", nd)
        if m and "page" in l and l["page"] >= 0: T[m.group(1)] = (l["page"], l["to"])
        elif "page" in l and l["page"] >= 0 and l["kind"] != pymupdf.LINK_URI:
            # đích kiểu "Anchor N" (InDesign): suy số trích dẫn từ chữ trong vùng link
            for n in re.findall(r"\d+", pg.get_textbox(l["from"]))[:1]:
                T.setdefault("CR" + n, (l["page"], l["to"]))
bad = 0
for pno, (ps, pd) in enumerate(zip(src, d)):
    s_uri = [l for l in ps.get_links() if l["kind"] == pymupdf.LINK_URI]
    for l in pd.get_links(): pd.delete_link(l)
    done = set()
    def add(r, u):
        k = (round(r.x0), round(r.y0), u)
        if k not in done: pd.insert_link({"kind": pymupdf.LINK_URI, "from": r, "uri": u}); done.add(k)
    for l in s_uri:
        u = l["uri"]; from urllib.parse import unquote; vis = re.sub(r"^(mailto:|https?://)", "", unquote(u))
        hits = pd.search_for(vis) or pd.search_for(u)
        if not hits:  # URL bị ngắt dòng: gắn từng mảnh dài ≥ 8 ký tự
            for cut in range(len(vis) - 8, 8, -1):
                h1 = pd.search_for(vis[:cut]); h2 = pd.search_for(vis[cut:]) if len(vis) - cut >= 4 else []
                if h1 and h2: hits = h1[:1] + h2[:1]; break
        if not hits and l["from"].is_valid: hits = [l["from"]]
        for r in hits: add(r, u)
    n_int = 0
    # link nội bộ nằm trong vùng giữ nguyên chữ gốc (keep.json): chèn lại đúng tọa độ cũ
    for l in ps.get_links():
        if l["kind"] != pymupdf.LINK_URI and "page" in l and any(r.contains(l["from"]) or (r & l["from"]).get_area() > 0.6 * l["from"].get_area() for r in KEEPB.get(pno, [])):
            pd.insert_link({"kind": pymupdf.LINK_GOTO, "from": l["from"], "page": l["page"], "to": l["to"]}); n_int += 1
    ws = pd.get_text("words")
    CITE = re.compile(r"[\[(]\d+(?:[–-]\d+)?(?:[,;]\s*\d+(?:[–-]\d+)?)*[\])][.,;:]?")
    j = 0
    while j < len(ws):
        t = ws[j][4]
        if t[:1] in "[(" and re.match(r"[\[(]\d", t):
            grp = [ws[j]]; k = j
            while not re.search(r"[\])]", grp[-1][4]) and k + 1 < len(ws) and len(grp) < 8:
                k += 1; grp.append(ws[k])
            txt = " ".join(g[4] for g in grp)
            if CITE.fullmatch(txt.replace(" ", " ").replace(", ", ",").replace(",", ", ").strip()) or CITE.fullmatch(txt):
                for g in grp:
                    for n in re.findall(r"\d+", g[4])[:1]:
                        if "CR" + n in T:
                            pd.insert_link({"kind": pymupdf.LINK_GOTO, "from": pymupdf.Rect(g[:4]), "page": T["CR" + n][0], "to": T["CR" + n][1]}); n_int += 1
                j = k
        j += 1
    for j, w in enumerate(ws):
        t = w[4]
        if t in ("(" + A.fig, "(" + A.tab) and j + 1 < len(ws):
            m = re.match(r"(\d+)", ws[j + 1][4])
            key = ("Fig" if A.fig in t else "Tab") + (m.group(1) if m else "")
            if key in T:
                pd.insert_link({"kind": pymupdf.LINK_GOTO, "from": pymupdf.Rect(w[:4]) | pymupdf.Rect(ws[j + 1][:4]), "page": T[key][0], "to": T[key][1]}); n_int += 1
    nu = len({k[2] for k in done}) and len(done)
    ni = sum(1 for l in ps.get_links() if l["kind"] != pymupdf.LINK_URI)
    print(f"Trang {pno+1}: URI {len(s_uri)}→{nu}  nội bộ {ni}→{n_int}")
    if len({k[2] for k in done}) < len({l["uri"] for l in s_uri}): bad += 1
d.save(A.out, garbage=4, deflate=True)
sys.exit(9 if bad else 0)
