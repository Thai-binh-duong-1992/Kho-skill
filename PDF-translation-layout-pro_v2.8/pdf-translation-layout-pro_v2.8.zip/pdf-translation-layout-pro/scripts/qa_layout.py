#!/usr/bin/env python3
"""Kiểm định PDF đầu ra: vùng an toàn, chữ chồng lấn, chữ cắt qua đường kẻ/viền khung, font nhúng.
Dùng: python qa_layout.py output.pdf [--margin 36]   → in kết quả từng trang; thoát mã 5 nếu còn lỗi.
"""
import pymupdf, sys, itertools, subprocess, argparse
ap = argparse.ArgumentParser(); ap.add_argument("pdf"); ap.add_argument("--margin", type=float, default=36); ap.add_argument("--bottom", type=float, default=12)
A = ap.parse_args(); d = pymupdf.open(A.pdf); tot = 0
for pno, p in enumerate(d):
    W, H = p.rect.width, p.rect.height
    lines = []
    for b in p.get_text("dict")["blocks"]:
        if b["type"]: continue
        for l in b["lines"]:
            t = "".join(s["text"] for s in l["spans"]).strip()
            if t: lines.append((pymupdf.Rect(l["bbox"]), t))
    viol = [t for r, t in lines if r.x0 < A.margin or r.x1 > W - A.margin or r.y0 < A.margin or r.y1 > H - A.bottom]
    ov = []
    for (r1, t1), (r2, t2) in itertools.combinations(lines, 2):
        i = r1 & r2
        if not i.is_empty and i.width > 1.5 and i.height > 2.5: ov.append((t1[:30], t2[:30]))
    hl = []
    for dr in p.get_drawings():
        for it in dr["items"]:
            if it[0] == "l" and abs(it[1].y - it[2].y) < 0.5: hl.append((min(it[1].x, it[2].x), max(it[1].x, it[2].x), it[1].y))
            if it[0] == "re" and it[1].height < 1.5 and it[1].width > 30: hl.append((it[1].x0, it[1].x1, it[1].y0))
        r = dr["rect"]
        if dr.get("color") is not None and r.width > 20 and r.height > 8: hl += [(r.x0, r.x1, r.y0), (r.x0, r.x1, r.y1)]
    cross = [t[:30] for r, t in lines for x0, x1, y in hl if x0 < r.x1 - 1 and x1 > r.x0 + 1 and r.y0 + 2.5 < y < r.y1 - 2.5]
    n = len(viol) + len(ov) + len(cross); tot += n
    print(f"Trang {pno+1}: dòng={len(lines)} ngoài_vùng_an_toàn={len(viol)} chồng_lấn={len(ov)} cắt_đường_kẻ={len(cross)}", (viol + ov + cross)[:3] if n else "")
fonts = subprocess.run(["pdffonts", A.pdf], capture_output=True, text=True).stdout
notemb = [l for l in fonts.splitlines()[2:] if len(l.split()) > 5 and l.split()[-5] == "no"]
print(fonts); print("FONT_CHƯA_NHÚNG", len(notemb)); print("TOTAL", tot + len(notemb))
sys.exit(5 if tot + len(notemb) else 0)
