> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Nhạc Việt: lịch sử, hệ điệu–hơi, phong cách, bảng 24 thể loại và xung đột nguồn. C4 = Đô giữa; âm vực ghi theo cao độ thực trừ khi nói rõ. Nhãn: [BC] có bằng chứng, [QU] quy ước thực hành/suy luận, [Cần kiểm chứng]; [BC – tập mẫu] = đếm từ 37 bài hợp âm trên hopamchuan.com (một phiên bản do người dùng đóng góp mỗi bài, không phải bản gốc tác giả).

# 11. Nhạc Việt: thể loại, hơi và phong cách

## Cách dùng tệp này

Mở tệp này khi:
- Người dùng muốn viết theo một **thể loại Việt** (dân ca, cổ truyền, bolero, Trịnh, tiền chiến, cách mạng, V-pop, folktronica, rap Việt, indie, thiếu nhi/Tết…) → tra **mục 11.6** (bảng 24 thể loại, 6 cột).
- Cần **chọn hơi/điệu** cho cảm xúc (vui, buồn, trang nghiêm, kỳ ảo, oán) → tra **bảng "Chọn hơi theo cảm xúc"** ngay dưới, rồi mục 11.2.
- Cần **đặt phong cách** (lối hát, nhạc cụ, mô hình ê-kíp, cách đưa chất liệu dân gian vào bài) → mục 11.3.
- Cần **bài mẫu tham khảo** → cột cuối bảng 11.6; bài có dấu (*) chưa được nguồn xác nhận.
- Cần nêu **năm, tác giả, mốc lịch sử** → mục 11.1 và bảng xung đột nguồn 11.4 (ghi cả hai khi nguồn mâu thuẫn).
- Hòa âm chi tiết và tập 37 bài mẫu: `14-hoa-am-viet-bai-mau.md`; thanh–nhạc và đặt chữ vào nhịp: `ngon-ngu/vi.md`; nhịp cổ truyền: `02-nhip-tiet-tau.md` mục 4.5.

## Chọn hơi theo cảm xúc

Tên hơi và tình cảm: [BC] (Trần Văn Khê, UNES08049). Cột "Hiện thực hóa trong bài hiện đại" là [QU] trừ chỗ ghi khác.

| Hệ | Hơi/điệu | Tình cảm | Hiện thực hóa trong bài hiện đại |
|---|---|---|---|
| Bắc | **Bắc** | Vui | [BC] Tiết tấu nhanh; song lang gõ ở mỗi phách mạnh (bài dài: chỉ khuông 3 và 4). [QU] Ngũ cung kiểu sol–la–do–re–mi, ít luyến (mô tả chưa được nguồn xác nhận, chỉ là định hướng nghe); giọng trưởng hoặc vòng I–IV–V ít âm dẫn; bộ gõ sáng, nguyệt/sáo chạy nốt |
| Bắc | **Quảng** | Kỳ ảo | [QU] Nền hòa âm tĩnh (âm trì, sus2/sus4, chồng quãng 4); pad, đàn tranh rải, reverb dài; để nốt trang sức lơ lửng, không giải quyết bằng V7 |
| Bắc | **Nhạc** | Trang nghiêm, nghi lễ | [QU] Tempo vừa–chậm, nhịp đều; kèn bầu, trống, nhị theo lối nhã nhạc; hòa âm trưởng tối giản hoặc bourdon; tránh luyến nhiều; hợp lễ hội, nghi thức, nhạc hiệu trang trọng |
| Nam | **Xuân** | Thanh thản | [QU] Tempo vừa, giai điệu ngũ cung mềm, luyến nhẹ; nền acoustic (tranh, guitar nylon, sáo), hòa âm tĩnh add9/maj, ít cao trào |
| Nam | **Ai** | Buồn | [BC] Chậm; câu nhạc 8 khuông, song lang ở phách mạnh khuông 6 và 8; Nam Ai có cao độ "già/non" biến đổi so với ký âm. [QU] Giọng thứ, nhấn trống/bass ở **cuối câu**; để nốt nhấn lơ lửng trên hòa âm tĩnh; chấp nhận độ lệch ~166 cent so với piano; không bám lưới auto-tune |
| Nam | **Đảo** | [Cần kiểm chứng] Nguồn chỉ nêu tên, chưa mô tả tình cảm | [QU] Chỉ dùng khi có bản ký âm/bài mẫu của điệu Đảo; không tự gán cảm xúc |
| Nam | **Oán** | Rất gần Ai (bi thương, ai oán) | [BC] Chậm, câu 8 khuông, song lang khuông 6 và 8; vọng cổ thuộc hơi Oán. [QU] Mô tả "xự non, phạn già" chưa được nguồn xác nhận. Giọng thứ có bII (màu "oán"/Phrygian, [BC – tập mẫu] 3 bài) hoặc IV trưởng màu Dorian; guitar phím lõm/đàn kìm đối đáp; kết câu về "hò" (chủ âm) |

Quy tắc chung [BC]: đàn tỳ bà lên dây giống nhau cho mọi điệu, chỉ đổi cách luyến láy → **khác biệt hơi nằm ở luyến láy và trang sức**, không chỉ ở thang âm. Vì vậy muốn "có hơi" phải viết/giữ luyến láy; công cụ chỉnh cao độ bám lưới 12 bình quân sẽ xóa đúng phần làm nên hơi.

## 11.1. Lịch sử: bốn tầng cổ truyền và năm chặng hiện đại

### Tầng cổ truyền: từ trống đồng đến nhã nhạc
- **Trống đồng Đông Sơn**: khoảng 600 TCN – TK3 SCN; vừa nhạc cụ vừa vật thờ (cầu mưa, cầu mùa, cưới, tang, hiệu lệnh quân sự, biểu tượng quyền lực). **Đàn đá** M'nông, Mạ: khoảng 1000 TCN.
- Phân kỳ giáo trình ĐH Văn Hiến: Hùng Vương → Lý–Trần (nhạc cung đình tách khỏi dân gian) → Lê (điển chế hóa nhạc cung đình) → Nguyễn → giữa TK19–1945 (cải lương, nhạc cải cách).
- Nhạc cung đình giao thoa Trung Hoa, Chăm và Việt hóa: nguyệt, tam, tranh, tỳ bà, nhị, tam thập lục có gốc Trung Hoa; tiếp nhận ca nữ Chăm sau 1044, dùng trống cơm, dịch bài Chăm năm 1060.
- **Mốc khởi đầu nhã nhạc chưa thống nhất** (xem 11.4): Trần (Wikipedia, tự ghi tranh cãi); Hồ 1402–1407 (Phan Thuận Thảo); TK15 (UNESCO). Lê sơ: Nguyễn Trãi chủ trương "hòa bình là gốc của nhạc" nhưng thua Lương Đăng (phỏng theo nhạc Trung Hoa).
- Triều Nguyễn có ba dàn (Phan Thuận Thảo): **Nhã nhạc** (ti trúc 8 nhạc cụ); **Nhạc huyền** (lối "bát âm", về sau thất truyền); **Đại nhạc** (trống và kèn, cuối triều giảm từ ~42 xuống ~10 nhạc công).

### Tân nhạc: hai mốc khởi đầu song song
- "Nhạc cải cách" ra đời từ ba lực đẩy: khiêu vũ và phim nói phổ biến ca khúc Pháp; phong trào "bài Tây theo điệu Tây"; tinh thần dân tộc. Conservatoire d'Extrême-Orient mở 1927, đóng 1930 → phần lớn nhạc sĩ đầu tiên tự học nhạc lý Pháp (Gibbs).
- **Mốc được thừa nhận rộng rãi: 09/6/1938**, Nguyễn Văn Tuyên biểu diễn ca khúc tự sáng tác tại Hà Nội, có báo chí bình luận. Theo Phạm Duy, chữ "nhạc cải cách" do **Nguyễn Văn Cổn** đặt.
- Dòng ca khúc cách mạng: *Cùng nhau đi hồng binh* (Đinh Nhu, 1930) là bài đầu tiên của âm nhạc Việt hiện đại (Đại biểu Nhân dân). **1930 và 1938 là hai hệ quy chiếu → ghi cả hai.**
- Quanh 1938: nhóm Myosotis, Tricea; Lê Thương, Văn Cao, Đặng Thế Phong được ưa chuộng. *Giọt mưa thu*: 1942 (RFA, cùng *Đêm thu* 1940, *Con thuyền không bến* 1941) **hoặc** 1939, đồng tác giả Bùi Công Kỳ (Gibbs). *Tiến quân ca*: sáng tác 1944, đăng 11/1944, thành quốc ca 1946.

### 1945–1975: hai hệ thống song song
- Miền Bắc: Trường Âm nhạc Việt Nam 1956 (nay Học viện Âm nhạc Quốc gia); Hội Nhạc sĩ Việt Nam 30/12/1957; đến 1954 Đài TNVN đã phát >2.000 tác phẩm của >300 nhạc sĩ.
- Miền Nam: mô hình thị trường; Trường Quốc gia Âm nhạc Sài Gòn 1956. "Nhạc vàng" (phần lớn điệu bolero) đối lập "nhạc đỏ". Trịnh Công Sơn ra mắt 1957 với *Ướt mi*; *Ca khúc da vàng* gồm 8 bài (1967–1968).
- 1968: chữ "BOLÉRO" trên bản nhạc *Phố đêm* mới là ký hiệu tiết tấu, chưa phải tên thể loại.

### Sau 1975: từ lệnh cấm đến folktronica và ê-kíp
- Nhạc vàng bị cấm từ 7/1976, tồn tại ở hải ngoại; nới dần từ 1986. Làn Sóng Xanh ra đời 1997; 1998 *Tình thôi xót xa* (Lam Trường) đánh dấu thị trường nội địa khởi sắc.
- Bolero hồi sinh như "hợp tác" nghệ sĩ–kiểm duyệt để phi chính trị hóa nhạc trước 1975: *Chanh Bolero* (2007), *Solo cùng Bolero* (2014), *Thần tượng Bolero* (2017).
- Từ 01/02/2021, Nghị định 144/2020 bỏ cơ chế cấp phép phổ biến tác phẩm, kể cả ca khúc trước 1975.
- Rap thành dòng chính với *Rap Việt* từ 5/2020 (15–25 triệu lượt xem YouTube mỗi tập).
- Fusion dân gian: *Để Mị nói cho mà nghe* (Hoàng Thùy Linh) là Bài hát của năm ở cả Mai Vàng và Làn Sóng Xanh 2019; *Bắc Bling* (Hòa Minzy, 3/2025) đạt 200 triệu lượt xem sau 81 ngày, nhanh nhất V-pop, nhưng **không lọt top 10 Spotify Việt 2025** → lượt xem MV ≠ lượt nghe streaming.
- 2025–2026: (1) sản xuất theo **ê-kíp**: album *Made in Vietnam* (DTAP) 16 bài, 3 chương, 25 nghệ sĩ nhiều thế hệ (có NSND Bạch Tuyết, Đen Vâu); dự án *Giai Nhân* (Hứa Kim Tuyền) 3 tháng với "trại sáng tác" và nhiều vòng góp ý. (2) Chất liệu dân gian đi vào **cấu trúc**, không chỉ lời: *Thầy Dùi* (Hoàng Thùy Linh, 2026) lấy nhịp trống chầu văn và vè làm khung; báo chí cùng lúc cảnh báo nguy cơ "làm mới" mà mất đặc trưng làn điệu (Báo Văn Hóa, 28/10/2026).

### Di sản UNESCO (trục thể loại cổ truyền chính thức)
Nhã nhạc (2003; vào Danh sách đại diện 2008) · Cồng chiêng Tây Nguyên (2005; 2008) · Quan họ (2009) · Ca trù (2009, khẩn cấp) · Xoan (2011 khẩn cấp → 2017 đại diện) · Đờn ca tài tử (2013) · Ví Giặm (2014) · Thờ Mẫu Tam phủ, gồm hát văn (2016) · Bài chòi (2017) · Then (2019) · Xòe Thái (2021). Hai mốc năm của Nhã nhạc và Cồng chiêng là năm tuyên bố Kiệt tác và năm chuyển vào Danh sách đại diện, **không phải mâu thuẫn nguồn**.

## 11.2. Giai điệu: điệu thức ngũ cung, hệ điệu–hơi, tên nốt

### Ngũ cung không bình quân [BC]
- Thang 5 âm nhưng **không chia đều**: đàn tranh có nhiều bậc khoảng **166 cent** (không trùng nửa cung hay nguyên cung); nghệ nhân lên dây bằng tai; điệu Bắc và Nam có thứ bậc cao độ nội tại khác nhau (Keefe, Burns & Phong Nguyễn 1991).
- **Hai hệ** (Trần Văn Khê): Hệ Bắc = Bắc (vui), Quảng (kỳ ảo), Nhạc (trang nghiêm, nghi lễ). Hệ Nam = Xuân (thanh thản), Ai (buồn), Đảo; Oán rất gần Ai. Mỗi điệu có bậc dùng nhiều hơn, luyến láy, nét nhạc và tình cảm riêng.
- **Tỳ bà lên dây giống nhau cho mọi điệu, chỉ đổi luyến láy** → khác biệt điệu thức nằm ở trang sức âm. Hệ quả sản xuất: auto-tune bám 12 bình quân xóa "hơi" (xem `16-san-xuat.md`).

### Hệ điệu riêng theo loại hình [BC]
| Loại hình / vùng | Đặc điểm điệu thức |
|---|---|
| Ca trù | Cũng gọi "Nam", "Bắc" nhưng **không đồng nhất** với điệu ca Huế hay đờn tài tử |
| Chèo (Hoàng Kiều) | 5 cung: Nam, Pha, Huỳnh, Bắc, Nao. Trong 127 làn điệu: Nam ở 77 làn, Nao ở 65; kết hợp phổ biến nhất Nam–Nao (32 làn) |
| Ca Huế | Nam Ai ghi trên khuông giống điệu Bắc; khi diễn, cao độ "già"/"non" biến đổi tạo nỗi buồn xa xăm |
| Miền Trung | Xự thấp hơn, xang cao hơn thang chuẩn (pha trộn nhạc Chăm); hát ru miền Trung dùng **thang 4 âm** |
| Tây Nguyên | Bán âm (ví dụ Fa#) biến thang 5 âm thành 6 âm |
| Tày–Thái | "Đường nét hoa mỹ" uốn quanh bậc I, IV, V |
| Chăm | Nốt hoa mỹ quanh bậc 3, 4, 5 tạo nửa cung đặc trưng |

### Tên nốt hò–xự–xang–xê–cống [BC]
- Đọc Hán-Việt của ký âm công xích. Quy ước tương đối: **hò = sol thấp, xự = la, xang = do, xê = re, cống = mi, líu = sol cao**.
- **Xung đột quy ước:** một số ký âm ca Huế lấy **hò = do**. Khi viết bản phổ, **ghi rõ quy ước đang dùng**.
- [QU] Hai mô tả hay gặp chưa có nguồn: "hơi Bắc ≈ ngũ cung sol–la–do–re–mi ít luyến"; "hơi Oán dùng xự non và phạn già". Chỉ là định hướng nghe, không phải định nghĩa nhạc lý.

### Rao, lòng bản, giai điệu khung
- [BC] Đờn ca tài tử: nhạc công biến tấu **giai điệu khung** bằng ngẫu hứng và trang sức; cần ≥3 năm để nắm kỹ thuật cơ bản (UNESCO). Trước mỗi bài có **"rao"**: dạo ngẫu hứng, nhịp tự do, trong điệu của bài.
- "Lòng bản" ứng với giai điệu khung; [Cần kiểm chứng] chưa có định nghĩa chuẩn có nguồn cho thuật ngữ.
- [QU] Ứng dụng: intro tự do kiểu "rao" bằng nhạc cụ dân tộc, trong đúng hơi của bài, trước khi vào nhịp.

## 11.3. Phong cách: từ hơi dân gian đến ê-kíp sản xuất

Thể loại hiện đại Việt được định danh bởi **tổ hợp tiết tấu, điệu thức và lối hát** nhiều hơn bởi hòa âm.

**Bolero Việt** [BC]
- 4/4, **khoảng 60–80 BPM**, gốc bolero Cuba và rumba; giai điệu dựa vào ngũ cung; luyến láy theo sáu thanh; **guitar Hawaii vuốt nốt như tiếng nấc** (Vietcetera). Lưu ý: 60–80 BPM từ báo phổ thông, không phải phép đo; không trang hợp âm nào ghi BPM.
- Theo dạng **Mexico/Mỹ Latin, không phải Tây Ban Nha 3/4**; bản thu *Đôi ngả chia ly* (1961) có tiết tấu **clave Cuba** (Gibbs).
- Ba lối giọng: giọng mũi kiểu Nam, giọng óc thiên cổ điển, giọng ngực mạnh; thường xen ngâm thơ hoặc vọng cổ.
- Nguyễn Thị Mỹ Liêm ("Vietnamese Boléro?", Viện Âm nhạc) xếp ca khúc tiết tấu boléro thành thể loại riêng (chỉ có tóm tắt công khai). Tác giả *Lòng mẹ*: Y Vân (RFA) hay Trúc Phương (Rising Asia) → "tác giả có tranh cãi".

**Folktronica / folk fusion** [BC]
- *Để Mị nói cho mà nghe*: future bass/folktronica, **sáo mèo làm hook**, lời lấy cảm hứng *Vợ chồng A Phủ*.
- *See tình*: disco-pop retro, điệp khúc ngũ cung pha cải lương.
- *Bắc Bling*: hip-hop điện tử, đàn nguyệt, nhị, sáo trúc, tempo nhanh; intro kèn bầu và trống; chất liệu quan họ, hát văn, xẩm, chèo.
- Tiền thân: album *Đường xa vạn dặm* (Quốc Trung) ghép điện tử với chèo, xẩm, quan họ, ca trù. Quốc Trung coi làn điệu là chất liệu để **phân mảnh, kéo giãn, tái tạo**.
- DTAP chọn chất liệu dân gian theo ba trục **tinh thần – âm sắc – câu chuyện**; mỗi chi tiết dân gian phải có **"lý do tồn tại"** rõ ràng.

**Rap, indie, ê-kíp** [BC]
- Công thức Đen Vâu: rap đời thường + **điệp khúc âm vực hẹp do ca sĩ khác hát** làm điểm tựa.
- Ngọt: giai điệu âm hưởng The Beatles, lời thẳng về tuổi trẻ đô thị.
- Thập niên 2020: nhà sản xuất là trung tâm; DTAP, Hứa Kim Tuyền, Slim V, JustaTee, Dương K làm giám đốc âm nhạc các show lớn.

**Ca khúc trữ tình mang màu dân tộc** [BC] (Trần Hoàng Tiến): khai thác quãng đặc trưng vùng — ca trù trong *Một thoáng Tây Hồ* (Phó Đức Phương), Ví Giặm trong *Giận mà thương* (Nguyễn Trung Phong), quan họ trong *Người ở đừng về* (Nguyễn Xuân Tứ), lượn cọi Tày trong *Tiếng hát giữa rừng Pác Bó* (Nguyễn Tài Tuệ), thang Tây Nguyên có bán âm trong *Em là hoa Pơ Lang* (Đức Minh).

**Công thức hợp âm theo thể loại – đã đối chiếu tập mẫu** [BC – tập mẫu]
- Bolero: 5/5 giọng thứ, 4/5 có V/V7 trưởng; ĐK **ngả sang giọng trưởng song song tên** (relative major: Dm→F, Am→C), **không phải trưởng cùng tên** (thay quy tắc cũ: "chuyển sang trưởng cùng tên Am→A").
- Nhạc Trịnh: 3/3 giọng thứ, **I7→iv** ở cả 3 bài.
- V-pop ballad: **I–V–vi–IV không được xác nhận (0/37)**; họ IV–V–iii–vi có ở 4 bài (thay quy tắc cũ: "V-pop ballad dùng I–V–vi–IV").
- [QU] Hành khúc 2/4, giọng trưởng, nhịp chấm dôi vẫn là quy ước; 3/4 bài cách mạng trong mẫu ở giọng trưởng nhưng gắn nhãn Disco/Boston/Slow → **nhãn trên trang hợp âm là điệu đệm guitar của người đóng góp, không phải nhịp gốc**.

## 11.4. Bảng xung đột nguồn và giới hạn bằng chứng

| Vấn đề | Quan điểm A | Quan điểm B | Cách xử lý |
|---|---|---|---|
| Năm *Giọt mưa thu* | 1942 (RFA) | 1939, có Bùi Công Kỳ (Gibbs) | Ghi cả hai |
| Vọng cổ nhịp 32 | 1954 (Trần Thị Hoàng Mỹ) | 1940–1941, Năm Nhỏ – Trần Tấn Hưng (Đỗ Quốc Dũng) | Ghi cả hai |
| Tác giả *Lòng mẹ* | Y Vân (RFA) | Trúc Phương (Rising Asia) | Ghi "tác giả có tranh cãi" |
| Mốc nhã nhạc | Trần, TK13 (Wikipedia, tự ghi tranh cãi) | Hồ 1402–1407 (Phan Thuận Thảo); TK15 (UNESCO) | Trình bày cả ba |
| Bài tân nhạc đầu tiên | *Cùng nhau đi hồng binh*, 1930 | Buổi diễn Nguyễn Văn Tuyên, 1938 | Hai hệ quy chiếu |
| Quy ước tên nốt | hò = sol (công xích) | hò = do (một số ký âm ca Huế) | Ghi rõ quy ước khi ký âm |
| Tác giả *Đất nước lời ru* | Văn Thành Nho (nguồn có trích dẫn) | Phan Huỳnh Điểu (danh sách suy luận) | Theo nguồn có trích dẫn |
| Vòng V-pop ballad | I–V–vi–IV (quy ước bản trước) | 0/37 trong tập mẫu; IV–V–iii–vi ở 4 bài | Theo tập mẫu; coi là giả thuyết vì mẫu nhỏ |
| Nâng tông ở ĐK cuối | Quy ước bản trước cho pop ballad | 0/37 bản hợp âm | Không coi là đặc trưng; cần nghe bản thu |
| Phiên bản hợp âm cùng bài | *Như có Bác trong ngày vui đại thắng* có 3 bản bất đồng; *Mưa chiều miền Trung* có bản khác | *Biển nhớ* ghi tông Gm nhưng hiển thị theo Am, không ghi capo | Chỉ dùng 1 phiên bản mỗi bài, ghi chú bất đồng |
| Nhãn điệu trên trang hợp âm | *Tiến quân ca* gắn nhãn "Slow" | Hành khúc theo lịch sử là 2/4 | Nhãn là điệu đệm guitar, không phải thể loại gốc |
| Chữ 6 và chữ 8 câu bát khác thanh | Giả thuyết chưa có nguồn (bản đầu) | SGK Ngữ văn 7; Bùi Văn Nguyên & Hà Minh Đức | Nay là [BC] (xem `12-thi-luat.md`) |
| Sơ đồ vần song thất lục bát | Chữ 7 câu thất trên vần chữ 5 câu thất dưới (mô tả truyền thống, khớp *Chinh phụ ngâm*) | Bài ĐH Phú Yên: "tiếng cuối câu một vần với tiếng thứ 6 câu hai" | Theo mô tả truyền thống, ghi [Cần kiểm chứng] |
| Chia khổ hát nói | "11 câu, chia 6 khổ" (bản trước) | Khổ đủ 11 câu chia 4–4–3 (KoreaScience) | Theo nguồn mới: 4–4–3 |
| Tác giả thơ *Ở hai đầu nỗi nhớ* | Trần Hoài Thu (Báo Văn hóa) | Trần Đình Chính (SGGP) | Ghi cả hai |

**Giới hạn bằng chứng:** không truy cập được Grove/Oxford, vi.wikipedia, giáo trình Nhạc viện và giáo trình thanh nhạc Học viện Âm nhạc Quốc gia; tập mẫu hợp âm chỉ từ một trang người dùng đóng góp. Do đó quy tắc bù quãng nhảy, loại kết theo thuật ngữ Việt và ký hiệu luyến láy chuẩn Việt vẫn là [QU].

## 11.5. Nguyên lý cốt lõi

1. **Ràng buộc gốc của ca khúc Việt nằm ở ngôn ngữ, không ở hòa âm.**
2. Thanh điệu quyết định hướng giai điệu theo **điểm kết thúc của thanh** (sắc/ngã cao; ngang trung; huyền thấp; hỏi/nặng rất thấp), **không theo bằng/trắc**.
3. **Kéo dài cuối ngữ đoạn** quyết định chữ nào nằm trên phách mạnh.
4. **Hơi và luyến láy** quyết định "chất Việt" nhiều hơn thang âm.
5. Hòa âm là **lớp vỏ thay theo thế hệ**: thế hệ trước dùng giọng thứ chức năng có V7 và ngả sang giọng trưởng song song tên; thế hệ sau dùng vòng lặp aeolian hoặc IV–V–iii–vi và tạo tương phản bằng sản xuất.
6. Folktronica thành công vì thay toàn bộ lớp vỏ nhưng giữ hai tầng không thể thay: **làn điệu ngũ cung** và **âm sắc nhạc cụ dân tộc**.
7. Quy trình: kiểm tra thanh–nhạc ngay khi phác giai điệu; chọn "hệ" hòa âm theo **thế hệ thể loại**, không theo một công thức pop chung; **bảo vệ luyến láy** suốt khâu sản xuất.

## 11.6. Bảng hướng dẫn sáng tác 24 thể loại Việt

13 thể loại cổ truyền + 11 thể loại hiện đại. Cột **Hòa âm & Phối khí** của thể loại hiện đại đã cập nhật theo tập mẫu 37 bài (**[BC – tập mẫu]**). Số La Mã tính theo chủ âm: chữ thường = hợp âm thứ, chữ hoa = hợp âm trưởng. **[QU]** = kiến thức thực hành chưa có nguồn Việt Nam xác nhận.

| Thể loại | Giai điệu | Phong cách | Nhạc lý | Hòa âm & Phối khí | Ví dụ tên bài hát đặc trưng |
|---|---|---|---|---|---|
| **Quan họ** (Bắc Ninh, UNESCO 2009) | Ngũ cung. Cao độ dựa trên tầm thanh của lời lục bát, chia ba tầng cao, trung, thấp; có "biến thanh" đi ngược thanh. Âm cuối câu ngân dài | Hát đối đáp nam–nữ giữa hai làng, hát đôi (giọng dẫn và giọng luồn). Canh hát đi từ giọng lề lối, giọng vặt, ứng tác đến giã bạn | Quan họ cổ dùng nhịp hỗn hợp 2/4–3/4; quan họ mới dùng 2/4 hoặc 4/4. Lời: từ đệm lót, đưa hơi dùng "đậm đặc vào bậc nhất", thành ngữ tách 2/2 chêm hư từ [BC] (Ngô Thị Thanh Hằng 2012); thể thơ lời cổ là lục bát [Cần kiểm chứng]; xem `12-thi-luat.md` §12.10 | Truyền thống hát không đệm. Gần đây đệm nhị, nguyệt, sáo, bầu. *Nam Nhi* phối quan họ với ngũ tấu dây | Gọi đò; Con nhện giăng mùng; Mời trầu; Đêm qua nhớ bạn; Giã bạn; Người ơi người ở đừng về (*) |
| **Chèo** (đồng bằng Bắc Bộ) | Khoảng 200 làn điệu, chia 5 cung Nam, Pha, Huỳnh, Bắc, Nao; phổ biến nhất là Nam và Nao. Chuyển cung theo tâm lý nhân vật | Sân khấu dân gian. Kỹ thuật hát liền hơi, liền giọng, nhấn, ngắt, rung giọng, nảy hạt | Có điệu thức thiếu âm và thừa âm. Phân biệt bài nhịp chặt với lối nói, hát tự do | Nguyệt, nhị, bầu, sáo, trống, chũm chọe. Đặng Hữu Phúc đưa làn chèo vào giao hưởng | Lới lơ; Vãn cầm; Hề mồi cơm canh; Con gà rừng; Lưu không; vở Quan Âm Thị Kính; Đường trường (*) |
| **Ca trù** (UNESCO 2009, khẩn cấp) | Giai điệu không cố định, đi theo đường nét thanh điệu của thơ. Có điệu Nam (buồn) và Bắc (vui) riêng | Một ca nương trình diễn, kép đàn đáy và quan viên đánh trống chầu khen chê | Hát nói khổ đủ gồm 11 câu, chia 3 khổ 4–4–3 (bản trước ghi "6 khổ"; xem 11.4); mưỡu dùng lục bát; 56 thể cách | Đàn đáy 3 dây lên quãng 4, phách, trống chầu. *Đại Lâm Linh* ghép đàn đáy với guitar điện. Thư viện MNTRA "Ha Noi" có mẫu giọng ca trù | Tỳ bà hành; các bài hát nói; Một thoáng Tây Hồ (ca khúc khai thác quãng ca trù) |
| **Hát văn / Chầu văn** (trong Thờ Mẫu, UNESCO 2016) | Lời, nhịp và nhạc khớp với từng giá hầu | Nghi lễ hầu đồng. Cung văn phối hợp với thanh đồng, nhịp mạnh hướng tới xuất thần | Chuỗi làn điệu theo giá; chưa có nguồn cho từng làn điệu | Đàn nguyệt là chính; chầu văn hiện đại thêm guitar phím lõm. Fusion: *Tứ phủ*; *Thầy Dùi* (2026) lấy nhịp trống chầu văn làm khung | Tứ phủ; Thầy Dùi (Hoàng Thùy Linh); Dọc (*); Phú (*); Cờn (*) |
| **Ví Giặm** (Nghệ Tĩnh, UNESCO 2014) | Ví chậm, tự do; Giặm có nhịp hơn. Hơi trữ tình, kể, khuyên răn, than | Hát khi lao động và sinh hoạt cộng đồng, thường không đệm | Tiết tấu đổi theo loại. Phương ngữ Nghệ Tĩnh không phân biệt ngã/nặng. Lời: ví dùng lục bát, lục bát biến thể, song thất lục bát; giặm dùng câu 5 chữ, nhịp 3/4 và 6/8 [BC] (Báo Nghệ An; Nguyễn Duy Cường 2025); xem `12-thi-luat.md` §12.10 | Truyền thống không đệm. **[QU]** Khi phối hiện đại nên giữ intro tự do không nhịp | Ví đò đưa sông La; Ví phường cấy; Ví trèo non; Giặm cửa quyền; Giặm ru; Giận mà thương (ca khúc) |
| **Ca Huế** | Hai điệu Bắc (Khách) và Nam. Nam Ai có cao độ "già/non" biến đổi. Nhảy quãng 4, 5, 6 phổ biến do thanh điệu Huế hẹp | "Chất Huế" ở rung và nhấn. Hơi Dựng chuyển qua lại giữa Nam và Bắc | Phương ngữ Huế gộp hỏi và ngã. Một số ký âm lấy hò = do | Kỹ thuật đàn: mổ, bấm, day, chớp, vả, nhấn nửa bực, một bực, hai bực. Nguyệt, tranh, tỳ bà, nhị | Nam Ai; Nam Bình; Nam Xuân; Tứ đại cảnh; Lý Hoài Nam; Lý con sáo; Lý mười thương |
| **Nhã nhạc** (Huế, UNESCO 2003/2008) | Nhạc lễ trang nghiêm; cung đình tiếp nhận giai điệu Chăm | Nghi lễ cung đình; đầu TK19 có ba dàn Nhã nhạc, Nhạc huyền, Đại nhạc | Bộ 10 bài ngự; Đại nhạc kèm múa văn vũ, võ vũ | Cấu trúc ti trúc 8 nhạc cụ: kèn bầu, tỳ bà, nguyệt, tam, nhị, sáo, trống | Thập thủ liên hoàn; Bình bán; Tây mai; Kim tiền; Xuân phong; Long hổ; Tẩu mã |
| **Bài chòi** (Trung Bộ, UNESCO 2017) | Dàn nhạc chơi Xuân nữ, Xàng xê, Cổ bản; anh hiệu hô theo các điệu hò | Trò chơi bài dịp Tết; 2–4 anh hiệu luân phiên, ứng tác | Lời thơ ứng tác; hô bài theo hò khoan, hò mái nhì, hò giã gạo. Thể lời (câu thai): chưa có khuôn lời đã kiểm chứng; xem `12-thi-luat.md` §12.10 | Trống, nhị, đàn bầu, kèn, sanh | Xuân nữ; Xàng xê; Cổ bản; Hò khoan; Hò mái nhì |
| **Đờn ca tài tử** (Nam Bộ, UNESCO 2013) | Ngẫu hứng trên giai điệu khung. Bốn điệu Bắc, Nam, Lễ, Oán; rao trước mỗi bài | Nhạc thính phòng dân gian–bác học, trình diễn ở đám giỗ, lễ hội | 20 bài tổ, 72 bài cổ điển. Bài Nam và Oán câu 8 khuông, song lang ở khuông 6 và 8 | "Ngũ tuyệt": tranh, tỳ bà, kìm, cò, tam; thêm sáo, song lang, guitar phím lõm | Lưu thủy; Phú lục; Bình bán; Cổ bản; Xuân tình; Tây thi; Nam xuân; Nam ai; Phụng hoàng; Tứ đại oán |
| **Cải lương / Vọng cổ** | Vọng cổ thuộc hơi Oán điệu Nam. Nhịp 32 có âm kết cố định: cống, xang, hò, hò, xê, hò | Sân khấu xen thoại và ca; giọng kết "hò" là chỗ đánh giá người ca | Từ nhịp 2 (20 câu) đến nhịp 32 (6 câu); niên đại nhịp 32 có tranh cãi. Lời co giãn theo khung câu nhạc: câu 1 nguyên thủy 5 chữ, ở *Khúc oan vô lượng* hai câu đầu lên 10 và 12 chữ [BC] (RFA, Nguyễn Phương 2006); xem `12-thi-luat.md` §12.10 | Kìm, guitar phím lõm điện, cò, tranh, song lang. **[BC – tập mẫu]** Không thu được bản hợp âm tân cổ nào; hai bài mang tên "vọng cổ/giao duyên" trong mẫu là tân nhạc | Dạ cổ hoài lang (Cao Văn Lầu); Hoa rơi cửa Phật; Gánh nước đêm trăng; vở Kim Vân Kiều (1918) |
| **Then** (Tày–Nùng–Thái, UNESCO 2019) | **[QU]** Thang 5 âm; đường nét hoa mỹ uốn quanh bậc I, IV, V | Nghi lễ cầu an, cầu mùa, gọi hồn | Quan hệ I–IV và I–V là nhân tố chính trong nhạc Tày–Thái | Đàn tính, gốc từ tianqin của người Choang | Then cầu an, Then cầu mùa (loại nghi lễ); Tiếng hát giữa rừng Pác Bó (ca khúc dùng lượn cọi Tày) |
| **Cồng chiêng Tây Nguyên** (UNESCO 2005/2008) | Thang 5 âm có bán âm, thành 6 âm; Gia Rai chồng hai dạng thang âm | Không gian nghi lễ nhà dài, nhà rông | **[QU]** Tiết tấu chu kỳ, đa tầng | Chiêng, k'ni, t'rưng, klông pút, đàn đá. Có thư viện mẫu T'rưng và đàn đá (Bunker Samples, 2026) | Lễ mừng lúa mới; Cúng bến nước (dịp diễn tấu); Em là hoa Pơ Lang (ca khúc thang Tây Nguyên) |
| **Hát ru** | Bắc Bộ ngũ cung; miền Trung tứ cung; Nam Bộ có ầu ơ, ví dầu. Huyền hát đi xuống ở 81/90 trường hợp; sắc đi lên ở 28/42, dạng cong lõm | Bài đầu tiên trẻ được nghe; ở Nam Bộ thường là tâm sự của người phụ nữ | Chậm, nhịp tự do; 110 lần rung gom thành 5 nhóm cao độ khớp điệu Ai–Oán. Lời lấy chủ yếu từ ca dao, đồng dao, hò [BC] (Nguyễn Quốc Khánh 2021); xem `12-thi-luat.md` §12.10 | Truyền thống hát không đệm; bản phân tích có đàn bầu đệm | Ru con miền Nam; Ầu ơ ví dầu; Đất nước lời ru (Văn Thành Nho; một ghi chú suy luận ghi Phan Huỳnh Điểu) |
| **Tiền chiến** (khoảng 1938–1954) | Ngôn ngữ âm nhạc Tây phương hóa, giai điệu luyến theo thanh | Lãng mạn, gắn với Thơ Mới và báo *Ngày Nay* | **[BC – tập mẫu]** Cả 4 bài là giọng thứ; nhãn "Slow" ở 2 bài. Strophic hoặc AABA | **[BC – tập mẫu]** i–VI–i–III–V7–i (Con thuyền không bến); cadence v–i (Giọt mưa thu); bII và bridge (Buồn tàn thu); bài duy nhất chuyển sang trưởng cùng tên (Thiên thai, Dm→D). **[QU]** Phối phòng trà: piano, guitar Hawaii, violin, accordion | Bông cúc vàng; Kiếp hoa; Đêm thu; Con thuyền không bến; Giọt mưa thu (1939 hay 1942); Thiên thai; Buồn tàn thu; Ai về sông Tương (*) |
| **Nhạc cách mạng / hành khúc** | Giai điệu kêu gọi, mang tính tập thể. *Tiến quân ca* là hành khúc 2 lời, mỗi lời có điệp khúc | Hùng tráng, lời dùng "ta", "chúng ta" | **[BC – tập mẫu]** 3 trong 4 bài là giọng trưởng; nhãn đệm Disco, Boston, Slow (nhãn đệm guitar, không phải nhịp gốc). **[QU]** Gốc là 2/4 hoặc 4/4, nhịp chấm dôi | **[BC – tập mẫu]** I–vi–IV–I (Tiến quân ca); I–iii–vi–IV (Giải phóng miền Nam); bài giọng thứ dùng i–III–iv–V. Một bài có 3 phiên bản hợp âm bất đồng. **[QU]** Kèn đồng, snare, hợp xướng | Tiến quân ca; Cùng nhau đi hồng binh; Giải phóng miền Nam; Như có Bác trong ngày vui đại thắng; Bác đang cùng chúng cháu hành quân; Lên đàng (*) |
| **Trữ tình quê hương / dân ca mới** | Thang 5 âm pha thất cung; dùng quãng đặc trưng vùng miền | Ca khúc mang hồn dân ca, có câu đệm "ơi", "à ơi" (**[QU]**) | Chuyển làn, ví dụ *Lý hoài xuân* mở ở Xự rồi sang Xê. **[BC – tập mẫu]** 2 thứ / 1 trưởng | **[BC – tập mẫu]** Giọng thứ không V trưởng (i–v–i) kèm bII (Ngẫu hứng lý qua cầu); IV trưởng màu Dorian (Ngẫu hứng giao duyên); bài giọng trưởng I–IV–ii–V (Mưa chiều miền Trung). **[QU]** Sáo trúc, đàn bầu, đàn tranh trên nền dàn dây | Một thoáng Tây Hồ; Giận mà thương; Người ở đừng về (Nguyễn Xuân Tứ); Em là hoa Pơ Lang; Mưa chiều miền Trung; Ngẫu hứng lý qua cầu |
| **Bolero / nhạc vàng** | Giai điệu ngũ cung, luyến láy theo sáu thanh. Chủ đề tình dang dở, chia ly, quê nhà, mẹ | Ba lối giọng: giọng mũi kiểu Nam, giọng óc, giọng ngực. Xen ngâm thơ hoặc vọng cổ | 4/4, khoảng 60–80 BPM (nguồn báo phổ thông), gốc bolero Cuba, có clave. **[BC – tập mẫu]** 5/5 giọng thứ; hình thức "1., 2., ĐK, 3." (AABA) | **[BC – tập mẫu]** 4/5 có V/V7 trưởng (i–iv–VII–III, i–VI–III–VII… V7); ĐK **ngả sang giọng trưởng song song tên** (Dm→F, Am→C); một bài có IV trưởng màu Dorian. Guitar acoustic, violin, contrebasse, **guitar Hawaii vuốt nốt**. **[QU]** Bass ở phách 1, đệm đảo phách | Đắp mộ cuộc tình; Sầu tím thiệp hồng; Chuyện hoa sim; Thành phố buồn; Vọng cổ buồn; Nắng chiều; Phố đêm; Đôi ngả chia ly; Lòng mẹ (tác giả có tranh cãi) |
| **Nhạc Trịnh** | Đề tài thân phận, người mẹ, "người da vàng". **[QU]** Âm vực hẹp, giai điệu nhắc lại theo chuỗi | Tình ca, phản chiến, triết lý vô thường; gắn với giọng Khánh Ly | **[BC – tập mẫu]** 3/3 giọng thứ, nhãn "Slow"; dạng strophic hoặc A A–ĐK ngắn–A A | **[BC – tập mẫu]** **I7→iv ở 3/3 bài** (Am–A7–Dm; Em–E7–Am); V/V7 trưởng; một bài ngả sang giọng trưởng song song tên giữa khổ. **[QU]** Đệm một guitar rải hoặc piano | Ướt mi; Diễm xưa; Biển nhớ; Một cõi đi về; Ca khúc da vàng; Nối vòng tay lớn; Ngủ đi con; Hạ trắng (*); Cát bụi (*) |
| **Pop ballad 1990s–2000s** | **[QU]** Giai điệu thất cung, điệp khúc nhảy quãng cao | Nhạc nhẹ thời Đổi mới, thị trường hình thành quanh giải Làn Sóng Xanh (1997) | **[BC – tập mẫu]** 2 thứ / 2 trưởng; nhãn Ballad, Slow, Chachacha | **[BC – tập mẫu]** I–vi–IV–V (Hãy về đây bên anh); I–V–vi–IV–V có thêm V (Mắt nai cha cha cha); vòng quãng 5 i–iv–VII–III ngả sang trưởng (Hà Nội mùa vắng những cơn mưa); vòng lặp IV–V–iii–vi ở ĐK. **Không ghi nhận nâng tông ở ĐK cuối.** **[QU]** Synth pad, piano, saxophone, về sau R&B | Tình thôi xót xa (Lam Trường, 1998); Hà Nội mùa vắng những cơn mưa; Hãy về đây bên anh; Mắt nai cha cha cha; Có không giữ mất đừng tìm |
| **V-pop** (2010s–2026) | Hook ngắn, có R&B và EDM; sau 2020 bài thiết kế cho TikTok | Ê-kíp sản xuất là trung tâm, trại sáng tác, casting giọng qua demo | **[BC – tập mẫu]** 1 thứ / 3 trưởng; nhãn Ballad; **vòng lặp xuyên suốt bài** | **[BC – tập mẫu]** **Họ IV–V–iii–vi / IV–V–vi** (Nơi này có anh, Ánh nắng của anh); vi–iii–IV–V lặp cả bài (Em của ngày hôm qua); I–iii–vi–IV (Có chàng trai viết lên cây); **0 bài I–V–vi–IV nguyên dạng**. **[QU]** Piano, strings, 808, drop EDM hoặc future bass; tương phản bằng mật độ phối | Em của ngày hôm qua; Nơi này có anh; Ánh nắng của anh; Có chàng trai viết lên cây; Chúng ta của hiện tại; Buồn của anh; Phép màu; Lạc trôi (*) |
| **Folk fusion / folktronica** | Làn điệu ngũ cung: quan họ, chèo, xẩm, hát văn, cải lương. Chất liệu dân gian đi vào cấu trúc bài | Kể chuyện dân gian bằng hình ảnh hiện đại; mỗi chi tiết dân gian có "lý do tồn tại" (DTAP) | Future bass, disco-pop, hip-hop điện tử, tempo nhanh. **[BC – tập mẫu]** 2 thứ / 1 trưởng; nhãn trên trang (Ballad, Blues) không phản ánh groove thật | **[BC – tập mẫu]** **Vòng aeolian không có V trưởng**: i–VI–iv–v (Bắc Bling), iv–VII–v–i một vòng cho mọi đoạn (See tình); IV–V–iii–vi ở intro (Để Mị). Nhạc cụ dân tộc làm hook: sáo mèo, kèn bầu, nguyệt, nhị, sáo trúc, đàn bầu, đàn tranh | Để Mị nói cho mà nghe; Bánh trôi nước; Tứ phủ; See tình; Gieo quẻ; Bắc Bling; Thầy Dùi; Made in Vietnam; Nam Quốc Sơn Hà (DTAP) |
| **Rap Việt** | Điệp khúc âm vực hẹp do ca sĩ khác hát làm điểm tựa (công thức Đen Vâu) | Kể chuyện đời thường, gia đình, chữa lành; bùng nổ qua *Rap Việt* từ 2020 | Tỉ lệ khớp thanh–nhạc thấp hơn các thể loại khác (dữ liệu Thái). **[BC – tập mẫu]** 3/3 giọng thứ. **[QU]** Boom-bap 85–95 hoặc trap 130–150 BPM | **[BC – tập mẫu]** Vòng 2–4 hợp âm lặp cả bài: i–V7 (Bigcityboi); i–v–VI–VII (Lối nhỏ); VI–i–VII–iv (Ngày khác lạ). **[QU]** Beat boom-bap hoặc trap, 808, sample; có thể thêm nhạc cụ dân tộc (*Gieo quẻ*) | Bigcityboi; Lối nhỏ; Ngày khác lạ; Cây bàng; Đưa nhau đi trốn; Nấu ăn cho em; Trap (RHYDER); Sự nghiệp chướng |
| **Indie / rock** | Ngọt có giai điệu âm hưởng The Beatles; rock thế hệ mới pha rap | Lời thẳng, kể chuyện tuổi trẻ đô thị; Ngũ Cung lấy chất liệu dân tộc thiểu số | **[BC – tập mẫu]** 3/3 giọng trưởng; có Valse (Em dạo này) | **[BC – tập mẫu]** **iv thứ mượn** (Fm trong C, Dm trong A); line cliché đi xuống; bVII; vi–IV–I–V ở verse và vòng Canon ở chorus (2004). Ban nhạc guitar, bass, trống | Em dạo này; Thấy chưa; Lần cuối (Ngọt); 2004 (Cá Hồi Hoang); Tìm lại (Microwave); Nhảy Lửa Cầu Mưa (Ngũ Cung) |
| **Thiếu nhi & nhạc Tết** | Ngôn ngữ giản dị, giai điệu tươi vui. Trẻ 5–6 tuổi hát tự nhiên nhất trong C4–C5; bài vượt khoảng quãng 9 nên dịch giọng | Nhạc Xuân sống lâu nhờ được hát lại nhiều lần | Một số bài dùng tango (*Anh cho em mùa xuân*). **[QU]** 2/4 hoặc 4/4, giọng trưởng, câu 4 nhịp | Bản song ngữ *Ngày Tết quê em* phối acoustic, piano chủ đạo. **[QU]** Sample pháo, trống cơm, sáo trúc; chọn tông theo trẻ, không theo giọng người lớn | Ngày Tết quê em (Từ Huy, 1994); Anh cho em mùa xuân; Xuân đã về; Cánh thiệp đầu xuân; Điệp khúc mùa xuân; Mùa xuân ơi (*) |

**Chú thích dấu (*):** Bài có dấu (*) chỉ được nêu trong mục suy luận hoặc kiến thức nền của ghi chú nguồn, chưa có nguồn trích dẫn xác nhận tên bài, tác giả hoặc đặc điểm âm nhạc; cần kiểm chứng trước khi dùng làm tài liệu chính thức. Các bài trong tập mẫu đều có trang hợp âm làm nguồn (danh sách ở `14-hoa-am-viet-bai-mau.md` và `nguon-tham-khao.md`). **[BC – tập mẫu]** nghĩa là đếm từ một phiên bản hợp âm do người dùng đóng góp trên hopamchuan.com, không phải bản nhạc gốc của tác giả.

**Lưu ý khi dùng bảng:** nhãn điệu trên trang hợp âm (Slow, Ballad, Disco, Boston, Blues…) là **điệu đệm guitar** của người đóng góp, không phải nhịp gốc hay groove sản xuất. Tông bấm trên trang hợp âm thường quy về dáng Am/Em/Dm/C/G kèm capo → **không suy được tông thu âm gốc** từ trang hợp âm.

**Khung lời của các làn điệu chưa có dòng riêng trong bảng** (chi tiết và nguồn: `12-thi-luat.md` §12.10):
- **Lý Nam Bộ:** đại đa số điệu dùng lục bát (1–28 cặp), ngoài ra song thất lục bát, 4, 7, 8 chữ, hỗn hợp; từ phụ chêm được ở bất kỳ vị trí nào trong câu; hình thức nhạc phổ biến nhất là 1 đoạn đơn [BC] (Nguyễn Bảo Lan 2025). Xem `12-thi-luat.md` §12.10.
- **Hát bội:** nói lối viết bằng thể biền ngẫu đối xứng 3–10 chữ, không nhịp; hát Nam có nhịp, dựa trên lục bát, lục bát biến thể hoặc song thất [BC] (Đào Thị Như Mì 2025). Xem `12-thi-luat.md` §12.10.
- **Hò:** chưa có khuôn lời đã kiểm chứng (câu kể, câu xô, câu mở chưa có nguồn). Xem `12-thi-luat.md` §12.10.
- **Hát xoan:** chưa có khuôn lời đã kiểm chứng. Xem `12-thi-luat.md` §12.10.

