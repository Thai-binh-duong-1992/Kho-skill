> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Âm vực, BPM là giá trị xấp xỉ; C4 = Đô giữa, âm vực ghi theo cao độ thực. Nhãn: [BC] có bằng chứng; [BC – tập mẫu] đếm từ tập 37 bài hopamchuan.com (giả thuyết có dữ liệu ủng hộ); [QU] quy ước thực hành/suy luận; [Cần kiểm chứng].

# 5. Hòa âm 

Tệp này gồm 5 bảng tra: loại hợp âm, vòng hợp âm, thang âm và điệu thức, chuyển giọng, kỹ thuật hòa âm. Claude ghi hợp âm bằng **số La Mã** (độc lập với giọng) rồi dịch sang tên hợp âm cụ thể bằng script; viết hoa là trưởng (I), viết thường là thứ (vi).

**Bài Việt (bolero, Trịnh, tiền chiến, trữ tình, V-pop, fusion, rap, màu dân ca):** chọn hệ hòa âm theo bảng quyết định ở `14-hoa-am-viet-bai-mau.md` (tập mẫu 37 bài + trục quãng 4) **trước** khi dùng các bảng quốc tế dưới đây. Khi bảng quốc tế và tệp 14 khác nhau về nhạc Việt, theo tệp 14 [BC – tập mẫu].

## 5.1. Các loại hợp âm (ví dụ trên nốt gốc C)

| Nhóm | Ký hiệu | Nốt | Màu sắc | Hay dùng trong |
| --- | --- | --- | --- | --- |
| Ba nốt | C | C–E–G | Sáng, vững | Mọi thể loại |
| Ba nốt | Cm | C–Eb–G | Buồn, trầm | Mọi thể loại |
| Ba nốt | Cdim | C–Eb–Gb | Căng, bất an | Nối hợp âm, cổ điển |
| Ba nốt | Caug | C–E–G# | Lơ lửng, chờ đợi | Nối hợp âm, nhạc phim |
| Ba nốt | Csus2 / Csus4 | C–D–G / C–F–G | Mở, chưa kết | Pop, rock, worship |
| Ba nốt | C5 (power chord) | C–G | Trung tính, mạnh | Rock, metal, punk |
| Sáu | C6 / Cm6 | C–E–G–A / C–Eb–G–A | Cổ điển, sân khấu | Swing, gypsy jazz, bolero |
| Sáu | C6/9 | C–E–G–A–D | Mở, sang | Jazz, bossa, kết bài |
| Bảy | Cmaj7 | C–E–G–B | Mơ màng, sang | Ballad, lo-fi, bossa, city pop |
| Bảy | C7 | C–E–G–Bb | Cần giải quyết, blues | Blues, funk, gospel, hợp âm át |
| Bảy | Cm7 | C–Eb–G–Bb | Mềm, trầm tư | R&B, house, jazz |
| Bảy | Cm7b5 (ø) | C–Eb–Gb–Bb | U buồn, dẫn | ii–V giọng thứ |
| Bảy | Cdim7 (°7) | C–Eb–Gb–A | Kịch tính | Nối hợp âm, gospel, nhạc phim câm |
| Bảy | CmMaj7 | C–Eb–G–B | Bí ẩn, điệp viên | Nhạc phim, line cliché |
| Bảy | C7sus4 | C–F–G–Bb | Lơ lửng | Jazz, pop, hợp âm trước điệp khúc |
| Bảy | C7#5 / Cmaj7#5 | C–E–G#–Bb / C–E–G#–B | Căng, ảo | Jazz, nhạc phim |
| Thêm nốt | Cadd9 / Cm(add9) | C–E–G–D / C–Eb–G–D | Trong, hiện đại | Pop, worship, indie |
| Thêm nốt | Cadd11 (add4) | C–E–F–G | Cọ xát nhẹ | Indie, folk |
| Mở rộng | C9 / Cmaj9 / Cm9 | Thêm D vào hợp âm bảy | Ấm, dày | R&B, neo-soul, lo-fi, funk |
| Mở rộng | C11 (thường bỏ E) / Cm11 | Thêm D, F | Mở, lơ lửng | Neo-soul, gospel, modal jazz |
| Mở rộng | Cmaj7#11 | C–E–G–B–F# | Bay bổng (Lydian) | Nhạc phim, dream pop |
| Mở rộng | C13 / Cmaj13 / Cm13 | Thêm A | Giàu, jazz | Jazz, neo-soul |
| Biến đổi | C7b9 / C7#9 | C–E–G–Bb–Db / D# | Tối / gai góc | Jazz giọng thứ, rock (7#9) |
| Biến đổi | C7b5 / C7#11 | C–E–Gb–Bb / thêm F# | Lạ | Bebop, thay tritone |
| Biến đổi | C7b13, C7alt | b9, #9, b5/#11, b13 | Căng tối đa | Jazz, trước giải quyết về I |
| Đảo, bass riêng | C/E, C/G | Đảo 1, đảo 2 | Bass đi mượt | Ballad, gospel, đường bass đi xuống |
| Đảo, bass riêng | D/C, Bb/C, F/G | Hợp âm trên bass khác | Hiện đại, mở | Pop, gospel, film (F/G thay G7sus) |
| Đa hợp âm | D/C (polychord) | Hai hợp âm chồng | Rực rỡ | Nhạc phim, jazz |
| Quãng bốn | C–F–Bb–Eb | Xếp quãng 4 | Hiện đại, màu ngũ cung | Modal jazz, nhạc Á Đông hiện đại |
| Cụm nốt | C–D–E | Quãng 2 liền | Mờ, căng | Nhạc phim, ambient |
| Chức năng đặc biệt | Neapolitan (bII), át tăng (It+6, Fr+6, Ger+6) | Db–F–Ab; Ab–C–(D/Eb)–F# | Kịch tính cổ điển | Cổ điển, nhạc phim, ballad cao trào |

## 5.2. Vòng hợp âm kinh điển

| Tên | Số La Mã | Ví dụ giọng C / Am | Cảm xúc, thể loại |
| --- | --- | --- | --- |
| Ba hợp âm cơ bản | I–IV–V–I | C–F–G–C | Dân ca, thiếu nhi, rock and roll, country |
| Vòng pop (axis) | I–V–vi–IV | C–G–Am–F | Tươi sáng, pop, rock phương Tây. **Không phải mặc định V-pop**: 0/37 bài Việt trong mẫu dùng nguyên dạng [BC – tập mẫu] |
| Vòng buồn–hy vọng | vi–IV–I–V | Am–F–C–G | Ballad, emo; trong mẫu Việt chỉ gặp ở indie (verse *2004*) [BC – tập mẫu] |
| Vòng thập niên 50 | I–vi–IV–V | C–Am–F–G | Doo-wop, nhạc xưa, thiếu nhi |
| Vòng Canon | I–V–vi–iii–IV–I–IV–V | C–G–Am–Em–F–C–F–G | Trang trọng, cưới, ballad |
| Vòng quãng năm | vi–ii–V–I (iii–vi–ii–V–I) | Am–Dm–G–C | Trôi chảy: jazz, nhạc tiền chiến, ballad |
| ii–V–I | ii7–V7–Imaj7 | Dm7–G7–Cmaj7 | Jazz, bossa, city pop |
| Turnaround | I–vi–ii–V | C–Am–Dm–G | Jazz, swing (rhythm changes) |
| 12 ô blues | I7–I7–I7–I7 / IV7–IV7–I7–I7 / V7–IV7–I7–V7 | C7…F7…G7 | Blues, rock, R&B |
| Ragtime | III7–VI7–II7–V7–I | E7–A7–D7–G7–C | Vui, cổ |
| Thứ cơ bản | i–iv–V7–i | Am–Dm–E7–Am | Bolero, nhạc vàng, trữ tình, tiền chiến (15/23 bài giọng thứ Việt có V/V7 [BC – tập mẫu]), tango |
| Andalucia | i–bVII–bVI–V | Am–G–F–E | Flamenco, Latin, rock kịch tính |
| Lament bass | i–v/b7–bVI–V (bass đi xuống) | Am–Em/G–F–E | Bi thương, Baroque, ballad |
| Line cliché | i–i(maj7)–i7–i6 | Am–AmMaj7–Am7–Am6 | Nhạc phim, jazz, bossa |
| Plagal (Amen) | IV–I | F–C | Thánh ca, gospel, kết bài ấm |
| Picardy | … → I (kết trưởng trong bài thứ) | … Am → A | Kết bài hy vọng |
| Gospel đi qua | I–I7/b7–IV–#iv°7–I/V–V7–I | C–C7/Bb–F–F#°7–C/G–G7–C | Gospel, soul, ballad cao trào |

## 5.3. Vòng hợp âm hiện đại và đặc trưng vùng

| Tên | Số La Mã | Ví dụ giọng C / Am | Cảm xúc, thể loại |
| --- | --- | --- | --- |
| Đường hoàng gia (J-pop) | IVmaj7–V7–iii7–vi | Fmaj7–G7–Em7–Am | Xúc động, J-pop, anime, C-pop; **V-pop ballad sau 2014**: họ IV–V–iii–vi / IV–V–vi ở 4/37 bài [BC – tập mẫu] |
| "Just the Two of Us" | IVmaj7–III7–vi7–(v7–I7) | Fmaj7–E7–Am7–Gm7–C7 | City pop, R&B, K-pop |
| Neo-soul | ii9–V13–Imaj9 hoặc IVmaj9–iii7–ii7–Imaj7 | Dm9–G13–Cmaj9 | Ấm, mềm |
| Lo-fi | ii7–V7–Imaj7–vi7 (thêm 9) | Dm9–G7–Cmaj7–Am9 | Thư giãn |
| Trap, emo thứ | i–VI–III–VII | Am–F–C–G | U tối, hip-hop, EDM, trance |
| Epic | i–bVI–bIII–bVII | Am–F–C–G (cảm nhận thứ) | Hùng tráng, trailer, metal |
| Aeolian vamp | i–bVI–bVII–i | Am–F–G–Am | Rock kịch tính, anthem |
| Mixolydian rock | I–bVII–IV–I | C–Bb–F–C | Classic rock, Celtic, anthem |
| Mario cadence | bVI–bVII–I | Ab–Bb–C | Chiến thắng, cao trào game, pop |
| Hợp âm mượn | I–iv–I hoặc IV–iv–I | C–Fm–C | Hoài niệm, ballad |
| Backdoor | iv7–bVII7–I | Fm7–Bb7–C | Jazz, R&B mềm |
| Thay tritone | ii–bII7–I | Dm7–Db7–Cmaj7 | Jazz, bossa |
| Chromatic mediant | I–bVI–I hoặc I–III–I | C–Ab–C; C–E–C | Kỳ vĩ, nhạc phim, game |
| Pedal point | Hợp âm đổi trên bass giữ nguyên | C–Bb/C–F/C–C | Build EDM, nhạc phim, intro |
| Modal vamp Dorian | i7–IV7 | Am7–D7 | Funk, soul, Latin rock |
| Lydian | I–II | C–D | Bay bổng, nhạc phim, dream pop |
| Bossa | Imaj7–II7–ii7–V7 | Cmaj7–D7–Dm7–G7 | Bossa, nhạc xưa |
| Coltrane changes | Ba trung tâm giọng cách nhau quãng 3 trưởng | C–Eb7–Ab–B7–E–G7–C | Jazz nâng cao |
| K-pop | Hợp âm mượn bVI, bVII; chuyển nửa cung giữa bài | — | K-pop, dance-pop |
| Bolero Việt | i–iv–V7–i; ĐK **ngả sang giọng trưởng song song tên** (Dm → F, Am → C) | Am–Dm–E7–Am │ ĐK C–G–Am | Bolero, nhạc vàng, trữ tình: 5/5 bolero giọng thứ, 4/5 có V/V7; 7 bài ngả sang trưởng song song tên [BC – tập mẫu] (thay quy tắc cũ: "chuyển sang trưởng cùng tên Am → A" — chỉ 1/37 bài, *Thiên thai*) |
| Trịnh | Giọng thứ + V/V7 + **I7→iv** | Am–A7–Dm–E–Am | Nhạc Trịnh: I7→iv ở 3/3 bài [BC – tập mẫu] |
| V-pop vòng lặp | vi–iii–IV–V hoặc IV–V–iii–vi lặp xuyên suốt; tương phản bằng mật độ phối | Am–Em–F–G; F–G–Em–Am | V-pop ballad, rap: vòng lặp xuyên suốt ở 8 bài, đều sau 2014 [BC – tập mẫu] |
| Aeolian Việt (fusion, rap) | i–VI–iv–v; iv–VII–v–i; i–v–VI–VII — **không V trưởng**, cadence v–i hoặc VII–i | Am–F–Dm–Em | Folk fusion, rap Việt (*Bắc Bling*, *See tình*) [BC – tập mẫu] |
| Ngũ cung Á Đông | Trục quãng 4: hợp âm chồng quãng 4, bourdon chủ âm–át âm, sus2/sus4/add9; hạn chế V7 có nốt cảm | C–Am–Dm–Gsus4; bass C–G giữ | Màu dân ca Việt, Trung, Nhật. Trục quãng 4 của điệu thức Việt: [BC] (Nguyễn Xinh 1978; Lê Anh Tuấn 2012). "Hạn chế V7" chỉ đúng cho hướng ngũ cung/fusion, **không** phải thực hành chung của tân nhạc Việt [QU] |
| bII, IV trưởng trong giọng thứ | bII (Eb trong Dm); IV trưởng (D trong Am) | Am–Bb–Am; Am–D–Am | Màu "oán"/Phrygian và Dorian ở trữ tình, tiền chiến: bII 3 bài, IV trưởng 2 bài [BC – tập mẫu] |

## 5.4. Thang âm và điệu thức

| Thang âm | Nốt trên C | Màu sắc | Thể loại |
| --- | --- | --- | --- |
| Trưởng (Ionian) | C D E F G A B | Sáng | Phổ biến |
| Thứ tự nhiên (Aeolian) | C D Eb F G Ab Bb | Buồn | Phổ biến |
| Thứ hòa âm | C D Eb F G Ab B | Kịch tính, Trung Đông | Cổ điển, metal, bolero |
| Thứ giai điệu | C D Eb F G A B | Trang nhã | Jazz, cổ điển |
| Dorian | C D Eb F G A Bb | Buồn mà có hy vọng | Funk, Celtic, jazz modal |
| Phrygian | C Db Eb F G Ab Bb | Tối, Tây Ban Nha | Metal, flamenco |
| Phrygian dominant | C Db E F G Ab Bb | Rực, Trung Đông | Flamenco, nhạc Do Thái, metal |
| Lydian | C D E F# G A B | Bay bổng, thần tiên | Nhạc phim, dream pop |
| Lydian dominant | C D E F# G A Bb | Vui lạ | Jazz, nhạc hoạt hình |
| Mixolydian | C D E F G A Bb | Phóng khoáng | Rock, blues, Celtic, country |
| Locrian | C Db Eb F Gb Ab Bb | Bất ổn | Metal, nhạc ma quái |
| Ngũ cung trưởng | C D E G A | Trong, dân gian | Dân ca Việt, Trung, country, thiếu nhi |
| Ngũ cung thứ | C Eb F G Bb | Mộc, mạnh | Rock riff, blues, dân ca |
| Blues | C Eb F Gb G Bb | Blues | Blues, rock, jazz |
| Toàn cung | C D E F# G# A# | Mơ hồ | Ấn tượng, cảnh mơ |
| Giảm (bát cung) | C D Eb F Gb Ab A B | Căng | Jazz, nhạc phim hồi hộp |
| Chromatic | 12 nốt | Trượt, căng | Nốt đi qua, nhạc phim |
| Hirajoshi, In (Nhật) | C D Eb G Ab / C Db F G Ab | Nhật cổ | Nhạc Nhật, game |
| Yo (Nhật) | C D F G A | Dân gian Nhật | Dân ca Nhật |
| Ryukyu (Okinawa) | C E F G B | Biển đảo | Nhạc Okinawa |
| Điệu thức Trung Hoa (cung, thương, giác, chuỷ, vũ) | 5 điệu xoay trên ngũ cung | Theo điệu | Cổ phong, nhạc truyền thống |
| Hơi Việt Nam (Bắc, Nam, Xuân, Ai, Oán) | Ngũ cung có nốt nhấn, nốt "non", "già" lệch khỏi 12 cung đều | Vui (Bắc), buồn (Nam), ai oán (Oán) | Ca Huế, đờn ca tài tử, cải lương |
| Maqam Hijaz, Rast, Bayati | Có nốt phần tư cung (Rast, Bayati) | Trung Đông | Nhạc Ả Rập, Thổ Nhĩ Kỳ |
| Raga (Yaman, Bhairav…) | Mỗi raga có nốt đi lên, đi xuống và câu đặc trưng riêng | Theo thời điểm trong ngày | Nhạc Ấn Độ |
| Slendro, pelog | 5 âm, 7 âm không chia đều | Gamelan | Nhạc Indonesia |

Với thang âm có nốt lệch khỏi 12 cung đều (hơi Việt, maqam, raga, slendro), Claude ghi chú "nốt nhấn/rung, không ghi chính xác được bằng hợp âm phương Tây" và đề nghị dùng nhạc công truyền thống.

## 5.5. Chuyển giọng

| Kỹ thuật | Cách làm | Hiệu quả |
| --- | --- | --- |
| Nâng tông điệp khúc cuối | Lên nửa cung hoặc một cung, chuẩn bị bằng V7 của giọng mới hoặc 1 phách lặng | Cao trào, phấn khích (pop, ballad, K-pop). **Bài Việt:** 0/37 bản hợp âm có nâng tông ĐK cuối [BC – tập mẫu]; chỉ dùng khi có lý do sân khấu |
| Hợp âm chung (pivot) | Một hợp âm thuộc cả hai giọng làm cầu nối | Mượt, tự nhiên |
| Trực tiếp | Đổi giọng ngay đầu câu mới | Bất ngờ |
| Nốt chung | Giữ một nốt, đổi hợp âm xung quanh | Kỳ ảo, nhạc phim |
| Cùng tên (parallel) | Thứ ↔ trưởng cùng tên (Am ↔ A) | Đổi cảm xúc mạnh; hiếm trong bài Việt (1/37, *Thiên thai* Dm → D) [BC – tập mẫu] |
| Song song tên (relative; tiếng Anh: relative key) | Thứ ↔ trưởng chung hóa biểu (Am ↔ C, Dm ↔ F) | Nhẹ nhàng, phổ biến; **cách tạo tương phản chuẩn của ĐK bolero và trữ tình Việt** (7 bài) [BC – tập mẫu] (thay quy tắc cũ: "song song Am ↔ A cho bolero") |
| Theo chuỗi (sequence) | Lặp một câu ở cao độ mới | Dồn dập |
| Chromatic mediant | Nhảy quãng 3 (C → E, C → Ab) | Hoành tráng, nhạc phim |

## 5.6. Kỹ thuật và quy tắc hòa âm

- **Chọn giọng (tông):** ưu tiên vùng hát thoải mái của người hát (`04-giong-hat.md`), sau đó mới tính nhạc cụ. Giọng thuận: guitar E, A, D, G, C; kèn đồng, sax Bb, Eb, F; dàn dây D, G, A.
- **Nhịp hòa âm:** số hợp âm mỗi ô. Verse thưa (1 hợp âm / 1–2 ô), pre-chorus dày dần, điệp khúc ổn định; ballad và jazz đổi nhanh hơn.
- **Giai điệu gặp hợp âm:** nốt ở phách mạnh nên là nốt của hợp âm; nốt ngoài hợp âm (nốt thêu, nốt lướt, appoggiatura) đặt ở phách yếu hoặc giải quyết ngay.
- **Dẫn bè (voice leading):** nối hợp âm bằng bước đi ngắn nhất; giữ nốt chung; tránh quãng 5 và quãng 8 song song trong hợp xướng cổ điển.
- **Bass đi:** bass đi xuống từng bậc (C–C/B–Am–Am/G–F) tạo chất ballad, gospel.
- **Hòa âm lại (reharmonization)** cho điệp khúc cuối hoặc bản phối mới: thay hợp âm cùng chức năng (I ↔ iii, vi; IV ↔ ii), thêm dominant phụ (V/V, V/vi), mượn hợp âm (iv, bVI, bVII), thay tritone, thêm nốt mở rộng.
- **Ba cách ghi:** tên hợp âm (Am7), số La Mã (vi7), hệ số Nashville (6m7) cho nhạc công đổi giọng nhanh.
