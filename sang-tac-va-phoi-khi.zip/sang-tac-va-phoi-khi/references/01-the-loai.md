> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Âm vực, BPM là giá trị xấp xỉ; C4 = Đô giữa, âm vực ghi theo cao độ thực.

# 3. Thể loại và phong cách 

Tệp này là ma trận khoảng 150 thể loại trong 14 họ. Mỗi dòng cho Claude đủ 6 thông số để viết đúng chất: nhịp độ, nhịp và tiết tấu, màu hòa âm, nhạc cụ, chất giọng và đặc điểm lời. BPM là khoảng thường gặp, không phải luật cứng.

## 3.1. Pop

| Thể loại | BPM | Nhịp, tiết tấu | Hòa âm, thang âm | Nhạc cụ đặc trưng | Giọng, lời |
| --- | --- | --- | --- | --- | --- |
| Pop ballad | 60–80 | 4/4, 6/8; nốt đen chậm | I–V–vi–IV, hợp âm treo (sus), nâng tông cuối | Piano, dàn dây, pad, guitar mộc | Ngân dài, cao trào ở điệp khúc cuối; lời tâm sự |
| Dance-pop | 115–128 | 4/4, kick 4 phách | Vòng 4 hợp âm lặp, giọng thứ | Synth, trống máy, bass synth | Câu móc ngắn, lặp nhiều |
| Synth-pop | 110–130 | 4/4, nốt móc đều | Vòng đơn giản, màu thập niên 80 | Synth analog, trống điện tử, arpeggiator | Lạnh, rõ chữ |
| Electropop | 115–130 | 4/4 | Vòng 4 hợp âm | Synth hiện đại, 808 | Giọng xử lý hiệu ứng |
| Indie pop | 90–120 | 4/4 | Add9, maj7 | Guitar điện sạch, synth nhẹ | Mộc, thủ thỉ; lời hình ảnh đời thường |
| Dream pop | 70–100 | 4/4 | Maj7, hợp âm lơ lửng | Guitar reverb dày, pad | Hơi thở, mờ |
| K-pop | 100–130 | 4/4, đổi nhịp giữa bài | Đổi phần liên tục, nâng tông | Synth, 808, dây | Chia phần nhiều giọng, xen rap và tiếng Anh |
| J-pop | 120–180 | 4/4 nhanh | Vòng "đường hoàng gia" IV–V–iii–vi | Ban nhạc, dây, piano | Giai điệu dày nốt, nhiều chuyển hợp âm |
| Mandopop, C-pop | 65–110 | 4/4 | I–V–vi–iii–IV, ngũ cung xen | Piano, dây, nhạc cụ Trung Hoa | Tình ca, lời tả cảnh |
| City pop | 100–120 | 4/4 nghiêng funk | Maj7, m9, ii–V | Bass slap, Rhodes, kèn đồng | Thành thị, hoài niệm |
| Teen pop, bubblegum | 110–130 | 4/4 | I–IV–V | Ban nhạc sáng | Vui, từ đơn giản |
| Acoustic pop | 80–110 | 4/4, 6/8 | I–V–vi–IV | Guitar mộc, cajon, ukulele | Gần gũi |

## 3.2. Nhạc đại chúng Việt Nam

Bảng đầy đủ 24 thể loại Việt (6 cột, bài mẫu, lịch sử, hơi): `11-nhac-viet-the-loai.md`. [BC – tập mẫu] = đếm từ 37 bản hợp âm hopamchuan.com (một phiên bản/bài); BPM ở đây phần lớn là [QU] vì trang hợp âm không ghi BPM.

| Thể loại | BPM | Nhịp, tiết tấu | Hòa âm, thang âm | Nhạc cụ đặc trưng | Giọng, lời |
| --- | --- | --- | --- | --- | --- |
| V-pop ballad (2014–nay) | 60–85 [QU] | 4/4, 6/8 | [BC – tập mẫu] **Vòng lặp xuyên suốt bài**: họ IV–V–iii–vi / IV–V–vi, vi–iii–IV–V, I–iii–vi–IV; **0/37 bài có I–V–vi–IV nguyên dạng**; **0/37 nâng tông ở ĐK cuối** (thay quy tắc cũ: "vi–IV–I–V, nâng tông") | Piano, dây, guitar, 808; tương phản bằng mật độ phối, không bằng đổi hợp âm | Ngân, luyến nhẹ; tình yêu, chia tay; hook ngắn, sau 2020 thiết kế cho TikTok |
| V-pop dance | 110–128 [QU] | 4/4 | Vòng 4 hợp âm giọng thứ [QU] | Synth, 808, drop EDM/future bass | Câu móc lặp, xen tiếng Anh |
| Bolero Việt | Khoảng 60–80 [QU] (nguồn báo phổ thông, chưa đo) | 4/4, gốc bolero Cuba/rumba, **clave Cuba**; dạng Mexico/Mỹ Latin, **không phải bolero Tây Ban Nha 3/4** [BC]. [QU] Bass phách 1, đệm đảo phách | [BC – tập mẫu] 5/5 giọng thứ, 4/5 có V/V7 trưởng (i–iv–V7–i); ĐK **ngả sang giọng trưởng song song tên** Dm→F, Am→C (thay quy tắc cũ: "trưởng song song" hiểu là Am→A); giai điệu ngũ cung | **Guitar Hawaii vuốt nốt** [BC], guitar phím lõm, guitar acoustic, violin, contrebasse, organ | Ba lối giọng: mũi kiểu Nam, óc, ngực; luyến theo sáu thanh; xen ngâm thơ/vọng cổ; tình dang dở, quê nhà, mẹ, lính. Hình thức "1., 2., ĐK, 3." |
| Nhạc vàng, slow rock | 55–75 [QU] | 12/8 slow rock, 4/4 rumba, boston (điệu đệm guitar) | Giọng thứ chức năng có V7; ĐK ngả giọng trưởng song song tên [BC – tập mẫu] | Guitar, organ, trống | Tâm tình |
| Nhạc tiền chiến (1938–1954) | 60–90 [QU] | 4/4, 3/4; strophic hoặc AABA | [BC – tập mẫu] 4/4 bài giọng thứ: i–VI–i–III–V7–i, v–i, bII; chuyển trưởng cùng tên hiếm (1 bài: Thiên thai Dm→D) | Piano, guitar Hawaii, violin, accordion [QU] | Trữ tình, lời Thơ Mới |
| Nhạc Trịnh | 60–90 [QU] | 4/4, 3/4 (nhãn "Slow"); strophic hoặc A A–ĐK ngắn–A A | [BC – tập mẫu] 3/3 giọng thứ, **I7→iv ở 3/3 bài** (Am–A7–Dm), V/V7 trưởng (thay quy tắc cũ: "vòng i–iv–VII–III") | Một guitar rải hoặc piano [QU] | Giọng mộc; triết lý, thân phận, phản chiến |
| Nhạc cách mạng, hùng ca | 100–120 [QU] | 2/4, 4/4 hành khúc, nhịp chấm dôi [QU]; nhãn Disco/Boston/Slow trên trang hợp âm chỉ là điệu đệm guitar | [BC – tập mẫu] 3/4 giọng trưởng: I–vi–IV–I, I–iii–vi–IV; bài thứ i–III–iv–V | Kèn đồng, snare, hợp xướng | Hợp xướng, khỏe; "ta", "chúng ta" |
| Ca khúc trữ tình quê hương | 60–90 [QU] | 2/4, 4/4 | Ngũ cung pha thất cung, quãng đặc trưng vùng [BC]; [BC – tập mẫu] giọng thứ không V trưởng + bII, hoặc IV trưởng màu Dorian | Sáo trúc, đàn tranh, đàn bầu, dây | Giọng dân ca, luyến; câu đệm "ơi", "à ơi" |
| Pop ballad 1990s–2000s | 60–85 [QU] | 4/4; nhãn Ballad, Slow, Chachacha | [BC – tập mẫu] I–vi–IV–V, I–V–vi–IV–V, vòng quãng 5 i–iv–VII–III ngả trưởng; không ghi nhận nâng tông ĐK cuối | Synth pad, piano, saxophone, về sau R&B | Điệp khúc nhảy quãng cao [QU] |
| Folk fusion, folktronica | Nhanh (future bass, disco-pop, hip-hop điện tử) | 4/4 | [BC – tập mẫu] **Vòng aeolian không V trưởng**: i–VI–iv–v, iv–VII–v–i, một vòng cho mọi đoạn | Nhạc cụ dân tộc làm hook: sáo mèo, kèn bầu, nguyệt, nhị, sáo trúc, bầu, tranh | Làn điệu ngũ cung đi vào cấu trúc bài; mỗi chi tiết dân gian có "lý do tồn tại" |
| Nhạc trẻ, pop rock, indie Việt | 70–130 [QU] | 4/4, có Valse | [BC – tập mẫu] 3/3 giọng trưởng: iv thứ mượn, line cliché đi xuống, bVII, vi–IV–I–V, vòng Canon | Ban nhạc guitar, bass, trống | Lời thẳng, tuổi trẻ đô thị |
| Lo-fi, chill Việt | 70–90 | 4/4 tiết tấu lệch nhẹ | Maj7, m9 | Piano Rhodes, trống mềm, tiếng đĩa than | Thì thầm |
| Vinahouse, remix | 132–142 | 4/4, kick 4 phách, bass nảy | Giọng thứ, vòng ngắn | Synth lead, bass "nảy", sáo/đàn bầu xử lý điện tử | Câu móc ngắn, nhiều đoạn không lời |
| Nhạc thiếu nhi, nhạc Tết | 100–130 [QU] | 2/4, 4/4, câu 4 nhịp; một số bài tango | Giọng trưởng, 3 hợp âm [QU] | Piano, xylophone, vỗ tay; Tết: sample pháo, trống cơm, sáo trúc | Trẻ 5–6 tuổi hát tự nhiên nhất C4–C5 [BC]; từ đơn giản |

Rap Việt: xem 3.6 và `11-nhac-viet-the-loai.md` ([BC – tập mẫu] 3/3 giọng thứ, vòng 2–4 hợp âm lặp cả bài; điệp khúc âm vực hẹp do ca sĩ khác hát).

## 3.3. Nhạc truyền thống Việt Nam

Nhạc truyền thống có hệ thang âm riêng (hơi, điệu), không áp hòa âm phương Tây một cách máy móc. Khi làm bản "phối mới", giữ thang âm và cách luyến láy, chỉ làm giàu phần đệm. [BC] Ngũ cung Việt **không bình quân** (nhiều bậc ~166 cent); khác biệt giữa các hơi nằm chủ yếu ở **luyến láy** (tỳ bà lên dây như nhau cho mọi điệu). Hệ Bắc: Bắc (vui), Quảng (kỳ ảo), Nhạc (trang nghiêm); hệ Nam: Xuân (thanh thản), Ai (buồn), Đảo; Oán gần Ai. Tên nốt hò–xự–xang–xê–cống = sol–la–do–re–mi (một số ký âm ca Huế lấy hò = do: ghi rõ quy ước). Bảng đầy đủ, bảng chọn hơi theo cảm xúc và bài mẫu: `11-nhac-viet-the-loai.md`.

| Thể loại | Vùng | Nhịp, tiết tấu | Thang âm, hơi | Nhạc cụ | Giọng, lời |
| --- | --- | --- | --- | --- | --- |
| Quan họ | Bắc Ninh | [BC] Quan họ cổ: nhịp hỗn hợp 2/4–3/4; quan họ mới: 2/4 hoặc 4/4 | Ngũ cung; cao độ theo ba tầng thanh của lời lục bát, có "biến thanh" | Truyền thống không đệm; gần đây nhị, nguyệt, sáo, bầu | Hát đối nam nữ, giọng dẫn–giọng luồn, "nảy hạt", vang–rền–nền–nảy; lời lục bát có tiếng đệm |
| Ca trù | Bắc Bộ | Tự do, phách gõ đều | Điệu Nam (buồn), Bắc (vui) **riêng của ca trù**, không đồng nhất với ca Huế/tài tử; giai điệu theo thanh điệu thơ | Đàn đáy 3 dây lên quãng 4, phách, trống chầu | Ca nương hát; hát nói khổ đủ 11 câu chia 4–4–3; mưỡu lục bát |
| Chèo | Bắc Bộ | Bài nhịp chặt xen lối nói, hát tự do | 5 cung Nam, Pha, Huỳnh, Bắc, Nao (Nam, Nao phổ biến nhất); có điệu thức thiếu âm, thừa âm | Nguyệt, nhị, bầu, sáo, trống, chũm chọe | ~200 làn điệu; hát liền hơi, nhấn, ngắt, nảy hạt |
| Hát xoan | Phú Thọ | 2/4 | Ngũ cung | Mõ, trống, phách | Hát tập thể, nghi lễ |
| Chầu văn, hát văn | Bắc Bộ | Nhịp dồn dần, hướng tới xuất thần | Chuỗi làn điệu theo giá hầu | Đàn nguyệt (chính), phách, trống, thanh la; hiện đại thêm guitar phím lõm | Giọng vang, nghi lễ |
| Ca Huế | Huế | Linh hoạt | Điệu Bắc (Khách) và Nam (Nam Ai, Nam Bình); Nam Ai có cao độ "già/non"; nhảy quãng 4, 5, 6 phổ biến | Tranh, tỳ bà, nguyệt, nhị, bầu, sáo | Nhẹ, sâu lắng; phương ngữ gộp hỏi–ngã |
| Nhã nhạc cung đình Huế | Huế | Trang nghiêm | Ngũ cung, tiếp nhận giai điệu Chăm | Ti trúc 8 nhạc cụ: kèn bầu, tỳ bà, nguyệt, tam, nhị, sáo, trống | Nghi lễ cung đình, phần lớn không lời |
| Hò, lý | Trung, Nam Bộ | Tự do (hò), 2/4 (lý) | Ngũ cung, hơi Nam; miền Trung xự thấp, xang cao (ảnh hưởng Chăm) | Thường không đệm hoặc đàn kìm, tranh | Hò lao động, lý trữ tình; lời lục bát + tiếng đệm |
| Đờn ca tài tử | Nam Bộ | Nhịp song lang; bài Nam/Oán câu 8 khuông, song lang ở khuông 6 và 8; bài Bắc nhanh | Bốn điệu Bắc, Nam, Lễ, Oán; "rao" tự do trước mỗi bài | "Ngũ tuyệt" tranh, tỳ bà, kìm, cò, tam; thêm sáo, song lang, guitar phím lõm | Ngẫu hứng trên giai điệu khung; 20 bài tổ, 72 bài cổ điển |
| Cải lương, vọng cổ | Nam Bộ | Từ nhịp 2 (20 câu) đến nhịp 32 (6 câu); nhịp 32 có âm kết cố định cống–xang–hò–hò–xê–hò | Hơi Oán điệu Nam | Kìm, guitar phím lõm điện, cò, tranh, song lang | Ngân dài, xòng, lót; giọng kết "hò" là chỗ đánh giá người ca |
| Tuồng, hát bội | Trung Bộ | Trống chầu dẫn | Ngũ cung | Trống chiến, kèn, nhị | Giọng mạnh, hào hùng |
| Then | Tày, Nùng, Thái | 2/4 đều [QU] | Ngũ cung; nét hoa mỹ quanh bậc I, IV, V; trụ I–IV, I–V | Đàn tính, xóc nhạc | Kể chuyện, nghi lễ cầu an, cầu mùa |
| Cồng chiêng | Tây Nguyên | Chu kỳ lặp, đa tầng nhịp [QU] | Thang 5 âm có bán âm thành 6 âm; mỗi chiêng một cao độ | Cồng, chiêng, k'ni, t'rưng, klông pút, đàn đá | Hát kể sử thi, lễ hội |
| Ví Giặm | Nghệ Tĩnh | Ví chậm, tự do; Giặm có nhịp | Ngũ cung; phương ngữ không phân biệt ngã/nặng | Thường không đệm; phối hiện đại giữ intro tự do [QU] | Trữ tình, kể, khuyên răn |
| Bài chòi | Trung Bộ | Theo điệu hò (hò khoan, mái nhì, giã gạo) | Xuân nữ, Xàng xê, Cổ bản | Trống, nhị, đàn bầu, kèn, sanh | Anh hiệu ứng tác, trò chơi dịp Tết |
| Hát ru | Ba miền | Chậm, tự do | Bắc ngũ cung; miền Trung **tứ cung**; Nam Bộ ầu ơ, ví dầu | Không đệm | Huyền hát đi xuống ở 81/90 trường hợp [BC] |
| Dân ca Khmer Nam Bộ | Nam Bộ | 2/4, 4/4 | Thang 7 âm riêng | Dàn nhạc ngũ âm (pin peat), trống | Múa hát lễ hội |

## 3.4. Rock và Metal

| Thể loại | BPM | Nhịp, tiết tấu | Hòa âm, thang âm | Nhạc cụ đặc trưng | Giọng, lời |
| --- | --- | --- | --- | --- | --- |
| Rock and roll | 140–180 | 4/4 shuffle hoặc thẳng | 12 ô blues, I–IV–V | Guitar, piano, contrabass, trống | Vui, ngắn |
| Classic rock | 100–140 | 4/4 phách 2–4 nhấn | I–bVII–IV, power chord | Guitar điện, organ Hammond | Khỏe, solo guitar |
| Hard rock | 110–150 | 4/4 | Power chord, riff ngũ cung | Guitar distortion 2 cây | Giọng cao, mạnh |
| Blues rock | 70–130 | 4/4, 12/8 | 12 ô blues, thang blues | Guitar, harmonica | Khàn, cảm xúc |
| Punk | 160–200 | 4/4 nhanh, nốt móc đều | 3 hợp âm | Guitar, bass, trống | Hét, phản kháng |
| Pop punk | 150–190 | 4/4 | I–V–vi–IV | Guitar distortion, trống nhanh | Trẻ trung, hát chung |
| Alternative | 90–140 | 4/4 | Vòng lạ, hợp âm mượn | Guitar hiệu ứng | Đa dạng |
| Grunge | 90–130 | 4/4 | Power chord, chuyển động từ nhẹ sang mạnh | Guitar dơ, bass nặng | Khàn, u uất |
| Indie rock, Britpop | 100–140 | 4/4 | I–IV–vi–V | Guitar sạch và crunch | Giọng giản dị |
| Progressive rock | 60–160 | Nhịp lẻ 5/4, 7/8, đổi nhịp | Điệu thức, hợp âm phức | Synth, organ, guitar | Bài dài, lời triết lý |
| Post-rock | 60–120 | 4/4, xây dựng dần | Vòng lặp, crescendo | Guitar reverb, dây | Thường không lời |
| Heavy metal | 100–160 | 4/4, ngựa phi | Aeolian, Phrygian | Guitar chùng dây thấp, trống 2 bàn đạp | Cao, mạnh |
| Thrash metal | 160–220 | 4/4 rất nhanh | Phòng chromatic, Phrygian | Guitar palm-mute nhanh | Gay gắt |
| Power, symphonic metal | 140–200 | 4/4 | Giọng thứ, i–bVI–bVII | Guitar, dàn nhạc, hợp xướng | Giọng opera, sử thi |
| Metalcore, nu-metal | 90–160 | 4/4, breakdown nửa nhịp | Chùng dây Drop, Phrygian | Guitar 7 dây, DJ (nu-metal) | Hát sạch xen gầm (scream) |

## 3.5. R&B, Soul, Funk, Gospel

| Thể loại | BPM | Nhịp, tiết tấu | Hòa âm, thang âm | Nhạc cụ đặc trưng | Giọng, lời |
| --- | --- | --- | --- | --- | --- |
| Doo-wop | 60–130 | 12/8, 4/4 | I–vi–IV–V | Bè nam, piano | Hát bè âm tiết vô nghĩa |
| Soul cổ điển | 70–120 | 4/4, 12/8 | Dominant 7, gospel | Kèn đồng, organ, bass | Nội lực, luyến |
| R&B đương đại | 60–100 | 4/4, hi-hat 16 | m9, maj7, 11 | Trống máy, Rhodes, bass synth | Melisma, hát gió |
| Neo-soul | 70–95 | 4/4 lệch nhịp (lazy) | ii9–V13–Imaj9 | Rhodes, bass, trống mộc | Mềm, ngẫu hứng |
| Funk | 95–120 | 4/4 nhấn phách 1, 16 nốt nghịch | 7, 9, một hợp âm vamp | Bass slap, guitar gảy chặn, kèn | Hô đáp |
| Disco, nu-disco | 110–125 | 4/4 kick đều, hi-hat mở phách lẻ | m7–IV, vòng ngắn | Dây, bass quãng tám | Vui, bè nữ |
| Gospel | 60–140 | 4/4, 12/8, 6/8 | Tiến trình gospel, chuyển giọng nhiều lần | Organ Hammond, piano, hợp xướng | Belt, hô đáp với ca đoàn |

## 3.6. Hip-hop và Rap

| Thể loại | BPM | Nhịp, tiết tấu | Hòa âm, thang âm | Nhạc cụ đặc trưng | Giọng, lời |
| --- | --- | --- | --- | --- | --- |
| Old school | 95–110 | 4/4 | Vòng ngắn, sample funk | Trống máy, scratch | Vui, kể chuyện |
| Boom bap | 85–95 | 4/4, kick–snare rõ, swing nhẹ | Sample jazz, m7 | Sample, trống máy | Vần đa âm tiết, lời sâu |
| Trap | 130–170 (cảm giác nửa nhịp 65–85) | Hi-hat cuộn 1/32, snare phách 3 | Giọng thứ, vòng i–VI–III–VII | 808 trượt, hi-hat, pad | Flow ba nốt, ad-lib |
| Drill | 138–145 | Snare lệch, hi-hat trượt | Thứ, Phrygian | 808 trượt, dây u tối | Lạnh, dồn dập |
| Melodic rap | 80–150 | 4/4 | Vòng cảm xúc | Guitar, piano, 808 | Vừa hát vừa rap |
| Lo-fi hip-hop | 70–90 | 4/4 swing, trống lệch | Maj7, m9 | Rhodes, tiếng đĩa than | Thường không lời |
| Phonk | 130–160 | 4/4 | Sample cũ, cowbell | Cowbell, 808 méo | Lời ít, giọng xử lý |
| Rap Việt | 80–150 | 4/4 | Theo nền | Theo nền, có thể lồng nhạc cụ dân tộc | Vần theo thanh điệu, chơi chữ |

## 3.7. Nhạc điện tử

| Thể loại | BPM | Nhịp, tiết tấu | Hòa âm, thang âm | Nhạc cụ đặc trưng | Giọng, lời |
| --- | --- | --- | --- | --- | --- |
| House | 118–128 | Kick 4 phách, clap phách 2–4 | m7, vòng 2–4 hợp âm | Piano house, bass synth | Câu lặp, giọng soul |
| Deep house | 118–124 | Kick 4 phách mềm | m9, m11 | Pad ấm, bass tròn | Thì thầm |
| Tech house | 124–128 | Kick 4 phách, bộ gõ dày | Ít hợp âm | Bộ gõ, bass groove | Cụm từ ngắn |
| Techno | 125–140 | Kick 4 phách cứng | Gần như không hợp âm | Synth modular, trống máy | Không lời |
| Trance | 130–140 | Kick 4 phách, bass nốt móc lệch | i–VI–III–VII | Supersaw, arpeggio | Giọng nữ bay bổng |
| EDM big room, progressive house | 126–130 | Build up–drop | Vòng 4 hợp âm | Supersaw, lead synth | Câu móc trước drop |
| Dubstep | 140 (nửa nhịp 70) | Snare phách 3 | Thứ, Phrygian | Bass wobble | Ít lời |
| Drum and bass | 165–178 | Breakbeat nhanh | m7, m9 | Trống break, bass Reese | Giọng lướt |
| Future bass | 140–160 | Nửa nhịp | Maj7, add9, hợp âm nhấp nháy | Synth chord, giọng cắt ghép | Ngọt, cảm xúc |
| Synthwave | 80–118 | 4/4, snare reverb lớn | Thứ, i–VI–III–VII | Synth analog, trống 80s | Hoài niệm 80s |
| Hardstyle | 150–160 | Kick méo | Thứ | Kick đặc trưng, lead | Câu hô ngắn |
| UK garage | 130–135 | 2 bước (2-step), swing | m7, m9 | Bass, trống lệch | Giọng cắt |
| Tropical house | 100–115 | 4/4 mềm | Maj7 | Marimba, sáo pan, steel drum | Nhẹ, hè |
| Ambient, chillout, downtempo | 60–100 | Tự do hoặc 4/4 chậm | Hợp âm ngân, pedal | Pad, piano, tiếng tự nhiên | Ít hoặc không lời |

## 3.8. Jazz và Blues

| Thể loại | BPM | Nhịp, tiết tấu | Hòa âm, thang âm | Nhạc cụ đặc trưng | Giọng, lời |
| --- | --- | --- | --- | --- | --- |
| Delta blues | 60–100 | 12/8, tự do | 12 ô, thang blues | Guitar mộc, slide | Khàn, AAB |
| Chicago blues | 80–130 | Shuffle | 12 ô, dominant 7 | Guitar điện, harmonica, piano | Mạnh, hô đáp |
| Ragtime | 80–110 | 2/4, tay trái nhảy | Vòng quãng năm | Piano | Không lời |
| Swing, big band | 120–220 | 4/4 swing | ii–V–I, I–vi–ii–V | Kèn đồng, sax, piano, contrabass, trống | Crooner, scat |
| Bebop | 200–320 | Swing rất nhanh | ii–V chuỗi, thay tritone | Sax, trumpet, piano trio | Ngẫu hứng |
| Cool, modal jazz | 100–180 | Swing nhẹ | Điệu thức Dorian | Trumpet câm, piano | Nhẹ |
| Jazz ballad | 50–80 | 4/4 chổi | Maj7, m7b5, hợp âm mượn | Piano, chổi trống, contrabass | Ngân, rubato |
| Gypsy jazz | 160–240 | La pompe (đệm gõ) | m6, dim7 | Guitar acoustic, violin | Nhanh, ngẫu hứng |
| Fusion, smooth jazz | 80–130 | 4/4, 16 nốt | maj9, 13, sử dụng slash chord | Sax, synth, bass fretless | Thường không lời |
| Jazz waltz | 120–180 | 3/4 swing | ii–V | Piano trio | Nhẹ nhàng |

## 3.9. Latin

| Thể loại | BPM | Nhịp, tiết tấu | Hòa âm, thang âm | Nhạc cụ đặc trưng | Giọng, lời |
| --- | --- | --- | --- | --- | --- |
| Salsa | 160–220 | Clave 2-3 / 3-2 | I–IV–V, montuno | Piano montuno, conga, timbales, kèn | Hô đáp (coro–pregon) |
| Cha-cha-chá | 110–130 | "Cha-cha-chá" nốt phách 4 | I–V | Piano, guíro, sáo | Vui, nhảy |
| Rumba, bolero Cuba | 70–100 | Clave rumba | Giọng thứ | Guitar, bongo, maracas | Lãng mạn |
| Bachata | 120–140 | 4/4, phách 4 nhấn | i–iv–V | Guitar đánh nốt, bongo, güira | Tình ca buồn |
| Reggaeton | 88–100 | Dembow (3+3+2) | i–VI–III–VII | Trống máy dembow, synth | Rap–hát xen kẽ |
| Cumbia | 80–110 | 2/4, guíro đều | I–V | Accordion, guíro, sáo | Dân dã |
| Merengue | 120–160 | 2/4 nhanh | I–V | Accordion, támbora, güira | Vui, nhanh |
| Samba | 90–105 (cảm giác 2) | 2/4, surdo phách 2 | ii–V Brazil | Bộ gõ samba, cavaquinho | Lễ hội |
| Bossa nova | 110–140 | 2/4 lệch | maj7, m7, dim, chromatic | Guitar nylon, sáo, trống chổi | Hát thủ thỉ |
| Tango | 60–70 (cảm giác 2/4 hoặc 4/4 mạnh) | Marcato, habanera | i–iv–V, Andalucía | Bandoneon, violin, piano, contrabass | Kịch tính |
| Flamenco | Linh hoạt | Compás 12 phách | Andalucía i–bVII–bVI–V, Phrygian dominant | Guitar flamenco, cajon, vỗ tay (palmas) | Cante jondo, ngân |
| Mariachi, ranchera | 80–180 | 3/4, 6/8, 2/4 | I–IV–V | Trumpet, violin, vihuela, guitarrón | Hào sảng, kéo dài |
| Latin pop | 90–110 | 4/4, dembow nhẹ | Vòng pop | Guitar Latin, bộ gõ | Song ngữ |

## 3.10. Country, Folk, Celtic

| Thể loại | BPM | Nhịp, tiết tấu | Hòa âm, thang âm | Nhạc cụ đặc trưng | Giọng, lời |
| --- | --- | --- | --- | --- | --- |
| Country | 80–130 | 4/4 "train beat", 3/4 | I–IV–V | Guitar steel, banjo, fiddle, pedal steel | Kể chuyện, giọng mũi |
| Country pop | 90–120 | 4/4 | I–V–vi–IV | Guitar mộc, trống pop | Câu móc rõ |
| Bluegrass | 140–220 | 2/4 nhanh | I–IV–V | Banjo, mandolin, fiddle, dobro, contrabass | Hát bè cao |
| Americana, folk | 70–120 | 4/4, 3/4 | I–IV–V, Mixolydian | Guitar mộc, harmonica | Chân thật |
| Celtic (jig, reel) | Jig 110–130 (6/8), reel 100–120 (4/4) | 6/8, 4/4 | Dorian, Mixolydian | Fiddle, tin whistle, bodhrán, kèn túi | Bài dân ca, hát chung |
| Sea shanty | 90–120 | 4/4, 6/8 | I–V | Giọng tập thể, vỗ tay, dậm chân | Hô đáp lao động |
| Polka | 110–130 | 2/4 bass–hợp âm | I–V | Accordion, tuba, clarinet | Vui |

## 3.11. Caribbean và châu Phi

| Thể loại | BPM | Nhịp, tiết tấu | Hòa âm, thang âm | Nhạc cụ đặc trưng | Giọng, lời |
| --- | --- | --- | --- | --- | --- |
| Reggae | 60–90 | One drop, guitar phách lệch (skank) | I–IV, i–VII | Guitar skank, bass nặng, organ | Thông điệp, hòa bình |
| Ska | 110–160 | Phách lệch nhanh | I–IV–V | Kèn đồng, guitar | Vui |
| Dancehall | 90–110 | Riddim, dembow | Thứ, ít hợp âm | Trống máy | Toasting (nói–hát) |
| Calypso, soca | 100–160 | 2/4 | I–IV–V | Steel pan, kèn | Lễ hội, châm biếm |
| Afrobeat cổ điển | 100–130 | Đa nhịp, vamp dài | Một hợp âm, Dorian | Kèn đồng, guitar đan, bộ gõ | Thông điệp xã hội |
| Afrobeats (đương đại) | 95–115 | 3+3+2, bộ gõ lệch | Maj7, vòng 4 hợp âm | Log drum, shaker, guitar | Nhẹ nhàng, nhảy |
| Amapiano | 110–115 | Log drum, shaker 16 | m7, m9 | Log drum, piano, pad | Giọng lướt, câu lặp |
| Highlife, soukous | 110–150 | Đa nhịp | I–IV–V | Guitar đan nốt, kèn | Vui, hô đáp |

## 3.12. Châu Á và Trung Đông

| Thể loại | BPM | Nhịp, tiết tấu | Hòa âm, thang âm | Nhạc cụ đặc trưng | Giọng, lời |
| --- | --- | --- | --- | --- | --- |
| Enka (Nhật) | 60–100 | 4/4, 3/4 | Thang Yonanuki thứ | Dàn dây, guitar, shakuhachi | Kobushi (luyến rung) |
| Trot (Hàn) | 90–130 | 2/4 | Ngũ cung thứ | Synth, kèn | Luyến, vui hoặc buồn |
| Cổ phong, Guofeng (Trung) | 60–90 | 4/4 | Ngũ cung + pop | Guzheng, địch tử, nhị hồ, pipa | Lời cổ văn, hình ảnh |
| Cantopop | 65–110 | 4/4 | Vòng pop | Piano, dây | Giữ 6 thanh Quảng Đông |
| Bollywood, filmi | 90–130 | 4/4, nhịp tabla | Raga + pop | Tabla, dhol, sitar, dây | Melisma, nữ giọng cao |
| Nhạc cổ điển Hindustan | Tự do rồi nhanh dần | Tāla (chu kỳ 16, 10, 7 phách) | Raga | Sitar, sarod, tabla, tanpura | Ngẫu hứng theo raga |
| Bhangra | 90–110 | Dhol nhịp chẵn–lẻ | Một hợp âm | Dhol, tumbi | Hô vui |
| Gamelan (Indonesia) | Linh hoạt | Chu kỳ lặp, tầng lớp nhanh chậm (irama) | Thang slendro (5 âm), pelog (7 âm) | Cồng gong, saron, bonang, trống kendang | Thường không lời; có giọng sinden |
| Dangdut | 70–130 | Trống kendang | Thứ, điệu đại chúng | Trống kendang, sáo suống, guitar | Luyến |
| Luk thung, mor lam (Thái, Lào) | 90–140 | 2/4, 4/4 | Ngũ cung | Khaen (kèn bè), phin, trống | Kể chuyện nông thôn |
| Arabic pop, maqam | 70–130 | Iqa' (maqsum, baladi, saidi) | Maqam có nửa cung giáng (Hijaz, Rast, Bayati) | Oud, qanun, darbuka, ney | Melisma |
| Thổ Nhĩ Kỳ, Ba Tư | 60–140 | Nhịp lẻ 9/8 (aksak) | Makam, dastgah | Saz, ney, kemençe, daf | Ngân, luyến |

## 3.13. Cổ điển, sân khấu và nhạc cho hình ảnh

| Thể loại | BPM | Nhịp, tiết tấu | Hòa âm, thang âm | Nhạc cụ đặc trưng | Giọng, lời |
| --- | --- | --- | --- | --- | --- |
| Baroque | 60–140 | Nhịp đều, đối điểm | Vòng quãng năm, bass liên tục | Harpsichord, dây, organ | Aria, hợp xướng |
| Cổ điển (thời Mozart) | 60–160 | Rõ câu 4–8 ô | Chức năng I–IV–V | Dàn nhạc cổ điển | Trong sáng |
| Lãng mạn | Rubato | Tự do co giãn | Hợp âm mượn, chromatic, chuyển giọng xa | Dàn nhạc lớn, piano | Cảm xúc mạnh |
| Ấn tượng | Tự do | Mờ phách | Toàn cung, ngũ cung, hợp âm song song | Harp, sáo, dây | Màu sắc |
| Tối giản (minimalism) | 60–140 | Mẫu lặp lệch pha | Hợp âm trầm tĩnh | Piano, marimba, dây | Ít lời |
| Opera, aria | Linh hoạt | Recitative–aria | Hòa âm cổ điển–lãng mạn | Dàn nhạc | Giọng opera theo loại (`04-giong-hat.md`) |
| Ca khúc nghệ thuật (lied, art song) | Linh hoạt | Tự do | Phức tạp | Piano đệm ngang hàng giọng | Lời thơ |
| Hợp xướng, thánh ca | 60–110 | 4/4, 3/4 | SATB, hòa âm 4 bè | Organ, piano | Trang nghiêm |
| A cappella | Theo thể loại | Beatbox thay trống | Xếp bè gần | Chỉ giọng người | Bè âm tiết |
| Nhạc kịch (musical) | 60–160 | Đa dạng | Pop + cổ điển, chuyển giọng kịch tính | Dàn nhạc pit | Kể chuyện, bài "tôi muốn" (I want song) |
| Nhạc phim | Theo cảnh | Theo cảnh | Leitmotif, chromatic mediant | Dàn nhạc, synth | Ít lời |
| Epic, trailer | 70–140 | Build 3 hồi | i–bVI–bIII–bVII | Dàn nhạc, taiko, hợp xướng, riser | Hợp xướng La-tinh giả |
| Nhạc game (8-bit, orchestral) | 100–180 | Vòng lặp liền mạch | Đơn giản hoặc dàn nhạc | Chiptune, dàn nhạc | Không lời |
| Neo-classical piano | 60–90 | 4/4, 3/4 | Vòng đơn giản, lặp | Piano, dây nhỏ | Không lời |

## 3.14. Nhạc có chức năng

| Loại | BPM | Độ dài | Yêu cầu riêng | Nhạc cụ gợi ý |
| --- | --- | --- | --- | --- |
| Jingle quảng cáo | 100–130 | 5, 15, 30, 60 giây | Tên thương hiệu trong 3–5 giây đầu hoặc cuối; logo âm thanh 3–5 nốt | Theo hình ảnh thương hiệu |
| Nhạc hiệu chương trình | 90–140 | 10–60 giây, có bản cắt 5 giây | Nhận diện nhanh, kết dứt khoát | Theo chương trình |
| Nhạc thiếu nhi, mầm non | 100–130 | 1–2,5 phút | Âm vực hẹp (`04-giong-hat.md`), lặp nhiều, có động tác | Xylophone, ukulele, vỗ tay |
| Hành khúc, đội ca, bài truyền thống | 100–120 | 2–3 phút | 2/4 hoặc 4/4 đi bước, hát tập thể được | Kèn đồng, snare |
| Cổ động thể thao | 120–140 | 1–3 phút | Câu hô dễ nhớ, dậm chân–vỗ tay | Trống lớn, guitar |
| Nhạc cưới | 60–120 | 3–4 phút | Lời chúc phúc, tránh từ chia ly | Piano, dây, guitar mộc |
| Nhạc thiền, thư giãn, ngủ | 50–70 hoặc không phách | 10–60 phút | Không cao trào, tránh âm cao gắt | Pad, chuông xoay, sáo, tiếng tự nhiên |
| Nhạc tập thể dục | 120–160 | Theo bài tập | BPM khớp động tác, đếm nhịp 8 | Trống máy |
| Nhạc lễ tôn giáo | 50–100 | Theo nghi lễ | Đúng giáo lý, từ ngữ trang nghiêm | Organ, chuông, mõ |
| Nhạc Tết, lễ hội | 100–130 | 3 phút | Từ ngữ chúc Tết, màu ngũ cung | Nhạc cụ dân tộc + pop |
| Bài ca doanh nghiệp, tổ chức | 100–130 | 3 phút | Tên tổ chức, giá trị cốt lõi, hát tập thể | Pop-rock hoặc hành khúc |

## 3.15. Cấu trúc bài hát chuẩn

Ký hiệu: I intro, V verse (đoạn kể), PC pre-chorus (đoạn dẫn), C chorus (điệp khúc), PoC post-chorus, B bridge (đoạn chuyển), S solo, O outro.

| Khung | Sơ đồ | Hay dùng cho |
| --- | --- | --- |
| Verse–chorus hiện đại | I–V–PC–C–V–PC–C–B–C–C–O | Pop, rock quốc tế |
| V-pop sau 2014 | I–V–(PC)–C–V–(PC)–C–(Rap)–C–O, cả bài trên một vòng lặp | V-pop, folk fusion, rap Việt |
| Có post-chorus | I–V–PC–C–PoC–V–PC–C–PoC–B–C | K-pop, dance-pop |
| AABA 32 ô | A–A–B–A (mỗi phần 8 ô) | Jazz standard |
| Khổ đánh số + ĐK (Việt trước 2000) | 1. – 2. – ĐK – 3. (AABA hoặc AA–B–A) | Bolero, nhạc vàng, trữ tình, tiền chiến |
| Strophic (lời nối tiếp) | A–A–A–A | Dân ca, folk, thiếu nhi, thánh ca |
| 12 ô blues | AAB mỗi khổ | Blues, rock and roll |
| Hip-hop | I–Hook–V16–Hook–V16–Hook–O | Rap |
| EDM | I–Build–Drop–Break–Build–Drop–O | Điện tử |
| Through-composed | A–B–C–D (không lặp) | Ca khúc nghệ thuật, nhạc phim, nhạc kịch |
| Rondo, điệp khúc dân gian | A–B–A–C–A | Nhạc thiếu nhi, dân ca có vế xướng–xô |
| Jingle | Hook–thông điệp–Hook + logo âm thanh | Quảng cáo |

**Ghi chú hình thức ca khúc Việt** ([BC – tập mẫu] 37 bài hopamchuan.com; nhãn đoạn do công cụ tóm tắt suy ra nên số đếm là ước lượng):
- **Trước 2000:** dạng **khổ đánh số và ĐK "1., 2., ĐK, 3."** = AABA hoặc AA–B–A (6 bài, ví dụ Đắp mộ cuộc tình, Thành phố buồn); dạng **strophic** một khung lặp không có ĐK rõ (4 bài, ví dụ Con thuyền không bến, Diễm xưa). Nhạc Trịnh: strophic hoặc A A–ĐK ngắn–A A.
- **Sau 2014:** nhãn **Intro–Verse–(Pre-chorus)–Chorus–Rap**; 3 bài chèn đoạn rap vào bài pop; 8 bài (đều sau 2014) dùng **một vòng hợp âm 2–5 hợp âm cho mọi đoạn** → tương phản giữa các đoạn đến từ mật độ phối, không từ đổi hợp âm.
- **Bridge có nhãn chỉ 1/37 bài** (Buồn tàn thu); pre-chorus có nhãn chỉ 1/37 (See tình). Không mặc định thêm bridge cho bài Việt.
- **Nâng tông ở ĐK cuối: 0/37** bản hợp âm → không phải đặc trưng đã ghi nhận; chỉ dùng khi có lý do sân khấu (bản hợp âm có thể bỏ qua chi tiết dàn dựng, cần nghe bản thu để kiểm chứng).
- [QU] Khung thực hành: trữ tình và bolero "2 khổ phiên khúc, ĐK, 1 khổ"; V-pop Verse–Pre-chorus–Chorus kèm rap hoặc interlude; điệp khúc có âm vực cao hơn đoạn A. [BC] Câu nhạc thường 4 ô, kết bằng cadence; đoạn nhạc gồm câu hỏi kết lửng và câu đáp kết trọn; đỉnh cao trào thường ở nửa sau bài.

## 3.16. Quy tắc lai thể loại và thể loại chưa có trong bảng

- **Lai thể loại:** chọn một thể loại **nền** quyết định nhịp và cấu trúc, một thể loại **màu** góp nhạc cụ, thang âm hoặc chất giọng; ghi rõ tỷ lệ, ví dụ "70% pop ballad, 30% nhạc cụ dân tộc".
- **Thể loại chưa có:** xếp vào họ gần nhất, nêu 6 thông số ước định, ghi rõ "suy luận từ họ …" và đề nghị người dùng xác nhận hoặc gửi bài tham khảo.
