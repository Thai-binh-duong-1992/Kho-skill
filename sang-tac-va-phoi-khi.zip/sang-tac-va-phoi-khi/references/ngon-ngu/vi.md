> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Tiếng Việt: thanh–nhạc, đặt chữ vào nhịp, âm vực, chọn tông, phương ngữ. C4 = Đô giữa; âm vực ghi theo cao độ thực trừ khi nói rõ. Nhãn: [BC] có bằng chứng · [QU] quy ước thực hành/suy luận · [Cần kiểm chứng].

# Tiếng Việt: khớp lời với giai điệu

Tiếng Việt có 6 thanh (giọng Bắc). Giai điệu đi **ngược hướng** chuyển thanh thì người nghe dễ nghe ra chữ khác ("lả" thành "là"). Đây là ràng buộc quan trọng nhất khi đặt lời tiếng Việt, nhưng là **ràng buộc yếu** (xem mục 1).

Tệp liên quan: `references/12-thi-luat.md` (vần, bằng–trắc, thể thơ, V1–V16) · `references/13-nghe-viet-loi.md` (nghề viết lời, L1–L12) · `references/04-giong-hat.md` (âm vực mọi loại giọng) · `references/07-loi-ca.md` (kỹ thuật lời chung).

## 0. Hai lưới khác nhau – không trộn

| Câu hỏi | Lưới dùng | Chia sáu thanh |
|---|---|---|
| **Cao độ khi hát** (nốt đi lên hay xuống) | Nhóm thanh theo **điểm kết thúc (offset)** của thanh (Ladd & Kirby) | Cao: sắc, ngã · Trung: ngang · Thấp: huyền · Rất thấp: hỏi, nặng |
| **Thi luật** (vị trí luật, vần) | Bằng–trắc | Bằng: ngang, huyền · Trắc: sắc, hỏi, ngã, nặng |

**[BC]** Bằng/trắc **không** phải là phân nhóm đúng cho cao độ hát: huyền là "bằng" nhưng thấp; ngã là "trắc" nhưng cao; hỏi, nặng là "trắc" và rất thấp. Chỉ dựa vào bằng/trắc để đặt nốt sẽ dễ làm lời bị nghe sai. **Không dùng bằng/trắc để đặt cao độ.**

## 1. QUY TẮC THANH–NHẠC: tránh ngược hướng theo nhóm thanh

### 1.1. Bảng nhóm thanh (dùng cho mọi bước kiểm tra)

| Thanh | Ví dụ | Đường nét (Chao) | Nhóm cao độ | Mã số (script) | Mã chữ (T1) |
|---|---|---|---|---|---|
| Sắc | má | 24 | **Cao** | 3 | C |
| Ngã | mã | 3ˀ5 | **Cao** | 3 | C |
| Ngang | ma | 33 | **Trung** | 2 | T |
| Huyền | mà | 32 | **Thấp** | 1 | Th |
| Hỏi | mả | 21 | **Rất thấp** | 0 | RT |
| Nặng | mạ | 21ˀ | **Rất thấp** | 0 | RT |

Nguồn: Kirby & Ladd (2016), 20 bài tân nhạc, dữ liệu công bố (DOI 10.7488/ds/1434); Ladd & Kirby. [BC]

### 1.2. Quy tắc

So **từng cặp âm tiết liền nhau** (chữ trước → chữ sau):

| Nhóm thanh chữ sau so với chữ trước | Nốt chữ sau nên | Không được (cờ đỏ) |
|---|---|---|
| Tăng (ví dụ ngang → sắc; hỏi → huyền) | Đi lên **hoặc đứng yên** | Đi xuống (ngược hướng) |
| Giảm (ví dụ sắc → ngang; ngang → huyền; huyền → nặng) | Đi xuống **hoặc đứng yên** | Đi lên (ngược hướng) |
| Bằng nhau (ngang–ngang; sắc–ngã; hỏi–nặng) | Đứng yên, hoặc đi lên/xuống nhẹ | — |

- **[BC] Ràng buộc yếu, "tránh ngược hướng":** với tiếng Việt, **tránh ngược hướng quan trọng hơn đạt song song hoàn toàn**. Không cần mọi cặp cùng hướng; chỉ cần ít cặp ngược hướng.
- **[BC] Khoảng 77%** cặp âm tiết liền nhau trong tân nhạc có giai điệu **cùng hướng** với thanh (Kirby & Ladd 2016).
- **[BC] Chuyển động xiên (một bên đứng yên) được dung nạp**, nhất là với chuỗi thanh ngang. Chuyển động ngược hướng tương đối hiếm.
- **[BC]** Pop Thái (1.775 cặp âm tiết): người viết chủ yếu **tránh ngược hướng** thay vì tối đa hóa song song; bài chịu ảnh hưởng rap có tỉ lệ khớp **dưới 50%** (Ketkaew & Suwannarat, ICPhS 2023).
- **[QU]** Ưu tiên nghiêm ở **chữ then chốt**: tên riêng, câu móc/tiêu đề, chữ ở phách mạnh, chữ ngân dài, chữ có cặp tối thiểu (mục 2). Hư từ (thì, là, của, mà) cho phép lệch nhẹ hơn.

> **(thay quy tắc cũ của bản 1.0:** "so cao độ của nốt mang chữ với nốt ngay trước: huyền, hỏi, nặng thấp hơn nốt trước; sắc, ngã cao hơn nốt trước" và "hai chữ cùng thanh bằng có thể cùng cao độ". Quy tắc mới so **hướng chuyển nhóm thanh** của cặp chữ, không gán hướng tuyệt đối cho từng thanh. Ví dụ: hỏi → huyền là nhóm **tăng** (0 → 1), nên nốt huyền đi lên hoặc đứng yên, không bắt buộc đi xuống. Ngang → huyền khác nhóm (2 → 1) dù cùng "bằng". Đứng yên luôn chấp nhận được.**)**

### 1.3. Dữ liệu dân ca: cùng xu hướng, không phải luật cứng

| Nguồn | Phát hiện | Nhãn |
|---|---|---|
| *Ru con miền Nam*, 412 đồ thị cao độ (Phan & Ngô) | Huyền hát đi xuống **81/90**; sắc đi lên **28/42** (dạng cong lõm); hỏi/ngã dạng lõm **42/72**; ngang hát phẳng ở âm vực cao. Tương hợp mạnh là điển hình; lệch có chủ ý tạo cá tính | [BC] |
| Hoàng Kiều (Tạp chí Nghệ thuật 57/2025) | Sắc kéo giai điệu lên, huyền xuống; hỏi, ngã luyến uốn phức tạp hơn | [BC] |
| Quan họ (Hoàng Minh Thùy, USSH–VNU) | Ba tầng cao độ ứng với thanh của lời lục bát; có mô hình đi ngược thanh gọi là **"biến thanh"** | [BC] |
| Ca Huế (Trần Kiều Lại Thủy 2012) | Khoảng cách thanh hẹp nên nhảy quãng 4, 5, 6 tự do hơn; trong *Tứ đại cảnh*, "vườn" (huyền) hát cao hơn "cũ" (ngã) | [BC] |

Tương quan thanh–nhạc **phụ thuộc phương ngữ** (mục 9).

## 2. Lỗi nghe nhầm và cặp tối thiểu

**[BC]** Ví dụ ghi nhận (Nghiêm Nguyễn): "lả" → "là" (*Mộng dưới hoa*); "đắm say" → "đắng cay" (*Hướng về Hà Nội*); "trăng" → "trâu" (*Biết đâu nguồn cội*); "thổi suốt" → "thổi xuống" (*Một cõi đi về*). Báo chí chủ yếu bàn **ca sĩ hát sai lời**; nguyên nhân nhạc sĩ nêu là bản sao sai, karaoke sai chính tả, học truyền khẩu. NS Đức Trịnh đề xuất ca sĩ chép tay bản nhạc; NS Đức Huy: hát sai một giới từ có thể làm lệch nội dung bài. Bài khoa học về ca sĩ hát lệch chuẩn tiếng Việt (Trần Quốc Việt & Trần Yến Nhi 2023) mới đọc được tóm tắt.

**[QU]** Nhiều lỗi là **cặp tối thiểu** (chỉ khác thanh hoặc một âm) – đúng loại lỗi do giai điệu ngược thanh, hoặc nốt ngân làm mất âm cuối, gây ra. **Không tìm thấy** checklist đặt lời được công bố của Phạm Duy, Trịnh Công Sơn, Phó Đức Phương, Nguyễn Văn Chung hay Hứa Kim Tuyền; bộ T/N dưới đây tổng hợp từ ngôn ngữ học (Ladd & Kirby, Brunelle, Phan & Ngô), không phải "quy tắc của nhạc sĩ X".

**Danh sách cặp dễ nhầm cần soát** [QU] (giữ từ bản 1.0, bổ sung theo 4.1):
lả/là · đắm/đắng · trăng/trâu · suốt/xuống · nhớ/nhờ · má/mà/mạ · có/cò · tới/tôi · bên/bến · yêu/yếu · thương/thường · mai/mãi · về/vế · chờ/chở · ở/ơ.

## 3. Bộ kiểm tra thanh–nhạc T1–T10 (chạy cho từng câu)

Mã nhóm thanh: **Cao = sắc, ngã · Trung = ngang · Thấp = huyền · Rất thấp = hỏi, nặng** (Ladd & Kirby).

| # | Bước kiểm tra | Cách làm | Cờ đỏ | Cơ sở |
|---|---|---|---|---|
| T1 | Gán nhóm thanh | Ghi C/T/Th/RT dưới từng âm tiết của lời | — | [BC] |
| T2 | So hướng từng cặp chữ liền nhau | Nhóm thanh tăng thì nốt đi lên hoặc đứng yên; nhóm giảm thì nốt đi xuống hoặc đứng yên | Nhạc đi **ngược** hướng thanh | [BC] hướng; ngưỡng là [QU] |
| T3 | Đếm tỉ lệ | Mục tiêu khoảng 70–80% cùng hướng, dưới khoảng 10% ngược hướng | Trên 10% ngược hướng | [QU] từ số liệu Việt và Thái |
| T4 | Kiểm tra cặp tối thiểu | Với mỗi chữ then chốt về nghĩa: có từ nào chỉ khác một dấu không (lả/là, đắm/đắng)? Nếu có, giai điệu phải "nói đúng" thanh đó | Chữ then chốt bị ngược hướng | [QU] |
| T5 | Huyền và sắc | Huyền kết bằng nét đi xuống hoặc nốt thấp hơn chữ trước; sắc ở nốt cao hơn hoặc có luyến nhẹ đi lên | Huyền nhảy lên; sắc rơi xuống | [BC] Ru con: huyền xuống 81/90, sắc lên 28/42 |
| T6 | Hỏi, ngã, nặng | Hỏi đặt nốt thấp, có thể luyến xuống rồi lên; nặng dùng nốt ngắn, thấp, không luyến dài; ngã giọng Bắc nên là nốt ngắn hoặc luyến hai nốt đi lên | Nặng trên nốt ngân dài; ngã (giọng Bắc) đặt thấp hơn chữ trước | [QU] |
| T7 | Chuỗi cùng thanh | Hai chữ cùng thanh, nhất là ngang–ngang, có thể chung một nốt | — | [BC] chuyển động xiên được dung nạp |
| T8 | Nốt cao trào | Nốt cao nhất bài mang thanh ngang hoặc sắc, nguyên âm mở (a, o, e), âm cuối mở hoặc mũi | Hỏi hoặc nặng trên nốt cao nhất | [QU] |
| T9 | Vi phạm có chủ ý | Nếu buộc phải ngược hướng, đặt ở chỗ ngắt câu hoặc ở chữ mà ngữ cảnh đã rõ nghĩa | Vi phạm giữa một từ ghép | [QU]; "biến thanh" quan họ là tiền lệ |
| T10 | Phương ngữ mục tiêu | Xác định ca sĩ và khán giả Bắc, Trung hay Nam rồi chỉnh mức nghiêm (mục 9) | Nét đúng với giọng Nam nhưng lệch với giọng Bắc | [BC] phương ngữ; hệ quả [QU] |

Ghi chú: T5 nói "huyền thấp hơn chữ trước" là xu hướng dân ca và đúng khi chữ trước thuộc nhóm Trung/Cao; khi chữ trước là hỏi/nặng (Rất thấp), áp dụng T2 (huyền được đi lên hoặc đứng yên). [QU]

## 4. Ngôn điệu và đặt chữ vào nhịp

### 4.1. Bằng chứng ngôn điệu

- **[BC]** Không có đồng thuận về bản chất, thậm chí sự tồn tại, của trọng âm từ tiếng Việt. Tiếng Việt miền Nam: **âm tiết cuối ngữ đoạn dài hơn khoảng 41%** các âm tiết khác; ranh giới từ ghép/cụm từ không rõ (Brunelle 2017, JIPA).
- **[BC]** Trọng âm tiếng Việt chủ yếu thể hiện bằng kéo dài nguyên âm. Hầu hết thực từ mang trọng âm; loại từ "cái" không bao giờ mang trọng âm; "cho", "để" mang trọng âm khi là động từ, không mang khi là hư từ. Đặt sai trọng âm có thể làm vỡ từ: "bảo với" (một từ) ≠ "bảo" + "với" (Mai Ngọc Chừ và cs.).
- **[BC]** Ngữ liệu đọc tin: khoảng ngừng trung bình ở ranh giới ngữ điệu ≈ **252 ms**; ở ranh giới ngữ đoạn nhỏ hơn **139–219 ms** (Nguyen T.T. Trang và cs., INTERSPEECH 2014).
- **[QU]** Ba quy tắc suy ra: chữ cuối ngữ đoạn và thực từ quan trọng ở phách mạnh/nốt dài; hư từ, loại từ (cái, con, của, thì, mà, là, những) ở phách yếu/nốt ngắn; không ngắt hơi giữa hai âm tiết của từ ghép hay từ láy.

### 4.2. Bộ kiểm tra đặt chữ vào nhịp N1–N9

| # | Bước kiểm tra | Cách làm | Cơ sở |
|---|---|---|---|
| N1 | Đánh dấu ranh giới ngữ đoạn | Gạch "/" ở cuối mỗi cụm nghĩa và "//" ở cuối mệnh đề | [BC] ranh giới ngữ đoạn kéo dài âm tiết (Brunelle) |
| N2 | Chữ cuối ngữ đoạn | Đặt trên phách mạnh hoặc nốt dài | [QU] từ mức kéo dài khoảng 35–41% |
| N3 | Thực từ và hư từ | Thực từ quan trọng ở phách mạnh; hư từ, loại từ (cái, con, của, thì, mà, là, những) ở phách yếu hoặc nốt ngắn | [BC] thực từ mang trọng âm (Mai Ngọc Chừ, qua ngonngu.net) |
| N4 | Không tách từ | Không đặt nghỉ hay lấy hơi giữa hai âm tiết của từ ghép hoặc từ láy ("hạnh / phúc" là lỗi); chỗ lấy hơi trùng ranh giới mệnh đề | [BC] đặt sai trọng âm làm vỡ từ; quy tắc [QU] |
| N5 | Âm cuối của nốt ngân | Nốt ngân dài dùng âm tiết kết bằng nguyên âm, -m, -n, -ng, -nh; tránh âm tắc -p, -t, -c, -ch | [QU]; nhất quán với thực hành đặt lời Việt. Được củng cố bởi thi luật: vần khép luôn trắc (12-thi-luat.md, V8) |
| N6 | Mật độ âm tiết | Ballad khoảng 1–2 âm tiết mỗi phách; rap khoảng 2–4; bolero luyến láy dày cuối câu | [QU], chưa có số liệu đo |
| N7 | Lục bát | Chữ chẵn (mang luật) vào phách mạnh; vần chữ 6 và chữ 8 trùng nốt ngân cuối tiết hoặc câu; chữ 6 và chữ 8 câu bát là một huyền, một ngang, nên nốt cuối câu bát có sẵn hướng (huyền thấp hơn ngang) | Cách đặt nhịp [QU]. Luật huyền–ngang [BC] (VietJack – SGK Ngữ văn 7; vjol – KHXH). Xem 12-thi-luat.md |
| N8 | Hook rap được hát | Khi rapper chuyển sang hát hook trên nốt cố định, chạy lại T2–T6 cho hook | [QU]; chưa có nghiên cứu về thanh điệu trong rap Việt (Komaniecki 2020) |
| N9 | Bản lời chuẩn | Phát hành lyric sheet hoặc bản ký âm chuẩn kèm demo để ca sĩ không học sai | [QU] từ khuyến nghị NS Đức Trịnh, Đức Huy |

### 4.3. Quy ước thực hành giữ từ bản 1.0 [QU]

- Một chữ = một âm tiết = thường một nốt; luyến hai nốt cho chữ ngân.
- Câu cùng vị trí giữa các đoạn lệch không quá 2 âm tiết (chạy `scripts/dem-am-tiet.py`); khi muốn hát chung một giai điệu thì phải bằng số chữ (V2).
- Câu 5–8 chữ dễ hát chung; câu trên 10 chữ chỉ hợp rap hoặc verse kể chuyện.
- Ngắt nhịp theo cụm nghĩa: 8 chữ ngắt 4/4 hoặc 3/5; không ngắt giữa từ ghép ("bệnh / viện").

## 5. Lục bát, vần và ánh xạ sang câu nhạc

**[BC]** Luật bằng/trắc ở chữ chẵn; chữ lẻ tự do.
- Câu lục (6): B-B-T-T-B-B (bắt buộc chữ 2 B, 4 T, 6 B).
- Câu bát (8): B-B-T-T-B-B-T-B (bắt buộc chữ 2 B, 4 T, 6 B, 8 B).
- Chữ 6 câu lục vần chữ 6 câu bát (**vần lưng**); chữ 8 câu bát vần chữ 6 câu lục kế tiếp (**vần chân**). Vần lục bát là **vần bằng**.
- **Luật trầm bổng [BC]:** chữ 6 và chữ 8 câu bát cùng bằng nhưng **khác thanh: một huyền (trầm), một ngang (bổng)** (VietJack – SGK Ngữ văn 7; bài tạp chí dẫn Bùi Văn Nguyên & Hà Minh Đức). Wikipedia tiếng Anh không ghi quy tắc này.
- Nhịp lục bát chủ yếu chẵn (2/2/2, 4/4) (Nguyễn Thị Thanh Nguyên & Nguyễn Văn Bản 2022).
- Lý và hò Nam Bộ đặt lời trên lục bát kèm tiếng đệm; hát Nam của hát bội dùng lục bát và song thất; mưỡu ca trù dùng câu 6–8; song thất lục bát đặt hai câu 7 trước cặp 6–8 (*Chinh phụ ngâm*, *Cung oán ngâm khúc*).
- Đặt lời Việt cho nhạc nước ngoài: ưu tiên dễ hát hơn dịch sát, cân số âm tiết, đảo câu, thêm bớt từ đệm, thường kết câu bằng nguyên âm để ngân.

**[QU] Ánh xạ vào ô nhịp** (chưa có nghiên cứu Việt Nam mô tả quy trình này):
- Chữ chẵn vào phách mạnh hoặc nốt dài; vần chữ 6 và chữ 8 trùng nốt ngân cuối tiết/câu.
- Chữ thanh huyền cuối câu làm nốt kết về chủ âm.
- Vì luật trầm bổng buộc chữ 6 và chữ 8 câu bát là một huyền, một ngang, câu bát luôn có sẵn chênh lệch cao độ ở hai nốt cuối (huyền Thấp, ngang Trung): **kết ở ngang = kết lửng; kết ở huyền về chủ âm = kết trọn.**

**Vần tóm tắt** (đầy đủ ở 12-thi-luat.md):
- Vần = phần sau phụ âm đầu (âm đệm + âm chính + âm cuối), bỏ thanh; âm đầu không tính. Hai tiếng hiệp vần **cùng nhóm bằng hoặc trắc**, không cần cùng thanh. [BC]
- **Vần khép (-p, -t, -c, -ch) chỉ mang sắc hoặc nặng → luôn là vần trắc** [BC]; không bao giờ đặt ở vị trí vần bằng (chữ 6, 8 lục bát; cuối câu điệp khúc ngân). [QU]
- Vần gần trong pop (-an/-ang, -in/-inh, -ơn/-ơng, -ăn/-ăng; miền Nam phát âm gần nhau) – chấp nhận như **vần thông** ở phiên khúc. [QU]
- Rap Việt: phân vần theo số âm tiết (vần đơn, đôi, ba) [BC]; ví dụ vần cả thanh "bước/trước", "lượt/được" [QU].

## 6. Hình thức ca khúc Việt

**[BC]**
- Motif là đơn vị nhỏ nhất; câu nhạc thường 4 ô và kết bằng một cadence; đoạn nhạc = câu hỏi kết lửng + câu đáp kết trọn (Rothfarb). Hình thức hai phần: AB, AABA, ABAC; đỉnh cao trào thường ở nửa sau bài.
- Tập mẫu 37 bài (hopamchuan.com): bài **trước 2000** thường dạng **khổ đánh số + ĐK** (1., 2., ĐK, 3.) tức AABA hoặc AA–B–A (6 bài, ví dụ *Đắp mộ cuộc tình*, *Thành phố buồn*); 4 bài strophic không có ĐK rõ (*Con thuyền không bến*, *Diễm xưa*). Bài **sau 2014** có nhãn Intro/Verse/(Pre-chorus)/Chorus/Rap.
- **Bridge có nhãn chỉ 1/37 bài** (*Buồn tàn thu*); pre-chorus có nhãn 1 bài (*See tình*); 3 bài chèn đoạn rap vào pop.
- Giáo trình Việt (chưa đọc được toàn văn): Ngọc Kôn, *Bạn muốn sáng tác ca khúc?* (2007); Hồng Đăng, *Sáng tạo âm nhạc*; Lê Quang Vịnh, *Biên tập và phối khí âm nhạc*; Đặng Hữu Phúc, *Lý thuyết âm nhạc cơ bản*.

**[QU]** Nhãn đoạn trên trang hợp âm do công cụ suy ra, nên số bài AABA là ước lượng. Khung thực hành: trữ tình, bolero dùng "2 khổ phiên khúc, ĐK, 1 khổ"; V-pop dùng Verse–Pre-chorus–Chorus kèm rap hoặc interlude; điệp khúc có âm vực cao hơn đoạn A.

## 7. Nhịp cổ truyền: phách mạnh ở cuối chu kỳ

**[BC]**
- Bài hơi Bắc tiết tấu nhanh; song lang gõ mỗi phách mạnh, hoặc chỉ ở khuông 3 và 4 với bài dài.
- Bài Nam và Oán chậm, câu nhạc dài 8 khuông, song lang gõ phách mạnh khuông 6 và 8 (UNES08049).
- Vọng cổ bắt nguồn từ *Dạ cổ hoài lang* (Cao Văn Lầu, Bạc Liêu, 1917–1919), tương đương hơi Oán điệu Nam.
- Vọng cổ nhịp 32, âm kết cố định mỗi câu: câu 1 kết **cống**, câu 2 kết **xang**, câu 3, 4, 6 kết **hò**, câu 5 kết **xê** (Đỗ Quốc Dũng 2019).
- **Mâu thuẫn nguồn – niên đại nhịp 32:** Trần Thị Hoàng Mỹ (2017) ghi **1954**; Đỗ Quốc Dũng (2019) gán cho Năm Nhỏ (Trần Tấn Hưng) năm **1940**, trình diễn 1941. Ghi cả hai.

**[QU]** Vì phách mạnh nằm cuối chu kỳ, khi phối nhạc dân tộc nên đặt điểm nhấn trống hoặc bass ở cuối câu.

## 8. Âm vực, tessitura và chọn tông

### 8.1. Bảng âm vực theo loại giọng

**[BC]** Âm vực tham chiếu quốc tế: Soprano C4–C6, Mezzo A3–A5, Contralto F3–E5, Countertenor E3–E5, Tenor C3–C5, Baritone A2–A4, Bass E2–E4 (muted.io; Lumen Learning). NSND Lê Dung, Lan Anh, Bích Thủy được ghi nhận hát tới khoảng C1–D3/E3 theo hệ Đức/Nga, tức khoảng **C4–D6/E6** hệ khoa học (Trịnh Thị Kim Oanh 2025). Ca sĩ pop nam (ngoài R&B) hát thoải mái khoảng **1,5 quãng 8**; nam R&B **2–2,5 quãng 8** kể cả falsetto; nữ R&B **2,5–3 quãng 8** (BMI). Đa số bài nằm trong khoảng **1 quãng 8**; giai điệu rộng hơn hẳn **quãng 10** dễ gây vấn đề (Secrets of Songwriting).

| Loại giọng | Âm vực tham chiếu (hệ khoa học) | Tessitura gợi ý cho bài pop [QU] | Ghi chú |
|---|---|---|---|
| Nữ cao (Soprano) | C4–C6 | khoảng E4–E5 | Ca sĩ Việt cổ điển lên tới D6–E6 |
| Nữ trung (Mezzo) | A3–A5 | khoảng C4–C5 | — |
| Nữ trầm (Contralto/Alto) | F3–E5 | khoảng A3–A4 | — |
| Phản nam cao (Countertenor) | E3–E5 | khoảng A3–A4 | — |
| Nam cao (Tenor) | C3–C5 | khoảng E3–E4 | Nốt giọng ngực cao thoải mái là yếu tố quyết định trong pop/R&B (Berklee) |
| Nam trung (Baritone) | A2–A4 | khoảng C3–C4 | — |
| Nam trầm (Bass) | E2–E4 | khoảng G2–G3 | — |
| Trẻ mẫu giáo (3–5 tuổi) | khoảng C4–A4 | khoảng D4–G4 | Đọc ký hiệu Lumen là suy luận [Cần kiểm chứng] |
| Trẻ 5–6 tuổi | khoảng quãng 7–8, c1–h1 hoặc c1–c2 (C4–B4/C5); hát tự nhiên nhất **C4–C5** | khoảng F4–A4 | Bài vượt khoảng quãng 9 nên dịch giọng (Tôn Nữ Diệu Hằng) [BC] |
| Lớp 1–3 (6–8 tuổi) | khoảng C4–C5 | khoảng F4–G4 | Vùng khỏe nhất quanh F–G (Lumen) |
| Lớp 4–6 (9–11 tuổi) | khoảng B♭3–E5 | khoảng E4–B4 | Dùng giọng đầu nhẹ, không ép giọng ngực |

**[BC]** Hai lỗi phổ biến với bài thiếu nhi: người lớn thường chọn tông **quá thấp** cho trẻ (Lumen); giọng cô giáo thường thấp hơn trẻ khoảng **một quãng 4**, nên phải chọn tông theo trẻ (Tôn Nữ Diệu Hằng).

**Quy đổi ký hiệu:** tài liệu Việt thường dùng hệ Đức/Nga: **c1 = Đô giữa = C4**; "H" = Si (B). Chưa tìm được bảng âm vực chuẩn Việt Nam từ giáo trình Học viện Âm nhạc Quốc gia, số liệu passaggio cho ca sĩ pop Việt, hay số liệu tuổi vỡ giọng. Bảng chi tiết (passaggio, tuổi, kỹ thuật): `references/04-giong-hat.md`.

### 8.2. Chọn tông

**[BC]** Trong bài pop, **nốt thấp nhất thường ở verse, nốt cao nhất ở điệp khúc**. Nốt thấp nhất thường nâng được mà không hại giai điệu; nốt cao nhất thường là then chốt (BMI). Đặt bài vào giữa giọng; bài cảm xúc mạnh nâng tông nhẹ, chấp nhận căng ngắn ở nốt cao; bài trầm tư hạ nhẹ (Secrets of Songwriting). Nếu chỉ một nốt vượt tầm, **đổi nốt đó thay vì đổi cả tông**; thu thử ở nhiều tông để chọn (Berklee).

**[QU] Quy trình 5 bước:**
1. Đo nốt thấp nhất thoải mái, nốt cao nhất thoải mái và nốt giọng ngực cao nhất của **ca sĩ thật**, không phải của người viết.
2. Tính tessitura của bài: vùng chứa khoảng **70–80% thời lượng nốt**.
3. Dịch tông để tessitura nằm giữa giọng.
4. Nốt cao trào bằng hoặc nhỉnh hơn nốt ngực cao thoải mái **tối đa 1–2 nửa cung**, và chỉ xuất hiện ngắn.
5. Bài có nhạc cụ dân tộc: thử tông với nhạc cụ trước khi chốt. Đàn tranh lên dây ngũ cung, đàn bầu lên dây khoảng C3, nên đổi tông sau khi đã thu nhạc cụ rất tốn kém. **Dịch tông không đổi hướng giai điệu**, nên kết quả T1–T10 giữ nguyên.

Công cụ: `scripts/chuyen-giong.py` để dịch tông.

## 9. Phương ngữ

**[BC]**
- **Bắc:** 6 thanh.
- **Trung:** 5 thanh, kiểu nhập khác nhau: **Thanh Hóa** lẫn hỏi/ngã; **Nghệ Tĩnh** không phân biệt ngã/nặng; **Bình Trị Thiên** không phân biệt hỏi/ngã (ngonngu.net).
- **Nam:** 5 thanh, **hỏi và ngã trùng làm một**.
- Thanh nặng giọng Bắc: dạng xuống ngắn, trung bình ≈ **146 ms**; Nam và Trung: dạng xuống–lên, ≈ **244 ms** và **293 ms** (Mai Chi Nguyen, NCUR 2019 – báo cáo sinh viên, mẫu nhỏ 80 bản ghi).
- *Ru con miền Nam*: hỏi và ngã hát như một nhóm, dạng lõm ở khoảng 58% trường hợp (Phan & Ngô).

**[QU] Hệ quả cho bộ kiểm tra:**
- Ca sĩ hoặc khán giả miền Nam: có thể **gộp hỏi và ngã thành một nhóm**, hát dạng lõm (xuống rồi lên).
- Giọng Bắc: ngã thuộc nhóm **Cao**, hỏi thuộc nhóm **Rất thấp**. Một nét nhạc đúng với giọng Nam có thể nghe lệch với giọng Bắc.
- Thanh nặng giọng Nam dài hơn, nên chịu được nốt dài hơn giọng Bắc.
- Bolero và trữ tình Nam Bộ cho phép luyến dài trên huyền và ngang; hạn chế luyến dài trên nặng, và trên ngã nếu ca sĩ hát giọng Bắc.
- Ca Huế khoảng cách thanh hẹp, chịu được nhảy quãng 4–6.

**Đặc điểm phát âm khác (giữ từ bản 1.0, [QU]):**

| Đặc điểm | Bắc | Trung | Nam |
|---|---|---|---|
| Thanh | 6 thanh | 5 thanh; Thanh Hóa lẫn hỏi/ngã, Nghệ Tĩnh ngã≡nặng, Bình Trị Thiên hỏi≡ngã [BC] | 5 thanh; hỏi≡ngã [BC] |
| Phụ âm đầu v, gi, d, r | v ≠ d; r đọc như d/z | Đa dạng | v đọc như d (gi), r rung nhẹ |
| Vần cuối -n/-ng, -t/-c | Phân biệt | Đa dạng | -n/-ng, -t/-c gần nhau |
| Hợp thể loại | Ca trù, quan họ, chèo, ca khúc nghệ thuật | Ca Huế, hò | Bolero, vọng cổ, tài tử |

Bài viết theo thể loại vùng nào thì dùng từ ngữ, xưng hô của vùng đó (ví dụ "má, ba, tui" cho nhạc Nam Bộ).

## 10. Ký hiệu luyến láy – khoảng trống

**[BC]** Kỹ thuật hát chèo được mô tả bằng "liền hơi, liền giọng, nhấn, ngắt, rung giọng, nảy hạt" (Đặng Thị Lan 2021). Tài liệu chuyên sâu: Trần Bảng, *Kĩ thuật biểu diễn Chèo* (1992); Nguyễn Thị Tuyết, *Giáo trình hát Chèo* (2000). Ký hiệu phương Tây: **dấu nối (tie)** nối hai nốt cùng cao độ; **dấu luyến (slur)** nối các nốt khác cao độ. **Không tìm thấy hệ ký hiệu chuẩn Việt** cho láy rền, láy trên, láy dưới, nhấn, rung, nảy hạt.

**[QU] Đề xuất tạm cho lead sheet pop:**

| Kỹ thuật | Ghi bằng |
|---|---|
| Luyến láy | Dấu luyến + nốt hoa mỹ (grace note, appoggiatura) |
| Nhấn | Accent (>) hoặc tenuto (–) |
| Rung | "vib." hoặc đường lượn sóng |
| Nảy hạt | Staccato hoặc nốt hoa mỹ ngắn |

Luôn gửi kèm **guide vocal** có luyến láy thật, vì bản giấy không mô tả đủ.

## 11. Khi máy AI hát tiếng Việt

| Lỗi thường gặp | Cách xử lý trong ô lời cho máy |
|---|---|
| Sai thanh hỏi–ngã, sắc–nặng | Thử thay từ đồng nghĩa; tạo nhiều bản và chọn bản đúng; ưu tiên soát các chữ trong danh sách cặp dễ nhầm (mục 2) |
| Đọc từ tiếng Anh theo âm Việt hoặc ngược lại | Viết theo âm: Claude → Clốt, AI → Ây Ai, Project → Prô-déch |
| Đọc chữ viết tắt sai | Viết đầy đủ hoặc tách chữ cái theo âm ("bê vê" cho BV) |
| Đọc số sai | Viết số bằng chữ ("hai trăm") |
| Giọng vùng không mong muốn | Ghi vùng trong prompt phong cách (Northern / Southern Vietnamese accent) và thử lại; chạy T10 theo vùng đã chọn |

Bản chiếu lời cho người hát luôn giữ chữ gốc; chỉ bản dán vào máy mới viết theo âm. Bản lời chuẩn (N9) phát hành kèm demo.

## 12. Cách script kiem-tra-thanh-nhac.py và dem-am-tiet.py dùng các quy tắc này

**Tách thanh và vần** (cả hai script): chuẩn hóa NFD, nhận dấu thanh (huyền ̀, sắc ́, hỏi ̉, ngã ̃, nặng ̣; không dấu = ngang); bỏ phụ âm đầu (ngh, ng, nh, ch, gh, gi, kh, ph, th, tr, qu, b, c, d, đ, g…) để lấy **vần**.

**Mã số nhóm cao độ** (mục 1.1): **cao = 3** (sắc, ngã) · **trung = 2** (ngang) · **thấp = 1** (huyền) · **rất thấp = 0** (hỏi, nặng). Nhóm bằng/trắc chỉ dùng cho kiểm tra vần, **không** dùng cho hướng nốt.

**kiem-tra-thanh-nhac.py** (đầu vào: lời + cao độ từng âm tiết, kèm trường độ nếu có):
1. **T1:** gán mã 0–3 cho từng âm tiết.
2. **T2 – kiểm hướng cặp:** với mỗi cặp liền nhau, `d_thanh = sign(mã_sau − mã_trước)`, `d_nhac = sign(cao_độ_sau − cao_độ_trước)`. Phân loại:
   - **cùng hướng:** d_thanh = d_nhac ≠ 0;
   - **xiên (chấp nhận):** một trong hai bằng 0;
   - **ngược hướng (cờ đỏ):** d_thanh × d_nhac = −1.
3. **T3:** báo % cùng hướng / xiên / ngược; cờ khi ngược > 10%; tham chiếu ≈ 77% cùng hướng (Kirby & Ladd).
4. **T4 – từ có rủi ro cặp tối thiểu:** so từng chữ với danh sách cặp dễ nhầm (mục 2) và với các biến thể cùng vần khác dấu; chữ có rủi ro mà rơi vào cặp **ngược hướng** → cờ đỏ ưu tiên cao.
5. **N5/V8 – vần khép trên nốt dài:** âm tiết kết bằng **-p, -t, -c, -ch** đặt trên nốt ngân (trường độ ≥ ngưỡng, ví dụ ≥ 1 phách hoặc nốt cuối câu) → cờ.
6. **T6/T8:** nặng trên nốt ngân dài → cờ; hỏi hoặc nặng trên nốt cao nhất bài → cờ.
7. **T10 – phương ngữ** (tùy chọn `--phuong-ngu bac|trung|nam`): mặc định Bắc. Với Nam, coi hỏi ≡ ngã (cùng mã, cặp hỏi–ngã không bị kiểm hướng) [QU]; báo kèm cảnh báo nếu chữ ngã được đặt thấp vì giọng Bắc sẽ nghe lệch.

**dem-am-tiet.py** (đầu vào: lời có nhãn đoạn):
- Đếm âm tiết mỗi câu, so câu cùng vị trí giữa các đoạn (lệch > 2 âm tiết thì cờ; V2).
- Chữ cuối câu: báo vần, thanh, **bằng/trắc** (cho V5–V6) và **nhóm cao độ 0–3** (cho V12).
- **Vần khép ở vị trí vần:** chữ cuối câu kết -p/-t/-c/-ch → ghi "vần khép = trắc, không dùng làm vần bằng / nốt ngân cuối" (V8, N5).
- Dựng sơ đồ vần từ vần chữ cuối; hai tiếng chỉ tính là hiệp vần khi cùng nhóm bằng/trắc (V6).
- Lục bát, song thất, Đường luật (V3, V4, V5, V10): chạy `kiem-tra-thi-luat.py` – kiểm chữ 2–4–6(–8), luật trầm bổng chữ 6 ≠ chữ 8 câu bát (một huyền, một ngang), vần lưng, vần chân, niêm.
