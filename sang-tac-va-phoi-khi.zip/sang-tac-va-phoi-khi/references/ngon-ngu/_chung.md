> Tệp tra cứu của skill sang-tac-va-phoi-khi. Âm vực, BPM là giá trị xấp xỉ; C4 = Đô giữa, âm vực ghi theo cao độ thực.

# Ngôn ngữ: nhóm ngôn ngữ, quy tắc từng ngôn ngữ, xen ngôn ngữ

Đọc tệp này cho mọi bài không phải thuần tiếng Việt; bài tiếng Việt đọc thêm `vi.md`.

## 9.6. Bốn nhóm ngôn ngữ khi đặt lời

| Nhóm | Nguyên tắc khớp lời với nhạc | Ngôn ngữ |
| --- | --- | --- |
| Có thanh điệu | Hướng đi giai điệu phải theo thanh, nếu không người nghe hiểu sai nghĩa | Việt, Trung phổ thông, Quảng Đông, Thái, Lào, Yoruba |
| Có trọng âm | Âm tiết nhấn rơi vào phách mạnh hoặc nốt dài, cao | Anh, Đức, Nga, Ý, Tây Ban Nha, Bồ Đào Nha, Ả Rập, Hindi |
| Đếm theo mora | Mỗi mora một nốt, đếm mora thay vì âm tiết | Nhật |
| Âm tiết đều | Phân bố âm tiết đều, nhấn nhẹ cuối cụm từ | Pháp, Hàn, Indonesia, Mã Lai |

## 9.7. Nội dung từng tệp ngôn ngữ

| Ngôn ngữ | Quy tắc khớp lời chính | Vần | Lỗi hay gặp khi máy AI hát |
| --- | --- | --- | --- |
| Tiếng Việt | 6 thanh: sắc, ngã đi lên; huyền, nặng đi xuống; hỏi xuống rồi lên (luyến hoặc nốt thấp); ngang giữ hoặc ngân. Kiểm tra cặp dễ nhầm (nhớ/nhờ, ma/mà/má) | Vần chính + bằng/trắc; vần lưng | Sai thanh hỏi–ngã, đọc từ tiếng Anh theo âm Việt, phương ngữ không mong muốn |
| Trung phổ thông | 4 thanh + thanh nhẹ; pop chấp nhận lệch thanh nhưng chữ quan trọng phải đúng | 13 nhóm vần (thập tam triệt) | Đọc sai đa âm tự |
| Quảng Đông | 6 thanh (9 điệu); Cantopop khớp thanh rất chặt, thường viết nhạc trước đặt lời sau | Vần cuối | Chuyển sang giọng phổ thông |
| Thái | 5 thanh; giai điệu theo thanh | Vần chân và vần nối dòng | Sai thanh |
| Nhật | Mỗi mora một nốt (っ, ん, trường âm chiếm nốt riêng); cao độ trọng âm nhẹ | Ít dùng vần, dùng nguyên âm cuối | Đọc kanji sai, nên ghi kèm kana |
| Hàn | Âm tiết; phụ âm cuối (batchim) khó ngân | Vần nguyên âm, xen tiếng Anh | Nối âm sai |
| Anh | Trọng âm từ rơi phách mạnh; chữ ngân nên có nguyên âm dài | Vần hoàn hảo, vần gần | Nhấn sai âm tiết |
| Pháp | E câm có thể thành âm tiết khi hát; nhấn cuối nhóm từ; nối âm (liaison) | Vần giàu, xen kẽ vần giống đực–cái | Bỏ hoặc thêm e câm |
| Tây Ban Nha | Âm tiết đều; nối nguyên âm giữa hai từ (sinalefa) | Vần nguyên âm (asonante), vần đủ | Ít lỗi |
| Bồ Đào Nha | Nguyên âm mũi, nguyên âm nhược | Vần nguyên âm | Lẫn giọng Brazil–Bồ |
| Ý | Nguyên âm mở, nối nguyên âm; hợp opera | Vần cuối nguyên âm | Ít lỗi |
| Đức | Cụm phụ âm dày, nguyên âm dài–ngắn | Vần chân | Khó ở nhịp nhanh |
| Nga | Trọng âm di động, nguyên âm không nhấn bị nhược | Vần chân xen kẽ | Sai trọng âm; ghi dấu nhấn |
| Ả Rập | Phụ âm họng, nguyên âm dài–ngắn, melisma | Vần đơn (qafiya) | Cần chuyển tự Latin cho một số công cụ |
| Hindi | Phụ âm bật hơi, nguyên âm dài, melisma | Vần chân | Cần chuyển tự Latin |
| Indonesia, Mã Lai | Âm tiết đều, dễ hát | Vần cuối (pantun ABAB) | Ít lỗi |

Ngôn ngữ chưa có tệp: Claude xếp vào một trong 4 nhóm trên, nói rõ mức độ chắc chắn và đề nghị người bản ngữ kiểm tra lời.

## 9.8. Xen nhiều ngôn ngữ

- Câu ngoại ngữ ngắn, đặt ở câu móc, ad-lib hoặc câu kết; mỗi câu một ngôn ngữ, trừ khi cố ý đổi giữa câu.
- Chọn từ ngoại ngữ người nghe đã quen; đúng ngữ pháp.
- Luôn kèm bản dịch nghĩa cho người dùng và ghi chú phát âm.
- Bài song ngữ hoàn chỉnh (mỗi verse một ngôn ngữ) phải kiểm tra cả hai bản khớp cùng giai điệu.
- Bản dịch lời để hát (singable translation) ưu tiên hát được và giữ ý chính, không dịch từng chữ.
