> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Âm vực, BPM là giá trị xấp xỉ; C4 = Đô giữa, âm vực ghi theo cao độ thực.

# 8. Phối khí 

Phối khí là quyết định **ai chơi gì, ở đâu, khi nào, to hay nhỏ**. Tệp này cho Claude 6 công cụ: chọn đội hình, phân vai, chia dải tần, vẽ đường năng lượng, xếp hợp âm và chuyển đoạn. Bài Việt: xem thêm mục 8.10 dưới đây, `15-nhac-cu-viet.md` (nhạc cụ, ma trận theo thể loại, bộ kiểm tra I1–I10) và `16-san-xuat.md` (thu âm, xử lý, sản xuất). Nhãn: [BC] có bằng chứng ([BC – tập mẫu]: đếm từ tập 37 bài, xem tệp 14); [QU] quy ước/suy luận; [Cần kiểm chứng].

## 8.1. Đội hình thường gặp

| Đội hình | Thành phần | Dùng cho |
| --- | --- | --- |
| Solo piano hoặc guitar | 1 nhạc cụ + giọng | Ballad mộc, acoustic, buổi nhỏ |
| Acoustic duo/trio | Guitar mộc, cajon, bass mộc (+ violin) | Cafe, folk, pop mộc |
| Ban nhạc 4–5 người | Trống, bass, guitar, phím (+ guitar 2) | Pop, rock, nhạc trẻ |
| Ban nhạc có kèn | Ban 4 người + trumpet, sax, trombone | Funk, soul, ska, pop sôi động |
| Jazz trio, quartet | Piano, contrabass, trống (+ sax) | Jazz, bossa, lounge |
| Big band | 5 sax, 4 trumpet, 4 trombone, piano, guitar, bass, trống | Swing, hòa nhạc gala |
| Tứ tấu dây | 2 violin, viola, cello | Cưới, lễ, cover thanh lịch |
| Dàn nhạc thính phòng | Dây + vài kèn gỗ, kèn co, piano | Nhạc phim nhỏ, ballad sang |
| Dàn nhạc giao hưởng | Dây, kèn gỗ ×2–3, kèn đồng, bộ gõ, harp | Nhạc phim, epic, hùng ca |
| Ban kèn (brass band, marching band) | Kèn đồng, kèn gỗ, trống diễu hành | Hành khúc, lễ hội, thể thao |
| Hợp xướng + piano/organ | SATB + đệm | Thánh ca, bài truyền thống, lễ |
| Dàn nhạc dân tộc Việt | Tranh, bầu, nhị, sáo, nguyệt, tỳ bà, trống, phách | Dân ca, nhạc truyền thống, lễ hội |
| Ban tài tử | Đàn kìm (nguyệt), tranh, tỳ bà, cò (nhị), tam, sáo, guitar phím lõm, song lang [BC] | Đờn ca tài tử, cải lương |
| Điện tử (DAW) | Trống máy, synth, sample | EDM, hip-hop, pop hiện đại |
| Lai (fusion) | Một đội hình nền + 1–2 nhạc cụ màu | Pop dân tộc, EDM dân tộc, nhạc phim |

## 8.2. Sáu vai trong một bản phối

| Vai | Nhiệm vụ | Nhạc cụ thường đảm nhận |
| --- | --- | --- |
| Nền móng (foundation) | Bass và nhịp gốc | Bass, kick, cello, tuba, 808 |
| Nhịp (rhythm) | Giữ groove | Trống, guitar đệm, piano chặn, bộ gõ |
| Thảm hòa âm (pad) | Lấp khoảng giữa, tạo không khí | Dây, pad synth, organ |
| Giai điệu chính (lead) | Giọng hát hoặc nhạc cụ solo | Giọng, sax, guitar solo, sáo, đàn bầu |
| Phản giai điệu (counter-melody) | Đối đáp khi giọng nghỉ | Guitar fill, violin, kèn, piano |
| Màu và hiệu ứng (color) | Tô điểm, chuyển đoạn | Glockenspiel, harp, riser, cymbal, tiếng tự nhiên |

**Quy tắc:** tại mỗi thời điểm chỉ một giai điệu chính; phản giai điệu chỉ xuất hiện trong khoảng trống của giọng hát.

## 8.3. Bản đồ dải tần

| Dải tần | Khoảng | Thuộc về | Lưu ý |
| --- | --- | --- | --- |
| Siêu trầm | 20–60 Hz | 808, kick, bass synth | Chỉ một nhạc cụ chiếm |
| Trầm | 60–250 Hz | Bass, kick, cello, tay trái piano | Kick và bass nhường nhau |
| Trung trầm | 250–500 Hz | Guitar, piano, hợp âm dày | Dễ đục; hợp âm dưới C3 chỉ dùng quãng 5, quãng 8 |
| Trung | 500 Hz–2 kHz | Giọng hát, kèn, guitar, snare | Vùng của giai điệu, nhường cho giọng |
| Trung cao | 2–5 kHz | Độ rõ chữ, tấn công của guitar, trống | Tai nhạy nhất, tránh chồng nhiều nhạc cụ. Dải **1–4 kHz, đỉnh quanh 2 kHz** quyết định độ rõ lời [BC] (DPA) |
| Cao | 5–20 kHz | Hi-hat, cymbal, độ "không khí" của giọng, shaker | Tạo độ sáng |

## 8.4. Đường năng lượng

Claude chấm năng lượng từng phần theo thang 1–10 và ghi vào bảng phối khí. Mẫu cho bài verse–chorus:

| Phần | Mức | Cách tạo |
| --- | --- | --- |
| Intro | 3–5 | Câu móc nhạc cụ hoặc không khí |
| Verse 1 | 3–4 | Ít nhạc cụ, để lời rõ |
| Pre-chorus | 5–6 | Thêm pad, trống dồn, hợp âm dày dần |
| Chorus 1 | 7–8 | Toàn ban, nới quãng, bè hát |
| Verse 2 | 4–5 | Giữ một lớp mới từ chorus để không tụt quá sâu |
| Chorus 2 | 8 | Thêm phản giai điệu hoặc lớp bè |
| Bridge | 3–6 | Khác biệt: rút bớt, đổi hợp âm, hoặc đổi nhịp |
| Chorus cuối | 9–10 | Tất cả nhạc cụ, ad-lib, nâng tông (pop quốc tế; bài Việt: 0/37 bản hợp âm có nâng tông ĐK cuối [BC – tập mẫu], chỉ dùng khi có lý do sân khấu) |
| Outro | 2–5 | Kết dứt khoát hoặc nhỏ dần |

Cách tăng năng lượng: thêm nhạc cụ, mở rộng quãng (nốt cao hơn, bass thấp hơn), dày nhịp hơn (hi-hat 8 → 16), hợp âm nhanh hơn, nâng tông, tăng cường độ. Cách giảm: đảo ngược các bước trên, hoặc cắt hẳn còn một nhạc cụ.

## 8.5. Xếp hợp âm (voicing)

- **Close:** các nốt sát nhau trong một quãng tám; dày, gọn (kèn đồng, hợp xướng pop).
- **Open, spread:** trải rộng hơn một quãng tám; thoáng, lớn (dàn dây, piano ballad).
- **Drop 2, drop 3:** hạ nốt thứ 2 hoặc thứ 3 từ trên xuống một quãng tám (guitar jazz, bộ sax).
- **Shell:** chỉ nốt gốc, quãng 3, quãng 7 (jazz, đệm nhẹ).
- **Rootless:** bỏ nốt gốc vì bass đã chơi (piano jazz, neo-soul).
- **Quãng 4, upper structure:** màu hiện đại.
- **Quy tắc dải trầm:** dưới khoảng C3 chỉ dùng quãng 8 hoặc quãng 5; quãng 3 ngắn ở vùng trầm sẽ đục.

## 8.6. Kỹ thuật phối theo họ nhạc cụ

| Họ | Kỹ thuật |
| --- | --- |
| Dây | Legato ngân (thảm), ostinato spiccato (dồn dập), pizzicato (nhẹ, vui), tremolo (căng), unison quãng tám violin–viola–cello cho giai điệu hoành tráng, divisi chia bè hợp âm |
| Kèn gỗ | Nhân đôi giai điệu dây ở quãng tám trên, trang trí lượn, nốt nhấn vui (bassoon, clarinet) |
| Kèn đồng | Stab ngắn (funk), hợp âm dài (anthem), fanfare (trumpet), chủ đề anh hùng (kèn co), swell crescendo |
| Guitar | Đệm quạt, rải, power chord, palm-mute verse rồi mở tiếng ở chorus, hai guitar chơi hai quãng khác nhau, solo ngắn 8 ô |
| Piano, phím | Rải ballad, hợp âm chặn nốt đen (pop), stride, montuno, gospel chords, tay trái quãng tám |
| Trống | Đổi trống theo phần (hi-hat đóng → ride → crash), fill trước chuyển đoạn, half-time ở bridge, stop-time |
| Giọng hát | Bè quãng 3 ở chorus, ad-lib chorus cuối, hô–đáp, gang vocal |
| Điện tử | Sidechain (pad "thở" theo kick), filter mở dần trong build, riser, drop |
| Dân tộc | Mỗi lần một nhạc cụ dân tộc nổi bật; để khoảng trống cho luyến láy; tránh hợp âm dày đè lên nốt nhấn; giao vai giai điệu/đối âm, không giao đệm hợp âm dày [BC] (xem 8.10) |

## 8.7. Chuyển đoạn, mở bài, kết bài

- **Chuyển đoạn:** fill trống, ngắt 1 phách, build-up, riser, reverse cymbal, hợp âm sus4 trước chorus, pickup (giai điệu vào trước phách 1).
- **Mở bài:** câu móc nhạc cụ, hợp âm verse, tiếng không khí, vào thẳng giọng hát (cold open), điệp khúc thu nhỏ.
- **Kết bài:** kết dứt khoát cả ban, nhỏ dần (fade out), lặp câu móc, hợp âm ngân (fermata), kết bất ngờ (Picardy, hợp âm mượn).

## 8.8. Phối lại và biến thể

- **Acoustic, unplugged:** giữ giai điệu và hợp âm, thay bằng guitar mộc, cajon, piano; giảm nhịp độ 5–10%.
- **Giao hưởng:** chuyển riff guitar sang dây hoặc kèn đồng; thêm timpani và hợp xướng ở cao trào.
- **Remix điện tử:** cắt câu móc thành vocal chop, nhịp độ theo thể loại đích, thêm build–drop.
- **Dân tộc hóa:** thay synth lead bằng sáo trúc hoặc đàn bầu, thêm trống cơm, giữ thang ngũ cung; với hoà âm, chuyển sang vòng aeolian không V trưởng hoặc hướng quãng 4 (`14-hoa-am-viet-bai-mau.md`).
- **Bản karaoke:** giữ đủ nhạc, thêm nhạc cụ nhắc giai điệu (guide melody) nhỏ, có 4 phách đếm vào.

## 8.9. Khung bảng phối khí đầu ra

Mỗi bảng phối khí Claude xuất phải có đủ 8 cột sau:

| Phần | Thời gian | Số ô | Hợp âm | Nhạc cụ và vai | Cách chơi | Năng lượng 1–10 | Chuyển sang phần sau |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Ví dụ: Verse 1 | 0:15–0:30 | 8 | vi–IV–I–V | Piano (pad), bass (nền), trống hi-hat (nhịp), giọng (lead) | Piano rải nốt móc, bass nốt tròn | 4 | Snare dồn 1 ô |

## 8.10. Ghi chú riêng cho bài Việt

| Chủ đề | Quy tắc | Nhãn |
| --- | --- | --- |
| Dải lời | Dải **1–4 kHz, đỉnh quanh 2 kHz** quyết định độ rõ lời (DPA). Nhạc cụ có năng lượng chính ở đây — sáo, nhị, kèn bầu, tiếng gảy của tranh, violin dây E, oboe, trumpet — **nhường chỗ khi có lời**, chỉ vào khoảng nghỉ của câu hát. Tiếng Việt có thanh điệu nên lời bị che dễ nghe nhầm hơn | [BC] dải tần; [QU] áp dụng |
| Vai của nhạc cụ dân tộc | Nhạc cụ dây gảy và đàn bầu **mạnh ở luyến, nhấn, vuốt** → hợp vai **giai điệu hoặc đối âm** hơn đệm hợp âm dày. Đối âm/câu đáp (bầu, sáo, nhị) đi vào khoảng nghỉ của lời | [BC] |
| Phân lớp | Giai điệu chính; đối âm hoặc câu đáp (bầu, sáo, nhị); nền dây, pad hoặc đàn tranh rải; bass có âm trì; nhịp gồm trống, song lang, phách hoặc hi-hat. Chưa có tài liệu Việt Nam xác nhận | [QU] |
| Cấu trúc năng lượng | **Intro**: nhạc cụ dân tộc làm hook → **verse** mỏng → **chorus** đủ các lớp → **outro** trở về độc tấu dân tộc. Ví dụ có nguồn về hook dân tộc: sáo mèo trong *Để Mị*, kèn bầu và trống mở *Bắc Bling* [BC] | Khung: [QU]; ví dụ: [BC] |
| Vòng lặp V-pop | Với vòng lặp xuyên suốt (8 bài sau 2014 trong tập mẫu), **tương phản giữa các đoạn đến từ mật độ phối**, không từ đổi hợp âm | [BC – tập mẫu]; [QU] |
| Drone chiêng | Bộ 3 chiêng núm lõi **C–G–C** = bourdon chủ âm–át âm [BC] (Della Ratta). Hợp vòng **aeolian** của folktronica; va chạm với V7 và vòng đổi gốc nhanh có ii, iii. Chiêng thật không chỉnh A440 → đo cao độ trước hoặc chỉ dùng ở đoạn không có nhạc cụ 12 bình quân | Số liệu: [BC]; áp dụng: [QU] |
| Dây trầm đàn tranh | Dây trầm tranh/guzheng có năng lượng ở 40–250 Hz, chồng vùng bass guitar [BC] (BioResources) → khi tranh rải xuống dây trầm, bass nghỉ hoặc đi nốt dài | [BC]; [QU] |
| Synth và đàn tranh | Không để synth pluck rải cùng quãng với đàn tranh | [QU] |
| Chất liệu dân gian | DTAP chọn chất liệu theo **tinh thần, âm sắc và câu chuyện**; **mỗi chi tiết phải có lý do tồn tại rõ ràng**; dân gian là nền móng có thể khoác ngôn ngữ EDM hay hip-hop (Nhân Dân) → mỗi nhạc cụ hoặc sample dân gian trong bảng phối ghi kèm một dòng "lý do tồn tại" | [BC]; cách ghi: [QU] |
| Ví dụ có nguồn | Đàn đáy và trống chầu trong *Đại Lâm Linh*; ngũ tấu dây phương Tây với quan họ trong *Nam Nhi*; Trần Mạnh Hùng phối bộ gõ dân tộc (chén, trống chiến, trống đế, mõ chùa) với dàn dây và horn; *Made in Vietnam* (DTAP, 2025) dùng đàn bầu, đàn tranh, trống và ba giọng ba miền | [BC] |

Chọn nhạc cụ cụ thể, ma trận theo thể loại, năm "ngăn" tần số và bộ kiểm tra I1–I10: `15-nhac-cu-viet.md`. Thu âm nhạc cụ dân tộc, chiến lược cao độ 166 cent, mix và master: `16-san-xuat.md`.
