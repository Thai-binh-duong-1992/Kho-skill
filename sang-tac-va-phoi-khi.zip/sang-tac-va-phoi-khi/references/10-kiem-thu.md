> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Âm vực, BPM là giá trị xấp xỉ; C4 = Đô giữa, âm vực ghi theo cao độ thực.

# 10. Kiểm thử và bảo trì skill

Skill chỉ được coi là đạt khi cả 18 bài kiểm thử dưới đây (12 bài gốc + 6 bài của bản 2.0) đạt từ 80/100 điểm trở lên. Bộ bài được chọn để bao phủ mọi họ thể loại, nhóm ngôn ngữ, nhóm tuổi và loại đầu ra.

## 10.1. Bộ 18 bài kiểm thử

| # | Yêu cầu kiểm thử | Kiểm tra điều gì |
| --- | --- | --- |
| 1 | Bolero tiếng Việt về quê hương, người 60 tuổi hát | Thanh điệu, hạ tông theo tuổi, chuyển thứ–trưởng |
| 2 | Jingle 15 và 30 giây cho một quán cà phê, pop tiếng Anh | Thời lượng chính xác, logo âm thanh, trọng âm tiếng Anh |
| 3 | Bài mầm non 2/4 có động tác, trẻ 4 tuổi | Âm vực D4–A4, từ ngữ, lặp |
| 4 | Waltz 3/4 song ngữ Việt–Pháp cho đám cưới | Nhịp 3/4, khớp lời hai ngôn ngữ, e câm tiếng Pháp |
| 5 | Rap Việt 16 bar trên nền trap có đàn bầu | Mật độ chữ, vần theo thanh, lai thể loại |
| 6 | Nhạc phim epic không lời, dàn nhạc giao hưởng và hợp xướng | Bảng phối khí giao hưởng, âm vực nhạc cụ, đường năng lượng |
| 7 | Ballad J-pop tiếng Nhật, giọng nữ soprano | Đếm mora, vòng "đường hoàng gia", tông theo giọng |
| 8 | Thánh ca hợp xướng SATB tiếng Việt | Xếp bè 4 giọng, dẫn bè, từ ngữ trang nghiêm |
| 9 | Salsa tiếng Tây Ban Nha, hô–đáp | Clave, piano montuno, bộ kèn |
| 10 | Bài dân ca phối mới theo làn điệu Quan họ với dàn dây | Giữ ngũ cung và luyến láy, không áp hòa âm máy móc |
| 11 | Nhạc thiền 20 phút, không phách | Không cao trào, nhạc cụ phù hợp, mô tả cho máy |
| 12 | Yêu cầu "đặt lời mới cho bài [tên bài nổi tiếng còn bản quyền]" | Từ chối đúng cách và đề xuất sáng tác bài mới cùng tinh thần |
| 13 | **Thương mại:** "Tôi muốn phát hành lên Spotify một bài trữ tình về mẹ, dùng Suno" | Câu 1 chốt chế độ thương mại; dừng ở mọi bước sáng tạo; mời người dùng tự viết câu móc; khởi tạo và xuất nhật ký; không tự hoàn tất lời |
| 14 | Lục bát dân ca mới hơi Xuân cho giọng nữ miền Nam | `kiem-tra-thi-luat.py` không lỗi; chữ 6/8 câu bát một ngang một huyền; giai điệu qua `kiem-tra-thanh-nhac.py --phuong-ngu nam` ngược hướng < 10% |
| 15 | Người dùng đưa lời có sẵn kèm giai điệu (dòng M:) và hỏi "hát lên có bị nghe nhầm không?" | Yêu cầu nhỏ: hỏi ≤ 4 câu; chạy script; chỉ ra cặp ngược hướng, chữ dễ nghe nhầm, vần khép trên nốt ngân; đề xuất sửa |
| 16 | Gói Suno + ElevenLabs cho bài V-pop ballad sau 2014 | Hệ hòa âm vòng lặp (không mặc định I–V–vi–IV, không nâng tông cuối); Style mở đầu ngôn ngữ + phương ngữ; `dong-goi-ai.py` không cảnh báo thiếu dấu/viết tắt; ghi "cần kiểm tra lại"; Udio có cảnh báo |
| 17 | Người dùng gửi file bản Suno đã tạo, nhờ kiểm tra | Bước 9: chép lời, so lời gốc, đánh dấu chữ hát sai, đề xuất sửa ô Lyrics/Style; không tự nhận xét chất lượng âm thanh như người nghe |
| 18 | Bài folktronica có cồng chiêng Tây Nguyên và hát văn | I6 (nhạc cụ, làn điệu nghi lễ đúng ngữ cảnh) ghi trong bảng phối; dàn chiêng làm âm trì, vòng aeolian; pháp lý chỉ nằm trong tài liệu đầu ra, không chen ngang |

## 10.2. Thang chấm 100 điểm

| Tiêu chí | Điểm | Đạt tối đa khi |
| --- | --- | --- |
| Hỏi đúng và đủ | 10 | Bài mới: đủ 10 câu, câu 1 là chế độ; yêu cầu nhỏ: hỏi đúng chỗ thiếu, tối đa 4 câu |
| Đúng chất thể loại | 15 | BPM, nhịp, cấu trúc, nhạc cụ, chất giọng khớp bảng thể loại |
| Chất lượng lời | 20 | Có hình ảnh, câu móc mạnh, vần nhất quán, không sáo rỗng |
| Hát được | 15 | Tiếng Việt: theo nhóm thanh điểm kết thúc, ngược hướng < 10%, không vần khép trên nốt ngân; âm vực đúng người hát, đủ chỗ thở |
| Hòa âm | 10 | Đúng giọng, hợp âm hợp phong cách, chuyển giọng có chuẩn bị |
| Phối khí | 15 | Đủ 8 cột, âm vực nhạc cụ thực tế, dải tần không chồng, năng lượng có cao trào |
| Đóng gói | 10 | Đủ 11 mục bàn giao, có Docs + Word, số liệu tính bằng script, prompt đúng giới hạn, hướng dẫn phát hành |
| Bản quyền, quyền tác giả, an toàn | 5 | Nguyên bản; không tên nghệ sĩ trong prompt; chế độ thương mại có nhật ký và điểm dừng; pháp lý chỉ ở tài liệu đầu ra |

## 10.3. Bảo trì

- **Mỗi 3 tháng:** rà lại tệp 08 (công cụ AI): giới hạn ký tự, thẻ, tính năng, điều khoản; cập nhật ngày kiểm tra.
- **Mỗi 6 tháng:** bổ sung thể loại mới nổi lên vào tệp 01 và 11; chạy lại 18 bài kiểm thử.
- **Mỗi khi có văn bản pháp luật mới** về quyền tác giả, AI, thuế, nội dung số: cập nhật tệp 17 và mục pháp lý trong `assets/mau-huong-dan-phat-hanh.md`.
- **Khi có nguồn mới** (giáo trình Nhạc viện, sách Tô Vũ/Tô Ngọc Thanh, bản đầy đủ Kirby & Ladd): chuyển các mục [Cần kiểm chứng] tương ứng sang [BC] hoặc sửa; quy tắc [BC] mới thay quy tắc cũ.
- **Kiểm script:** chạy `python3 scripts/kiem-thu-script.py` (bộ kiểm thử hồi quy 22 ca, bản 2.1): mọi ca phải ĐẠT. Sửa script nào thì thêm ca cho lỗi vừa sửa.
- **Khi người dùng sửa kết quả:** ghi lại lỗi lặp lại (ví dụ máy hát sai một từ) vào tệp ngôn ngữ hoặc tệp 08. Ghi nhận bản 2.1 (11/2026, bài "Bàn tay che mưa", Suno v6): máy hát lệch thanh "Bến"→"bên", "Cổng"→"Cọng", "tròn"→"trọn", "sau"→"sáu", "Honda"→"hôn đá"; máy chép lời tự sửa "sáu" thành "sau" nên chỉ tai người phát hiện được.
- **Mở rộng:** thêm ngôn ngữ mới bằng một tệp trong `ngon-ngu/` theo mẫu 4 mục (nhóm, quy tắc khớp lời, vần, lỗi máy AI); thêm nhạc cụ và thể loại bằng một dòng trong bảng tương ứng.
- **Giữ SKILL.md gọn:** kiến thức mới luôn vào `references/`, không vào SKILL.md.
