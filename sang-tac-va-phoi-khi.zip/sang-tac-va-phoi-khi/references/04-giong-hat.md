> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Âm vực, BPM là giá trị xấp xỉ; C4 = Đô giữa, âm vực ghi theo cao độ thực. Nhãn: [BC] có bằng chứng · [QU] quy ước thực hành/suy luận · [Cần kiểm chứng].

# 6. Giọng hát 

Giai điệu đẹp mà sai âm vực thì người hát không hát được. Claude phải đặt nốt cao nhất và thấp nhất của giai điệu vào **vùng hát thoải mái (tessitura)** của người hát, không phải vào giới hạn tối đa. Số liệu dưới đây là xấp xỉ (C4 = Đô giữa); từng người có thể lệch 2–3 nốt. Thanh điệu tiếng Việt khi đặt nốt: xem `references/ngon-ngu/vi.md`.

**Quy đổi ký hiệu:** tài liệu Việt thường dùng hệ Đức/Nga: **c1 = Đô giữa = C4**; "H" = Si (B). Ví dụ c1–c2 = C4–C5.

## 6.1. Loại giọng học thuật và âm vực

**[BC] Âm vực tham chiếu quốc tế** (muted.io; Lumen Learning): Soprano **C4–C6**, Mezzo **A3–A5**, Contralto **F3–E5**, Countertenor **E3–E5**, Tenor **C3–C5**, Baritone **A2–A4**, Bass **E2–E4**. Cột "Âm vực đầy đủ" theo nguồn này. Cột "Vùng hát thoải mái", "passaggio", "Phân loại nhỏ" và giá trị mở rộng trong ngoặc là [QU] (quy ước sư phạm thanh nhạc, chưa đối chiếu nguồn đơn lẻ). Cột "Tessitura pop" theo tài liệu gốc 2026 [QU].

| Giọng | Âm vực đầy đủ [BC] | Vùng hát thoải mái [QU] | Tessitura gợi ý cho bài pop [QU] | Vùng chuyển giọng (passaggio) [QU] | Phân loại nhỏ |
| --- | --- | --- | --- | --- | --- |
| Nữ cao (Soprano) | C4–C6 (coloratura đến F6 [QU]; ca sĩ Việt cổ điển tới D6–E6 [BC]) | G4–G5 | khoảng E4–E5 | E5–F#5 | Coloratura, soubrette, trữ tình, spinto, kịch tính |
| Nữ trung (Mezzo-soprano) | A3–A5 | C4–F5 | khoảng C4–C5 | E4 và D5–E5 | Trữ tình, kịch tính |
| Nữ trầm (Contralto, Alto) | F3–E5 | A3–D5 | khoảng A3–A4 | D4, C5–D5 | Contralto trữ tình, kịch tính |
| Nam cao giọng giả (Countertenor) | E3–E5 (giọng giả) | C4–C5 | khoảng A3–A4 | — | Sopranist, alto nam |
| Nam cao (Tenor) | C3–C5 | E3–A4 | khoảng E3–E4 | E4–G4 | Leggero, trữ tình, spinto, kịch tính, Heldentenor |
| Nam trung (Baritone) | A2–A4 (một số tài liệu ghi G2–G4 [QU]) | B2–E4 | khoảng C3–C4 | C4–E4 | Trữ tình, kịch tính, baritone-martin (gần tenor) |
| Nam trầm trung (Bass-baritone) | E2–F4 [QU] | A2–D4 | — | B3–D4 | — |
| Nam trầm (Bass) | E2–E4 (basso profondo xuống C2 [QU]) | G2–C4 | khoảng G2–G3 | A3–C4 | Basso cantante, basso buffo, basso profondo, oktavist |

(thay số liệu cũ của bản 1.0: Contralto F3–F5 → F3–E5; Countertenor G3–E5 → E3–E5; Baritone G2–G4 → A2–A4, theo nguồn [BC] ở trên.)

**[BC] Ca sĩ Việt:** NSND Lê Dung, Lan Anh, Bích Thủy được ghi nhận hát tới khoảng C1–D3/E3 theo hệ Đức/Nga, tức khoảng **C4–D6/E6** hệ khoa học (Trịnh Thị Kim Oanh, Nghệ thuật 605/2025). Chưa tìm được bảng âm vực chuẩn Việt Nam từ giáo trình Học viện Âm nhạc Quốc gia, số liệu passaggio cho ca sĩ pop Việt, hay số liệu tuổi vỡ giọng.

## 6.2. Giọng đại chúng và người không chuyên

**[BC] Bề rộng giai điệu pop** (BMI; Secrets of Songwriting):
- Ca sĩ pop nam (ngoài R&B) hát thoải mái khoảng **1,5 quãng 8**; nam R&B **2–2,5 quãng 8** kể cả falsetto; nữ R&B **2,5–3 quãng 8**.
- Đa số bài nằm trong khoảng **1 quãng 8**; giai điệu rộng hơn hẳn **quãng 10** dễ gây vấn đề. Mục tiêu thực hành: **1 quãng 8 đến quãng 10**.
- **Nốt thấp nhất thường ở verse, nốt cao nhất ở điệp khúc.** Nốt thấp nhất thường nâng được mà không hại giai điệu; nốt cao nhất thường là then chốt.
- Nốt giọng ngực cao thoải mái là yếu tố quyết định trong pop/R&B (Berklee).

Bảng dưới là vùng an toàn thực hành [QU]:

| Người hát | Vùng an toàn cho giai điệu | Ghi chú |
| --- | --- | --- |
| Ca sĩ pop nữ | G3–E5 (belt đến C5–E5, giọng pha cao hơn) | Phần lớn hát giọng ngực và giọng pha |
| Ca sĩ pop nam | A2–A4 (belt đến G4–A4, giọng giả cao hơn) | Nhiều ca sĩ nam pop hát vùng tenor |
| Nữ không chuyên | A3–C5 | Tránh giữ nốt trên C5 |
| Nam không chuyên | A2–D4 | Tránh giữ nốt trên E4 |
| Hát tập thể nam nữ | Nữ C4–D5, nam thấp hơn một quãng tám (C3–D4) | Toàn bài gói trong quãng 9–10 |
| Song ca nam–nữ | Giọng nữ thường cao hơn nam quãng 4–5 | Chọn giọng giữa hoặc chuyển giọng khi đổi người hát |

## 6.3. Giọng theo độ tuổi

| Nhóm tuổi | Âm vực thoải mái | Đặc điểm | Quy tắc viết |
| --- | --- | --- | --- |
| 3–5 tuổi (mầm non) | Khoảng C4–A4; tessitura D4–G4 (5–6 nốt) [Cần kiểm chứng: đọc ký hiệu Lumen là suy luận] | Hơi ngắn, dễ lạc giọng | Câu 2 ô, bước liền bậc, lặp nhiều, có động tác |
| 5–6 tuổi | Khoảng quãng 7–8, c1–h1 hoặc c1–c2 (C4–B4/C5); hát tự nhiên nhất **C4–C5**; tessitura khoảng F4–A4 [BC] (Tôn Nữ Diệu Hằng) | Giọng sáng, hẹp | Bài vượt khoảng quãng 9 nên dịch giọng [BC] |
| 6–8 tuổi (lớp 1–3) | Khoảng C4–C5 [BC] (Lumen); bản 1.0 ghi tới D5 [QU]; tessitura khoảng F4–G4 | Giọng sáng, chưa bền; vùng khỏe nhất quanh F–G | Câu 2–4 ô, nhảy quãng ít, từ quen thuộc |
| 9–11/12 tuổi (lớp 4–6, trước dậy thì) | Khoảng B♭3–E5 [BC] (Lumen); bản 1.0 ghi tới F5 [QU]; tessitura khoảng E4–B4 | Giọng thiếu nhi (treble) đẹp nhất | Dùng giọng đầu nhẹ, không ép giọng ngực; có thể hát 2 bè |
| 12–15 tuổi nam (vỡ giọng) | Thu hẹp còn khoảng quãng 6 (thường F3–C4 hoặc G3–D4) | Giọng không ổn định | Âm vực hẹp, không ép nốt cao |
| 12–15 tuổi nữ | A3–E5 | Hơi thở thay đổi | Tránh hát quá sức |
| 16–25 tuổi | Theo loại giọng, đang hoàn thiện | Linh hoạt, sáng | Bài nhanh, rap, belt tốt |
| 26–45 tuổi | Đầy đủ theo loại giọng | Ổn định, dày | Mọi thể loại |
| 46–60 tuổi | Mất 1–3 nốt ở đỉnh | Giọng ấm, trầm hơn | Hạ giọng 1–2 cung so với người trẻ |
| Trên 60 tuổi | Thu hẹp còn quãng 8–10 | Rung rộng, hơi ngắn | Giọng thấp hơn 2–3 cung, câu ngắn, nhịp vừa hoặc chậm |

Các dòng 12 tuổi trở lên là [QU] (giữ từ bản 1.0).

**[BC] Hai lỗi phổ biến với bài thiếu nhi:** người lớn thường chọn tông **quá thấp** cho trẻ (Lumen); giọng cô giáo thường thấp hơn trẻ khoảng **một quãng 4**, nên phải chọn tông theo trẻ, không theo cô (Tôn Nữ Diệu Hằng).

## 6.3a. Chọn tông

**[BC]** Đặt bài vào giữa giọng. Bài cảm xúc mạnh thì nâng tông nhẹ, chấp nhận căng ngắn ở nốt cao; bài trầm tư thì hạ nhẹ (Secrets of Songwriting). Nếu chỉ một nốt vượt tầm, **đổi nốt đó thay vì đổi cả tông**, và thu thử ở nhiều tông để chọn (Berklee). Nốt thấp nhất (verse) thường nâng được; nốt cao nhất (điệp khúc) là then chốt (BMI).

**[QU] Quy trình 5 bước:**
1. Đo nốt thấp nhất thoải mái, nốt cao nhất thoải mái và nốt giọng ngực cao nhất của **ca sĩ thật**, không phải của người viết.
2. Tính tessitura của bài: vùng chứa khoảng **70–80% thời lượng nốt**.
3. Dịch tông để tessitura nằm giữa giọng.
4. Nốt cao trào bằng hoặc nhỉnh hơn nốt ngực cao thoải mái **tối đa 1–2 nửa cung**, chỉ xuất hiện ngắn.
5. Bài có nhạc cụ dân tộc: thử tông với nhạc cụ trước khi chốt (đàn tranh lên dây ngũ cung, đàn bầu lên dây khoảng C3; đổi tông sau khi thu nhạc cụ rất tốn kém). Dịch tông không đổi hướng giai điệu, nên kết quả kiểm tra thanh–nhạc T1–T10 giữ nguyên.

Công cụ: `scripts/chuyen-giong.py`.

## 6.4. Chất giọng và kỹ thuật hát

| Nhóm | Kỹ thuật, chất giọng | Mô tả | Thể loại |
| --- | --- | --- | --- |
| Cộng minh | Giọng ngực (chest) | Dày, nói | Pop, rock, dân ca |
| Cộng minh | Giọng đầu (head) | Nhẹ, vang | Cổ điển, thiếu nhi |
| Cộng minh | Giọng pha (mix) | Nối ngực–đầu | Pop, nhạc kịch |
| Cộng minh | Belt | Mạnh, sáng ở nốt cao | Pop, gospel, nhạc kịch |
| Cộng minh | Giọng giả (falsetto) | Thở, mỏng | R&B, soul, ballad nam |
| Cộng minh | Whistle | Cực cao | Pop diễn |
| Cộng minh | Bel canto, opera | Vang, đều, legato | Opera, hợp xướng |
| Màu giọng | Gió (breathy) | Thì thầm | Ballad, bossa, dream pop |
| Màu giọng | Khàn (raspy) | Thô ráp | Rock, blues, soul |
| Màu giọng | Twang, giọng mũi | Sắc, xa | Country, nhạc kịch |
| Màu giọng | Vocal fry | Lè rè ở đầu câu | Pop hiện đại |
| Màu giọng | Growl, scream | Gầm, hét có kỹ thuật | Metal, rock |
| Trang trí | Melisma, runs | Nhiều nốt trên một chữ | R&B, gospel, nhạc Ả Rập, Ấn |
| Trang trí | Vibrato rộng / hẹp / giọng thẳng | Rung ở cuối nốt | Bolero (rộng), indie (thẳng) |
| Trang trí | Luyến láy, rung, nhấn nhá | Trang trí theo thanh điệu | Dân ca, bolero, cải lương |
| Trang trí | Nảy hạt, ề họng | Kỹ thuật truyền thống | Quan họ, ca trù |
| Trang trí | Kobushi, yodel | Luyến Nhật; nhảy giọng ngực–giả | Enka; dân ca núi Alps, country |
| Lời nói | Xướng, nói–hát, spoken word | Nửa nói nửa hát | Intro, bridge, cải lương (nói lối) |
| Rap | Flow thẳng, ba nốt (triplet), nhanh gấp đôi, chopper, melodic | Mật độ và vị trí chữ so với phách | Hip-hop |
| Tập thể | Ad-lib, hô–đáp, gang vocal, beatbox | Giọng phụ, đám đông | Pop, gospel, a cappella |

## 6.5. Hát bè và đội hình giọng

- **Đội hình:** đơn ca, song ca, tam ca, tốp ca, nhóm nhạc (chia phần), hợp xướng SATB (nữ cao–nữ trầm–nam cao–nam trầm), SSA, TTBB, hợp xướng thiếu nhi 2 bè.
- **Bè đơn giản:** quãng 3 hoặc quãng 6 song song với giai điệu; người không chuyên nên hát đồng âm hoặc cách quãng tám.
- **Bè lót:** ngân âm "ô", "a" theo nốt hợp âm; hô–đáp bằng câu ngắn.
- **Khoảng cách bè:** các bè trên (S–A, A–T) không cách quá quãng tám; bè bass có thể cách xa hơn.

## 6.6. Quy tắc viết giai điệu cho giọng hát

- Nốt cao nhất đặt ở cao trào, không dùng sớm; không giữ nốt dài đúng vùng chuyển giọng.
- Nốt cao dùng nguyên âm mở (a, o, ơ); hạn chế i, u ở nốt cao cho người không chuyên. Tiếng Việt: chữ thanh nặng, hỏi khó ngân dài; ưu tiên thanh ngang, huyền, sắc (sắc chỉ khi âm cuối mở hoặc mũi) ở nốt ngân; tránh âm tiết khép (-p, -t, -c, -ch) ở nốt ngân (N5); nốt cao nhất bài không mang hỏi/nặng (T8) – xem `ngon-ngu/vi.md`.
- Chừa chỗ lấy hơi: câu không quá 4 ô ở nhịp vừa cho người không chuyên.
- Nhảy quãng lớn (quãng 6 trở lên) chỉ dùng ở câu móc hoặc cao trào, sau đó đi bậc ngược lại.
- Với giọng máy AI: mô tả giới tính, độ tuổi cảm nhận (young, mature, child, elderly), loại giọng (tenor, alto…) và chất giọng (breathy, raspy, powerful) trong prompt.
