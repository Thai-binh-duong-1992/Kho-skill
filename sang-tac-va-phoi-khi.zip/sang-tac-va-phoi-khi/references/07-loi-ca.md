> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Âm vực, BPM là giá trị xấp xỉ; C4 = Đô giữa, âm vực ghi theo cao độ thực.

# 9. Lời ca và ngôn ngữ 

Lời hay phải đạt hai điều: **có ý** (hình ảnh, câu chuyện, câu móc) và **hát được** (khớp thanh điệu hoặc trọng âm, đủ chỗ thở). Tệp 07 dạy kỹ thuật chung; mỗi tệp trong `ngon-ngu/` dạy cách khớp lời với nhạc của một ngôn ngữ.

## 9.1. Kỹ thuật lời

- **Câu móc:** có 4 loại: câu chứa tên bài, câu giai điệu không lời ("ô–ô–ô"), câu tiết tấu (lặp âm tiết), câu hô sau điệp khúc (post-chorus chant). Tên bài nằm ở câu đầu hoặc câu cuối điệp khúc.
- **Verse cụ thể, chorus khái quát:** verse kể chi tiết (ai, ở đâu, lúc nào, nhìn thấy gì); chorus nói cảm xúc hoặc thông điệp.
- **Tả, không kể cảm xúc trực tiếp:** dùng hình ảnh 5 giác quan thay cho tính từ trừu tượng ("ly cà phê nguội trên bàn" thay cho "tôi buồn").
- **Ngôi kể và người được nói tới:** giữ nhất quán suốt bài (tôi–em, ta–mình, chúng ta).
- **Vòng câu chuyện:** verse 1 bối cảnh, verse 2 phát triển, bridge bước ngoặt hoặc góc nhìn mới, chorus cuối có thể đổi một chữ để mang nghĩa mới.
- **Tiết kiệm chữ:** mỗi dòng một ý; bỏ từ đệm không cần thiết; tránh sáo ngữ ("trái tim tan vỡ", "mãi mãi bên nhau") trừ khi dùng có chủ đích.
- **Nguyên âm ở nốt ngân:** đặt chữ có nguyên âm mở ở cuối câu và ở nốt cao.

## 9.2. Vần và sơ đồ vần

Bảng chung cho mọi ngôn ngữ. Với tiếng Việt, "vần" = phần vần (âm đệm + âm chính + âm cuối, không tính âm đầu) **cộng nhóm thanh**: hai tiếng hiệp vần phải **cùng bằng hoặc cùng trắc** [BC]. Đầy đủ: `references/12-thi-luat.md` mục 12.1.

| Loại vần | Mô tả | Dùng cho |
| --- | --- | --- |
| Vần chân (cước vận) | Chữ cuối các dòng cùng vần | Mọi thể loại |
| Vần lưng (yêu vận) | Chữ cuối dòng trên vần với chữ giữa dòng dưới; "cốt lõi" của lục bát [BC] | Lục bát, dân ca Việt |
| Vần nội | Vần trong cùng một dòng; trong tiếng Việt thực chất là vần lưng mở rộng [QU] | Rap, pop hiện đại |
| Vần đa âm tiết | Nhiều âm tiết liền nhau cùng vần; rap Việt gọi vần đơn / đôi / ba theo số âm tiết [BC] | Rap |
| Vần gần (slant) / vần thông | Giống nguyên âm hoặc phụ âm cuối, không hoàn toàn. Tiếng Việt: cùng nhóm thanh, âm chính gần (i–ê, u–ô, a–ă), âm cuối cùng loại (cùng mũi hoặc cùng tắc) | Pop, indie, tiếng Anh; phiên khúc Việt |
| Vần chính (vần giàu) | Tiếng Việt: trùng âm chính + âm cuối, cùng nhóm thanh (xanh/cành) [BC] | Câu tiêu đề, cuối điệp khúc |
| Điệp âm | Lặp phụ âm đầu hoặc nguyên âm | Rap, câu móc |

**Vần khép tiếng Việt (-p, -t, -c, -ch) luôn là vần trắc** (chỉ mang sắc hoặc nặng) [BC]. Hệ quả [QU]: **không bao giờ** đặt vần khép ở vị trí vần bằng (chữ 6, chữ 8 lục bát; cuối câu Đường luật) và **không đặt trên nốt ngân giữ ở cuối câu**; vần khép hợp nốt cắt, staccato, rap dồn, câu kết dứt khoát (V8, N5).

Sơ đồ vần (mỗi chữ là một vần): AABB – vần liền (vui, thiếu nhi), ABAB – vần cách (cân đối), ABBA – vần ôm, ABCB (tự nhiên, ballad), AAAA (rap, điệp khúc hô), AAXA (câu thứ 3 mở ra rồi quay về). Tên liền/cách/ôm là [QU] [Cần kiểm chứng]. Verse và chorus nên dùng sơ đồ khác nhau để tạo tương phản; trong phiên khúc giữ nhất quán (V9).

## 9.3. Thể thơ và luật bằng trắc tiếng Việt

Tóm tắt; bảng 14 thể thơ, sơ đồ luật theo vị trí chữ, nhịp thơ → ô nhịp, tu từ, phổ thơ và bộ kiểm tra **V1–V16** ở `references/12-thi-luat.md`. Nghề viết lời (L1–L12): `references/13-nghe-viet-loi.md`. Thanh–nhạc (T1–T10, N1–N9): `references/ngon-ngu/vi.md`.

- **Thanh bằng:** ngang, huyền. **Thanh trắc:** sắc, hỏi, ngã, nặng. Hai tiếng hiệp vần phải cùng nhóm: **vần bằng với bằng, trắc với trắc**, không cần cùng thanh [BC]. Ở thể truyền thống, bằng gặp trắc là lỗi (V6); rap được nới lỏng [QU].
- **Bằng/trắc KHÔNG quyết định cao độ.** Cao độ theo nhóm thanh Ladd & Kirby: sắc/ngã cao; ngang trung; huyền thấp; hỏi/nặng rất thấp. Hai vần bằng có thể ở hai độ cao khác nhau (ngang trung, huyền thấp) (V12).
- **Lục bát** [BC]: cặp dòng 6–8 chữ. Chữ chẵn bắt buộc (lục 2–4–6 = B–T–B; bát 2–4–6–8 = B–T–B–B), chữ lẻ tự do. Chữ 6 dòng 6 vần với chữ 6 dòng 8 (vần lưng), chữ 8 dòng 8 vần với chữ 6 dòng 6 tiếp theo (vần chân); vần lục bát là **vần bằng**. **Luật trầm bổng:** chữ 6 và chữ 8 câu bát **một huyền, một ngang** (V4). Ưu tiên khi viết [QU]: vần chữ 6–8 → trầm bổng → chữ 4 trắc → chữ 2 bằng. Hợp dân ca, ru, quan họ, lý, hò.
- **Song thất lục bát** [BC]: khổ 7–7–6–8; câu thất xét chữ 3–5–7 (trên T–B–T, dưới B–T–B), nhịp 3/4; cặp thất có vần lưng trắc rồi nối vần bằng sang lục bát. Sơ đồ vần chi tiết có **mâu thuẫn nguồn** (xem 12-thi-luat.md mục 12.3). Trang trọng, hợp đoạn kể, than.
- **Đường luật** [BC]: chữ 2–4–6 phân minh, niêm, vần bằng cuối câu 1–2–4–6–8, đối 3–4 và 5–6; ít phổ trực tiếp.
- **Thơ 4, 5 chữ** [BC]: nhịp 2/2; 3/2 hoặc 2/3. **Thơ 7, 8 chữ (Thơ Mới)** [QU]: đều nhịp, dễ phổ pop; 7 chữ ngắt 4/3 hoặc 3/4; 8 chữ ngắt 3/5, 5/3 hoặc 4/4; không cắt đôi từ ghép (V11).
- **Hát nói** [BC]: khổ đủ 11 câu (4–4–3), vần chân luân phiên T – BB – TT – BB…, câu cuối 6 chữ kết bằng. **Vè, đồng dao** [BC]: 4 chữ, nhịp 2/2, vần chân + vần lưng. Hợp kể chuyện, thiếu nhi; gần rap Việt [QU].
- **Vị trí vần bằng giữ trên nốt ngân:** dùng âm tiết mở, nửa mở hoặc nửa khép (kết nguyên âm, -i/-y, -o/-u, -m, -n, -ng, -nh); không dùng vần khép.

(thay nội dung cũ của bản 1.0: mục 9.3 cũ không nêu luật chữ chẵn, luật trầm bổng câu bát và vần khép; "thơ 5, 7, 8 chữ đều nhịp" nay tách nguồn [BC]/[QU].)

## 9.4. Rap

- **Đơn vị:** 1 bar = 1 ô nhịp 4/4; verse thường 16 bar, hook 8 bar.
- **Mật độ chữ:** khoảng 8–16 âm tiết mỗi bar ở 85–95 BPM; flow nhanh gấp đôi 20–24; ghi chỗ thở mỗi 2–4 bar.
- **Vần:** cuối bar có vần chính, giữa bar có vần nội; vần đa âm tiết cho đoạn cao trào.
- **Kỹ thuật:** punchline ở bar 4, 8, 16; chơi chữ; đổi flow giữa verse; ad-lib ở khoảng trống.
- **Tiếng Việt:** vần theo cả vần lẫn thanh (bằng/trắc) mới êm tai; chữ thanh nặng, sắc ngắt tạo nhịp gọn.

## 9.5. Lời theo đối tượng và mục đích

| Đối tượng | Nguyên tắc |
| --- | --- |
| Trẻ 3–5 tuổi | Từ cụ thể (con vật, màu, đồ vật), động từ hành động, lặp lại, tuyệt đối trong sáng |
| Trẻ 6–12 tuổi | Câu ngắn, có bài học nhẹ, hài hước, không bạo lực hay tình yêu người lớn |
| Thanh thiếu niên | Ngôn ngữ trẻ, tự khẳng định, tránh nội dung cổ vũ hành vi nguy hại |
| Người lớn | Đa dạng chủ đề |
| Người cao tuổi | Từ quen, hình ảnh hoài niệm, nhịp vừa |
| Tổ chức, doanh nghiệp | Giá trị cốt lõi thể hiện qua hình ảnh công việc thật, tránh khẩu hiệu khô |
| Quảng cáo | Tên thương hiệu rõ, không cam kết sai sự thật, tuân thủ quy định quảng cáo |
| Y tế, sức khỏe | Không hứa chữa khỏi, tôn trọng người bệnh |
| Tôn giáo, nghi lễ | Đúng giáo lý và thuật ngữ, trang nghiêm |
| Tang lễ, tưởng niệm | Nhẹ nhàng, trân trọng, không bi lụy quá mức |
