> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Âm vực, BPM là giá trị xấp xỉ; C4 = Đô giữa, âm vực ghi theo cao độ thực.

# 4. Nhịp, tiết tấu và nhịp độ 

Nhịp độ quyết định cảm xúc trước cả giai điệu; tệp này cho Claude chọn đúng BPM, loại nhịp và kiểu tiết tấu của bộ gõ. Công thức thời lượng: **1 ô nhịp = số phách × 60 ÷ BPM (giây)**; với 6/8 và 12/8 đếm theo phách chấm (nốt đen chấm).

## 4.1. Thuật ngữ nhịp độ

| Thuật ngữ | BPM xấp xỉ | Cảm giác | Ví dụ dùng |
| --- | --- | --- | --- |
| Grave, Largo | 40–60 | Trang nghiêm, nặng | Nhạc tang lễ, thiền |
| Adagio | 60–76 | Chậm, sâu lắng | Ballad, bolero |
| Andante | 76–108 | Đi bước thư thả | Folk, pop nhẹ, R&B |
| Moderato | 108–120 | Vừa phải | Pop, hành khúc |
| Allegro | 120–156 | Nhanh, vui | Dance, rock, EDM |
| Vivace, Presto | 156–200+ | Rất nhanh | Punk, bebop, bluegrass |
| Rubato | Co giãn | Tự do biểu cảm | Intro ballad, ca khúc nghệ thuật |
| Accelerando / Ritardando | Tăng dần / giảm dần | Dồn dập / kết lắng | Chầu văn (tăng), kết bài (giảm) |
| Fermata | Ngân tự do | Dừng lại | Nốt cao cuối, trước cao trào |

## 4.2. Loại nhịp

| Nhóm | Nhịp | Cảm giác, dùng cho |
| --- | --- | --- |
| Đơn | 2/4 | Đi bước, hành khúc, dân ca, polka, thiếu nhi |
| Đơn | 3/4 | Waltz, đung đưa, hát ru, mariachi |
| Đơn | 4/4 | Phổ biến nhất: pop, rock, hip-hop, EDM |
| Kép | 6/8 | Hai phách chấm, lướt sóng: ballad, jig Celtic, rock ballad |
| Kép | 9/8 | Ba phách chấm: slip jig, một số nhạc cổ điển |
| Kép | 12/8 | Bốn phách chấm: blues chậm, slow rock, soul, gospel |
| Lẻ | 5/4, 5/8 | Lệch, lạ: progressive, jazz, nhạc phim |
| Lẻ | 7/8, 7/4 (2+2+3, 3+2+2) | Balkan, progressive, nhạc game |
| Lẻ | 9/8 aksak (2+2+2+3) | Thổ Nhĩ Kỳ, Balkan |
| Lẻ | 11/8, 13/8 | Thử nghiệm |
| Hỗn hợp | Đổi nhịp giữa bài (4/4 → 3/4, 7/8 → 4/4) | Nhạc kịch, progressive, nhạc phim |
| Tự do | Không số chỉ nhịp | Hò, ngâm thơ, intro, nhạc thiền |
| Theo chu kỳ | Tāla (16, 10, 7 phách), compás flamenco (12 phách), nhịp song lang (4, 8, 16, 32) | Nhạc truyền thống Ấn, Tây Ban Nha, Việt Nam |

## 4.3. Các kiểu tiết tấu (groove)

| Nhóm | Tiết tấu | Mô tả ngắn |
| --- | --- | --- |
| Cơ bản | Straight 8 / 16 | Nốt móc hoặc móc kép đều |
| Cơ bản | Backbeat | Snare nhấn phách 2 và 4 (nền tảng pop, rock) |
| Cơ bản | Four-on-the-floor | Kick đều 4 phách (disco, house, EDM, vinahouse) |
| Cơ bản | Half-time / double-time | Cảm giác chậm đi hoặc nhanh gấp đôi mà BPM giữ nguyên |
| Swing | Swing 2:1 đến 3:1 | Nốt móc đôi chia dài–ngắn (jazz, blues, lo-fi) |
| Swing | Shuffle | Swing trên nền trống rock, blues |
| Nghịch phách | Syncopation | Nhấn vào phách yếu hoặc nửa phách (funk, Latin, K-pop) |
| Nghịch phách | Skank, one drop | Guitar phách lệch; kick và snare cùng phách 3 (reggae) |
| Hip-hop | Boom bap | Kick phách 1, snare 2–4, swing nhẹ |
| Hip-hop | Trap | Hi-hat cuộn 1/16–1/32, 808 dài, snare phách 3 (nửa nhịp) |
| Hip-hop | Drill | Snare lệch, hi-hat trượt, 808 trượt cao độ |
| Điện tử | 2-step, breakbeat | Kick lệch (UK garage), trống cắt ghép (drum and bass) |
| Điện tử | Build-up | Snare dồn 1/4 → 1/8 → 1/16 → 1/32 trước drop |
| Latin | Clave 3-2 / 2-3 (son, rumba) | Khung 5 nốt qua 2 ô, mọi nhạc cụ bám theo |
| Latin | Tresillo, habanera | 3+3+2; nền tango, reggaeton, nhiều pop hiện đại |
| Latin | Dembow | Tresillo + snare lệch (reggaeton) |
| Latin | Bossa nova, samba | Bass phách 1–3, guitar lệch; surdo phách 2 (samba) |
| Latin | Cha-cha-chá, bolero, rumba | Ba nốt nhanh cuối ô; bolero chậm lãng mạn |
| Việt Nam | Bolero Việt | 4/4, khoảng 60–80 BPM, gốc bolero Cuba/rumba có clave [BC]; bass phách 1, đệm đảo phách [QU]. Xem 4.5 |
| Việt Nam | Slow rock 12/8, rumba, boston, chát-chát | Các "điệu" **đệm guitar** phổ biến của nhạc đại chúng Việt; không phải nhịp gốc hay groove sản xuất (xem 4.5) |
| Việt Nam | Nhịp song lang | Phách mạnh ở cuối chu kỳ (đờn ca tài tử, cải lương). Xem 4.5 |
| Châu Phi | Afrobeats 3+3+2, amapiano log drum | Shaker 16 đều, kick thưa, log drum chạy bass |
| Châu Phi | Đa nhịp 3:2, 4:3 | Hai lớp nhịp chồng nhau (afrobeat, gamelan, cồng chiêng) |
| Dân gian | Jig, reel, polka, waltz | Theo 6/8, 4/4, 2/4, 3/4 |
| Trung Đông | Maqsum, baladi, saidi | Chu kỳ "dum–tek" của trống darbuka |
| Ấn Độ | Teental 16 phách, Rupak 7, Jhaptal 10 | Chu kỳ tabla |
| Biểu cảm | Rubato, stop-time, push (vào sớm nửa phách) | Tạo kịch tính cho câu hát |

## 4.4. Chọn nhịp độ theo mục đích

- **Người không chuyên hát tập thể:** 90–125 BPM; nhanh hơn sẽ vấp lời, chậm hơn dễ trôi nhịp.
- **Nhảy, vận động:** 115–130 BPM (đi bước nhanh 120); tập aerobic 130–160.
- **Trẻ mầm non:** 90–120 BPM, tiết tấu đơn giản, lặp nhiều.
- **Người cao tuổi:** 60–100 BPM, nhịp quen thuộc (bolero, rumba, waltz).
- **Thư giãn, ngủ:** 50–70 BPM hoặc không có phách rõ.
- **Rap:** mật độ chữ quyết định độ khó; 80–95 BPM cho flow nốt móc kép, 130–160 BPM cho flow nửa nhịp kiểu trap.

## 4.5. Nhịp cổ truyền và nhịp đại chúng Việt Nam

| Nội dung | Quy tắc | Nhãn |
| --- | --- | --- |
| Vị trí phách mạnh | Trong nhịp cổ truyền, **phách mạnh nằm ở cuối chu kỳ** (cuối câu/khuông), không ở đầu ô như nhạc phương Tây | [BC] |
| Song lang – hơi Bắc | Tiết tấu nhanh; song lang gõ ở **mỗi phách mạnh**, hoặc chỉ ở **khuông 3 và 4** với bài dài | [BC] |
| Song lang – hơi Nam, Oán | Chậm; câu nhạc **8 khuông**, song lang gõ ở phách mạnh **khuông 6 và 8** | [BC] |
| Vọng cổ | Gốc *Dạ cổ hoài lang* (Cao Văn Lầu, Bạc Liêu, 1917–1919), tương đương hơi Oán điệu Nam. Từ nhịp 2 (20 câu) đến **nhịp 32 (6 câu)** | [BC] |
| Vọng cổ nhịp 32 – âm kết cố định | Câu 1 kết **cống**, câu 2 kết **xang**, câu 3, 4 và 6 kết **hò**, câu 5 kết **xê** (hò–xự–xang–xê–cống ≈ sol–la–do–re–mi; một số ký âm lấy hò = do) | [BC] |
| Niên đại nhịp 32 | Hai nguồn mâu thuẫn: 1954 (Trần Thị Hoàng Mỹ) **hoặc** 1940, trình diễn 1941, Năm Nhỏ – Trần Tấn Hưng (Đỗ Quốc Dũng) | Ghi cả hai |
| Quan họ | Quan họ cổ: **nhịp hỗn hợp 2/4–3/4**; quan họ mới: 2/4 hoặc 4/4 | [BC] |
| Bolero Việt | **4/4, khoảng 60–80 BPM** (số từ báo phổ thông, không phải phép đo; không trang hợp âm nào ghi BPM); gốc bolero Cuba và rumba; dạng Mexico/Mỹ Latin, **không phải bolero Tây Ban Nha 3/4**; bản thu *Đôi ngả chia ly* (1961) có tiết tấu **clave Cuba** | [BC] |
| Bolero – cách đệm | Bass ở phách 1, đệm đảo phách | [QU] |
| Ứng dụng phối nhạc dân tộc | Vì phách mạnh ở cuối chu kỳ: đặt **điểm nhấn trống hoặc bass ở cuối câu**; intro kiểu "rao" nhịp tự do trước khi vào nhịp | [QU] |
| Nhãn điệu trên trang hợp âm | Slow, Ballad, Bolero, Slow Rock, Disco, Boston, Blues, Chachacha, Valse, Bossa Nova… trên hopamchuan.com là **điệu đệm guitar** của người đóng góp, **không phải nhịp gốc hay groove sản xuất** (ví dụ *Tiến quân ca* gắn "Slow" dù hành khúc là 2/4; folk fusion/rap gắn "Ballad", "Blues"). Trong 37 bài: Ballad 14, Slow 7, Bolero 5, Rumba 0, Tango 0 | [BC – tập mẫu] |
| Hành khúc, cách mạng | 2/4 hoặc 4/4, nhịp chấm dôi | [QU] |
