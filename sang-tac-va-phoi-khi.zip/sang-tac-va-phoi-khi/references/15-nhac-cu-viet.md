> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Nhạc cụ cho người phối khí: nhạc cụ Việt (Kinh và dân tộc thiểu số), dàn nhạc truyền thống, dàn giao hưởng phương Tây, phím, ban nhạc, điện tử, nhạc cụ thế giới; ma trận kết hợp theo thể loại; bộ kiểm tra I1–I10. C4 = Đô giữa. Cao độ ghi theo cao độ thực, trừ bảng 15.5 ghi tầm **viết**. Nhãn: [BC] có bằng chứng; [QU] quy ước thực hành/suy luận; [Cần kiểm chứng]; "Chưa có nguồn" = chỗ trống thật, **không lấp bằng phỏng đoán**. Danh mục ngắn đa thể loại ở `05-nhac-cu.md`; cách phân lớp ở `06-phoi-khi.md`.

# 15. Nhạc cụ Việt và nhạc cụ cho người phối

## 15.0. Điều quan trọng nhất: hệ cao độ trước, "nghe hay" sau

[BC] Phát hiện cốt lõi cho người phối là **cao độ**, không phải danh sách tên:

| Nhạc cụ / dàn | Dây buông hoặc thang | Hệ quả |
|---|---|---|
| Tỳ bà | C4–F4–G4–C5 | Cùng xoay quanh Đô–Fa(–Sol) |
| Đàn tam | F3–C4–F4 | |
| Guitar phím lõm | C3–F3–C4–G4–C5 | |
| Ba chiêng núm lõi Tây Nguyên | **C–G–C** (nghệ nhân Nay Phai, Della Ratta) | Bourdon chủ âm–át âm |
| Dàn chiêng Ê Đê | Thang 6 âm, **không bán cung** | Không khớp 12 bình quân |
| Dàn chiêng Gia Rai | Thang 5 âm, **có 2 bán cung** | Không khớp 12 bình quân |
| Gamelan slendro | 5 âm gần chia đều quãng tám | Không khớp 12 bình quân |
| Điệu thức Việt | Nhiều bậc khoảng **166 cent**, luyến láy theo hơi (Keefe, Burns & Phong Nguyễn 1991) | Lệch khỏi piano/synth |

→ Câu hỏi đầu tiên khi chọn nhạc cụ: **"nhạc cụ này lên dây theo hệ nào?"**

## 15.1. Cách đọc

- **Phân loại** theo bốn nhóm nhạc công Việt quen dùng, tương ứng Hornbostel–Sachs:

| Nhóm Việt | Hornbostel–Sachs | Ví dụ |
|---|---|---|
| Dây gảy, dây kéo, dây gõ | Chordophone | Tranh, nhị, tam thập lục |
| Hơi | Aerophone | Sáo, kèn bầu, khèn |
| Gõ – tự thân vang | Idiophone | Chiêng, phách, t'rưng, đàn đá |
| Gõ – màng rung | Membranophone | Các loại trống |

  Klông pút là trường hợp lai: vỗ tay đẩy luồng hơi vào ống → về cơ chế là nhạc cụ hơi, dù thường xếp vào bộ gõ.
- **Nhạc cụ dịch giọng:** "viết" = cao độ ghi trên bản nhạc; "kêu" = cao độ thực nghe được.
- **Nguồn:** nhạc cụ Việt chủ yếu từ Wikipedia tiếng Anh, UNESCO, báo chuyên đề và Della Ratta (chiêng Tây Nguyên). Nhạc cụ phương Tây: OrchestraLibrary, Michael Norris, VSL Academy, Evan Rogers. **Chưa truy cập được** vi.wikipedia, phần lớn trang nhạc cụ của Viện Âm nhạc, sách *Nhạc khí dân tộc Việt* (Tô Vũ, Tô Ngọc Thanh), Garland Encyclopedia → nhiều nhạc cụ quen (đàn sến, đàn tính, sáo trúc, kèn bầu, tiêu) **chưa có âm vực có nguồn** (15.12).

## 15.2. Nhạc cụ truyền thống người Việt (Kinh)

[BC] Phần lớn dàn dây người Kinh có gốc họ nhạc cụ Trung Hoa nhưng đã Việt hoá: tỳ bà ← pipa; tam ← sanxian; nguyệt ← yueqin; tam thập lục ← yangqin; đàn hồ ← họ huqin; gáo ← yehu; kèn bầu ← suona. Đặc trưng chung: dây mềm, phím cao hoặc không phím → nhấn, luyến, vuốt được. **Mạnh ở giai điệu và đối âm, yếu ở đệm hợp âm dày.**

### 15.2a. Dây gảy và dây gõ

| Nhạc cụ | Nhóm | Cấu tạo & lên dây | Âm vực | Kỹ thuật & âm sắc | Thể loại dùng | Ghi chú phối khí hiện đại |
|---|---|---|---|---|---|---|
| **Đàn tranh** | Dây gảy | 16 dây, chuẩn 17 dây từ cuối thập niên 1980; lên dây ngũ cung trưởng [BC] | Khoảng 3 quãng tám [BC] | Rải, vuốt glissando, nhấn, tremolo; ít dùng cho bản bi tráng [BC] (Viện Âm nhạc) | Đờn ca tài tử, ca Huế, cải lương [BC] (UNESCO) | Muốn chromatic phải lên lại dây từng nửa cung (thư viện mẫu cũng vậy) [BC]; dây trầm chồng tần số với bass |
| **Đàn bầu** | Dây gảy (bồi âm) | 1 dây, cần uốn; dây buông khoảng **C3 (131 Hz)** [BC] | Theo **7 điểm bồi âm**, cộng uốn cần [BC] | Bồi âm, có hai quãng phi phương Tây; uốn cần lấy nốt giữa các bồi âm [BC] | Độc tấu, ca Huế, đờn ca tài tử, V-pop fusion | **Pickup từ** cho phép vào ban pop/rock [BC]; thu DI cộng micro. Bản điện phổ biến từ thập niên 1960–70 [Cần kiểm chứng] |
| **Đàn nguyệt** (nguyệt cầm; Nam Bộ: đàn kìm) | Dây gảy | 2 dây, phím cao (10 phím ngũ cung); hai dây cách quãng 4, 5 hoặc 7 thứ [BC] | Hơn 2 quãng tám [BC] (Viện Âm nhạc) | Nhấn trên phím cao | Nhạc cụ chính của hát văn [BC]; chèo, nhã nhạc, tài tử, bát âm, ca Huế | *Bắc Bling* dùng nguyệt ở tempo nhanh [BC] |
| **Đàn tỳ bà** | Dây gảy | 4 dây, thân quả lê; dây tơ xưa, nay nylon; **C4–F4–G4–C5** [BC] | Chưa có nguồn | Ôm gần thẳng đứng, miếng gảy lớn; tay trái nhấn uốn cao độ | Nhã nhạc, đờn ca tài tử [BC] | [QU] Dây buông hợp tông C và F. **Đừng thay bằng pipa** (15.9) |
| **Đàn tam** | Dây gảy | 3 dây, không phím, mặt da rắn; **F3–C4–F4** [BC] | Chưa có nguồn | Không phím → trượt liên tục | Nhã nhạc, chèo [BC] (RFA) | [QU] Khung F–C–F làm nền bourdon cho bài giọng F |
| **Đàn đáy** (vô đế cầm) | Dây gảy | Thùng gỗ hình thang **không mặt sau**, cần rất dài, 10 phím cao, 3 dây; nguồn chỉ ghi **G3 và C4** [BC] | Chưa có nguồn; dây thứ ba [Cần kiểm chứng] | Kỹ thuật chưa có nguồn | Đệm ca trù | Nhạc viện Hà Nội làm **bass điện dáng đàn đáy** cho nhạc tân truyền thống [BC]. *Đại Lâm Linh* ghép đáy với guitar điện và sitar [BC] (Vietcetera) |
| **Đàn tứ** (đàn đoản) | Dây gảy | Hai kiểu: thân tròn (gốc yueqin), hoặc thân vuông 4 dây thế kỷ 20 lên **C3–G3–D4–A4** [BC] | Chưa có nguồn | — | Dàn nhạc dân tộc cải biên | [QU] Lên dây như viola → dùng như "viola gảy" |
| **Đàn sến** | Dây gảy | 2 dây, có phím, hình hoa; **nguồn mâu thuẫn về gốc**: meihuaqin (Wikipedia: danh mục nhạc cụ) hay qinqin (Wikipedia: Music of Vietnam) | Chưa có nguồn | Chưa có nguồn | Nam Bộ, tài tử, cải lương [Cần kiểm chứng] | [QU] Màu Nam Bộ |
| **Guitar phím lõm** (lục huyền cầm) | Dây gảy | 5 dây, cần khoét lõm; **C3–F3–C4–G4–C5**; dây nhỏ nhất khoảng 0,5 mm (guitar thường 0,9 mm) [BC] | Chưa có nguồn | Nhấn sâu, luyến cao độ rộng; harmonics nhân tạo mô phỏng đàn bầu | Cải lương, tài tử, nay cả chầu văn [BC] | Bản điện ngày càng phổ biến, giá khoảng 1 triệu đồng, dùng ở tiệc, đám cưới, đám tang quê [BC] (Vietnam News) |
| **Đàn tam thập lục** | Dây gõ | 36 dây kim loại, gõ bằng que, giống yangqin [BC] | Chưa có nguồn | Gõ tremolo, rải | Chèo, nhạc sân khấu, nhạc dân tộc cải biên [BC] | [QU] Vai trò gần dulcimer hoặc celesta mềm trong lớp màu |

### 15.2b. Dây kéo

| Nhạc cụ | Nhóm | Cấu tạo & lên dây | Âm vực | Kỹ thuật & âm sắc | Thể loại dùng | Ghi chú phối khí hiện đại |
|---|---|---|---|---|---|---|
| **Đàn nhị** (đàn cò) | Dây kéo | 2 dây, ống cộng hưởng bịt da rắn. Cây "đàn cò" giống erxian; cây "đàn nhị" giống erhu [BC]. Lên dây quãng 5, ví dụ D4–A4 [Cần kiểm chứng] | Chưa có nguồn | Vuốt, rung, nhấn | Nhã nhạc, chèo, đờn ca tài tử, hát văn | Dàn dân tộc cải biên phần lớn đã thay nhị thủ công bằng **erhu nhập từ Trung Quốc** [BC]. Năng lượng nằm trong dải lời 1–4 kHz → phải nhường chỗ |
| **Đàn gáo** | Dây kéo | 2 dây, hộp cộng hưởng gáo dừa, gốc yehu [BC] | Chưa có nguồn | Xưa chơi cặp với đàn cò | Nam Bộ; đang mai một [BC] | [QU] Cặp gáo–cò là cặp trầm–cao của dàn dây kéo Nam Bộ |
| **Đàn hồ** | Dây kéo | 2 dây, hộp gỗ, tên từ "hu" trong huqin [BC] | Chưa có nguồn | Chưa có nguồn | Chưa có nguồn | [Cần kiểm chứng] Thường làm bè trầm của nhóm nhị trong dàn cải biên |

### 15.2c. Hơi

| Nhạc cụ | Nhóm | Cấu tạo | Âm vực | Kỹ thuật & âm sắc | Thể loại dùng | Ghi chú phối khí hiện đại |
|---|---|---|---|---|---|---|
| **Sáo trúc** (sáo ngang) | Hơi | Sáo ngang bằng trúc hoặc gỗ cứng [BC] | Chưa có nguồn; sáo có nhiều tông (C, D, G…) [Cần kiểm chứng] | Láy, vuốt, rung hơi | Nhã nhạc, chèo, đờn ca tài tử [BC] (UNESCO) | *Bắc Bling* dùng sáo trúc [BC]. **Chọn sáo theo tông bài trước khi chốt tông** |
| **Sáo mèo** | Hơi | Sáo của người H'Mông | Chưa có nguồn | — | Dân ca H'Mông | **Hook** của *Để Mị nói cho mà nghe* [BC] |
| **Tiêu** (sáo dọc) | Hơi | Sáo dọc; có trong thư viện mẫu Ha Noi (MNTRA) [BC] | Chưa có nguồn | Hơi gió nhiều, mềm [Cần kiểm chứng] | Ca Huế, nhạc thính phòng [Cần kiểm chứng] | [QU] Thay shakuhachi khi cần màu thiền mà vẫn là Việt |
| **Kèn bầu** (kèn loa) | Hơi, dăm kép | Thân nón, loa gỗ hình quả bầu, gốc suona [BC] | Chưa có nguồn | Tiếng sắc, to | Nhã nhạc, nhạc lễ | Intro *Bắc Bling* dùng kèn bầu và trống [BC]. Âm lượng lớn → thu xa micro |
| **Kèn đám ma** | Hơi, dăm kép | Thân nón, **loa kim loại** [BC] | Chưa có nguồn | — | Tang lễ Bắc Bộ | Mang nghĩa tang lễ rất mạnh (I6) |

### 15.2d. Gõ

| Nhạc cụ | Nhóm | Cấu tạo | Âm vực | Kỹ thuật & âm sắc | Thể loại dùng | Ghi chú phối khí hiện đại |
|---|---|---|---|---|---|---|
| **Trống cái** | Màng rung | Trống trầm [BC] | Không định âm | — | Lễ hội, nhạc lễ | [QU] Lớp sub thay kick ở intro trang trọng |
| **Trống chầu** | Màng rung | Trống lớn nhất trong dàn tuồng; Wikipedia ghi tên khác là "trống đế" | Không định âm | Ca trù: quan viên cầm chầu đánh khen hoặc chê theo phách [BC] | Tuồng, ca trù [BC] | Có thể Wikipedia gộp trống chầu ca trù với trống đế chèo [Cần kiểm chứng]. *Đại Lâm Linh* dùng trống chầu [BC] |
| **Trống cơm** | Màng rung | Trống hai mặt; dán cơm lên mặt để chỉnh âm [Cần kiểm chứng] | Có định âm tương đối [Cần kiểm chứng] | Vỗ tay | Chèo, nhã nhạc [BC]; cung đình dùng từ thời Lý [BC] | [QU] Lớp tiết tấu tay thay conga trong bài âm hưởng Bắc |
| **Trống bản, trống đế** | Màng rung | Chưa có nguồn | — | — | Chèo, nhã nhạc [Cần kiểm chứng] | Trần Mạnh Hùng phối trống đế với dàn nhạc [BC] (Báo Văn hóa) |
| **Trống đồng** | Tự thân vang | Trống đồng, văn hoá Đông Sơn [BC] | — | — | Nghi lễ cổ | Vật thờ; dùng sample hoặc bản phục chế, ghi rõ trong credit |
| **Phách** | Tự thân vang | Cặp que gỗ gõ lên bàn phách tre [BC] | — | Đào nương vừa hát vừa gõ | Ca trù, chèo | Thu track riêng để sắp lại timing |
| **Song lang** | Tự thân vang | Khối gỗ cứng gõ bằng hòn gỗ gắn lò xo sừng, gõ bằng chân [BC] | — | Gõ phách mạnh cuối chu kỳ: bài Nam và Oán ở khuông 6 và 8 [BC] | Đờn ca tài tử, cải lương | [QU] **Không quantize về phách đầu ô nhịp**; phách mạnh Việt rơi cuối câu |
| **Mõ** | Tự thân vang | Khối gỗ rỗng | — | — | Chèo, nhạc lễ, chùa [BC] | Mõ chùa trong *Thiên thanh* (Trần Mạnh Hùng) [BC] |
| **Thanh la, tam âm la** | Tự thân vang | Thanh la: chiêng nhỏ; tam âm la: ba thanh la nhỏ âm cao treo trên một giá [BC] | Âm cao | — | Thanh la: chèo. Tam âm la: nhã nhạc | [QU] Lớp "chuông" thay glockenspiel cho màu cung đình |
| **Chuông, kyey se** | Tự thân vang | Chuông đặt trước người diễn chèo [BC]; "kyey se" chỉ có tên | — | — | Chèo, chùa | Chuông chùa mang nghĩa tôn giáo (I6) |
| **Biên khánh, khánh** | Tự thân vang | Bộ khánh đá phẳng hình chữ L, gốc bianqing [BC]; khánh đơn [Cần kiểm chứng] | Định âm | — | Nhạc cung đình cổ | — |
| **Sênh tiền** | Tự thân vang | Phách gắn đồng tiền [Cần kiểm chứng] | — | — | Chưa có nguồn | [QU] Thay shaker hoặc tambourine trong lớp nhịp |
| **Chũm chọe** | Tự thân vang | Chỉ có nguồn trong dàn chiêng Gia Rai [BC] | — | — | Lễ hội, nhạc lễ [Cần kiểm chứng] | [QU] Dải cao trùng hi-hat; tránh đặt cả hai cùng lúc |
| **Đàn môi** | Tự thân vang (gảy lưỡi) | Kim loại hoặc tre [BC] | Theo bồi âm khoang miệng | Đổi khẩu hình để đổi bồi âm | Nhiều dân tộc miền núi | [QU] Âm nhỏ, cần micro áp sát |

**[QU] Ba hệ quả cho người phối:**
1. **Tông C và F là "tông nhà"** của tỳ bà, tam, guitar phím lõm (dây buông trên khung Đô–Fa–Sol). Chọn tông gần các giọng này để nhạc công dùng được dây buông.
2. **Đàn tứ thân vuông lên dây như viola** → cầu nối tự nhiên giữa dàn dân tộc và dàn dây phương Tây.
3. "Đàn nhị" trong dàn cải biên thực tế **đã là erhu** → khi viết part, hỏi nhạc công đang dùng cây nào.

## 15.3. Nhạc cụ các dân tộc thiểu số

[BC] Nhiều nhạc cụ tre và bầu được làm ra để **mô phỏng dàn cồng chiêng**:
- Chapi (Raglai) mô phỏng dàn chiêng bằng mã la — vốn đắt và cần 4–6 người chơi (VnExpress).
- Ting ning (Ê Đê, Gia Rai) có tiết mục và cách chơi gần như giống hệt dàn chiêng čĭng arap.
- Đinh năm (Ê Đê) có 6 ống, mỗi ống mang tên một chiêng bằng trong dàn čĭng; người Ê Đê coi là "khuôn mẫu" của dàn chiêng (Della Ratta).

### 15.3a. Bảng nhạc cụ dân tộc thiểu số

| Nhạc cụ — dân tộc | Nhóm | Cấu tạo & lên dây | Âm vực | Kỹ thuật & âm sắc | Thể loại dùng | Ghi chú phối khí hiện đại |
|---|---|---|---|---|---|---|
| **Đàn tính** (tính tẩu) — Tày, Nùng, Thái | Dây gảy | Cần dài, bầu khô làm thùng, 2 hoặc 3 dây tơ, gốc tianqin của người Choang [BC] | Chưa có nguồn; lên dây quãng 4 hoặc 5 [Cần kiểm chứng] | — | Nhạc cụ chính của **hát then**, nghi lễ cầu an, cầu mùa [BC] (VOV) | [QU] Âm nhỏ, cần micro áp sát. Then là thực hành nghi lễ (I6) |
| **Đàn chapi** — Raglai | Dây gảy (đồng chất) | Ống tre lồ ô khoảng 40 cm, **6 cặp dây** tách từ vỏ tre; lên dây bằng đẩy con kê [BC] | Chưa có nguồn | Gảy bằng ngón tay; âm nhỏ, ấm | Lễ bỏ mả, ăn lúa mới, đệm hát, tỏ tình [BC] | [QU] "Chiêng thu nhỏ" thay sample chiêng thật |
| **Ting ning / goong** — Ê Đê, Gia Rai | Dây gảy (dị chất) | Dây kim loại trên ống tre, bầu cộng hưởng ở chân; mẫu cũ 9 dây, mẫu mới **18 dây trở lên** [BC] | Theo thang dàn chiêng | Chơi như dàn čĭng arap | Tây Nguyên | Bản đồng chất *gông kram* gần như đã mất [BC] |
| **Bro** — Tây Nguyên | Dây gảy | Đàn tấm có phím, thân tre, bầu cộng hưởng [BC] | Chưa có nguồn | — | — | — |
| **K'ni** — Gia Rai | Dây kéo | **Một dây**, đĩa cộng hưởng ngậm trong miệng [BC] | Chưa có nguồn | Miệng biến âm tạo hiệu ứng "giọng nói" | — | [QU] Gần talk box tự nhiên; âm rất nhỏ |
| **Cò ke, t'rơbon, karong, tro** — Mường, Chứt, Khùa, Khmer | Dây kéo | Các phiên bản đàn nhị của khối Nam Á [BC] | Chưa có nguồn | — | — | — |
| **Kanhi** — Chăm | Dây kéo | Thùng mai rùa hoặc gáo dừa [Cần kiểm chứng] | Chưa có nguồn | — | Nhạc lễ Chăm [Cần kiểm chứng] | — |
| **Khèn H'Mông** | Hơi, lưỡi gà tự do | **6 ống tre** cắm vào bầu hơi gỗ thông; lưỡi gà lá đồng mỏng [BC] | Chưa có nguồn | Thổi **cả khi thở ra lẫn hít vào**; vừa thổi vừa múa [BC] | Xưa chỉ nam giới, chỉ trong đám tang; nay ở lễ hội, Tết, cưới [BC] | [QU] Âm liên tục → hợp pad hoặc ostinato hoà âm, không làm giai điệu đơn |
| **Khèn bè** — Thái | Hơi, lưỡi gà tự do | Nhiều ống xếp hai hàng [Cần kiểm chứng] | Chưa có nguồn | — | Nhạc Thái | Âm thanh khèn bè là điển hình của quan hệ I–IV, I–V trong nhạc Tày–Thái [BC] (`14-hoa-am-viet-bai-mau.md`) |
| **Đinh năm** — Ê Đê | Hơi, lưỡi gà tự do | **6 ống tre** cắm vào quả bầu; mỗi ống mang tên một chiêng bằng [BC] | Theo thang chiêng Ê Đê | Bịt mở lỗ tạo phức điệu đan xen | Tây Nguyên | Chưa rõ "đinh năm" và "đinh pă" có phải một nhạc cụ [Cần kiểm chứng] |
| **Đinh tút** — Ê Đê, Gia Rai | Hơi | Bộ **6 ống sáo dọc** bịt một đầu, **không lỗ bấm**; chỉnh cao độ bằng nước; bản Gia Rai 7 hoặc 9 ống [BC] | Theo thang chiêng | Mỗi người một ống, đan xen kiểu hoquet; nhóm toàn nữ, chơi ở tang lễ và đầu mùa mưa [BC] | Tây Nguyên | [QU] Khi dùng sample, lập trình đan xen từng nốt, không viết thành một bè liền |
| **Bi doi** — Mường | Hơi | Kèn đôi, giống mijwiz [BC] | Chưa có nguồn | — | Tỏ tình | — |
| **Pí pặp, pí lè** — Thái, Tày | Hơi | Pí pặp lưỡi gà tự do; pí lè dăm kép [Cần kiểm chứng] | Chưa có nguồn | — | — | — |
| **Kèn saranai** — Chăm | Hơi | Họ kèn; chưa có thông số [BC] (Tạp chí GDNT) | Chưa có nguồn | — | Lễ hội Chăm, cùng trống paranưng và ginăng | Nhạc Chăm chồng hai thang 5 âm cách nhau quãng 4 [BC] |
| **T'dep, ốc, púa** | Hơi | Tù và sừng trâu; tù và vỏ ốc; kèn đồng không van [BC] (hai mục sau Wikipedia ghi "citation needed") | — | — | Hiệu lệnh, nghi lễ | — |
| **Klông pút** — Tây Nguyên | Hơi (vỗ tay đẩy hơi) | Các ống tre; vỗ tay trước đầu ống [BC] | Theo chiều dài ống | Hoquet nhiều ống | Tây Nguyên | [QU] Tiếng "bass hơi" mềm, hợp lofi, ambient |
| **T'rưng** — Gia Rai, Ê Đê | Tự thân vang | Ống tre buộc dây; một người hai dùi [BC] | Thư viện mẫu: 3,5 quãng tám chromatic [BC] (rekkerd.org) | Xưa mô phỏng thang và tiết mục čĭng arap [BC] | Nay **phổ biến ở dạng diatonic** khắp Việt Nam [BC] | [QU] Nhạc cụ Tây Nguyên dễ ghép với hoà âm phương Tây nhất |
| **Čĭng kŏk, čĭng kram** (chiêng tre) | Tự thân vang | Ống tre đơn, mỗi người một ống; bản Ê Đê 6–7 ống, trẻ em dùng tập bài chiêng [BC] | Theo thang chiêng | Hoquet | Tây Nguyên | — |
| **Đàn đá** (goong lú, kologolo, gôông luk) — M'nông, Mạ | Tự thân vang | 9 thanh đá trở lên, dài 65–102 cm; niên đại khoảng 1000 TCN [BC] | Chưa có nguồn | — | Tây Nguyên | Có trong gói Vietnam Bundle (Bunker Samples) [BC] |
| **Cồng chiêng** (čĭng Ê Đê, čĭng arap Gia Rai) | Tự thân vang | Chiêng núm và chiêng bằng (15.3b) | Xem 15.3b | Mỗi người một chiêng, đan xen | Lễ mừng lúa mới, cúng bến nước, nhà dài, nhà rông; **mỗi chiêng chứa một vị thần** [BC] | Nhạc cụ nghi lễ (I6) |
| **Mã la** — Raglai | Tự thân vang | Dàn chiêng bằng, 4–6 người chơi [BC] | Chưa có nguồn | — | Nghi lễ Raglai | — |
| **Trống h'gor** — Ê Đê | Màng rung | Trống hai mặt hình thùng [BC] | — | — | Đi cùng dàn čĭng Ê Đê | — |
| **Trống paranưng, ginăng** — Chăm | Màng rung | Chưa có thông số [BC] | — | — | Lễ hội Chăm | — |
| **Nruas tuag** — H'Mông | Màng rung | Trống [BC] | — | — | Tang lễ | Nghĩa tang lễ (I6) |
| **Roneat, kuong vong, skor, chhing** — Khmer Nam Bộ | Gõ | Roneat: đàn thuyền gỗ/tre dẫn giai điệu; kuong vong: bộ cồng tròn; skor: trống; chhing: chũm chọe nhỏ [BC] | Thang 5 âm | Giai điệu nhiều hoa mỹ, tiết tấu chu kỳ | Dàn ngũ âm: chùa Nam tông, tang lễ, Ok-Om-Bok, Chôl Chnăm Thmây [BC] | [QU] Roneat gần xylophone về vai trò nhưng không cùng hệ cao độ |

### 15.3b. Số liệu dàn chiêng Tây Nguyên cho người phối [BC] (Della Ratta)

| Dàn | Thành phần | Quan hệ cao độ | Thang âm |
|---|---|---|---|
| **Čĭng Ê Đê** (dàn chiêng đứng) | 3 chiêng núm (*ana, mdŭ, mung*), 6 chiêng bằng, thêm chiêng bằng lớn *čhar* và trống *h'gor*; treo trên ghế dài trong nhà dài hoặc giá ngoài trời | Chỉnh theo **quãng 5 đúng**; nhóm *khôk* tạo **hợp âm trưởng** | **6 âm, không bán cung** |
| **Čĭng arap Gia Rai** (dàn chiêng diễu hành) | Chiêng núm *ania, či, bêt* (có chiêng nhân đôi) và khoảng 7–9 chiêng bằng; thêm trống và chũm chọe; đi ngược chiều kim đồng hồ | Chiêng núm cách nhau quãng 5 và quãng 4 | **5 âm có 2 bán cung** |
| **Lõi chung** | Bộ 3 chiêng núm | **C–G–C**, theo nghệ nhân chỉnh chiêng Nay Phai | — |

- [BC] Số chiêng dàn čĭng arap khác nhau giữa các nguồn (một số ghi 3 chiêng núm + 8 chiêng bằng). Phần lớn người được Della Ratta phỏng vấn cho rằng chiêng đến từ Lào và Campuchia; các bộ gần đây do người Việt làm.

**[QU] Hệ quả phối khí: drone C–G–C.** Bộ chiêng núm lõi C–G–C = quãng 5 + quãng 4 = **bourdon chủ âm–át âm**. Trong bài giọng C (hoặc dịch giọng bằng sample), dùng ba chiêng núm làm pedal chủ âm và át âm dưới toàn bài.
1. Pedal C–G hợp với I, IV(sus), vi và hoà âm chồng quãng 4; **va chạm với V7** và vòng có bậc ii, iii đổi gốc nhanh → drone chiêng hợp **vòng lặp aeolian của folktronica** hơn giọng thứ có V7 của bolero.
2. Chiêng bằng Ê Đê và Gia Rai theo **hai thang khác nhau** → ghi rõ đang mô phỏng **dàn nào**, không quy về "ngũ cung" chung chung.
3. Chiêng thật **không chỉnh theo A440** → đo cao độ chiêng trước rồi chỉnh toàn bài theo chiêng, hoặc chỉ dùng chiêng ở đoạn không có nhạc cụ 12 bình quân (I3).

## 15.4. Các dàn nhạc truyền thống

| Dàn | Biên chế có nguồn | Chức năng, đặc điểm | Khoảng trống |
|---|---|---|---|
| **Nhã nhạc – đại nhạc** | Cấu trúc cổ xuy gồm trống và kèn; cuối triều Nguyễn giảm từ khoảng 42 xuống khoảng 10 nhạc công [BC] (Phan Thuận Thảo, Viện Âm nhạc) | Trang trọng nhất, dùng trong đại lễ: tế Nam Giao, lễ Thái Miếu, đại triều [BC] | Danh sách nhạc cụ cụ thể [Cần kiểm chứng] |
| **Nhã nhạc – tiểu nhạc** (ti trúc) | Theo Phan Thuận Thảo: 8 nhạc cụ, di chuyển được theo đám rước. Nhạc cụ nhã nhạc nói chung: kèn bầu, tỳ bà, nguyệt, tam, nhị, sáo, trống; riêng cung đình có tam âm la và biên khánh [BC] | Nhẹ hơn: yến tiệc, Tết, tiếp khách nước ngoài [BC]. Năm 1897, F. Baille mô tả dàn khoảng 20 nhạc công | Chưa đối chiếu được 8 nhạc cụ ti trúc với danh sách Wikipedia [Cần kiểm chứng] |
| **Bát âm** | "Nhạc huyền" triều Nguyễn theo cấu trúc bát âm Trung Hoa, nay thất truyền [BC]; đàn nguyệt có đệm cho nhạc bát âm [BC] | Dàn bát âm dân gian Nam Bộ phục vụ cưới, tang, lễ đình [Cần kiểm chứng] | Thành phần dàn bát âm dân gian chưa có nguồn. "Bát âm" vừa là phân loại 8 chất liệu, vừa là tên dàn — **đừng lẫn hai nghĩa** |
| **Ngũ âm** | Ngũ âm Khmer: roneat, kuong vong, skor, chhing; thang 5 âm [BC] | Chùa Nam tông, tang lễ, lễ hội Khmer | Dàn ngũ âm của người Kinh (Huế, nhạc lễ) chưa có nguồn [Cần kiểm chứng] |
| **Chèo** | Giai điệu: đàn kìm (nguyệt), nhị (cò), tam thập lục, tam, sáo. Gõ: mõ, thanh la, trống cơm, chuông [BC] (RFA) | Nhạc chạy liên tục, không ngắt dài; đờn chánh đối đáp với diễn viên | Vị trí trống đế, trống con chưa rõ [Cần kiểm chứng] |
| **Ca trù** | Tối thiểu ba người: đào nương hát và gõ phách, kép đàn chơi đàn đáy, quan viên cầm chầu đánh trống chầu [BC] | Trống chầu khen hoặc chê theo phách | — |
| **Chầu văn / hát văn** | Đàn nguyệt là nhạc cụ chính [BC]; nay có cả guitar phím lõm [BC] | Đưa người hầu đồng vào trạng thái nhập đồng, minh hoạ hành động của giá đồng | Trống, phách, cảnh, thanh la, sáo [Cần kiểm chứng] |
| **Đờn ca tài tử** | Nguyệt (kìm), nhị (cò), **đàn tranh 16 dây**, tỳ bà, gõ, đàn bầu, sáo trúc [BC] (UNESCO); "ngũ tuyệt" tranh, tỳ bà, kìm, cò, tam, thêm sáo, song lang, guitar phím lõm [BC] | Ứng tác trên lòng bản; đôi khi thêm guitar, violin, steel guitar [BC] | — |
| **Cải lương** | Nhạc nền thường là đàn tranh hoặc guitar Việt hoá [BC] | Xen thoại và ca; khác chèo ở chỗ nhạc có ngắt | Biên chế đầy đủ, phần tân nhạc của tân cổ giao duyên [Cần kiểm chứng] |
| **Then** | Đàn tính là nhạc cụ chính [BC] (VOV) | Nghi lễ cầu an, cầu mùa, gọi hồn | Nhạc cụ gõ đi kèm [Cần kiểm chứng] |
| **Cồng chiêng Tây Nguyên** | Čĭng Ê Đê và čĭng arap Gia Rai (15.3b) | Nghi lễ cộng đồng | Dàn Ba Na, Mạ, Cơ Ho chưa có số liệu |
| **Chăm** | Trống paranưng, trống ginăng, kèn saranai [BC] | Lễ hội Chăm | Thông số từng nhạc cụ; vị trí kanhi |
| **Quan họ** | **Không nhạc đệm** [BC] | Hát đối đáp | — |

**[QU] "Tứ tấu dân tộc" chuẩn:** dàn chèo và dàn đờn ca tài tử có chung lõi **nguyệt/kìm + nhị/cò + một dây gảy + sáo + một nhạc cụ giữ nhịp**. Chỉ đổi bộ gõ: mõ, thanh la, trống cơm cho **Bắc**; song lang cho **Nam**. Với tân cổ giao duyên, phần vọng cổ nên chuyển hẳn sang lõi này thay vì giữ dàn pop.

## 15.5. Nhạc cụ dàn nhạc giao hưởng phương Tây

**[BC] Quy tắc dịch giọng cốt lõi** (Michael Norris):

| Nhạc cụ | Kêu so với viết |
|---|---|
| Nhạc cụ "in Bb" (clarinet, trumpet, soprano sax) | Thấp hơn quãng 2 trưởng |
| Tenor sax | Thấp hơn quãng 9 |
| Alto sax "in Eb" | Thấp hơn quãng 6 trưởng |
| Horn F, cor anglais | Thấp hơn quãng 5 đúng |
| Guitar, double bass, contrabassoon | Thấp hơn một quãng tám |
| Piccolo, xylophone, celesta | Cao hơn một quãng tám |
| Glockenspiel, crotales | Cao hơn hai quãng tám |

### Bảng 15.5. Tầm âm **viết** và dịch giọng [BC] (OrchestraLibrary)

| Nhóm | Nhạc cụ | Tầm âm viết | Kêu so với viết |
|---|---|---|---|
| Dây | Violin | G3–A7 | Như viết |
| Dây | Viola | C3–E6 | Như viết |
| Dây | Cello | C2–C6 | Như viết |
| Dây | Double bass | C2–C5 (có phần mở rộng) | −1 quãng tám |
| Dây | Harp | Cb1–G#7 | Như viết |
| Gỗ | Piccolo | D4–C7 | +1 quãng tám |
| Gỗ | Flute | C4–D7 (B-foot xuống B3) | Như viết |
| Gỗ | Alto flute (G) | C4–C7 | −quãng 4 đúng |
| Gỗ | Oboe | Bb3–A6 | Như viết |
| Gỗ | Cor anglais | B3–G6 | −quãng 5 đúng |
| Gỗ | Clarinet Bb / A / Eb | E3–C7 | Bb: −quãng 2 trưởng; A: −quãng 3 thứ; Eb: +quãng 3 thứ |
| Gỗ | Bass clarinet Bb | Eb3 (hoặc C3)–G6 | −quãng 9 (khoá Sol) |
| Gỗ | Bassoon | Bb1–Eb5 | Như viết |
| Gỗ | Contrabassoon | Bb1–Bb4 | −1 quãng tám |
| Đồng | Horn F | F#2–C6 | −quãng 5 đúng |
| Đồng | Trumpet C / Bb | F#3–D6 | C: như viết; Bb: −quãng 2 trưởng |
| Đồng | Tenor trombone | E2–F5 (pedal G1–Bb1) | Như viết |
| Đồng | Bass trombone | Bb1–Bb4 | Như viết |
| Đồng | Tuba | D1–F4 | Như viết |
| Gõ định âm | Timpani | 32": D2–A2; 29": F2–C3; 26": Bb2–F3; 23": D3–A3; 20": F3–C4 | Như viết |
| Gõ định âm | Xylophone | F3–C7 | +1 quãng tám |
| Gõ định âm | Marimba | C2 (hoặc A2)–C7 | Như viết |
| Gõ định âm | Glockenspiel | G3–C6 | +2 quãng tám |
| Gõ định âm | Vibraphone | F3–F6 | Như viết |
| Gõ định âm | Tubular bells | C4–F5 | — |

### Âm sắc theo quãng và cân bằng [BC] (VSL Academy)

| Nhạc cụ | Điểm cần nhớ |
|---|---|
| **Violin** | Dây buông G3–D4–A4–E5. G tối, dày; **D "gần giọng người nhất"**, hợp cantilena; A mềm hơn; E sáng, kim loại. Bấm kép quãng 5, 6 dễ hơn quãng 3, 4. Kỹ thuật: divisi, harmonics, sul ponticello, sul tasto, pizzicato, tremolo, con sordino, col legno. Hoà tốt với gỗ và horn; kém với trumpet, trombone, tuba |
| **Cello** | Lên dây C2–G2–D3–A3. **Dây D giàu nhạc tính nhất**, hợp giai điệu trữ tình. Cello + double bass cách quãng tám giữ nền bass rõ kể cả khi nhỏ; cello cách quãng tám với violin có thể lấn violin |
| **Clarinet** (cao độ kêu) | Chalumeau D3–E4 tối, ấm, gần như chìm trong tutti. **Throat F4–Ab4 yếu, đục → tránh đặt giai điệu chính.** Clarion A4–F6 sáng, gọn, dùng nhiều nhất. Altissimo từ A6 chói. Trong jazz/pop dần bị sax thay |
| **Đồng** | Trumpet ống trụ hẹp, miệng nông → sáng, sắc; horn ống nón, miệng sâu → mềm; tuba ống nón rất rộng → trầm, mềm |
| **Horn** | Đẹp nhất quanh C5 (kêu). **Horn forte ≈ một nửa âm lượng trumpet/trombone forte** → ghi cường độ cho horn cao hơn tương đối. Hoà tốt với clarinet, bassoon; đi unison với cello |

**[QU] Ba hệ quả cho bài Việt:**
1. Ballad: violin I ở dây D hoặc A cho điệp khúc; cello dây D làm câu đối đáp dưới giọng nữ.
2. Bolero thu thật: clarinet hoặc sax hợp câu dạo hơn trumpet (mềm, gần giọng hát).
3. Ghép với nhạc cụ dân tộc: nhạc cụ có năng lượng trong dải lời 1–4 kHz (violin dây E, oboe, trumpet, sáo, nhị) dễ va nhau nhất → xếp dàn dây phương Tây làm nền ở quãng trầm và giữa, nhạc cụ dân tộc giữ giai điệu phụ ở quãng cao. DAW thường ghi cao độ thực; chỉ dịch giọng khi xuất part cho nhạc công thật.

## 15.6. Nhạc cụ phím

| Nhạc cụ | Thông số | Âm sắc, vai trò | Nhãn |
|---|---|---|---|
| **Piano** | A0–C8 (OrchestraLibrary) | Nền hoà âm của gần như mọi thể loại tân nhạc | [BC] |
| **Celesta** | C3–C7 viết, kêu cao hơn một quãng tám (OrchestraLibrary) | Lớp chuông lấp lánh, nhạc thiếu nhi, intro ballad | Thông số [BC]; vai trò [QU] |
| **Harpsichord** | F1–F6 (OrchestraLibrary) | Màu baroque; tiếng gảy gần tỳ bà, tam | Thông số [BC]; vai trò [QU] |
| **Hammond organ** | Ra đời 1934; motor quay tonewheel (96 tonewheel trên B3/C3); drawbar trắng là các quãng tám, đen là bồi âm quãng 3 và 5, nâu là sub; percussion tạo tiếng "chink"; Leslie chậm "Chorale", nhanh "Tremolo"; **B3 sản xuất 1955–1974** (Sound On Sound; Apple Logic Pro) | Jazz, rock, soul, R&B | [BC] |
| **Rhodes** (electric piano tine) | Chưa có nguồn | Tròn, ngân như chuông khi đánh mạnh; R&B, neo-soul, city pop, ballad V-pop | [QU] |
| **Wurlitzer** (electric piano reed) | Chưa có nguồn | Gắt hơn, "bark" khi đánh mạnh; soul, indie-pop | [QU] |
| **Accordion** | Phím piano cộng nút bass Stradella | Tango, nhạc Pháp, valse tiền chiến | [Cần kiểm chứng] |
| **Keyboard arranger ("đàn organ")** | Yamaha PSR, Roland… có "điệu" bolero, rumba dựng sẵn | Trong đám cưới miền Tây và bolero, "organ" thường chỉ loại đàn này, **không phải Hammond** | [QU] |

[BC] *Chúng ta của hiện tại* (Sơn Tùng M-TP, 2020) được phê bình quốc tế nhận xét có sax solo, drum machine "cổ điển", synth lấp lánh, hợp âm R&B thập niên 90, cảm giác city pop (The Singles Jukebox). Nguồn không nêu loại electric piano.

## 15.7. Nhạc cụ ban nhạc

**[BC] Quy tắc phối thực dụng** (Evan Rogers; OrchestraLibrary):
- Mọi saxophone có chung tầm âm viết. Phối an toàn: **bỏ một quãng 4 ở mỗi đầu**, tránh vài nốt trầm nhất ở đoạn nhỏ, cẩn thận cao độ trên C cao. Điểm đổi quãng cần để ý: C#–D (viết).
- Trumpet Bb: G (viết) là trần an toàn.
- Trombone luôn khoá Fa; trombone 1–2 không xuống dưới C để chơi được không cần trigger.
- Guitar và bass kêu thấp hơn một quãng tám; **nhạc công session thường mang bass 5 dây**.
- Sax soprano Bb: −quãng 2 trưởng; alto Eb: −quãng 6 trưởng; tenor Bb: −quãng 9; baritone Eb: −quãng tám + quãng 6; bari đời mới xuống A viết = C2 kêu.

| Nhạc cụ | Lên dây / tầm âm | Vai trò thường gặp | Nhãn |
|---|---|---|---|
| Guitar acoustic dây thép / nylon | EADGBE; tầm viết E3–E6, kêu thấp hơn một quãng tám | Thép: strum ballad, pop acoustic. Nylon: bossa, ballad nhẹ, rải hợp âm, nhạc Trịnh | Tầm âm [BC]; vai trò [QU] |
| Guitar điện | Khoảng E2–E6 (22–24 phím) | Clean arpeggio cho ballad; crunch, distortion cho rock; lead solo; lead điện trong bolero | [Cần kiểm chứng] |
| Bass 4 dây | E1–A1–D2–G2 dây buông | Nền hoà âm, khoá với kick | [Cần kiểm chứng] |
| Bass 5 dây | Thêm dây B0 | Nốt dưới E1 cho pop, rock hiện đại, gospel | Phổ biến ở session: [BC] |
| Trống jazz (drum kit) | Kick, snare, hi-hat, tom, cymbal | Nền nhịp mọi thể loại tân nhạc; điệu bolero, rumba trong nhạc vàng | [QU] |
| Saxophone soprano, alto, tenor, baritone | Như trên | Solo ballad, jazz, city pop; câu dạo bolero | [BC] |
| Harmonica diatonic | Mỗi cây một tông (C, G, A…) | Blues, folk; uốn nốt | [Cần kiểm chứng] |
| Ukulele soprano, concert | G4–C4–E4–A4 (re-entrant) | Pop vui, indie acoustic | [Cần kiểm chứng] |
| Mandolin | G3–D4–A4–E5, dây đôi | Tremolo giai điệu, folk | [Cần kiểm chứng] |
| Banjo 5 dây | Open G (gDGBD) | Country, bluegrass | [Cần kiểm chứng] |
| Guitar Hawaii (Hạ uy cầm, steel guitar) | Chưa có nguồn về lên dây | Vuốt nốt "như tiếng nấc" trong bolero (Vietcetera) | [BC] |

**[BC] Bối cảnh Việt Nam:**
- **Guitar Hawaii** vào Việt Nam thập niên 1930 qua nhạc sĩ William Chan ("Hạ uy cầm"); thịnh hành 1950–1970 nhờ Đoàn Chuẩn, Nguyễn Thiện Tơ, Phạm Mạnh Đạt; gắn với *Suối mơ*, *Con kênh xanh xanh*, *Diễm xưa*. Bị lãng quên khoảng 30 năm (tính đến 2012); CLB Guitar Hawaii của Bùi Bạch Liên lập 1997 (OVietnam).
- Đờn ca tài tử đôi khi thêm guitar, violin, steel guitar.
- **Saxophone** gắn với Trần Mạnh Tuấn (sinh 1970): chơi sax từ 1979; album *Độc tấu Saxophone Trần Mạnh Tuấn* (1997), *Hạ trắng* (2002), *Về quê* (2003, dân ca cho sax), *Jazz It Up "Sến"* (2013); thập niên 1990 trong ban Phương Đông (Quốc Trung, Quyền Văn Minh, Văn Hà, Anh Quân). Ông nhận xét dân ca Bắc và Nam dễ hoà âm với nhạc đương đại hơn; **dân ca miền Trung khó kết hợp jazz hơn** (Báo Văn hóa).

[QU] Công thức bolero thu âm phổ biến: guitar (phím lõm hoặc lead điện) + keyboard arranger + bass + trống điệu rumba-bolero, đôi khi thêm sax hoặc violin. Guitar Hawaii là màu "hoài cổ" 1950–1970. Chưa có nguồn trực tiếp mô tả công thức này.

## 15.8. Nhạc cụ điện tử và sản xuất

| Mục | Nội dung | Nhãn |
|---|---|---|
| **Synth** | Subtractive (oscillator giàu bồi âm qua bộ lọc: bass, pad, lead ấm); FM (điều tần: electric piano, bell, bass gọn); wavetable (quét bảng dạng sóng: supersaw, pluck, bass chuyển động EDM). Chưa có nguồn lịch sử máy cụ thể | [Cần kiểm chứng] |
| Synth + đàn tranh | Synth pluck hoặc bell FM hay đi song song với đàn tranh trong folktronica; **cả hai cùng rải một quãng → nghe như tranh nhau** | [QU] |
| **TR-808** | Sản xuất 1980–1983, giá ra mắt 1.195 USD, khoảng 12.000 chiếc, analog hoàn toàn. Kick = oscillator sine qua lọc thông thấp + VCA; kéo dài decay → nốt hơi tụt cao độ. Rick Rubin phổ biến kéo dài decay và chỉnh cao độ kick **thành bassline**; *808s & Heartbreak* (2008) và **trap** đưa thành nền tảng (Wikipedia: TR-808) | [BC] |
| **TR-909** và kế thừa | TR-909 (1983) là máy Roland đầu tiên dùng sample, định hình techno, house, acid. Kế thừa: TR-08 (2017), bản phần mềm chính hãng (2018), Behringer RD-8 (2019), **Roland TR-1000 (2025)** | [BC] |
| "808" trong V-pop, rap Việt | Sample kick-bass dài, chỉnh nốt theo vòng hoà âm, có glide; cần sidechain hoặc tách tần số với kick; cần saturation để nghe được trên loa điện thoại. Dùng cả 808 và bass guitar: **808/sub giữ dưới ~60 Hz, bass guitar giữ vùng hài 80–250 Hz** | [QU] |
| **Sampler, MPC** | Gán bản thu nhạc cụ thật (trống cơm, song lang, câu hò) lên pad, chơi lại theo nhịp — cách phổ biến đưa chất liệu dân gian vào beat. Chưa có nguồn lịch sử MPC | [Cần kiểm chứng] |
| **MIDI, MPE** | MPE bổ sung vào chuẩn MIDI năm 2018; cho velocity, pitch bend, pressure và trục X/Y **riêng từng nốt** (Sound On Sound) | [BC] |
| **Vocoder, talk box, Auto-Tune** | Vocoder áp phổ giọng lên synth; talk box đưa âm nhạc cụ vào miệng qua ống; K'ni Gia Rai là "talk box" tự nhiên. Auto-Tune tốc độ rất nhanh → giọng robot của trap, V-pop | [Cần kiểm chứng] |
| Auto-Tune với tiếng Việt | **Làm phẳng đường nét thanh điệu** → chỉ dùng có chủ ý; chạy lại bộ T2–T6 trên bản đã xử lý | [QU] |
| **Thư viện mẫu nhạc cụ Việt** | Dan Bau, Dan Tranh (Bolder Sounds); Ha Noi (MNTRA: đàn đáy, nhị, bầu điện, trống ban, trống chèo, T'rưng, sáo mèo, tiêu); T'rung (Bunker Samples, 02/2026, có gói đàn đá) | [BC] |
| **AI tạo nhạc** | UMG rút kiện, ký thoả thuận cấp phép với Udio 10/2025; WMG dàn xếp và hợp tác với Suno 11/2025. Một nguồn tổng hợp ghi Sony vẫn kiện cả hai — chưa kiểm chứng đến 11/2026 [Cần kiểm chứng]. Blog 27/4/2026 (StraySpark) nêu Suno v5 xuất stem WAV 48 kHz, Udio Pro v3 xuất stem MIDI, Stable Audio 3 chạy cục bộ — **nguồn tin cậy thấp** (ghi Suno v5 ra 3/2026, nguồn khác ghi 9/2025; nói vụ kiện "vẫn đang diễn ra" 4/2026) → kiểm tra trang nhà sản xuất trước khi dựa vào. Nguyên tắc: AI cho demo, con người có đóng góp quyết định | [BC] (dàn xếp); tính năng: [Cần kiểm chứng] |

### Bảng 15.8. Bộ điều khiển MPE [BC] (Sound On Sound)

| Bộ điều khiển | Đặc điểm | Giá (theo SOS) |
|---|---|---|
| ROLI Seaboard 2 (và Seaboard M 24 phím) | Mặt phím mềm: nhấn, trượt dọc và ngang; pin khoảng 8 giờ | £1099 (M: £299) |
| Expressive E Osmose | Phím thường nhưng lắc ngang được; synth EaganMatrix 24 voice, chạy độc lập | £1549 / $1799 |
| LinnStrument | Lưới nốt cách quãng 4, năm kiểu cảm ứng, có sequencer và arpeggiator | £1125–£1399 |
| Ableton Push 3 / Push 3 Standalone | 64 pad cảm biến X/Y, audio interface, CV/gate; bản Standalone có CPU, pin, SSD 256 GB | £879 / £1299 |
| Haken Continuum / ContinuuMini | Điều khiển liên tục 3D cho từng ngón | Từ £1099 |
| Intuitive Instruments Exquis | Phím lục giác, bend và aftertouch từng phím | €299 |
| embodme Erae 2 | 16.000 cảm biến lực, looper 8 track | €799 |
| Jamstik | Guitar MIDI MPE, mỗi dây một kênh | Từ £799 |

[QU] MPE là cách gần nhất mô phỏng luyến láy đàn bầu, đàn tranh bằng phím: bend riêng từng nốt, vibrato theo lực nhấn; bend liên tục nên tái tạo nốt nhấn **166 cent** tốt hơn bộ mẫu Kontakt cố định 12 bình quân. Kỹ năng vẫn là của người chơi phím, không phải nghệ nhân → **phần độc tấu chính vẫn nên dùng người thật**.

## 15.9. Nhạc cụ thế giới thường dùng trong fusion châu Á

- [BC] **Guzheng:** phổ biến 21 dây (có loại 25–26), ngũ cung trưởng D–E–F#–A–B; dây 21 = D2 (73,41 Hz), dây 1 = D6 (1174,7 Hz); bảng cộng hưởng gỗ paulownia → sáng, rõ; dây thép bọc nylon sáng hơn dây tơ. Năng lượng dây trầm 19–21 chủ yếu ở **40–250 Hz** (BioResources) → dây trầm guzheng (và có thể cả đàn tranh) **chồng trực tiếp lên vùng bass guitar**.
- [BC] **Gamelan:** slendro 5 âm, **gần chia đều** quãng tám, đánh số 1-2-3-5-6; cao độ khác theo vùng và từng bộ; pelog là hệ còn lại (Wikipedia: Slendro). Chia đều tuyệt đối thì mỗi bước khoảng 240 cent (phép tính 1200/5, không phải số đo), khác bước 200/300 cent của ngũ cung trên piano. Ableton Live có sẵn hệ lên dây gamelan Sunda. **Hệ quả:** chỉnh tuning phần điện tử theo gamelan, hoặc chấp nhận độ lệch như màu riêng.

### Bảng 15.9. Nhạc cụ thế giới và quan hệ với nhạc cụ Việt

| Nhạc cụ | Nét chính để phối | Quan hệ với nhạc cụ Việt | Nhãn |
|---|---|---|---|
| **Guzheng** (Trung Hoa) | 21 dây, D2–D6, ngũ cung trưởng | **Trùng vai đàn tranh** | [BC] |
| **Erhu** | 2 dây, vibrato và glissando đậm | Gần đàn nhị; đã thay nhị thủ công trong dàn cải biên [BC] | Lên dây: [Cần kiểm chứng] |
| **Pipa** | 4 dây, tremolo (luân chỉ) | Gần tỳ bà | [Cần kiểm chứng] |
| **Dizi** | Sáo ngang có màng dimo rung | Gần sáo trúc nhưng sáng và "rè" hơn | [Cần kiểm chứng] |
| **Koto** (Nhật) | 13 dây, ngũ cung Nhật (hirajōshi…) | Gần đàn tranh | [Cần kiểm chứng] |
| **Shamisen** | 3 dây, gảy bằng phím lớn, tiếng gắt | Vai trò gần nguyệt, tam | [Cần kiểm chứng] |
| **Shakuhachi** | Sáo dọc tre, nhiều hơi gió | Gần tiêu | [Cần kiểm chứng] |
| **Gayageum** (Hàn) | 12 dây | Gần đàn tranh | [Cần kiểm chứng] |
| **Sitar** (Ấn Độ) | Dây cộng hưởng, meend (vuốt) | *Đại Lâm Linh* ghép sitar với guitar điện và đàn đáy (Vietcetera) | Dùng ở Việt Nam: [BC] |
| **Tabla** | Cặp trống tay, theo tala | Tương phản về nhịp với trống cơm | [Cần kiểm chứng] |
| **Gamelan** (Indonesia) | Slendro, pelog; không 12 bình quân | Gần dàn chiêng về vai trò, nhưng khác thang | [BC] |
| **Gõ Latin** (conga, bongo, clave, maracas) | Rumba, bolero, cha cha | Bolero Việt có clave Cuba (Rising Asia Journal) | Clave trong bolero: [BC] |
| **Cajón** | Hộp gỗ ngồi gõ, thay drum kit acoustic | Hợp unplugged, acoustic | [Cần kiểm chứng] |
| **Handpan / hang** | Thép, thang cố định (D Kurd…), ngân dài | Ambient, lofi | [Cần kiểm chứng] |
| **Kalimba** | Lamellophone, thường 17 phím C | Intro lofi, indie, thiếu nhi | [Cần kiểm chứng] |

### Cảnh báo: đừng nhầm tranh/guzheng, nhị/erhu, tỳ bà/pipa

[BC] Nhiều nhạc cụ Việt có gốc Trung Hoa nhưng **đã khác về cấu tạo và lên dây**:

| Việt | Trung Hoa | Khác biệt có nguồn |
|---|---|---|
| Đàn tranh: 16 hoặc 17 dây | Guzheng: phổ biến 21 dây | Số dây, thang lên dây |
| Tỳ bà: C4–F4–G4–C5 | Pipa | Nguồn chưa cho thấy pipa lên cùng dây |
| Đàn nhị (cây "nhị" giống erhu); đàn cò Nam Bộ giống **erxian** hơn erhu | Erhu | Dàn cải biên Việt đã dùng erhu thay nhị, nhưng không đồng nhất |
| Cao độ Việt: nhiều bậc khoảng **166 cent**, luyến láy theo hơi (Keefe, Burns & Phong Nguyễn 1991) | — | Sample Trung Hoa không mang hệ cao độ này |

**[QU] Bốn quy tắc:**
1. **Không** dùng sample guzheng, erhu, pipa rồi ghi credit là "đàn tranh", "đàn nhị", "tỳ bà".
2. **Không** xếp guzheng, koto hoặc dizi **cùng vai** với tranh, sáo trúc trong một bài → dễ thành "lai Trung, lai Nhật", mất bản sắc.
3. Nhạc cụ thế giới nên giữ **vai tương phản**: nhịp (cajón, tabla, gõ Latin) hoặc màu (handpan, kalimba, sitar).
4. Buộc dùng sample Trung Hoa cho demo → ghi rõ trong bảng phối là **sẽ thay bằng nhạc cụ Việt ở bản cuối**.

## 15.10. Ma trận kết hợp theo thể loại

| Thể loại | Lõi nhạc cụ Việt | Ghép với nhạc cụ hiện đại / thế giới | Vai trò và vùng tần số | Nhãn, nguồn |
|---|---|---|---|---|
| **Bolero / nhạc vàng** | Guitar phím lõm hoặc guitar Hawaii vuốt nốt | Guitar lead điện, keyboard arranger, bass, trống điệu bolero, clave; sax hoặc violin câu dạo | Hawaii, sax giữ câu dạo và câu đáp ở quãng giữa–cao; keyboard nền; bass đi âm trì | Guitar Hawaii, clave: [BC] (Vietcetera; Rising Asia Journal). Còn lại: [QU] |
| **Trữ tình, dân ca mới** | Sáo trúc, đàn tranh, đàn bầu, nhị | Dàn dây phương Tây, piano; giao hưởng hoá với horn, harp | Tranh rải làm nền; bầu hoặc sáo đáp vào khoảng nghỉ của lời; cello dây D làm đối âm | Dàn dây với dân ca: [BC] (Báo Văn hóa). Phân vai: [QU] |
| **Nhạc Trịnh** | Thường không có nhạc cụ dân tộc | Guitar nylon, piano, cello; đôi khi sáo trúc hoặc đàn tranh | Guitar nylon rải giữ hoà âm I7→iv; cello đối âm ở quãng tenor | [QU] |
| **V-pop ballad** | Tuỳ chọn: sáo trúc hoặc đàn tranh ở intro | Piano, pad, dàn dây, trống nhẹ hoặc 808 thưa; Rhodes, sax cho màu city pop | Lời giữ 1–4 kHz; dây và pad ở quãng giữa; 808 ở sub | Sax và city pop: [BC] (The Singles Jukebox). Còn lại: [QU] |
| **Folktronica** | Sáo mèo, sáo trúc, nguyệt, nhị, kèn bầu, trống | Future bass, synth pluck, 808/909, vocal chop, drone chiêng C–G–C | Nhạc cụ dân tộc làm hook ở intro và drop; synth tránh rải cùng quãng với tranh | Hook nhạc cụ dân tộc: [BC] (*Để Mị*, *Bắc Bling*). Drone chiêng: [QU] |
| **Rap** | Trống chầu văn, vè, đàn tranh, đàn bầu | Beat trap (808), boom-bap, sample trống cơm, song lang | 808 giữ sub; nhạc cụ dân tộc là sample vòng lặp hoặc hook; không chen vào câu rap | *Thầy Dùi*, mashup *Lý Ngựa ô*: [BC] (Báo Văn hóa) |
| **Giao hưởng dân tộc** | Bộ gõ dân tộc (chén, trống chiến, trống đế, mõ chùa); đàn bầu, đàn tranh độc tấu | Dàn nhạc giao hưởng đầy đủ | Nhạc cụ dân tộc độc tấu trên nền dây piano–mezzo; horn đỡ ở quãng giữa | Trần Mạnh Hùng: [BC] (Báo Văn hóa). Ngũ tấu dây với quan họ (*Nam nhi*): [BC] (Vietcetera) |
| **Rock, tân truyền thống** | Đàn đáy, trống chầu, bass dáng đàn đáy | Guitar điện, sitar, drum kit | Đáy và trống chầu làm màu; guitar điện giữ hoà âm | *Đại Lâm Linh*: [BC] (Vietcetera); bass dáng đáy: [BC] (Wikipedia: Đàn đáy) |
| **Jazz dân ca** | Giai điệu dân ca Bắc, Nam | Saxophone, piano, contrabass, trống jazz | Sax giữ giai điệu; dân ca miền Trung khó hơn | Trần Mạnh Tuấn: [BC] (Báo Văn hóa) |

**[QU] Xếp vai theo vùng tần số — năm "ngăn" giữ tách nhau:**

| Ngăn | Dải | Nhạc cụ | Quy tắc |
|---|---|---|---|
| 1. Sub | Dưới ~60 Hz | 808, sub synth, trống cái | **Chỉ một nguồn** |
| 2. Bass | ~60–250 Hz | Bass guitar, cello, dây trầm tranh/guzheng (40–250 Hz [BC] BioResources), đàn tam, đàn đáy | Khi tranh rải xuống dây trầm, bass nghỉ hoặc đi nốt dài |
| 3. Giữa | ~250 Hz–1 kHz | Piano, guitar đệm, pad, horn, viola, thân tiếng nguyệt, tỳ bà | — |
| 4. Dải lời | 1–4 kHz | Giọng hát + sáo, nhị, kèn bầu, violin dây E, trumpet, tiếng gảy của tranh | Nhạc cụ này **chỉ vào khoảng nghỉ của lời** (dải 1–4 kHz, đỉnh ~2 kHz quyết định độ rõ lời [BC] DPA) |
| 5. Cao | Trên 4 kHz | Hi-hat, chũm chọe, thanh la, tam âm la, celesta, glockenspiel | Chọn một nguồn chính, không chồng nhiều |

## 15.11. Bộ kiểm tra chọn nhạc cụ I1–I10

Chạy ở tiền kỳ, **sau khi chốt tông và BPM, trước khi viết arrangement map**.

| Mã | Câu hỏi kiểm tra | Cách làm, căn cứ |
|---|---|---|
| **I1** | Mỗi bè có nằm trong tầm âm thực dụng của nhạc cụ không? | Đối chiếu bảng 15.5. Lấy hẹp hơn tầm tối đa khoảng một quãng 4 ở mỗi đầu cho nhạc công phòng thu thông thường [BC] (Evan Rogers). Tránh vùng yếu, ví dụ clarinet throat F4–Ab4 |
| **I2** | Tông bài có thuận dây buông của nhạc cụ dân tộc không? | Tỳ bà, tam, phím lõm thuận C và F. Nếu tông khác, hỏi nhạc công có lên lại dây được không, hoặc nhích tông nửa cung |
| **I3** | Hệ cao độ có tương thích không (vấn đề 166 cent)? | Chọn một trong hai chiến lược: nhạc cụ theo synth, hoặc synth theo nhạc cụ (`16-san-xuat.md`). Ghi rõ đoạn nào là độc tấu dân tộc "tự do cao độ" |
| **I4** | Có nhạc cụ nào ngoài hệ 12 bình quân không (gamelan, dàn chiêng)? | Ghi rõ dàn chiêng nào (Ê Đê 6 âm hay Gia Rai 5 âm có bán cung). Đo cao độ chiêng thật hoặc dùng hệ lên dây tương ứng trong DAW. Không đặt pad 12 bình quân dày dưới chiêng thật |
| **I5** | Có hai nhạc cụ trùng vai không? | Không xếp tranh với guzheng hoặc koto, nhị với erhu, sáo trúc với dizi cùng vai. Không để synth pluck rải cùng quãng với đàn tranh (15.9) |
| **I6** | Nhạc cụ có mang nghĩa nghi lễ hoặc tâm linh không? | Cồng chiêng (mỗi chiêng chứa một vị thần), hát văn và hầu đồng, then, khèn H'Mông (xưa chỉ dùng trong đám tang), kèn đám ma, trống tang H'Mông, mõ và chuông chùa. Hỏi ý kiến nghệ nhân hoặc cộng đồng; tránh đặt vào ngữ cảnh chế giễu; ghi credit nghệ nhân và dân tộc |
| **I7** | Nhạc cụ có đủ âm lượng trong dàn không, hay cần khuếch đại? | Đàn bầu cần pickup. Chapi, đàn tính, đàn đáy, đàn môi, k'ni âm nhỏ, cần micro áp sát hoặc pickup tiếp xúc [QU]. Kèn bầu và trống to, thu xa micro (`16-san-xuat.md`) |
| **I8** | Có nhạc công thật không, hay dùng sample? | Độc tấu có luyến láy (bầu, sáo, nhị, nguyệt) nên dùng người thật ở bản cuối. Sample cho demo và lớp nền. Ghi danh sách phần sẽ thay bằng người thật |
| **I9** | Giấy phép của sample, thư viện và công cụ AI có cho dùng thương mại không? | Đọc EULA từng thư viện mẫu. Với AI, đọc điều khoản hiện hành của Suno và Udio (đã đổi sau các thoả thuận với hãng đĩa). Ghi nghệ nhân vào split sheet hoặc credit (`17-phap-ly-phat-hanh.md`) |
| **I10** | Part giao cho nhạc công đã đúng ký âm chưa? | Xuất part dịch giọng cho sax, trumpet, horn, clarinet; DAW thường ghi cao độ thực. Với nghệ nhân dân tộc, gửi guide audio có luyến láy kèm bản nhạc, vì **chưa có hệ ký hiệu luyến láy chuẩn Việt** |

## 15.12. Khoảng trống bằng chứng

| Mảng | Còn thiếu |
|---|---|
| **Thông số nhạc cụ Việt** | Âm vực và lên dây của đàn sến, đàn tính, đàn nhị, đàn hồ, đàn gáo, tam thập lục, sáo trúc, tiêu, kèn bầu, saranai. Đàn đáy chỉ có hai dây (G3, C4); dây thứ ba và kỹ thuật chưa có nguồn. Nên mở tiếp: vi.wikipedia "Nhạc cụ dân tộc Việt Nam", trang nhạc cụ Viện Âm nhạc, *Nhạc khí dân tộc Việt* (Tô Vũ, Tô Ngọc Thanh), mục của Phong T. Nguyễn trong *Garland Encyclopedia of World Music* (tập 4), toàn văn bài tạp chí về nhạc cụ Chăm, bài "Uniqueness Reexamined" về đàn đáy (Cambridge) |
| **Mâu thuẫn và tên gọi** | Gốc đàn sến (meihuaqin hay qinqin); trống chầu và trống đế có thể bị Wikipedia gộp; "đinh năm" và "đinh pă" có phải một nhạc cụ; số chiêng dàn čĭng arap khác nhau giữa các nguồn |
| **Chỉ có tên / chưa có nguồn** | Kanhi, khèn bè, pí pặp, pí lè, kèn lá, sáo ôi, đinh pá, trống bản, trống đế, sênh tiền, khánh đơn, đàn bầu điện |
| **Dàn nhạc** | Thành phần đại nhạc, tiểu nhạc; dàn bát âm dân gian Nam Bộ; ngũ âm người Kinh; biên chế đầy đủ dàn cải lương, dàn chầu văn; nhạc cụ gõ đi kèm then |
| **Nhạc cụ hiện đại** | Chưa có nguồn chuyên ngành cho Rhodes, Wurlitzer, accordion, ukulele, mandolin, banjo, harmonica, drum kit, synth subtractive/FM/wavetable, MPC, vocoder, talk box, lịch sử Auto-Tune. Âm sắc theo quãng (VSL) mới có cho clarinet, horn, violin, cello; thiếu flute, oboe, bassoon, trumpet, trombone, tuba, viola, double bass, harp, bộ gõ giao hưởng |
| **Nhạc cụ thế giới** | Chưa có nguồn sơ cấp cho erhu, pipa, dizi, koto, shamisen, shakuhachi, gayageum, sitar, tabla, gõ Latin, handpan, kalimba → so sánh ở bảng 15.9 phần lớn là [Cần kiểm chứng] |
| **Thực hành phối khí ở Việt Nam** | Chưa có nguồn kỹ thuật về khuếch đại từng nhạc cụ dân tộc (pickup, micro, xử lý); chưa có báo chí mô tả vai trò keyboard arranger trong bolero hay dàn dây trong ballad V-pop; chưa xác nhận synth hoặc 808 nào trong các hit cụ thể; chưa có ví dụ V-pop có nguồn dùng khèn, t'rưng, klông pút; tình trạng vụ kiện Sony với Suno và Udio chưa kiểm chứng đến 11/2026 |
