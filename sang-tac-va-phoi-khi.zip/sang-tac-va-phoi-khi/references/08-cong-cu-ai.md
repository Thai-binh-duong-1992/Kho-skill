> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Âm vực, BPM là giá trị xấp xỉ; C4 = Đô giữa, âm vực ghi theo cao độ thực. Nhãn: [BC] có bằng chứng; [QU] quy ước thực hành; [Cần kiểm chứng].

> **Cập nhật lần cuối: 2026-11-04** (thêm 10.6a – bảng nút "Tùy chọn khác" của Suno v6 giao diện tiếng Việt). Công cụ AI thay đổi rất nhanh. Mọi giới hạn ký tự, tên mô hình, tính năng, điều khoản, giới hạn tải trong tệp này đều **cần kiểm tra lại (cập nhật 11/2026)** trên trang chính thức trước khi dùng; khi nói với người dùng phải kèm câu "cần kiểm tra lại". Không suy diễn tính năng không có trong tệp.

# Công cụ nhạc AI và đóng gói

Mục tiêu chính: **Suno** (gói đầy đủ, 10.6). Gói rút gọn: **ElevenLabs Music** (10.7), **Udio** (10.8). Pháp lý AI tại Việt Nam: `17-phap-ly-phat-hanh.md` 17.8. Dùng bản AI làm bản thương mại: `16-san-xuat.md` 16.7.

## 10.1. Công thức prompt phong cách

Prompt phong cách viết bằng tiếng Anh, theo thứ tự 8 thành phần:

| # | Thành phần | Ví dụ |
| --- | --- | --- |
| 1 | Thể loại và phụ thể loại | upbeat pop-rock anthem, Vietnamese bolero, neo-soul ballad |
| 2 | Thời kỳ, vùng | 1980s, modern, Southern Vietnamese, Andean |
| 3 | Nhịp độ, nhịp, giọng | 92 BPM, 6/8, D minor |
| 4 | Nhạc cụ chủ đạo (3–5 thứ) | nylon guitar, đàn bầu (monochord zither), warm strings |
| 5 | Giọng hát | warm mature female alto, breathy, light vibrato |
| 6 | Cảm xúc | nostalgic, hopeful, triumphant |
| 7 | Cấu trúc đặc biệt | piano-only bridge, key change up a whole step, call-and-response chorus |
| 8 | Chất sản xuất | live band, lo-fi tape, polished radio mix, intimate acoustic |

Mẫu: `[1], [2], [3]. [4]. [5]. [6]. [7]. [8].` Không ghi tên ca sĩ, ban nhạc, bài hát thật (điều khoản ElevenLabs cấm rõ; Suno và đạo đức skill cũng không cho — `09-ban-quyen.md`). Luôn xuất 2 bản: đầy đủ và rút gọn dưới 200 ký tự (dự phòng cho công cụ/phiên bản giới hạn thấp).

## 10.2. Thẻ cấu trúc trong ô lời

| Nhóm | Thẻ |
| --- | --- |
| Cấu trúc | [Intro] [Verse 1] [Pre-Chorus] [Chorus] [Post-Chorus] [Hook] [Bridge] [Interlude] [Final Chorus] [Outro] [Fade Out] [End] |
| Nhạc cụ | [Instrumental] [Guitar Solo] [Piano Solo] [Sax Solo] [Break] [Breakdown] [Build-Up] [Drop] |
| Giọng | [Male Vocal] [Female Vocal] [Duet] [Choir] [Rap] [Spoken Word] [Whisper] [Harmonies] |
| Biến đổi | [Key Change] [Tempo Change] [Half-Time] [A Cappella] |
| Mô tả trong thẻ | [Verse 2: soft piano, emotional] [Chorus: full band, gang vocals] |

Quy ước chung [QU]: nội dung trong ngoặc vuông không được hát; nội dung trong ngoặc đơn thường được hát thành bè hoặc tiếng hô. Mức hỗ trợ từng thẻ khác nhau theo công cụ và phiên bản → thử và ghi lại. ElevenLabs dùng thêm ngoặc nhọn `{…}` cho chỉ dẫn trong dòng (10.7).

## 10.3. Quy tắc viết ô lời cho máy

1. Viết đủ lời mỗi lần điệp khúc lặp; không ghi "hát lại", "x2".
2. Mỗi dòng một câu hát; câu quá dài thì tách đôi để máy ngắt đúng chỗ.
3. Bỏ ký hiệu dành cho người ("LỚP HÔ", số thứ tự, ghi chú).
4. Từ máy dễ hát sai thì viết theo âm trong bản cho máy; bản trình chiếu giữ chữ gốc.
5. Ngôn ngữ không dùng chữ Latin có thể cần thêm bản chuyển tự Latin.
6. Đếm ký tự mọi ô bằng `scripts/dong-goi-ai.py` và so với giới hạn ở 10.4.
7. Hướng dẫn người dùng tạo 3–4 lượt và chấm bản thu theo bảng tiêu chí (phát âm, câu móc, đủ cấu trúc, tông hát, kết bài, thời lượng). Lưu ý giới hạn lượt **tải** (10.4) — nghe và chấm trên nền tảng, chỉ tải bản đã chọn.

## 10.3b. Mẹo để AI hát tiếng Việt đúng [QU]

Chưa có tài liệu chính thức của Suno/Udio/ElevenLabs về xử lý tiếng Việt; ElevenLabs liệt kê ví dụ ngôn ngữ (Anh, Tây Ban Nha, Đức, Nhật) mà không nêu tiếng Việt, nhưng hướng dẫn composition plan nói lời có thể ở bất kỳ ngôn ngữ nào. Các mẹo sau là quy ước thực hành, cần thử:

| # | Quy tắc | Lý do / ví dụ |
|---|---|---|
| 1 | **Viết chữ đúng dấu, đủ dấu**, chuẩn Unicode NFC (không dùng bảng mã cũ, không gõ dấu tách rời) | Thiếu dấu → máy đọc sai thanh, đổi nghĩa (ma/má/mà/mả/mã/mạ) |
| 2 | **Dùng chữ thường** trong ô lời (trừ tên riêng đầu câu nếu cần) | Chữ IN HOA có thể bị đọc như từ viết tắt hoặc nhấn bất thường |
| 3 | **Không viết tắt** (k, ko, đc, j, HN, TP.HCM, 2/9) | Viết đầy đủ: "không", "được", "Hà Nội", "thành phố Hồ Chí Minh", "mùng hai tháng chín" |
| 4 | Số, ký hiệu → viết thành chữ | "20" → "hai mươi"; "&" → "và"; "%" → "phần trăm" |
| 5 | **Tách hoặc viết theo âm** từ dễ đọc sai: từ mượn, tên nước ngoài, chữ ghép dài | Bản cho máy: "ô kê", "Ê-đi-xơn"; bản trình chiếu giữ chữ gốc (10.3 #4) |
| 6 | Tránh ký tự lạ, dấu câu chồng (…, !!!, ~) giữa dòng | Có thể bị đọc thành tiếng hoặc làm ngắt sai |
| 7 | **Ghi phương ngữ trong style prompt**, không viết lời "giả giọng" | Ví dụ: `sung in Vietnamese with a Southern Vietnamese (Saigon) accent` / `Northern Vietnamese (Hanoi) pronunciation` / `Central Vietnamese (Hue) accent`. Thêm `clear Vietnamese diction, accurate tones` |
| 8 | Ghi rõ ngôn ngữ ở đầu style | `Vietnamese-language ballad, ...` để máy không chuyển sang tiếng khác giữa bài |
| 9 | Câu ngắn, ngắt ở ranh giới ngữ đoạn | Không ngắt giữa từ ghép (N4); giúp máy đặt chữ vào phách đúng |
| 10 | Nghe kiểm lại chữ hỏi, ngã, nặng và chữ then chốt | Chạy T1–T8 trên bản tạo; chữ sai thanh → sửa chính tả/viết theo âm, tạo lại đoạn đó |

## 10.4. Bảng thông tin công cụ (cần kiểm tra lại – cập nhật 11/2026)

| Công cụ | Trạng thái / mô hình | Ô nhập và giới hạn | Tải xuống và quyền dùng | Nguồn (ngày) |
| --- | --- | --- | --- | --- |
| **Suno** | Bộ **v6** ra mắt 09/9/2026: **v6** (Pro, Premier), **v6-wild** (Pro, Premier; khó đoán, đa dạng hơn), **v6-mini** (mọi người dùng kể cả Free). Mô hình cũ ngừng tạo mới cùng ngày; bài cũ vẫn nằm trong thư viện. Đối tác: WMG, BMG, Believe; UMG và Sony không tham gia, vẫn kiện Suno tại Mỹ | Style **1.000** ký tự; Exclude styles **1.000**; Lyrics **5.000** (nguồn thứ ba, cho v6). Title: chưa xác minh (trình duyệt không chặn; cộng đồng nêu 80–100) → script dùng 80 | Từ **03/9/2026**: Free **7 lượt tải dùng thử trọn đời, chỉ dùng cá nhân, không thương mại**; Pro **20 lượt/tháng**; Premier **60 lượt/tháng**; Premier kèm Suno Studio: không giới hạn (theo blog Suno). Lượt tải reset theo ngày thanh toán, không cộng dồn; mua thêm được. Bài tải khi đang trả phí được dùng thương mại; Suno "assign" quyền đầu ra cho thuê bao Pro/Premier, kèm hạn chế dùng thương mại. Huỷ gói → theo giới hạn Free. Nghe và chia sẻ trong nền tảng không giới hạn | Suno blog, Suno Help (08–09/2026); Music Business Worldwide (09/9/2026); hookgenius (09/2026) |
| **ElevenLabs Music** (Eleven Music) | Mô hình music v2, v2.5; tạo trọn bài có giọng và lời; sửa từng đoạn và lời sau khi tạo (UI); tham chiếu âm thanh ngắn; API cho gói trả phí | Prompt văn bản **hoặc** composition plan (không dùng cả hai cùng lúc): tối đa 30 đoạn; mỗi đoạn 3–120 s; cả bài 3 s–10 phút; positive/negative styles tối đa 50 mỗi loại; style phải bằng tiếng Anh, lời bất kỳ ngôn ngữ | Xuất MP3 (theo trang trợ giúp). Điều khoản nhạc (cập nhật 09/10/2026): Free và Starter **cấm phân phối lên nền tảng stream**; Free không được tải, bắt buộc ghi công Eleven Music; Creator, Pro, Scale, Business **được phân phối stream**; cấm prompt nêu tên nghệ sĩ, bài, album, hãng thật; người dùng tự chịu nghĩa vụ khai báo AI theo luật và nền tảng (dấu của ElevenLabs không thay được) | elevenlabs.io: Music Terms, Help Center, Docs (10/2026) |
| **Udio** | Sau dàn xếp với UMG (10/2025) và WMG (11/2025): **tắt tải xuống từ 30/10/2025**; cửa sổ tải 48 giờ 03–05/11/2025 đã đóng; vẫn tạo và nghe trong nền tảng ("walled garden"). Nền tảng cấp phép chung với UMG dự kiến 2026 — **chưa xác nhận ra mắt** | Không kiểm chứng được giới hạn ô nhập hiện hành | **Không xuất file được → không phân phối ra ngoài được.** Bài tải trước 30/10/2025 hoặc trong cửa sổ 48 giờ theo điều khoản cũ | Music Business Worldwide; Digital Music News; dynamoi (cập nhật 26/4/2026) |
| Công cụ khác người dùng hay dùng | Ghi tương tự khi người dùng nêu | — | — | Ghi ngày kiểm tra |

Giá trị mặc định trong `scripts/dong-goi-ai.py` (**cần kiểm tra lại** trên công cụ trước mỗi lần dùng): Title 80; Style 1.000; Style rút gọn 200; Lyrics 5.000. Exclude styles (Suno v6) ghi nhận 1.000 ký tự — script kiểm qua `--max-exclude` (mặc định 1.000 với `--cong-cu suno`). Khi biết giới hạn mới: sửa bảng trên, đổi ngày cập nhật ở đầu tệp, truyền `--max-…` cho script.

## 10.5. Gói bàn giao

Khung 11 mục: `assets/mau-goi-ban-giao.md` (gói nhập liệu AI ở mục 6; kiểm tra bản AI tạo ở mục 8; hướng dẫn sản xuất – phát hành ở mục 9 theo `assets/mau-huong-dan-phat-hanh.md`; nhật ký sáng tạo ở mục 10; bản quyền và ghi công ở mục 11).

## 10.6. Gói Suno đầy đủ (mục tiêu chính)

Giao diện Suno v6 theo nguồn thứ ba (Jack Righteous, 11/9/2026 — **cần kiểm tra lại**): chọn mô hình (v6 / v6-wild / v6-mini) ở góc trên; chế độ **Simple** (mô tả bằng lời + tham chiếu Audio, Voice, Image) và **Advanced** (Lyrics; Styles có gợi ý thẻ; More Options gồm Exclude styles, Vocal Gender, Duration, Max Mode, Weirdness, Style Influence, Audio Influence, Variety, My Taste; tham chiếu âm thanh; Cover). Mục "Create Custom Model" cho Pro/Premier. **Persona trong v6 chưa xác minh** — không hứa với người dùng; nếu giao diện của họ có Persona/Voice thì ghi gợi ý giọng vào đó, nếu không thì đưa gợi ý giọng vào Style và Vocal Gender.

Gói gồm 7 phần, xuất theo thứ tự:

| # | Ô | Nội dung | Quy tắc |
|---|---|---|---|
| 1 | **Title** | Tên bài có dấu | ≤ 80 ký tự (giả định an toàn) |
| 2 | **Style** (đầy đủ) | Công thức 10.1, mở đầu bằng ngôn ngữ và phương ngữ: `Vietnamese-language …, sung with a Southern Vietnamese accent, clear diction, accurate tones` | ≤ 1.000 ký tự; tiếng Anh; không tên nghệ sĩ/bài thật |
| 2b | **Style** (rút gọn) | Thể loại, giọng, 2–3 nhạc cụ, BPM, cảm xúc, 1 ghi chú cấu trúc | < 200 ký tự |
| 3 | **Exclude styles** | Những gì không muốn: thể loại lệch, xử lý giọng không mong muốn (`heavy autotune`), ngôn ngữ khác (`English lyrics`, `Chinese vocals`), nhạc cụ lệch màu | ≤ 1.000 ký tự |
| 4 | **Lyrics** | Lời có thẻ cấu trúc 10.2, đã qua 10.3 và 10.3b | ≤ 5.000 ký tự; lời đầy đủ mỗi lần lặp |
| 5 | **Gợi ý giọng / persona** | Một dòng mô tả giọng (giới, tuổi cảm nhận, loại giọng, âm sắc, kỹ thuật, phương ngữ) + đặt **Vocal Gender** | Dùng cho ô Persona/Voice nếu có; nếu không, gộp vào Style |
| 6 | **Thiết lập More Options / Tùy chọn khác** (gợi ý, cần thử) | Đủ 8 nút theo bảng **10.6a**: Loại trừ, Giới tính giọng, Thời lượng (Tùy chỉnh theo `scripts/tinh-thoi-luong.py`), Chế độ Max (tắt khi nháp, bật bản chính), Độ kỳ lạ thấp, Ảnh hưởng phong cách cao, Đa dạng 0, Cá nhân hóa tắt; mô hình v6/v6-wild/v6-mini | Con số chỉ ghi kèm nhãn [QU – nguồn thứ ba] như 10.6a; còn lại mô tả "thấp/vừa/cao" |
| 7 | **Phiên bản và biến thể** | **A** – chính (Style đầy đủ); **B** – Style rút gọn; **C** – biến thể phối (đổi nhạc cụ chủ đạo hoặc mật độ, ví dụ acoustic vs full band); **D** – tuỳ chọn: v6-wild hoặc đổi tempo ±8 BPM | Mỗi phiên bản tạo 2–4 lượt; chấm theo 10.3 #7; chỉ tải bản thắng (giới hạn lượt tải) |

Mẫu khung xuất: `assets/mau-prompt-ai.md`; kiểm ký tự và xuất .txt: `scripts/dong-goi-ai.py`.

## 10.6a. Nút "Tùy chọn khác" của Suno v6 (giao diện tiếng Việt) – giải thích cho người dùng

Ghi nhận từ ảnh chụp giao diện của người dùng (04/11/2026) và các bài hướng dẫn, thử nghiệm của bên thứ ba (Jack Righteous 09/2026; SiliconSense; ytyng). Tài liệu chính thức của Suno mô tả các nút rất ngắn → mọi mô tả dưới đây **cần kiểm tra lại**; con số là điểm xuất phát [QU – nguồn thứ ba], không phải giá trị đúng duy nhất.

**Lưu ý giao diện:** ở chế độ **Nâng cao**, khung **Phong cách** và **Lời bài hát** hiện sẵn chữ mờ làm mẫu (ví dụ "party vibes, electro rock, sub-bass…"). Đó **không phải nội dung đã nhập** – nhắc người dùng dán Style và Lyrics từ gói vào cả hai khung.

| Nút (tiếng Việt / tiếng Anh) | Tác dụng | Cài mặc định cho nhạc Việt truyền thống, trữ tình | Khi nào đổi |
|---|---|---|---|
| **Loại trừ phong cách** (Exclude styles) | Liệt kê điều **không** muốn xuất hiện | Dán ô Exclude của gói (giọng sai giới/phương ngữ, thể loại lệch, autotune, lời ngoại ngữ, nâng tông) | Một nét lạ cứ lặp lại qua nhiều lượt → thêm vào đây |
| **Giới tính giọng hát** (Vocal Gender) | Hướng giọng nam/nữ | Theo người hát ở Bước 1 | Song ca: để trống, ghi phân vai bằng thẻ `[Verse 1: Male]` trong Lyrics |
| **Thời lượng** (Duration): Tự động / Tùy chỉnh | Tự động = máy tự quyết; Tùy chỉnh = đặt độ dài mong muốn | **Tùy chỉnh**, lấy từ `scripts/tinh-thoi-luong.py` (làm tròn lên ~10 giây) | Ghi nhận thực tế: để Tự động, bài 3:30 thiết kế ra **4:17** vì máy kéo dài intro và đoạn chuyển |
| **Chế độ Max** (Max Mode) | Tốn **thêm credit**; máy "bỏ công" hơn để giọng và phong cách đều suốt bài. Suno gợi ý cho bài > 2 phút, cover sát bản gốc, chuyển phong cách. **Không phải nút tăng chất lượng âm thanh** | **Tắt** ở lượt nháp; **Bật** ở lượt tạo bản chính (bài > 2 phút) | Người dùng hết credit hoặc chỉ phác thảo → tắt |
| **Độ kỳ lạ** (Weirdness) | Từ an toàn, dễ đoán (thấp) đến táo bạo, lạ tai (cao) | **Thấp, khoảng 15–20%** cho dân ca, trữ tình, bolero, cải lương | Kết quả quá nhàm, cần ý lạ → nâng từng nấc |
| **Ảnh hưởng phong cách** (Style Influence) | Mức máy bám khung Phong cách | **Cao, khoảng 75–80%** khi Style đã viết kỹ (nhạc cụ dân tộc, BPM, phương ngữ) | Máy làm quá cứng, lặp → hạ xuống ~60% |
| **Ảnh hưởng âm thanh** (Audio Influence; chỉ hiện khi có "+ Âm thanh") | Mức máy bám file tham chiếu tải lên | Chỉ dùng khi có tham chiếu | Xem ghi chú về bản nghe thử bên dưới |
| **Đa dạng** (Variety): 0/Tắt – Bình thường – Max | Cho máy **viết lại** khung Phong cách trước khi tạo (thử nghiệm bên thứ ba: ở mức Max, 10–12 thẻ thành 30–50 chữ, thêm nhạc cụ, đổi giới tính giọng). Mức 0 giữ nguyên chữ người dùng viết | **0 (Tắt)** khi Style đã viết kỹ – mặc định giao diện là "Bình thường", phải kéo về 0 | Đang tìm ý tưởng, chưa có Style rõ → Bình thường |
| **Cá nhân hóa – Gu của tôi** (My Taste / Personalize) | Pha thêm sở thích suy ra từ lịch sử nghe và tạo của tài khoản | **Tắt** – kết quả dễ lặp lại, khớp prompt đã ghi trong nhật ký sáng tạo (bằng chứng đóng góp, NĐ 134/2026) | Bài cá nhân, muốn máy "hiểu gu" → bật |

**Các nút khác:**
- **Cây đũa phép** cạnh khung Phong cách (Magic Wand / Style Augmentation): máy tự viết lại Style. **Không bấm** khi đã có Style từ gói – sẽ thay mất phần mô tả.
- **v6 / v6-wild / v6-mini** (góc trên): v6 cho bản chính, v6-wild khi muốn ý lạ, v6-mini khi dùng gói Free (cần kiểm tra lại theo gói).
- **+ Âm thanh / + Voice / + Inspo**: tham chiếu âm thanh, giọng, cảm hứng. [Chưa kiểm chứng] Có thể tải bản nghe thử giai điệu (`scripts/tao-ban-nghe-thu.py`) làm tham chiếu để máy bám giai điệu điệp khúc; bản nghe thử do máy đánh nên Suno có thể bắt chước cả âm sắc "máy" – chỉ thử ở một lượt riêng, ghi kết quả vào nhật ký.
- **Lưu vào… (My Workspace)**: thư mục lưu bài; nên tạo thư mục riêng cho mỗi dự án.

**Quy trình thử khuyến nghị [QU]:**
1. Lượt nháp: Max tắt, các nút như cột "Cài mặc định"; tạo 2 lượt, nghe chọn.
2. Chưa ưng → **mỗi lần chỉ đổi một nút**, ghi lại nút nào tạo khác biệt.
3. Lượt chính: bật Max, giữ nguyên các thiết lập còn lại.
4. Chụp màn hình thiết lập của bản được chọn, lưu vào nhật ký sáng tạo (`--tep-kem`).

Khi người dùng gửi ảnh chụp giao diện và hỏi về các nút: giải thích theo bảng này, kèm cột giá trị đề xuất **cho đúng bài đang làm**, và nói rõ đó là điểm xuất phát cần thử.

**Kèm theo gói Suno (bắt buộc khi người dùng định phát hành):**
- Nhắc: chỉ bài tải từ **gói trả phí** mới dùng thương mại; lượt tải Free chỉ dùng cá nhân (cần kiểm tra lại).
- Ghi chú pháp lý: **gắn nhãn âm thanh do AI tạo** (Luật Trí tuệ nhân tạo 134/2025/QH15) ở metadata/mô tả khi phát hành; **lưu toàn bộ prompt (Title, Style, Exclude, Lyrics, thiết lập, phiên bản) vào nhật ký sáng tạo** làm bằng chứng đóng góp của con người (NĐ 134/2026). Chi tiết: `17-phap-ly-phat-hanh.md` 17.8.
- Nếu phát hành chính bản AI: chạy 16.7 (`16-san-xuat.md`).

## 10.7. Gói rút gọn ElevenLabs Music

Dùng khi người dùng chọn ElevenLabs. Hai cách nhập (không dùng chung):

**Cách 1 – prompt văn bản** (giao diện): một đoạn tiếng Anh theo 10.1, thêm thời lượng (giây hoặc auto), BPM, giọng; có thể chèn mốc thời gian dạng "lyrics begin at 15 seconds", "instrumental only after 1:45"; dán lời riêng của người dùng kèm prompt. Lời có thể đổi ngôn ngữ bằng yêu cầu tiếp theo trong giao diện.

**Cách 2 – composition plan** (API, mô hình music v2/v2.5): danh sách đoạn theo thứ tự; đoạn đầu quyết định không khí chung.

```json
{
  "chunks": [
    {
      "text": "[Verse 1]\n<dòng lời 1>\n<dòng lời 2>\n{soft, intimate}",
      "duration_ms": 20000,
      "positive_styles": ["Vietnamese-language ballad", "Southern Vietnamese accent", "nylon guitar", "đàn tranh"],
      "negative_styles": ["heavy autotune", "English lyrics"],
      "context_adherence": "high"
    }
  ]
}
```

Quy tắc: `text` = tên đoạn trong `[…]`, lời mỗi dòng một câu, âm hô/âm vô nghĩa trong `(…)`, chỉ dẫn trong `{…}`; mỗi đoạn 3–120 s; tối đa 30 đoạn; tổng 3 s–10 phút; style tiếng Anh. Kèm 10.3b. Nhắc điều khoản 10.4 (Free/Starter không được phân phối stream; cấm tên nghệ sĩ/bài thật; người dùng tự khai báo AI).

## 10.8. Gói rút gọn Udio

**Tình trạng công cụ (cần kiểm tra lại – cập nhật 11/2026; nói một dòng khi người dùng chọn Udio, phần chi tiết ghi vào tài liệu đầu ra):** Udio đã tắt tải xuống từ 30/10/2025; nền tảng cấp phép mới chưa xác nhận ra mắt. Bài tạo trên Udio hiện **không xuất ra ngoài được nên không phát hành được**. Chỉ soạn gói Udio khi người dùng muốn nghe thử/phác thảo trong nền tảng; khuyên dùng Suno hoặc ElevenLabs nếu cần file.

Gói rút gọn: Title; prompt phong cách theo 10.1 (bản rút gọn, kèm ngôn ngữ và phương ngữ); Lyrics có thẻ 10.2 đã qua 10.3b. Không nêu giới hạn ký tự hay tính năng cụ thể của Udio vì chưa kiểm chứng được.

## 10.9. Ghi chú pháp lý chung cho mọi công cụ AI

- Gắn nhãn âm thanh do AI tạo khi phát hành; không tẩy xoá nhãn (Luật 134/2025/QH15).
- Không mô phỏng giọng hoặc danh tính nghệ sĩ thật (`09-ban-quyen.md`).
- Lưu prompt, phiên bản, quyết định chọn vào nhật ký sáng tạo; ở chế độ thương mại người dùng là tác giả chính (`09-ban-quyen.md` 9.2).
- Bài chỉ có prompt + một lần bấm tạo nhiều khả năng không được bảo hộ ở Việt Nam (`17-phap-ly-phat-hanh.md` 17.8).
