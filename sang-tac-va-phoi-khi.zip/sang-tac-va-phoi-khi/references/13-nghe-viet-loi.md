> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Nghề viết lời: từ "đúng luật" (sàn) đến "hay" (trần). Dùng sau khi đã nắm tương ứng thanh–nhạc (`ngon-ngu/vi.md`) và thi luật (`12-thi-luat.md`). Nhãn: [BC] có bằng chứng; [QU] quy ước thực hành/suy luận; [Cần kiểm chứng].

# 13. Nghề viết lời: từ đúng luật đến tuyệt tác

## 13.1. Sàn và trần của một lời ca

| Tầng | Gồm những gì | Tác dụng | Bộ kiểm tra |
|---|---|---|---|
| **Sàn** | Không ngược thanh, không lạc vận, không vỡ nhịp, không đặt vần khép (-p, -t, -c, -ch) ở nốt ngân | Ngăn lời ca bị **hỏng**; không làm lời ca **hay** | T1–T10, N1–N9 (`ngon-ngu/vi.md`), V1–V16 (`12-thi-luat.md`) |
| **Trần** | Chín nguyên tắc nghề ở 13.2 | Tăng xác suất lời được nhớ lâu | L1–L12 (13.4) |

- [BC] Phần lớn lời tân nhạc và V-pop là **thơ tự do**. Ràng buộc thật là **tương ứng thanh–nhạc**, không phải bằng–trắc của thi luật (bằng/trắc không dùng để đặt cao độ).
- [BC] Ngô Tự Lập: với thơ hiện đại, nhạc tính quan trọng hơn vần chặt (VnExpress). Lời ca có giai điệu gánh cùng nên nhận định này càng đúng.
- [QU] Phần lớn nội dung tệp này là đúc kết nghề viết lời, chưa có nghiên cứu định lượng về tiếng Việt. **Không quy tắc nào bảo đảm có tuyệt tác**; mỗi nguyên tắc chỉ tăng xác suất và đi kèm một **phép thử** để tự kiểm.

## 13.2. Chín nguyên tắc

### Nguyên tắc 1. Một sự thật cảm xúc duy nhất

- [BC] Hứa Kim Tuyền: nếu chỗ nào trong bài cũng là điểm đặc biệt, người nghe không biết tập trung vào đâu (Vietcetera).
- [QU] Một bài hát nói đúng **một** điều: một cảm xúc người viết đã thật sự trải qua và người nghe nhận ra mình trong đó, không phải thông điệp "nên nói". Bài có hai, ba ý ngang nhau thường thành bài nào cũng nhạt.
- **Phép thử:** viết được ý cốt lõi trong **một câu dưới 15 chữ**, và câu đó là một cảm xúc hoặc một nhận ra, không phải chủ đề.
  - Chủ đề: "Bài về mẹ".
  - Sự thật cảm xúc: "Đến khi tự nấu bữa cơm đầu tiên, tôi mới hiểu mẹ đã mệt thế nào".

### Nguyên tắc 2. Chi tiết cụ thể thay cho khái niệm

- [QU] Từ trừu tượng (buồn, nhớ, cô đơn, hạnh phúc) chỉ **gọi tên** cảm xúc; chi tiết cụ thể (một mùi, một đồ vật, một âm thanh, một khoảnh khắc có thời gian và địa điểm) **gây ra** cảm xúc.
- [QU] Cái riêng dẫn tới cái chung: chi tiết càng riêng, người nghe càng dễ đặt ký ức của mình vào.
- Ca dao đã làm việc này: thể **tỉ** và thể **hứng** mượn hình ảnh cụ thể để nói tình cảm thay vì gọi thẳng tên (`12-thi-luat.md`).
- **Phép thử:** gạch chân mọi từ chỉ cảm xúc trừu tượng. Mỗi phiên khúc có **ít nhất hai chi tiết cảm quan** (thấy, nghe, ngửi, chạm, nếm); số từ trừu tượng **không nhiều hơn** số chi tiết.

### Nguyên tắc 3. Giọng nói tự nhiên của một người với một người

- [BC] Rap của Đen Vâu dùng lời đời thường, kèm điệp khúc âm vực hẹp để người nghe hát theo (Znews). Ngọt viết lời thẳng về tuổi trẻ đô thị.
- [QU] Lời có sức nặng thường nghe như **một người đang nói với một người cụ thể**, không như diễn văn. Xác định rõ: ai nói, nói với ai, nói lúc nào.
- [QU] Ngôi xưng (anh/em, tôi/người, mình/ta) **nhất quán cả bài**.
- **Phép thử:** đọc to như đang nói chuyện. Câu nào ngoài đời mình **không bao giờ nói như thế** thì sửa, trừ khi là lựa chọn phong cách có chủ đích (ví dụ văn phong cổ của bài tiền chiến).

### Nguyên tắc 4. Âm thanh của chữ là một nửa của nhạc

- [BC] Mỗi chữ tiếng Việt đã mang sẵn một đường cao độ (thanh điệu). Hướng giai điệu theo **điểm kết thúc** của thanh: sắc/ngã = cao; ngang = trung; huyền = thấp; hỏi/nặng = rất thấp (Kirby & Ladd 2016).
- [BC] Âm tiết kết bằng -p, -t, -c, -ch chỉ mang thanh sắc hoặc nặng → không hợp nốt ngân.
- [BC] Lỗi nghe nhầm lời thường rơi vào cặp chữ chỉ khác một dấu, ví dụ "đắm say" thành "đắng cay" (Nghiêm Nguyễn).
- [QU] Chủ động dùng âm thanh:

| Mục đích | Cách dùng |
|---|---|
| Đỉnh cảm xúc | Chữ thanh cao (sắc, ngã, ngang) |
| Nốt ngân, cuối câu điệp khúc | Nguyên âm mở (a, ơi, ao, ang) |
| Độ mượt, dễ nhớ | Từ láy, điệp âm đầu |
| Đoạn gấp gáp, rap | Âm tắc dồn dập |

- **Phép thử:** hát hoặc ngân nhẩm riêng phần nguyên âm của câu hook. Câu đó phải dễ hát, không vấp lưỡi.

### Nguyên tắc 5. Kiến trúc có hướng đi và một câu hook

- [BC] Bài sau 2014 trong tập mẫu 37 bài dùng khung Intro/Verse/Pre-chorus/Chorus (`14-hoa-am-viet-bai-mau.md`). Điệp khúc của Đen Vâu cố ý giữ âm vực hẹp để dễ hát theo (Znews).
- [QU] Một bài hay có **đường đi**, mỗi đoạn làm một việc:

| Đoạn | Việc phải làm |
|---|---|
| Verse | Dựng tình huống bằng chi tiết |
| Pre-chorus | Dồn nén |
| Điệp khúc | Nói ra sự thật cốt lõi |
| Verse 2 | Đẩy câu chuyện đi tiếp, **không lặp lại** verse 1 |
| Bridge / đoạn cuối | Đổi góc nhìn |

- [QU] Câu hook thường là **tên bài**, đặt ở vị trí mạnh nhất của điệp khúc (đầu hoặc cuối). Câu hay nhất là câu mỗi lần lặp lại mang thêm một nghĩa nhờ những gì verse vừa kể.
- **Phép thử:** tóm tắt mỗi đoạn bằng **một động từ** (kể, dồn, vỡ, nhận ra, buông). Hai đoạn cùng động từ thì một đoạn đang thừa.

### Nguyên tắc 6. Tiết kiệm chữ, chừa chỗ cho nhạc

- [BC] Phú Quang chỉ lấy **21 trong 443 câu** thơ của Phan Vũ để làm *Em ơi Hà Nội phố* (Báo Pháp luật). Hứa Kim Tuyền nhắc chỉ giữ một điểm nhấn (Vietcetera).
- [QU] Thơ phải tự gánh hết nhạc tính; lời ca có giai điệu gánh cùng. Lời quá đầy chữ làm giai điệu nghẹt, ca sĩ không còn chỗ thở. **Chỗ trống trong lời là chỗ để nhạc nói.**
- **Phép thử:** thử bỏ từng câu; câu nào bỏ đi mà bài không mất gì thì bỏ. Đếm âm tiết mỗi câu nhạc: ballad chậm có câu quá dày thì rút gọn (bộ N, `ngon-ngu/vi.md`).

### Nguyên tắc 7. Ẩn ý: để người nghe tự điền

- [QU] Lời tuyệt tác thường không nói hết: đặt ra hình ảnh, để người nghe tự hiểu. Phần người nghe tự điền là phần khiến bài hát thành **của họ**.
- [QU] Ẩn ý khác mơ hồ: **hình ảnh phải rõ**, chỉ ý nghĩa là để ngỏ.
- **Phép thử:** tìm câu đang **giải thích** cảm xúc vừa được hình ảnh gợi ra ("vì thế em buồn", "điều đó làm anh đau"). Xoá thử, xem hình ảnh có tự đứng được không.

### Nguyên tắc 8. Gặp đúng thời điểm và bản sắc chung

- [BC] *Bắc Bling* đạt 200 triệu lượt xem sau 81 ngày, nhanh nhất lịch sử V-pop, nhưng **không lọt top 10 Spotify Việt 2025** (Wikipedia; Znews). Báo Văn Hóa cảnh báo nguy cơ "làm mới" mà đánh mất đặc trưng làn điệu.
- [QU] Một phần sức sống của bài nằm ngoài lời: chạm đúng tâm trạng chung của một thời điểm, hoặc một bản sắc người nghe muốn tự hào. Tự hỏi: *vì sao người nghe cần bài này **bây giờ**?*
- [QU] Lan toả một lần (lượt xem) và được nghe lại lâu dài (lượt nghe) là **hai thước đo khác nhau**.
- **Phép thử:** trả lời được "người nghe sẽ mang bài này vào khoảnh khắc nào của đời họ" (đám cưới, xa nhà, Tết, chia tay, tự hào quê hương…).

### Nguyên tắc 9. Viết lại

- [BC] Dự án *Giai Nhân* của Hứa Kim Tuyền kéo dài **3 tháng**, có trại sáng tác và nhiều vòng góp ý tập thể (Tiền Phong). Nguyễn Vĩnh Tiến dựng cấu trúc nhạc trước, rồi sửa và viết thêm lời cho vừa (`12-thi-luat.md`).
- [QU] Hiếm tuyệt tác ra đời ở bản nháp đầu. Chất lượng đến từ những vòng gọt, **mỗi vòng chỉ sửa một loại lỗi** để không bỏ sót (13.3).

## 13.3. Quy trình bốn vòng viết lại

| Vòng | Tập trung vào | Câu hỏi kiểm | Liên kết |
|---|---|---|---|
| 1. Sự thật | Ý cốt lõi, đường đi cảm xúc | Bài có nói đúng một điều? Mỗi đoạn có làm một việc khác nhau? | Nguyên tắc 1, 5, 8 |
| 2. Hình ảnh | Chi tiết, ẩn ý, giọng | Từ trừu tượng nào thay được bằng chi tiết? Câu nào đang giải thích thừa? Ngôi xưng nhất quán? | Nguyên tắc 2, 3, 7 |
| 3. Âm thanh | Thanh–nhạc, vần, nốt ngân | Chạy bộ T, N (`ngon-ngu/vi.md`) và V (`12-thi-luat.md`); câu hook dễ hát? | Nguyên tắc 4 |
| 4. Lược bỏ | Độ dày chữ, chỗ thở | Câu nào bỏ được? Còn chỗ trống cho nhạc? | Nguyên tắc 6 |

[QU] Sau vòng 4:
1. Để lời "nghỉ" **ít nhất một ngày** rồi đọc lại.
2. Hát cho một người **chưa xem lời** nghe, nhờ họ chép lại những gì nghe được.
3. Mọi chỗ chép sai là chỗ cần sửa — phép thử cuối cho cả lỗi nghe nhầm lẫn lỗi tối nghĩa.

## 13.4. Bộ kiểm tra nghề viết lời L1–L12

| Mã | Kiểm tra | Đạt khi | Nhãn |
|---|---|---|---|
| L1 | Ý cốt lõi | Viết được trong một câu dưới 15 chữ, là cảm xúc hoặc nhận ra, không phải chủ đề | [QU]; [BC] một điểm nhấn (Hứa Kim Tuyền) |
| L2 | Chi tiết cảm quan | Mỗi phiên khúc có ít nhất hai chi tiết cảm quan cụ thể | [QU] |
| L3 | Từ trừu tượng | Số từ cảm xúc trừu tượng không nhiều hơn số chi tiết | [QU] |
| L4 | Người nói, người nghe | Rõ ai nói, nói với ai, lúc nào; ngôi xưng nhất quán | [QU] |
| L5 | Giọng tự nhiên | Đọc to không có câu "không ai nói thế" ngoài chủ đích phong cách | [QU]; [BC] lời đời thường của Đen Vâu |
| L6 | Âm thanh câu hook | Hook dễ hát; nguyên âm mở ở nốt ngân; không vần khép ở cuối câu điệp khúc | [BC] âm tiết -p/-t/-c/-ch không hợp nốt ngân; [QU] |
| L7 | Đường đi | Mỗi đoạn tóm được bằng một động từ khác nhau; verse 2 không lặp verse 1 | [QU] |
| L8 | Vị trí hook | Câu hook (thường là tên bài) ở đầu hoặc cuối điệp khúc; mang thêm nghĩa sau mỗi verse | [QU] |
| L9 | Tiết kiệm | Không còn câu bỏ đi được mà bài không mất gì | [BC] Phú Quang 21/443; [QU] |
| L10 | Ẩn ý | Không có câu giải thích lại điều hình ảnh đã gợi | [QU] |
| L11 | Khoảnh khắc của người nghe | Trả lời được "người nghe mang bài này vào lúc nào trong đời họ" | [QU] |
| L12 | Người nghe thử | Một người chưa xem lời chép lại đúng lời và hiểu đúng ý cốt lõi | [QU]; liên quan T4 (`ngon-ngu/vi.md`) |

## 13.5. Thứ tự áp dụng: "trần trước, sàn sau"

[QU] Thứ tự đề xuất:

| Bước | Việc | Mã |
|---|---|---|
| 1 | Tìm sự thật cảm xúc, chi tiết, giọng, đường đi, hook | L1–L8 |
| 2 | Áp thi luật và thanh–nhạc để sửa lỗi | V1–V16, T1–T10, N1–N9 |
| 3 | Lược bỏ, kiểm ẩn ý | L9–L10 |
| 4 | Thử với người nghe | L11–L12 |

- **Làm ngược** (chọn khung luật trước rồi tìm ý để lấp) dễ cho ra lời **đúng luật mà rỗng**.
- **Ngoại lệ:** viết theo thể cố định có chủ đích (lục bát cho bài dân ca mới, hát nói cho bài ca trù) → chọn khung luật ngay từ đầu (`12-thi-luat.md`).
