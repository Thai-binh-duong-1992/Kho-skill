> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Hoà âm cho bài Việt: trục quãng 4 của điệu thức Việt và tập mẫu 37 bài (hopamchuan.com). C4 = Đô giữa. Nhãn: [BC] có bằng chứng; [BC – tập mẫu] đếm từ tập 37 bài, là giả thuyết có dữ liệu ủng hộ, chưa phải định luật; [QU] quy ước thực hành/suy luận; [Cần kiểm chứng]. Bảng vòng hợp âm quốc tế ở `03-hoa-am.md`.

# 14. Hoà âm Việt và tập bài mẫu

## 14.1. Bảng quyết định: chọn hệ hoà âm theo thế hệ/thể loại

Dùng bảng này **trước** khi chọn vòng hợp âm cho một bài Việt. Số liệu từ tập mẫu 37 bài (14.4–14.5).

| Thế hệ / thể loại | Hệ hoà âm mặc định | Tương phản đoạn B / ĐK | Bằng chứng (đếm) | Nhãn |
|---|---|---|---|---|
| **Trước 2000: bolero, nhạc vàng, trữ tình, tiền chiến** | Giọng thứ chức năng **i–iv–V7–i** (V/V7 trưởng có âm dẫn) | ĐK **ngả sang giọng trưởng song song tên** (relative major): Dm→F, Am→C. **Không** phải trưởng cùng tên (Am→A) | Bolero 5/5 giọng thứ, 4/5 có V/V7; 15/23 bài giọng thứ có V/V7; 7 bài ngả sang trưởng song song tên; chuyển trưởng cùng tên chỉ 1 bài thật (*Thiên thai* Dm→D) | [BC – tập mẫu] |
| **Nhạc Trịnh** | Giọng thứ + V/V7; thêm **I7→iv** (A7→Dm trong Am; E7→Am trong Em) | 1 bài ngả sang G (*Một cõi đi về*) | 3/3 giọng thứ; **I7→iv ở 3/3** | [BC – tập mẫu]; cỡ mẫu nhỏ, cần thêm *Hạ trắng*, *Cát bụi* |
| **Tiền chiến** (đa dạng nhất) | i–VI–i–III–V7–i; kết khổ bằng v thứ (tránh âm dẫn); bII trong bridge | Có thể chuyển trưởng cùng tên (*Thiên thai*, duy nhất) | 4/4 giọng thứ (1 bài kết ở trưởng) | [BC – tập mẫu] |
| **Trữ tình mượn màu dân gian** | Giọng thứ, có thể không V trưởng; thêm **bII** (màu "oán"/Phrygian) và **IV trưởng trong giọng thứ** (màu Dorian) | — | bII: 3 bài; IV trưởng trong giọng thứ: 2 bài | [BC – tập mẫu]; diễn giải màu "oán": [QU] |
| **Pop 1990–2000** (chuyển tiếp) | Lẫn lộn: I–vi–IV–V; I–V–vi–IV–V; vòng quãng 5 i–iv–VII–III; ĐK lặp VI–VII–v–i | — | 2 thứ / 2 trưởng | [BC – tập mẫu] |
| **V-pop ballad sau 2014** | **Vòng lặp 4 hợp âm xuyên suốt**: họ **IV–V–iii–vi** / IV–V–vi ("royal road") hoặc **vi–iii–IV–V** (Am–Em–F–G) | Tương phản bằng **mật độ phối**, không bằng đổi hợp âm | IV–V–iii–vi: 4 bài; vi–iii–IV–V: 3 bài; vòng lặp xuyên suốt: 8 bài, **đều sau 2014**; **I–V–vi–IV nguyên dạng: 0/37** | [BC – tập mẫu]; liên hệ J-pop royal road: [QU] |
| **Folk fusion, rap Việt** | **Aeolian 2–4 hợp âm, không V trưởng**; cadence v–i hoặc VII–i (i–VI–iv–v; iv–VII–v–i; VI–i–VII–iv; i–v–VI–VII) | Một vòng cho mọi đoạn | 8/23 bài giọng thứ không V trưởng, 6 trong đó là pop/V-pop/fusion/rap sau 2000; vòng aeolian 4 hợp âm: 3 bài (*Bắc Bling*, *See tình*, *Ngày khác lạ*) | [BC – tập mẫu] |
| **Indie** | Giọng trưởng + mượn từ giọng thứ: **iv thứ** (Fm trong C), bVII, line cliché; vi–IV–I–V, vòng Canon | Đổi vòng giữa verse và chorus (*2004*) | 0/3 giọng thứ; iv thứ mượn: 2 bài | [BC – tập mẫu] |
| **Cách mạng, hành khúc** | Giọng trưởng; I–vi–IV–I; i–III–i–iv–V | — | 3/4 giọng trưởng; nhãn điệu (Disco, Boston, Slow) **không đáng tin** | Giọng: [BC – tập mẫu]; 2/4, nhịp chấm dôi: [QU] |
| **Màu dân ca, ngũ cung thuần (folk colour)** | **Hướng ngũ cung–quãng 4**: trục quãng 4/5, hợp âm chồng quãng 4, bourdon chủ âm–át âm, sus2/sus4/add9; hạn chế V7 có âm dẫn | Tương phản bằng nhạc cụ, chồng điệu thức | Lý thuyết: [BC] (14.2). **Không có trong tập mẫu** (tập mẫu chỉ có bản hợp âm tân nhạc) | Áp dụng: [QU] |

**Ba điều KHÔNG làm khi viết bài Việt** (thay quy tắc cũ của bản 1.0):
- Không coi **I–V–vi–IV** là vòng mặc định của V-pop (0/37). (thay quy tắc cũ: "vòng pop axis I–V–vi–IV cho V-pop")
- Không cho ĐK bolero chuyển sang **trưởng cùng tên** (Am→A); chuẩn là **trưởng song song tên** (Am→C, Dm→F). (thay quy tắc cũ: "bolero chuyển sang trưởng cùng tên ở điệp khúc")
- Không mặc định **nâng tông ĐK cuối**: 0/37 bản hợp âm có; chỉ dùng khi có lý do sân khấu.
- "Hạn chế V7 có âm dẫn" chỉ đúng cho hướng ngũ cung/dân gian và fusion, **không** phải thực hành chung của tân nhạc.

## 14.2. Hoà âm cho giai điệu ngũ cung: trục quãng 4

### Cơ sở lý thuyết [BC]

| Luận điểm | Nguồn |
|---|---|
| Thang dân ca cổ nhất dựa trên **cặp quãng 4** (c–f, g–c) | Xôkanxki, dẫn trong Lê Anh Tuấn (2012, luận án, khảo sát 125 bài dân ca) |
| "**Trục quãng bốn**" là trụ cột của điệu thức Việt, gắn với sáu thanh | Nguyễn Xinh (1978) |
| Nhạc Chăm chồng **hai thang 5 âm cách nhau quãng 4** | Trần Hoàng Tiến (2025) |
| Nhạc Tày–Thái lấy quan hệ **I–IV và I–V** làm trụ; âm thanh khèn bè là ví dụ điển hình | Trần Hoàng Tiến (2025) |
| Hợp âm quãng 4 nước đôi về âm gốc → **giai điệu phải tự xác lập điệu tính** | Lý thuyết chung (Quartal and quintal harmony) |

### Kỹ thuật trong giao hưởng Việt sau 1975 [BC] (Vũ Tú Cầu, Viện Âm nhạc)

| Kỹ thuật | Mô tả | Ví dụ |
|---|---|---|
| Hợp âm chồng quãng 4 (quartal) | Xếp các nốt cách nhau quãng 4 đúng | Nguyễn Văn Nam: f–b–e–a–d |
| Bè trầm giữ âm (bourdon) | Bass giữ chủ âm hoặc chủ âm–át âm dưới toàn đoạn | — |
| Chồng điệu thức | Hai bè ở hai điệu thức khác nhau cùng lúc | Đặng Hữu Phúc: bè gỗ điệu Nam trên bè dây ở điệu thức khác |
| Hợp âm song song, đa chức năng | Dời nguyên khối hợp âm; chồng hai chức năng | — |

### Mô hình bolero: giai điệu ngũ cung trên nền V7

- [BC] Vietcetera mô tả giai điệu bolero "dựa vững vào thang ngũ cung"; nhưng 15/23 bài giọng thứ trong mẫu đệm bằng V7 trưởng có âm dẫn.
- [QU] Mô hình khớp dữ liệu nhất: **giai điệu ngũ cung hoặc gần ngũ cung, né bậc 7 nâng, trên nền i–iv–V7–i; âm dẫn chỉ có trong phần đệm.** Chưa kiểm chứng bằng phân tích giai điệu (tập mẫu chỉ có hợp âm).
- [QU] Vòng aeolian không V trưởng của folk fusion tương thích tự nhiên với giai điệu ngũ cung thứ → có thể vì vậy *Bắc Bling* nghe "dân gian" hơn bolero dù sản xuất điện tử.
- [QU] Tính "Việt" của bolero nằm ở **luyến láy, câu dạo, guitar Hawaii**, không nằm ở hoà âm.

### Quy tắc thực hành, đã sửa theo dữ liệu [QU]

1. Bolero, Trịnh, tiền chiến, trữ tình: mặc định **giọng thứ i–iv–V7–i**, ĐK ngả sang **giọng trưởng song song tên**. Nhạc Trịnh: thêm **I7→iv**.
2. V-pop ballad: mặc định vòng lặp **IV–V–iii–vi** hoặc **vi–iii–IV–V**, không phải I–V–vi–IV.
3. Folk fusion và rap: **vòng aeolian 2–4 hợp âm không V trưởng**, cadence v–i hoặc VII–i.
4. "Hạn chế V7 có âm dẫn" chỉ cho hướng ngũ cung/dân gian và fusion.
5. Khi nhạc cụ dân tộc độc tấu: dùng **sus2, sus4, add9** và **âm trì** ở chủ âm hoặc quãng 5.
6. Để nốt nhấn của điệu Nam/Oán "lơ lửng" trên nền hoà âm tĩnh; chấp nhận độ lệch của bậc **166 cent** so với piano như một chất riêng.
7. Nâng tông ĐK cuối không phải đặc trưng đã ghi nhận; chỉ dùng khi có lý do sân khấu.
8. Drone chiêng núm **C–G–C** (bourdon chủ âm–át âm) hợp vòng aeolian/folktronica, **va chạm với V7** và vòng đổi gốc nhanh có ii, iii (`15-nhac-cu-viet.md`). [QU]

### Ví dụ khung (giọng A thứ / C trưởng) [QU]

| Hướng | Khung |
|---|---|
| Bolero | Am–Dm–E7–Am │ ĐK: C–G–Am… (ngả sang C) |
| Trịnh | Am–A7–Dm–E(7)–Am |
| V-pop ballad | F–G–Em–Am (IV–V–iii–vi) lặp; hoặc Am–Em–F–G |
| Fusion/rap | Am–F–Dm–Em (i–VI–iv–v); Dm–G–Em–Am (iv–VII–v–i) |
| Folk colour | Bass giữ A–E; trên: A–D–G (quartal), Asus2, Dsus4; không E7 |

## 14.3. Màu vùng miền trong ca khúc trữ tình [BC]

Trần Hoàng Tiến (Tạp chí Nghệ thuật 55/2025) chỉ ra cách nhạc sĩ khai thác quãng đặc trưng vùng miền:

| Chất liệu | Bài | Tác giả |
|---|---|---|
| Ca trù | *Một thoáng Tây Hồ* | Phó Đức Phương |
| Ví Giặm | *Giận mà thương* | Nguyễn Trung Phong |
| Quan họ | *Người ở đừng về* | Nguyễn Xuân Tứ |
| Lượn cọi Tày | *Tiếng hát giữa rừng Pác Bó* | Nguyễn Tài Tuệ |
| Thang Tây Nguyên có bán âm | *Em là hoa Pơ Lang* | Đức Minh |

## 14.4. Tập mẫu 37 bài: phạm vi và giới hạn

- **Quy mô:** 37 bài, 11 nhóm; chỉ ghi ký hiệu hợp âm và cấu trúc, **không chép lời**.
- **Năm giới hạn** (đọc trước khi coi số liệu là "luật"):

| # | Giới hạn | Chi tiết |
|---|---|---|
| 1 | Chỉ một nguồn | Mọi hợp âm từ hopamchuan.com (người dùng tự đóng góp); hopamviet.vn báo lỗi nên không đối chiếu chéo được |
| 2 | Phiên bản bất đồng | Mỗi bài chỉ một phiên bản. *Diễm xưa* có ít nhất 8 bản khác chưa đối chiếu; *Như có Bác trong ngày vui đại thắng* có 3 bản bất đồng; trang *Biển nhớ* ghi tông Gm nhưng hiển thị hợp âm theo Am, không ghi capo |
| 3 | Công cụ trung gian | Trang được đọc qua công cụ tóm tắt; nhãn đoạn và vài ký hiệu hợp âm có thể sai |
| 4 | Không có tempo | Không trang nào ghi BPM; chỉ có nhãn "điệu" của người đệm |
| 5 | Cỡ mẫu nhỏ | Trịnh, folk fusion, rap, indie chỉ 3 bài/nhóm; **tân cổ giao duyên: 0 bài** |

→ Mọi kết luận là **giả thuyết có dữ liệu ủng hộ**, chưa phải định luật.

## 14.5. Bảng đếm mẫu hoà âm (37 bài)

| Mẫu hoà âm | Số bài | Ý nghĩa cho người sáng tác |
|---|---|---|
| Giọng thứ (trên tổng 37) | **23/37 (62%)** | Giọng thứ là mặc định của nhạc trữ tình Việt; toàn bộ bolero, Trịnh, tiền chiến và rap trong mẫu đều giọng thứ |
| Giọng thứ có V/V7 trưởng (họ i–iv–V7–i) | **15/23** | Âm dẫn có trong phần đệm dù giai điệu được mô tả là ngũ cung |
| Giọng thứ không V trưởng (cadence v–i hoặc VII–i) | 8/23, trong đó 6 bài là pop, V-pop, folk fusion hoặc rap sau 2000 | Hoà âm thứ tự nhiên (aeolian) là dấu hiệu của nhạc hiện đại |
| I7→iv (A7→Dm trong Am; E7→Am trong Em) | 3, **đủ 3/3 bài Trịnh** | Có thể là chữ ký hoà âm Trịnh; cần thêm bài |
| Đoạn B/ĐK ngả sang giọng trưởng song song tên | 7 | Cách tạo tương phản chuẩn của bolero và trữ tình |
| Chuyển sang trưởng cùng tên | 1 thực sự (*Thiên thai*, Dm→D), 1 thoáng qua | Hiếm |
| Họ "royal road" IV–V–iii–vi / IV–V–vi | 4 | Vòng đặc trưng V-pop ballad |
| Họ vi–iii–IV–V (Am Em F G) | 3 | Vòng lặp V-pop và rap |
| **I–V–vi–IV nguyên dạng** | **0** | Vòng pop phổ quát phương Tây không phải mặc định V-pop |
| Vòng aeolian 4 hợp âm (i–VI–iv–v, iv–VII–v–i, VI–i–VII–iv) | 3 | *Bắc Bling*, *See tình*, *Ngày khác lạ* |
| Vòng lặp xuyên suốt bài (2–5 hợp âm cho mọi đoạn) | **8, đều ra mắt sau 2014** | Sản xuất hiện đại xây bài trên vòng lặp; tương phản bằng phối khí |
| iv thứ mượn trong giọng trưởng | 2, đều indie | *Thấy chưa*, *Em dạo này* |
| bII (Eb trong Dm, F trong Em) | 3 | Màu "oán"/Phrygian ở trữ tình, tiền chiến |
| IV trưởng trong giọng thứ (màu Dorian) | 2 | *Vọng cổ buồn*, *Ngẫu hứng giao duyên* |
| Nâng tông ở ĐK cuối | **0/37** | Không có trên bản hợp âm; cần nghe bản thu để kiểm chứng |

Bài làm chứng: *Diễm xưa* (Am–A7–Dm–E); *Một cõi đi về* (E7→Am, ngả sang G); *Sầu tím thiệp hồng* (ĐK ngả sang F); *Nơi này có anh* (IV–V–vi–iii–ii–V–I); *Em của ngày hôm qua* (Am Em F G lặp cả 8 đoạn); *Bắc Bling* (i–VI–iv–v, không V trưởng); *See tình* (một vòng iv–VII–v–i cho mọi đoạn); *Thiên thai* (Dm→D).

## 14.6. Bảng tổng hợp theo nhóm

| Nhóm (số bài) | Thứ / trưởng | Nhãn điệu trên trang | Mẫu hoà âm nổi bật | Hình thức | Bài trong mẫu |
|---|---|---|---|---|---|
| Bolero / nhạc vàng (5) | 5 / 0 | Bolero/Bollero 4, Slow Rock 1 | V/V7 trưởng ở 4/5; ĐK ngả sang trưởng song song tên; IV trưởng màu Dorian ở 1 bài | "1., 2., ĐK, 3." (AABA) | *Đắp mộ cuộc tình*, *Sầu tím thiệp hồng*, *Chuyện hoa sim*, *Thành phố buồn*, *Vọng cổ buồn* |
| Nhạc Trịnh (3) | 3 / 0 | Slow 3 | **I7→iv ở 3/3**; V/V7 trưởng; 1 bài ngả sang G | Strophic hoặc A A–ĐK ngắn–A A | *Diễm xưa*, *Biển nhớ*, *Một cõi đi về* |
| Tiền chiến (4) | 4 / 0 (1 bài kết ở trưởng) | Slow 2, Ballad 1, không ghi 1 | i–VI–i–III–V7–i; v–i; bII; chuyển trưởng cùng tên (*Thiên thai*) | Strophic; 1 bài có Bridge | *Con thuyền không bến*, *Giọt mưa thu*, *Thiên thai*, *Buồn tàn thu* |
| Cách mạng (4) | 1 / 3 | Disco 2, Boston 1, Slow 1 | I–vi–IV–I; i–III–i–iv–V; 3 phiên bản bất đồng ở 1 bài | Có Intro | *Tiến quân ca*, *Giải phóng miền Nam*, *Như có Bác…*, *Bác đang cùng chúng cháu hành quân* |
| Trữ tình / dân ca mới (3) | 2 / 1 | Bolero, Ballad, Bossa Nova | i–v–i không V trưởng; bII; IV trưởng; I–IV–ii–V | — | *Mưa chiều miền Trung*, *Ngẫu hứng lý qua cầu*, *Ngẫu hứng giao duyên* |
| Pop 1990–2000 (4) | 2 / 2 | Slow, Ballad 2, Chachacha | I–vi–IV–V; I–V–vi–IV–V; vòng quãng 5 ngả sang C; ĐK lặp VI–VII–v–i | Có đoạn rap ở 1 bài | *Hà Nội mùa vắng những cơn mưa*, *Hãy về đây bên anh*, *Mắt nai cha cha cha*, *Có không giữ mất đừng tìm* |
| V-pop ballad 2014–2025 (4) | 1 / 3 | Ballad 4 | Họ IV–V–iii–vi; vi–iii–IV–V lặp cả bài; I–iii–vi–IV | Vòng lặp xuyên suốt; rap chèn | *Em của ngày hôm qua*, *Nơi này có anh*, *Ánh nắng của anh*, *Có chàng trai viết lên cây* |
| Folk fusion (3) | 2 / 1 | Ballad 2, Blues 1 | Aeolian không V trưởng; một vòng cho mọi đoạn | Intro/Verse/Pre/Chorus/Rap | *Để Mị nói cho mà nghe*, *See tình*, *Bắc Bling* |
| Rap Việt (3) | 3 / 0 | Ballad 2, Blues 1 | Vòng 2–4 hợp âm lặp cả bài | Verse/Chorus | *Bigcityboi*, *Lối nhỏ*, *Ngày khác lạ* |
| Indie (3) | 0 / 3 | Valse, Ballad 2 | iv thứ mượn; line cliché; bVII; vi–IV–I–V và vòng Canon | Intro/Verse/Chorus/Ending | *Em dạo này*, *Thấy chưa*, *2004* |
| Ngoài nhóm (1) | 0 / 1 | Slow Rock | I–vi–iii–V… | "1., 2., ĐK, 3." | *Đêm nay ai đưa em về* |
| **Tổng (37)** | **23 / 14** | **Ballad 14, Slow 7, Bolero 5**, Slow Rock 2, Disco 2, Blues 2, Boston 1, Chachacha 1, Valse 1, Bossa Nova 1, không ghi 1; **Rumba 0, Tango 0** | Xem 14.5 | Bridge có nhãn 1; nâng tông ĐK cuối 0 | — |

**Tông bấm và capo** [BC – tập mẫu]:
- Tông bấm hay gặp: Am (9 bài), Dm (7), C (6), Em (5), G (4), D (3).
- 11/37 bài ghi capo (capo 1 → capo 7). Người đóng góp quy về dáng Am, Em, Dm, C, G rồi dùng capo, nên tông vang thực tế đa dạng hơn: Bbm, Ebm, Cm, C#m, A#m, F#m, E, F, Eb.
- Hệ quả: **không thể suy tông thu âm gốc từ tông bấm trên trang hợp âm.**

## 14.7. Phát hiện theo thể loại

| Thể loại | Phát hiện | Nhãn |
|---|---|---|
| **Bolero** | Tạo tương phản bằng **đổi sang giọng trưởng song song tên, không đổi nhịp**: Dm→F (*Sầu tím thiệp hồng*), Am→C (*Chuyện hoa sim*, *Thành phố buồn*). *Vọng cổ buồn* có IV trưởng (D trong Am) → màu Dorian. Nhãn "Bollero" sai chính tả lặp nhiều lần → nhãn đến từ thói quen người đệm. Bài báo duy nhất mô tả giai điệu bolero ngũ cung không nói gì về hoà âm (Vietcetera) | [BC – tập mẫu] |
| **Nhạc Trịnh** | "Chữ ký" kiểm chứng được: I7 dẫn về iv ở cả 3 bài (A7→Dm trong *Diễm xưa*, *Biển nhớ*; E7→Am trong *Một cõi đi về*). Giọng thứ + I7→iv + nhãn "Slow" = khung đơn giản nhất để viết "theo tinh thần Trịnh" | [BC – tập mẫu]; cần kiểm thêm *Hạ trắng*, *Cát bụi* |
| **Tiền chiến** | Đa dạng nhất: *Con thuyền không bến* i–VI–i–III–V7–i; *Giọt mưa thu* kết khổ bằng v thứ (tránh âm dẫn); *Buồn tàn thu* bridge có bII (Eb trong Dm); *Thiên thai* là bài duy nhất chuyển giọng thật (Dm→D) | [BC – tập mẫu] |
| **Cách mạng** | Chủ yếu giọng trưởng; *Tiến quân ca* gắn nhãn "Slow", hai bài gắn "Disco" → nhãn phản ánh cách người đệm đổi nhịp hành khúc sang điệu phổ thông, không chứng minh nhịp gốc | [BC – tập mẫu] |
| **Trữ tình** | Mượn màu dân gian bằng bII và IV trưởng. *Ngẫu hứng lý qua cầu*: giọng thứ không V trưởng, có F (bII trong Em). *Ngẫu hứng giao duyên*: A trưởng (IV, Dorian), F (bII), thoáng E–C#m | [BC – tập mẫu]; hoà âm hoá màu "oán"/Phrygian: [QU] |
| **Pop 1990–2000** | Chuyển tiếp: I–vi–IV–V (*Hãy về đây bên anh*); gần I–V–vi–IV nhưng thêm V (*Mắt nai cha cha cha*); vòng quãng 5 i–iv–VII–III (*Hà Nội mùa vắng những cơn mưa*). *Có không giữ mất đừng tìm* có ĐK lặp VI–VII–v–i (= IV–V–iii–vi tính theo C), báo trước V-pop; năm sáng tác chưa xác minh | [BC – tập mẫu]; năm: [Cần kiểm chứng] |
| **V-pop ballad** | Cả bài trên một vòng lặp: *Em của ngày hôm qua* lặp Am–Em–F–G–C qua 8 đoạn; *Nơi này có anh* IV–V–vi–iii–ii–V–I, rap đi cùng vòng; *Ánh nắng của anh* IV–V–vi và IV–V–iii–vi. Không bài nào I–V–vi–IV nguyên dạng | [BC – tập mẫu]; gần "royal road" J-pop: [QU] |
| **Folk fusion, rap** | Né V trưởng. *Bắc Bling* lặp i–VI–iv–v (thuần thứ tự nhiên). *See tình* một vòng iv–VII–v–i cho mọi đoạn (hai phiên bản khác cũng giữ chức năng này). Rap: i–V7 (*Bigcityboi*), i–v–VI–VII (*Lối nhỏ*). Nhãn "Ballad"/"Blues" không mô tả groove điện tử → phân biệt **điệu đệm guitar** với **groove sản xuất** | [BC – tập mẫu] |
| **Indie** | Mượn màu giọng thứ: *Thấy chưa* có iv thứ (Fm trong C), E7/B, line cliché Am–Ammaj7–Am7–D7; *Em dạo này* có Dm trong A, nhãn Valse; *2004* chuyển vi–IV–I–V (verse) sang vòng Canon (chorus) | [BC – tập mẫu] |

## 14.8. Câu hỏi mở (tập mẫu chưa trả lời được)

| Vấn đề | Vì sao chưa trả lời | Cần gì |
|---|---|---|
| Giai điệu ngũ cung trên nền V7 | Hợp âm không cho biết giai điệu dùng bậc nào | Bản nhạc in hoặc bản thu |
| Đường bass | Gần như không đọc được từ ký hiệu hợp âm; con số 1 bài có bass đi xuống chắc chắn thấp hơn thực tế | Bản thu, bản phối |
| Nâng tông ĐK cuối | Trang hợp âm thường bỏ qua chi tiết dàn dựng; 0/37 không chứng minh bản thu không nâng tông | Nghe bản thu |
| Tân cổ giao duyên | 0 bài thu được | Sách dạy đờn ca tài tử, tài liệu dạy guitar phím lõm |
| Độ vững của số liệu | Cỡ mẫu nhỏ, một nguồn | Mở rộng mỗi nhóm lên 6–10 bài, đối chiếu ít nhất hai trang hợp âm, đo BPM từ bản thu |
