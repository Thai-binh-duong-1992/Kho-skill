> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Âm vực, BPM là giá trị xấp xỉ; C4 = Đô giữa, âm vực ghi theo cao độ thực.

# 7. Nhạc cụ 

Tệp này liệt kê khoảng 150 nhạc cụ trong 10 họ, ghi âm vực bằng **cao độ thực** (âm nghe được) và là giá trị xấp xỉ; âm vực dùng thực tế hẹp hơn giới hạn 2–3 nốt ở đỉnh. Nhạc cụ chưa có trong bảng thì Claude xếp vào họ gần nhất và nói rõ là suy luận.

**Nhạc cụ dịch giọng** (ghi bản nhạc khác cao độ nghe được): clarinet Bb, trumpet Bb, sax soprano và tenor Bb, sax alto và baritone Eb, kèn co F, English horn F; guitar, bass, contrabass ghi cao hơn một quãng tám; piccolo, celesta, xylophone ghi thấp hơn một quãng tám; glockenspiel, crotales ghi thấp hơn hai quãng tám [BC] (Michael Norris). Bảng tầm âm viết đầy đủ ở `15-nhac-cu-viet.md` mục 15.5. Khi xuất phần cho nhạc công, Claude ghi rõ "cao độ thực" hoặc "đã dịch giọng".

## 7.1. Dây kéo và đàn hạc

| Nhạc cụ | Âm vực | Vai trò | Cách chơi, màu đặc trưng |
| --- | --- | --- | --- |
| Violin | G3–E7 | Giai điệu, phản giai điệu, pad | Arco (kéo), pizzicato (gảy), tremolo, spiccato, legato, bồi âm, col legno, câm tiếng |
| Viola | C3–E6 | Bè giữa, giai điệu trầm ấm | Như violin, màu tối hơn |
| Cello | C2–A5 | Bass, giai điệu trữ tình | Legato hát, pizzicato bass |
| Contrabass | E1–G3 (bồi âm cao hơn) | Bass | Arco cho giao hưởng, pizz cho jazz |
| Dàn dây (section) | C2–E7 | Thảm hòa âm, cao trào | Divisi (chia bè), unison quãng tám, ostinato, swell |
| Đàn hạc (harp) | Cb1–G#7 | Rải hợp âm, lướt (glissando) | Glissando, bồi âm; đổi giọng bằng bàn đạp |

## 7.2. Dây gảy

| Nhạc cụ | Âm vực | Vai trò | Cách chơi, màu đặc trưng |
| --- | --- | --- | --- |
| Guitar cổ điển (dây nylon) | E2–B5 | Đệm, độc tấu | Ngón rải, rasgueado; mềm (bossa, bolero, flamenco) |
| Guitar mộc dây sắt | E2–C6 | Đệm quạt, rải | Quạt chả, fingerstyle, capo; sáng (pop, folk, country) |
| Guitar điện | E2–E6 | Riff, đệm, solo | Sạch, crunch, distortion, palm-mute, bend, slide, tapping, hiệu ứng delay, reverb, wah |
| Guitar 7–8 dây, chùng Drop | B1 / F#1 trở lên | Riff nặng | Metal hiện đại |
| Bass điện 4 dây (5 dây) | E1–G4 (B0 với 5 dây) | Bass | Ngón, pick, slap–pop, fretless |
| Ukulele | C4–A5 (dây G cao) | Đệm vui | Quạt, island strum |
| Mandolin | G3–A6 | Tremolo giai điệu, chop | Bluegrass, folk, Ý |
| Banjo 5 dây | D3–D6 | Đệm rải nhanh | Roll 3 ngón (bluegrass), clawhammer |
| Pedal steel, dobro | E2–E6 | Trượt nốt, đệm ngân | Country, Hawaii |
| Harpsichord | F1–F6 | Đệm Baroque | Không có to nhỏ, sắc |

## 7.3. Hơi gỗ

| Nhạc cụ | Âm vực | Vai trò | Cách chơi, màu đặc trưng |
| --- | --- | --- | --- |
| Piccolo | D5–C8 | Tô điểm cực cao | Chói, hành khúc |
| Sáo Tây (flute) | C4–C7 | Giai điệu nhẹ, trang trí | Legato, staccato, flutter, gió ở nốt thấp |
| Sáo alto | G3–G6 | Giai điệu trầm mềm | Nhạc phim |
| Oboe | Bb3–A6 | Giai điệu buồn, mộc mạc | Mũi, ngân đẹp |
| English horn | E3–C6 | Giai điệu u hoài | Trầm hơn oboe |
| Clarinet Bb | D3–Bb6 | Giai điệu, bè giữa | Mềm ở nốt trầm, sáng ở nốt cao; klezmer, jazz sớm |
| Bass clarinet | Bb1–F5 | Bass mềm | Nhạc phim, jazz |
| Bassoon | Bb1–E5 | Bass, hài hước | Staccato vui |
| Contrabassoon | Bb0–Bb3 | Siêu trầm | Giao hưởng |
| Sax soprano | Ab3–E6 | Giai điệu | Smooth jazz |
| Sax alto | Db3–Ab5 | Giai điệu, solo | Jazz, pop, R&B |
| Sax tenor | Ab2–E5 | Solo khàn, ấm | Rock and roll, jazz, soul |
| Sax baritone | C2–A4 | Bass kèn | Funk, big band |
| Recorder (sáo dọc) | C5–D7 (soprano) | Giáo dục, Baroque | Trong, đơn giản |
| Harmonica diệp (giọng C) | C4–C7 | Blues, folk | Bend, thổi–hút |
| Melodica | F3–F6 | Giai điệu vui | Giáo dục, reggae dub |

## 7.4. Hơi đồng

| Nhạc cụ | Âm vực | Vai trò | Cách chơi, màu đặc trưng |
| --- | --- | --- | --- |
| Trumpet Bb | E3–C6 | Giai điệu, fanfare, nốt nhấn (stab) | Câm tiếng (straight, cup, harmon), shake, fall |
| Flugelhorn | E3–Bb5 | Giai điệu mềm | Jazz ballad |
| Kèn co (French horn) | B1–F5 | Hòa âm ấm, chủ đề anh hùng | Nhạc phim, giao hưởng |
| Trombone | E2–F5 | Bè, glissando | Kéo trượt, ska, big band |
| Trombone bass | Bb1–Bb4 | Bass kèn | Giao hưởng, big band |
| Euphonium | Bb1–Bb4 | Giai điệu trầm | Ban kèn |
| Tuba | D1–F4 | Bass | Polka, hành khúc, giao hưởng |
| Bộ kèn đồng (horn section) | — | Stab, đệm hợp âm dày | Funk, soul, ska, salsa: trumpet + sax + trombone |

## 7.5. Phím

| Nhạc cụ | Âm vực | Vai trò | Cách chơi, màu đặc trưng |
| --- | --- | --- | --- |
| Piano | A0–C8 | Đệm, giai điệu, solo | Ballad rải, hợp âm chặn, stride, montuno, gospel |
| Rhodes (đàn phím điện) | E1–G6 | Hợp âm ấm | Neo-soul, lo-fi, R&B |
| Wurlitzer | A1–C7 | Đệm hơi sạn | Soul, rock 60–70s |
| Organ Hammond | C2–C7 | Pad, đệm, solo | Loa xoay Leslie; gospel, rock, blues |
| Organ ống | C1–C7 (kèm pedal) | Trang nghiêm | Nhà thờ, nhạc phim |
| Celesta | C4–C8 | Leng keng thần tiên | Nhạc phim, Giáng sinh |
| Accordion | F3–A6 (tay phải) | Giai điệu, đệm | Tango, polka, cumbia, nhạc Pháp |
| Organ điện tử (keyboard phổ thông) | — | Đệm điệu tự động | Nhạc đám cưới, bolero bình dân |

## 7.6. Gõ có cao độ

| Nhạc cụ | Âm vực | Vai trò, màu |
| --- | --- | --- |
| Glockenspiel | G5–C8 | Leng keng, nhấn giai điệu |
| Xylophone | F4–C8 | Khô, vui, thiếu nhi |
| Marimba | C2–C7 | Ấm, tropical, tối giản |
| Vibraphone | F3–F6 | Rung âm, jazz |
| Chuông ống (tubular bells) | C4–F5 | Chuông nhà thờ, cao trào |
| Timpani (bộ 4) | D2–C4 | Trống có cao độ, dồn, cao trào |
| Steel pan | C4–E6 (tenor) | Caribbean |
| Kalimba, mbira | C4–E6 (17 phím) | Nhẹ, thơ ngây |
| Crotales, chuông tay | C6–C8 | Lấp lánh |

## 7.7. Gõ không cao độ và trống

| Nhóm | Nhạc cụ | Vai trò |
| --- | --- | --- |
| Bộ trống | Kick, snare, tom, hi-hat, ride, crash, splash, china | Xương sống nhịp pop, rock, jazz |
| Trống tay | Cajon, conga, bongo, djembe, darbuka, frame drum, bodhrán | Groove mộc, Latin, châu Phi, Trung Đông, Celtic |
| Trống lớn | Taiko, bass drum giao hưởng, surdo, trống trận | Uy lực, epic, samba |
| Latin | Timbales, cowbell, claves, güiro, maracas, cabasa, agôgô | Clave và màu Latin |
| Nhỏ | Tambourine, shaker, tam giác, woodblock, chuông gió, vỗ tay, búng tay | Tăng độ sáng, năng lượng |
| Kim loại | Gong, chiêng, cymbal giao hưởng, chũm chỏe | Cao trào, chuyển đoạn |
| Trống máy | TR-808, TR-909, LinnDrum, sample one-shot | Hip-hop, house, synthwave |

## 7.8. Điện tử

| Loại âm | Vai trò | Thể loại |
| --- | --- | --- |
| Synth lead (saw, square, supersaw) | Giai điệu, câu móc drop | EDM, trance, K-pop |
| Synth bass, Reese, wobble | Bass | House, drum and bass, dubstep |
| 808 bass | Bass–kick, trượt cao độ | Trap, drill, hip-hop |
| Pad, string synth | Thảm hòa âm | Ambient, ballad hiện đại |
| Pluck, arpeggio | Nhịp giai điệu | Future bass, synthwave |
| Chiptune (8-bit) | Giai điệu game | Nhạc game |
| Vocoder, talk box, auto-tune hiệu ứng | Giọng robot | Funk, electro, hip-hop |
| Sampler, giọng cắt ghép (vocal chop) | Câu móc | Future bass, house |
| Theremin | Ma mị | Nhạc phim kinh dị, khoa học viễn tưởng |
| Hiệu ứng chuyển đoạn | Riser, downlifter, impact, white noise, reverse cymbal | Mọi thể loại hiện đại |

## 7.9. Nhạc cụ dân tộc Việt Nam

Bảng tóm tắt; số liệu đầy đủ, nguồn và bộ kiểm tra I1–I10 ở `15-nhac-cu-viet.md` (khi hai tệp khác nhau, theo tệp 15). Nhãn: [BC] có bằng chứng; [QU] quy ước/suy luận; [Cần kiểm chứng]; "Chưa có nguồn" = không lấp bằng phỏng đoán. Nguyên tắc chung [BC]: dây mềm, phím cao hoặc không phím → nhạc cụ dân tộc **mạnh ở luyến, nhấn, vuốt**, hợp vai giai điệu và đối âm hơn đệm hợp âm dày.

| Nhạc cụ | Loại | Lên dây, âm vực, thang âm | Màu sắc, cách dùng |
| --- | --- | --- | --- |
| Đàn bầu | Dây gảy 1 dây (bồi âm) | Dây buông khoảng C3 (131 Hz); nốt lấy theo 7 điểm bồi âm cộng uốn cần [BC]. Tổng âm vực: chưa có nguồn (thay số cũ "khoảng 3 quãng tám") | Luyến, nỉ non, uốn cần lấy nốt giữa bồi âm; giai điệu chính, solo. Pickup từ cho phép vào ban pop/rock [BC] |
| Đàn tranh | Dây gảy 16 dây, chuẩn 17 dây từ cuối thập niên 1980 [BC] (thay số cũ "16–22 dây"; 21 dây là guzheng) | Khoảng 3 quãng tám, lên dây ngũ cung trưởng; muốn chromatic phải lên lại dây [BC] | Rải, vuốt, nhấn, tremolo; ít dùng cho bản bi tráng [BC]. Dây trầm chồng vùng bass |
| Đàn nguyệt (Nam Bộ: đàn kìm) | Dây gảy 2 dây, phím cao | Hai dây cách quãng 4, 5 hoặc 7 thứ; hơn 2 quãng tám [BC] | Nhấn trên phím cao; nhạc cụ chính của hát văn; chèo, tài tử, ca Huế, cải lương [BC] |
| Đàn tỳ bà | Dây gảy 4 dây | C4–F4–G4–C5 [BC]; tổng âm vực: chưa có nguồn (thay số cũ "khoảng 3 quãng tám") | Nhã nhạc, đờn ca tài tử [BC]; tay trái nhấn uốn cao độ. Không thay bằng pipa |
| Đàn đáy | Dây gảy 3 dây, cần rất dài, 10 phím cao, thùng không mặt sau | Nguồn chỉ ghi G3 và C4 [BC]; dây thứ ba [Cần kiểm chứng] | Ca trù [BC]; có bass điện dáng đàn đáy cho nhạc tân truyền thống [BC] |
| Đàn tính | Dây gảy 2–3 dây tơ, bầu khô | Chưa có nguồn; lên dây quãng 4 hoặc 5 [Cần kiểm chứng] | Hát then (nghi lễ) [BC]; âm nhỏ, cần micro áp sát [QU] |
| Đàn tam | Dây gảy 3 dây, không phím | F3–C4–F4 [BC]; tổng âm vực: chưa có nguồn | Nhã nhạc, chèo [BC]; khung F–C–F làm bourdon cho giọng F [QU] |
| Đàn sến | Dây gảy 2 dây, có phím | Chưa có nguồn; gốc nguồn mâu thuẫn (meihuaqin hay qinqin) | Nam Bộ, tài tử, cải lương [Cần kiểm chứng] |
| Đàn tứ (thân vuông) | Dây gảy 4 dây | C3–G3–D4–A4 (như viola) [BC] | Dàn dân tộc cải biên; cầu nối với dàn dây phương Tây [QU] |
| Guitar phím lõm | Dây gảy **5 dây**, cần khoét lõm [BC] (thay ghi chú cũ "6 dây") | C3–F3–C4–G4–C5 [BC]; tổng âm vực: chưa có nguồn | Nhấn sâu, luyến rộng; cải lương, tài tử, nay cả chầu văn [BC]; bolero [QU] |
| Đàn tam thập lục | Dây gõ 36 dây kim loại | Chưa có nguồn | Gõ tremolo, rải; chèo, nhạc dân tộc cải biên [BC] |
| Đàn nhị (đàn cò) | Dây kéo 2 dây | Lên dây quãng 5, ví dụ D4–A4 [Cần kiểm chứng]; tổng âm vực: chưa có nguồn (thay số cũ "2,5 quãng tám từ D4") | Vuốt, rung, nhấn; nhã nhạc, chèo, tài tử, hát văn [BC]. "Đàn cò" là tên gọi khác của nhị (cây cò giống erxian), **không phải** nhạc cụ trầm hơn. Dàn cải biên phần lớn đã dùng erhu thay nhị [BC] |
| Đàn hồ, đàn gáo | Dây kéo 2 dây | Chưa có nguồn | Đàn hồ làm bè trầm nhóm nhị [Cần kiểm chứng]; gáo–cò là cặp trầm–cao Nam Bộ [QU], gáo đang mai một [BC] |
| Sáo trúc (sáo ngang) | Hơi | Chưa có nguồn (thay số cũ "khoảng 2,5 quãng tám"); có nhiều tông C, D, G… [Cần kiểm chứng] | Láy, vuốt, rung hơi; nhã nhạc, chèo, tài tử [BC]; chọn sáo theo tông bài |
| Sáo mèo | Hơi | Chưa có nguồn | Hook của *Để Mị nói cho mà nghe* [BC] |
| Tiêu (sáo dọc) | Hơi | Chưa có nguồn (thay ghi chú cũ "khoảng 2 quãng tám") | Hơi gió nhiều, mềm, trầm tư [Cần kiểm chứng] |
| Kèn bầu | Hơi dăm kép, gốc suona | Chưa có nguồn | Sắc, to; nhã nhạc, nhạc lễ [BC]; intro *Bắc Bling* [BC]; thu xa micro |
| Khèn H'Mông | Hơi lưỡi gà tự do, 6 ống tre | Chưa có nguồn | Thổi cả thở ra lẫn hít vào [BC] → âm liên tục, hợp pad/ostinato hòa âm [QU]; xưa chỉ dùng trong đám tang (nghĩa nghi lễ) [BC] |
| Đàn môi | Gảy lưỡi gà | Bồi âm theo khẩu hình [BC] | Vùng cao; âm nhỏ, cần micro áp sát [QU] |
| Đàn t'rưng | Gõ ống tre | Nay **phổ biến ở dạng diatonic** [BC] (thay ghi chú cũ "ngũ cung"); thư viện mẫu 3,5 quãng tám chromatic [BC]; xưa mô phỏng thang dàn chiêng | Tây Nguyên; dễ ghép với hòa âm phương Tây nhất [QU] |
| Klông pút | Vỗ tay đẩy hơi vào ống tre | Theo chiều dài ống; thang: chưa có nguồn (bỏ ghi chú cũ "ngũ cung") | Hoquet nhiều ống; "bass hơi" mềm hợp lofi, ambient [QU] |
| Đàn đá | Gõ thanh đá (9 thanh trở lên, 65–102 cm) | Chưa có nguồn | Tây Nguyên, niên đại khoảng 1000 TCN [BC] |
| Cồng chiêng | Gõ kim loại | 3 chiêng núm lõi **C–G–C**; Ê Đê thang 6 âm không bán cung; Gia Rai 5 âm có 2 bán cung; **không chỉnh theo A440** [BC] (Della Ratta) | Đa tầng đan xen, nghi lễ (mỗi chiêng chứa một vị thần) [BC]; drone C–G–C hợp aeolian, va chạm V7 [QU] |
| Trống cơm, trống đế, trống chầu, trống cái | Gõ da | Trống cơm định âm tương đối [Cần kiểm chứng]; các trống khác không định âm | Giữ nhịp, chấm câu; trống chầu trong ca trù, tuồng [BC] |
| Phách, song lang, mõ, sênh tiền, thanh la, tam âm la | Gõ nhỏ | — | Giữ phách, màu nghi lễ. Song lang gõ phách mạnh cuối chu kỳ → không quantize về phách đầu ô [QU] |

## 7.10. Nhạc cụ thế giới

| Vùng | Nhạc cụ | Màu sắc, cách dùng |
| --- | --- | --- |
| Trung Quốc | Nhị hồ (erhu), cổ tranh (guzheng: phổ biến 21 dây, D2–D6, ngũ cung trưởng [BC]), tỳ bà (pipa), địch tử (dizi), sanh (sheng), dương cầm (yangqin), kèn sô na (suona) | Cổ phong, nhạc phim kiếm hiệp, lễ hội |
| Nhật Bản | Koto, shamisen, shakuhachi, taiko, biwa | Thiền, sử thi, anime |
| Hàn Quốc | Gayageum, haegeum, daegeum, janggu | Gugak, nhạc phim cổ trang |
| Đông Nam Á | Gamelan (gong, saron, bonang; slendro 5 âm gần chia đều, pelog — **không khớp 12 bình quân** [BC]), khaen (Thái, Lào), ranat, angklung; roneat, kuong vong (dàn ngũ âm Khmer Nam Bộ) | Màu nhiệt đới, nghi lễ |
| Ấn Độ | Sitar, sarod, sarangi, santoor, bansuri, tabla, tanpura, harmonium, dhol | Raga, Bollywood, bhangra |
| Trung Đông | Oud, qanun, ney, saz (bağlama), kemençe, darbuka, daf, riq | Maqam, sa mạc |
| Châu Phi | Kora, balafon, djembe, talking drum, mbira, ngoni | Đa nhịp, tiếng gỗ |
| Mỹ Latin, Caribbean | Charango, quena, zampoña (sáo pan), cuatro, cavaquinho, bandoneon, steel pan, marimba Latin | Andes, samba, tango, calypso |
| Châu Âu dân gian | Kèn túi (bagpipes), fiddle, tin whistle, bodhrán, hurdy-gurdy, balalaika, bouzouki, nự cầm, accordion | Celtic, Nga, Hy Lạp, Trung cổ |
| Châu Đại Dương | Didgeridoo, ukulele, slack-key guitar | Thổ dân Úc, Hawaii |

**Không nhầm nhạc cụ Việt với nhạc cụ Trung Hoa** [BC]: đàn tranh 16–17 dây ≠ guzheng 21 dây; tỳ bà lên C4–F4–G4–C5, nguồn chưa cho thấy pipa lên cùng dây; đàn nhị gần erhu nhưng đàn cò Nam Bộ giống erxian hơn; cao độ Việt có nhiều bậc khoảng 166 cent. [QU] Không dùng sample guzheng, erhu, pipa rồi ghi credit "đàn tranh", "đàn nhị", "tỳ bà"; không xếp guzheng, koto, dizi cùng vai với tranh, sáo trúc; nhạc cụ thế giới giữ vai tương phản (nhịp hoặc màu). Chi tiết: `15-nhac-cu-viet.md` mục 15.9.
