> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Quy trình sản xuất từ demo đến master cho bài hát Việt (cũng dùng được cho thể loại khác). C4 = Đô giữa; âm vực ghi theo cao độ thực. Nhãn: [BC] có bằng chứng; [QU] quy ước thực hành hoặc suy luận; [Cần kiểm chứng].

# Sản xuất: tiền kỳ, thu, biên tập giọng, mix, master, giao nộp

Thứ tự dùng: 16.1 → 16.7. Danh sách kiểm tra C–G cuối tệp. Pháp lý và phát hành: `17-phap-ly-phat-hanh.md`. Prompt nhạc AI: `08-cong-cu-ai.md`.

## 16.1. Tiền kỳ: ê-kíp, trại sáng tác, "lý do tồn tại" của chất liệu dân gian

**[BC] Thực hành ê-kíp V-pop được báo chí ghi nhận** (báo chí mô tả tổ chức sản xuất rõ hơn kỹ thuật phòng thu):

| Thực hành | Ví dụ | Nguồn |
|---|---|---|
| Trại sáng tác để thống nhất ngôn ngữ âm nhạc; nhiều vòng góp ý tập thể | Dự án *Giai Nhân* (Hứa Kim Tuyền), kéo dài 3 tháng | Tiền Phong |
| Dùng demo để chọn giọng (casting vocal) | DươngK chọn HURRYKNG sau khi nghe demo *Nhạc Tình*; Tóc Tiên, Văn Mai Hương, CARA gửi bài thi | Tiền Phong |
| Chọn chất liệu dân gian theo tinh thần, âm sắc, câu chuyện; mỗi chi tiết phải có lý do tồn tại; dân gian là nền móng có thể khoác EDM, hip-hop | DTAP | Nhân Dân |

Không có phỏng vấn đáng tin của Masew, Huy Tuấn, Đức Trí mô tả BPM, chord chart hay template DAW → không bịa "công thức" của các producer này.

**[QU] Trình tự tiền kỳ 7 bước:**

1. **Demo thô** (giọng + guitar/piano, hoặc demo AI – xem 16.6) để khoá giai điệu, lời, hình thức. Chạy ngay bộ kiểm tra thanh–nhạc T1–T10 và đặt chữ vào nhịp N1–N9 (`ngon-ngu/vi.md`).
2. **Chốt tông theo ca sĩ thật** và thử với nhạc cụ dân tộc (tông thuận dây buông).
3. **Chốt BPM và grid/click.** Bolero, cải lương có rubato (nói lối, vọng cổ tự do): xác định từ đầu đoạn nào không chạy click.
4. **Lead sheet + arrangement map**: hợp âm, số ô nhịp, Intro–Verse–Pre–Chorus–Bridge, chỗ nhạc cụ dân tộc vào/ra. Kèm **guide audio** vì nhiều nghệ nhân quen giản phổ/ký âm truyền thống hơn ký hiệu hợp âm.
5. **Guide vocal có luyến láy thật**, để nhạc công dân tộc chơi quanh lời, không đè chỗ luyến.
6. **2–3 reference track** cùng thể loại để thống nhất âm sắc và mức hiện đại hoá.
7. Mỗi chất liệu dân gian phải trả lời: nó là **hook, màu sắc, cấu trúc nhịp hay kể chuyện**?

## 16.2. Thu âm nhạc cụ dân tộc và bài toán 166 cent so với 12 bình quân

**[BC]** Đàn bầu hiện đại dùng dây guitar điện và **pickup từ** để vào hoà tấu, pop/rock (Wikipedia: Đàn bầu). Thư viện Dan Bau (Bolder Sounds) ghi hai nguồn pickup và micro để trộn (KVR) → xác nhận thực hành thu đồng thời DI + micro.

**[BC – ngoại suy từ nhạc cụ Trung Hoa cùng họ]** Không có tài liệu kỹ thuật tiếng Việt về đặt micro cho tranh, sáo, nguyệt, kìm, song lang, phách. Mô hình tốt nhất hiện có:
- Guzheng (≈ đàn tranh): một micro wide-cardioid **đặt cao, ngang đầu người chơi, giữa thân đàn**; không khuyên cặp overhead vì stereo quá rộng (DPA). Có thể đặt micro **dưới gầm đàn** ở lỗ thoát âm cho độ dày, thêm một micro trên chỗ gảy (Production Expert).
- Erhu (≈ đàn nhị): micro thẳng trước bầu cộng hưởng.
- Pipa (≈ nguyệt, tỳ bà): cách khoảng **60 cm** phía trước; gần hơn thừa tiếng gảy.
- Nguồn to (trống, kèn) cách ly khỏi phòng chung (Production Expert).

**[QU] Bảng điểm xuất phát:**

| Nhạc cụ | Cách thu gợi ý | Lưu ý |
|---|---|---|
| Đàn bầu | DI từ pickup qua hộp DI/Hi-Z + một micro cách 20–40 cm hướng vùng gảy | Không dùng chỉnh cao độ tự động; chỉ sửa tay vài nốt đích lệch rõ |
| Đàn tranh | Micro tụ ngang đầu người chơi, giữa đàn, cách 40–60 cm; có thể thêm micro dưới gầm | Kiểm tra pha giữa micro trên và dưới |
| Sáo trúc, sáo mèo | Micro tụ cách 30–50 cm, lệch khỏi luồng hơi | Tránh tiếng gió, bật hơi |
| Đàn nguyệt, đàn kìm | Theo mô hình pipa, 40–60 cm, hướng giữa mặt đàn và cần | Gần quá thừa tiếng gảy |
| Đàn nhị | Theo mô hình erhu, micro trước bầu, lệch khỏi đường vĩ | Có thể thêm micro phòng |
| Trống cơm, trống chầu, song lang, phách | Micro động hoặc tụ cách 30–60 cm, gain vừa | Thu song lang, phách thành track riêng để sắp lại timing |

**[BC] Cao độ.** Thang Việt dùng nhiều bậc khoảng **166 cent**; luyến, nhấn là trang sức quan trọng (Keefe, Burns & Phong Nguyễn 1991). Đàn bầu có hai quãng bồi âm phi phương Tây. Đàn tranh 16 dây lên dây ngũ cung trưởng (KVR – Dan Tranh).

**[QU] Phải chọn chủ động một chiến lược trước buổi thu:**

| Phương án | Khi dùng | Cách làm | Đánh đổi |
|---|---|---|---|
| **A. Nhạc cụ theo synth** | Bài pop/V-pop/EDM, nhạc cụ dân tộc là màu | Lên dây buông tranh, nguyệt, kìm, bầu theo tuner A440; chấp nhận nốt nhấn lệch theo ý đồ. Ở đoạn nhạc cụ dân tộc độc tấu, pad chỉ chơi quãng 5, quãng 8 hoặc âm trì để không đụng bậc lệch | Mất một phần "hơi" (Oán, Ai) ở nốt buông; nốt nhấn vẫn giữ |
| **B. Synth theo nhạc cụ** | Nhạc cụ dân tộc là trục chính (ví dụ bài theo điệu Oán), tài tử, cải lương, fusion sâu | Chỉnh master tune synth lệch vài cent, hoặc nạp file microtuning **.scl/.tun** nếu synth hỗ trợ | Tốn công; nhạc cụ bình quân (piano, guitar phím thường) khó dùng cùng |
| Cả hai | — | Thu 2–3 take nhạc cụ dân tộc, chọn take theo cảm giác cao độ **trong bản phối**; chỉ chỉnh Melodyne cục bộ cho nốt đích dài | — |

Ghi phương án đã chọn vào arrangement map (bộ kiểm tra chọn nhạc cụ I1–I10 trong `15-nhac-cu-viet.md`).

## 16.3. Biên tập giọng: bảo vệ vết thanh và luyến láy

**[BC] Melodyne (Sound On Sound):**
- Pitch Centre 100% có thể kéo nốt về **sai** cao độ → luôn nghe lại.
- Pitch Drift làm phẳng dao động nhỏ trong nốt → **tách nốt** trước nếu chỉ sửa một phần; tách ở điểm biểu cảm (chỗ uốn vào chữ).
- Modulation quá tay → giọng robot.
- **Tắt snapping** để đẩy nốt khoảng 15 cent theo tai.
- Nguyên tắc: nghe lại mà nhận ra dấu vết chỉnh là đã quá tay.

**[QU] Riêng tiếng Việt (cảnh báo suy luận, chưa có nghiên cứu đo trực tiếp):** thanh hỏi (xuống rồi lên), ngã (gãy rồi lên), nặng (xuống, tắc), sắc (lên) để lại "vết" cao độ ở đầu/cuối âm tiết. Auto-Tune retune speed nhanh hoặc Pitch Drift 100% có thể xoá vết → chữ hỏi nghe như huyền hoặc không dấu, giảm độ rõ lời.

| Trường hợp | Quy tắc |
|---|---|
| Giọng chính mọi thể loại | Retune speed chậm; **Pitch Drift gần 0%**; tách riêng phần vết thanh khỏi phần ngân |
| Bolero, cải lương, dân ca | Chỉ chỉnh nốt đích kết câu và nốt ngân dài lệch rõ; **không lượng tử hoá timing** ở vọng cổ, nói lối, rubato; lệch nhiều → thu lại hoặc comp take khác |
| Comping | 3–6 take toàn bài + punch-in câu khó; comp theo câu/cụm từ, **không cắt giữa âm tiết có thanh**; crossfade ở phụ âm đầu hoặc chỗ lấy hơi |
| V-pop, rap, EDM | Auto-Tune nghe rõ là lựa chọn thẩm mỹ chấp nhận được, nhưng vẫn nghe lại riêng chữ hỏi, ngã |
| Thứ tự | Thu → comp → chỉnh timing thủ công → chỉnh cao độ thủ công (tắt snapping) → clip gain, giảm tiếng thở → mix |

Sau khi chỉnh: chạy lại T2–T6 trên bản đã chỉnh (Phụ lục E27).

## 16.4. Mix cho độ rõ lời của ngôn ngữ có thanh điệu

**[BC] Độ rõ lời (DPA):** năng lượng nguyên âm giảm nhanh trên ~1 kHz; phụ âm tập trung **2–4 kHz**; dải **1–4 kHz** quan trọng cho độ rõ, quanh **2 kHz** quan trọng nhất. Bỏ toàn bộ dưới 500 Hz mất phần lớn năng lượng nhưng chỉ giảm ~5% độ rõ; lọc thông thấp ở 1 kHz làm độ rõ xuống dưới 40%. Nhạc nền dưới lời có thể **cắt 5–10 dB ở 1–4 kHz**. Chưa có nguồn kỹ thuật riêng cho mix ngôn ngữ có thanh điệu hay quy ước mix bolero, cải lương.

**[QU] 5 nguyên tắc cho tiếng Việt:**
1. Tạo "khe" 1–4 kHz cho giọng bằng EQ động hoặc sidechain trên pad, guitar, đàn tranh, synth lead.
2. De-esser chỉ nhắm sibilance (thường 5–9 kHz); đặt thấp quá ăn mất x, s, ch, tr, th.
3. Nén giọng attack không quá nhanh để phụ âm đầu (t, k, b, đ) giữ transient.
4. Automation âm lượng theo từng chữ thay vì nén nặng — thanh nặng (và ngã giọng Bắc) có tắc thanh hầu, nhỏ hơn, dễ chìm; âm tiết kết -p/-t/-c/-ch (chỉ mang sắc hoặc nặng) cũng ngắn, dễ chìm.
5. Nghe thử trên loa điện thoại, tai nghe, loa xe và **loa karaoke**.

**[QU] Phân dải gợi ý** (ước lượng theo tầm âm vật lý, kiểm tra bằng analyzer):

| Nguồn âm | Dải chính | Nguy cơ va chạm / xử lý |
|---|---|---|
| Đàn bầu | thân 150–800 Hz; "hát" 1–3 kHz | Đụng giọng → hạ đàn hoặc EQ động 1–3 kHz khi có lời |
| Đàn tranh | thân 200–600 Hz; gảy 2–6 kHz; lấp lánh 6–10 kHz | Dùng làm lớp lấp lánh, pan rộng |
| Sáo trúc | ~500 Hz–2,5 kHz; tiếng hơi 4–8 kHz | Cạnh tranh giọng nữ |
| Đàn nhị | 300 Hz–3 kHz; tiếng mũi quanh 1 kHz | Đụng giọng ở dải trung |
| Trống, song lang, phách | transient 2–5 kHz; thân trống chầu, trống cơm 80–250 Hz | Song lang dễ cắt qua lời |
| Synth pad | 200–800 Hz hoặc trên 8 kHz | Tránh 1–4 kHz |

**[QU] Gợi ý theo thể loại** (hiệu chỉnh bằng reference):

| Thể loại | Giọng | Không gian | Khác |
|---|---|---|---|
| Bolero | To, gần; nén vừa giữ luyến láy | Reverb hall/plate ~1,5–2,5 s | Đàn tranh, guitar phím lõm đặt hai bên |
| Ballad V-pop | Trung tâm; nén song song | Plate, pre-delay 30–80 ms | — |
| EDM/folktronica | — | — | Kick + bass chiếm dưới ~120 Hz, có sidechain; đàn bầu, sáo làm lead, lọc cắt thấp ~150–250 Hz |
| Rap | Khô, gần, nén mạnh hơn | Chỉ "ném" reverb/delay cuối câu | — |

## 16.5. Mastering và giao nộp theo nền tảng

**[BC] Bảng thông số** (tài liệu chính thức hoặc nguồn chuyên ngành):

| Nền tảng | Mức chuẩn hoá | True peak | Định dạng nộp | Nguồn |
|---|---|---|---|---|
| Spotify | **−14 LUFS** (ITU-R BS.1770); Premium chọn Loud −11 / Normal −14 / Quiet −19; album chuẩn hoá chung, playlist chuẩn hoá từng bài | **Dưới −1 dBTP**; dưới −2 dBTP nếu master to hơn −14 LUFS | **FLAC** (khuyến nghị) hoặc WAV PCM; **không chấp nhận WAVE_FORMAT_EXTENSIBLE**; ≥44,1 kHz; **24-bit** nếu master gốc 24-bit; không nộp cả 16 và 24-bit | Spotify for Artists |
| Apple Music | **−16 LUFS** (**Sound Check** bật mặc định trên iOS) | Chừa ≥1 dB; kiểm tra inter-sample clipping và file AAC đã mã hoá | Nguồn **24-bit**, sample rate gốc cao nhất; không upsample, không bit-pad 16→24; công cụ afconvert, afclip | Production Expert; Apple Digital Masters |
| YouTube | Giảm bài to hơn mức tham chiếu, **không tăng bài nhỏ**; tham chiếu thường nêu −14 LUFS (nguồn thứ cấp) | — | Xem "Stats for nerds" để biết mức bị giảm | Production Advice; MeterPlugs |
| Dolby Atmos – Apple Music | — | — | **ADM BWF, 24-bit LPCM, 48 kHz**; khớp chính xác thời lượng bản stereo | Revelator |
| Dolby Atmos – TIDAL | **−18 LKFS** | ≤ −1 dBTP | ADM BWAV ≥48 kHz/24-bit | Revelator |
| **TikTok, Zing MP3, NhacCuaTui** | **Không tìm được tài liệu chính thức** | — | **Hỏi distributor** | — (khoảng trống) |

Apple: chuẩn hoá làm master bị limit nặng nghe **yếu hơn** khi phát.

**[QU] Mục tiêu thực dụng 2026:**

| Thể loại | Integrated LUFS | True peak |
|---|---|---|
| Ballad, bolero | khoảng −14 đến −11 | ≤ −1 dBTP; an toàn −1,5 đến −2 dBTP nếu to hơn −14 LUFS |
| EDM, rap | khoảng −10 đến −8 | ≤ −1,5 đến −2 dBTP |

Nền tảng sẽ hạ bài to xuống → nén quá chỉ mất động, không "to hơn" khi phát.

**[QU] Gói giao nộp:**
- Master stereo WAV/FLAC 24-bit ở sample rate gốc.
- Instrumental; **bản TV/karaoke** (nhạc + bè, bỏ giọng chính — rất cần cho karaoke và sân khấu Việt); acapella.
- Stems (trống, bass, nhạc cụ dân tộc, synth/keys, giọng chính, bè, FX) cùng điểm bắt đầu, cùng độ dài.
- Bản clean nếu có từ ngữ nhạy cảm; đoạn hook **15–60 giây** cho TikTok, Reels, Shorts.
- Metadata: ISRC mỗi bản thu, UPC mỗi release; tên bài có dấu chuẩn **Unicode NFC**; tác giả nhạc và lời; producer; người phối; nhạc công dân tộc/nghệ nhân; ca sĩ chính và featuring; năm (P)/(C); ngôn ngữ; cờ explicit; lời bài hát; khai báo AI (xem `17-phap-ly-phat-hanh.md`).
- [Cần kiểm chứng] Ảnh bìa thường vuông, khoảng 3000×3000 px — chưa kiểm chứng, hỏi distributor.

## 16.6. Thư viện mẫu Việt và AI: dùng cho demo, thay người thật ở bản cuối

**[BC] Thư viện mẫu đã xác minh:**

| Sản phẩm | Nội dung | Định dạng, giá (tại thời điểm nguồn) | Nguồn |
|---|---|---|---|
| Dan Bau – Bolder Sounds | 5 round-robin mỗi phím; dây buông C1–B1, bồi âm C2–C5; pickup + micro; 2 chế độ pitch bend; script vibrato | Kontakt 5, $59,95 | KVR |
| Dan Tranh – Bolder Sounds | Layout Pentatonic, Chromatic, Keyboard; ngũ cung trên phím đen để vuốt glissando; tremolo, vibrato; keyswitch | Kontakt 4/5, $59,95 | KVR |
| Ha Noi – MNTRA | Giọng ca trù; tranh, nhị, bầu điện, đàn đáy; trống ban, trống chèo; T'rưng; sáo mèo, sáo bầu, tiêu, sáo trúc; âm thanh môi trường Hà Nội, Ninh Bình | VST3/AU/AAX, $59 | Plugin Boutique |
| T'rưng – Bunker Samples (02/2026) | Thu tại Zebra Studios Hà Nội; 2.370 mẫu; 3,5 quãng 8 chromatic; 4 lớp lực × 4 round-robin; 3 vị trí micro; Vietnam Bundle thêm đàn đá | Kontakt 6+, $39 | rekkerd.org |

**[QU]** Nhạc cụ ảo hợp cho demo, tiền kỳ, lớp nền. Độc tấu đàn bầu, sáo, đàn nhị (nơi luyến và nhấn vi cung là bản sắc) → thay nghệ nhân thật ở bản cuối. Layout Chromatic/Keyboard và pitch bend của Kontakt dựa trên 12 bình quân → không tái tạo tự nhiên bậc 166 cent.

**[BC] AI tạo nhạc (bối cảnh, cần kiểm tra lại – cập nhật 11/2026):**
- UMG dàn xếp với Udio 10/2025; WMG dàn xếp và ký cấp phép với Udio 19/11/2025. Udio chuyển sang mô hình "walled garden" (nghe, tuỳ biến trong nền tảng, không xuất file tự do) (Music Business Worldwide; Digital Music News).
- WMG dàn xếp với Suno khoảng 25/11/2025; Suno cam kết mô hình được cấp phép năm 2026 và hạn chế tải xuống (GIGAZINE). Bài blog Suno 10/08/2026: bài tải từ gói trả phí được dùng thương mại; từ 03/09/2026 giới hạn tải: Free 7 lượt trọn đời, Pro 20/tháng, Premier 60/tháng (Suno blog). Điều khoản Suno nói công ty không bảo đảm đầu ra có quyền tác giả (Dubspot). Sony vẫn kiện Suno theo nguồn này. Chi tiết cập nhật: `08-cong-cu-ai.md`.

**[QU] Vai trò của AI trong sản xuất:** phác thảo không khí, thử tông và BPM, làm guide cho ca sĩ và nhạc công. Sản xuất lại bằng người thật hoặc công cụ có bản quyền rõ trước khi phát hành. Lưu toàn bộ nhật ký sáng tác (NĐ 134/2026 yêu cầu chứng minh đóng góp sáng tạo của con người – `17-phap-ly-phat-hanh.md`). Ghi rõ phần nào sẽ được thay bằng người thật (Phụ lục C19).

## 16.7. Khi dùng bản Suno/AI làm bản thương mại [QU]

Áp dụng khi người dùng quyết định phát hành chính bản thu do AI tạo (không sản xuất lại). Điều kiện tiên quyết: tải từ **gói trả phí** của công cụ cho phép dùng thương mại (`08-cong-cu-ai.md`).

| # | Bước kiểm | Cách làm | Đạt khi |
|---|---|---|---|
| 1 | Tải bản chất lượng cao nhất gói cho phép | Chọn định dạng không nén (WAV) nếu gói có; nếu chỉ có MP3 thì ghi rõ giới hạn chất lượng vào gói bàn giao. Lượt tải có giới hạn → chỉ tải bản đã chọn cuối cùng | Có file gốc chất lượng cao nhất, lưu kèm ngày tải và gói tài khoản |
| 2 | Kiểm lời bằng chép lời âm thanh | Chạy công cụ chép lời âm thanh (speech-to-text) trên bản thu; so từng dòng với lời gốc | Không thiếu, thừa, đảo câu; mọi chỗ sai được đánh dấu theo giây |
| 3 | Nghe lỗi phát âm tiếng Việt và thanh | Nghe riêng từng câu, nhất là chữ hỏi, ngã, nặng; chữ then chốt (cặp tối thiểu T4); âm cuối -p, -t, -c, -ch; phụ âm x/s, ch/tr, d/gi/r theo phương ngữ đã chọn. Chạy lại T1–T8 trên bản thu | Không có chữ bị đổi thanh làm đổi nghĩa; dưới khoảng 10% cặp ngược hướng (T1–T3) |
| 4 | Cân nhắc thu lại giọng người thật | Nếu bước 2–3 còn lỗi ở chữ then chốt, hoặc giọng AI nghe "máy", dùng bản AI làm nhạc nền và thu lại giọng chính bằng ca sĩ thật (tách stem nếu công cụ cho phép), rồi biên tập theo 16.3 | Giọng chính không còn lỗi nghĩa; đồng thời tăng đóng góp sáng tạo của con người (lợi cho quyền tác giả – `17-phap-ly-phat-hanh.md`) |
| 5 | Master lại theo bảng thông số | Đo integrated LUFS, true peak theo 16.5; master lại (EQ khe 1–4 kHz cho lời, limit ≤ −1 dBTP); xuất WAV/FLAC 24-bit theo yêu cầu nền tảng; không upsample file gốc chất lượng thấp rồi khai là hi-res | Đạt bảng 16.5 cho nền tảng đích |
| 6 | Gắn nhãn, lưu nhật ký | Khai báo AI ở metadata và mô tả; lưu prompt, các phiên bản, quyết định chọn bản vào nhật ký sáng tạo | Theo danh sách H–I trong `17-phap-ly-phat-hanh.md` |

## Danh sách kiểm tra sản xuất (Phụ lục C–G)

**C. Tiền kỳ**
14. Đo âm vực và tessitura của ca sĩ thật; chọn tông theo năm bước; bài thiếu nhi chọn tông theo trẻ.
15. Thử tông với nhạc cụ dân tộc trước khi chốt.
16. Chốt BPM và grid; đánh dấu các đoạn rubato.
16b. Chạy bộ kiểm tra chọn nhạc cụ I1–I10 (`15-nhac-cu-viet.md`).
17. Hoàn thiện lead sheet, arrangement map, guide audio, guide vocal có luyến láy.
18. Thống nhất 2–3 reference track.
19. Nếu dùng AI hoặc thư viện mẫu cho demo, ghi rõ phần nào sẽ thay bằng người thật.

**D. Thu âm**
20. Thu 24-bit ở 44,1 hoặc 48 kHz; giữ nguyên sample rate suốt dự án.
21. Chọn chiến lược cao độ: nhạc cụ theo synth (dây buông A440) hoặc synth theo nhạc cụ.
22. Đàn bầu: DI pickup + micro. Đàn tranh: micro ngang đầu người chơi, có thể thêm micro dưới gầm, kiểm tra pha.
23. Thu song lang và phách thành track riêng.
24. Giọng: 3–6 take toàn bài và punch-in câu khó.

**E. Biên tập giọng**
25. Comp theo câu, không cắt giữa âm tiết.
26. Chỉnh cao độ thủ công, tắt snapping, Pitch Drift gần 0% cho giọng chính; không lượng tử hoá luyến láy.
27. Nghe lại riêng chữ hỏi, ngã, nặng sau khi chỉnh; chạy lại T2–T6 trên bản đã chỉnh.

**F. Mix**
28. Dành dải 1–4 kHz cho giọng; cắt nhạc nền 5–10 dB ở dải này khi cần.
29. De-esser không ăn mất x, s, ch, tr, th; nén giữ transient phụ âm đầu.
30. Kiểm tra va chạm giữa nhạc cụ dân tộc và pad/synth ở đoạn độc tấu.
31. Nghe thử trên loa điện thoại, tai nghe, loa xe, loa karaoke.

**G. Master và giao nộp**
32. Đo integrated LUFS theo ITU-R BS.1770; so với −14 (Spotify, YouTube) và −16 (Apple).
33. True peak ≤ −1 dBTP, hoặc ≤ −2 dBTP nếu master to hơn −14 LUFS.
34. Chạy afclip, kiểm tra file AAC đã mã hoá không bị clip.
35. Với album, kiểm tra chênh lệch âm lượng giữa các bài.
36. Xuất master FLAC hoặc WAV PCM (không EXTENSIBLE), 24-bit gốc, không upsample.
37. Xuất instrumental, bản TV/karaoke, acapella, stems, bản clean, đoạn hook 15–60 giây.
38. Nếu làm Atmos: ADM BWF 24-bit/48 kHz, khớp thời lượng bản stereo.
