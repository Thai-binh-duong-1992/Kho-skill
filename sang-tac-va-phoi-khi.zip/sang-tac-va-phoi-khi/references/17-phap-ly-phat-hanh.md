> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Pháp lý và phát hành âm nhạc tại Việt Nam, cập nhật 2026. Nhãn: [BC] có bằng chứng; [QU] quy ước thực hành hoặc suy luận; [Cần kiểm chứng] phải đối chiếu toàn văn (vbpl.vn, congbao.chinhphu.vn).

> ⚠️ **Không phải tư vấn pháp lý; xác nhận với luật sư hoặc Cục Bản quyền tác giả trước khi phát hành thương mại. Skill chỉ ghi phần này vào tài liệu đầu ra, không làm gián đoạn sáng tác.**
>
> Nhiều văn bản gốc không truy cập được trực tiếp; thông tin lấy qua bài phân tích của công ty luật và báo chí. Mọi mục [Cần kiểm chứng] phải đối chiếu trước khi ký hợp đồng, đăng ký hoặc phát hành thương mại.

# Pháp lý và phát hành tại Việt Nam (2026)

Cách dùng trong skill: khi người dùng phát hành, cover, phổ thơ, dùng dân ca, sample hoặc AI → đưa các mục liên quan vào gói bàn giao (`assets/mau-goi-ban-giao.md`) mục 9 "Hướng dẫn sản xuất – phát hành" (theo `assets/mau-huong-dan-phat-hanh.md`) và mục 11 "Bản quyền và ghi công". Quy tắc đạo đức sáng tác: `09-ban-quyen.md`. Thông số kỹ thuật giao nộp: `16-san-xuat.md`.

## 17.1. Năm văn bản 2025–2026 thay đổi luật chơi [BC]

| Văn bản | Hiệu lực | Điểm chính cho người làm nhạc | Nguồn |
|---|---|---|---|
| **Luật 131/2025/QH15** sửa đổi Luật SHTT (thông qua 10/12/2025) | **01/4/2026** | Cho dùng tác phẩm đã công bố để huấn luyện AI nếu không ảnh hưởng bất hợp lý đến quyền tác giả; giao Chính phủ quy định quyền với sản phẩm tạo bằng AI; biện pháp buộc gỡ, ẩn, vô hiệu hoá nội dung/tài khoản vi phạm (khoản 7 Điều 202); trách nhiệm nền tảng số và trung gian (Điều 198b); dùng quyền SHTT góp vốn, thế chấp (Điều 8a) | Luật Việt An; Thư viện Pháp luật |
| **Nghị định 134/2026/NĐ-CP** sửa NĐ 17/2023 (ban hành 06/4/2026) | **09/4/2026** | Quyền với sản phẩm có dùng AI; điều kiện dùng dữ liệu cho AI và cơ chế opt-out; thủ tục đăng ký; cơ sở dữ liệu quyền tác giả; tổ chức đại diện tập thể; phân chia tiền bản quyền khi các bên không thoả thuận được | lsvn.vn; HCC Nghệ An |
| **Luật Trí tuệ nhân tạo 134/2025/QH15** (10/12/2025) | **01/3/2026** | Gắn nhãn nội dung do AI tạo; nhãn dễ nhận biết khi mô phỏng giọng nói hoặc ngoại hình người thật; cấm tẩy xoá nhãn | Hệ thống pháp luật; Apolat Legal |
| **Nghị định 341/2025/NĐ-CP** xử phạt VPHC về quyền tác giả, quyền liên quan | **15/02/2026** | Thay NĐ 131/2013; 35 hành vi vi phạm; mức phạt chung 1–250 triệu đồng; vô hiệu hoá phương tiện truyền tải với vi phạm trên mạng | Piracy Monitor |
| **Luật Thuế TNCN 109/2025/QH15** | **01/7/2026** | Tiền bản quyền chịu **5%** trên phần **vượt 20 triệu đồng mỗi hợp đồng** (trước đây 10 triệu) | Hệ thống pháp luật – Điều 16; EY Tax Alert |

Bộ VHTTDL ban hành văn bản hợp nhất số 6154/VBHN-BVHTTDL tháng 9/2026, nhiều khả năng hợp nhất NĐ 17/2023 và 134/2026 — [Cần kiểm chứng nội dung] (chinhphu.vn).

## 17.2. Ba tầng quyền trên một bài hát đã thu âm

**[BC]**
- Quyền tác giả **phát sinh tự động** khi tác phẩm được thể hiện dưới hình thức vật chất; không cần đăng ký.
- Tác phẩm âm nhạc bảo hộ **suốt đời tác giả + 50 năm**; đồng tác giả tính theo người mất cuối cùng; hết hạn lúc 24 giờ ngày 31/12 năm cuối.
- Quyền nhân thân không chuyển giao được bảo hộ vô thời hạn; quan trọng nhất là quyền bảo vệ sự toàn vẹn tác phẩm (Luật Việt An).
- Điều 34 Luật SHTT: quyền **người biểu diễn** 50 năm từ năm tiếp theo năm định hình cuộc biểu diễn; quyền **nhà sản xuất bản ghi âm** 50 năm từ năm tiếp theo năm công bố (hoặc năm định hình nếu chưa công bố).

**[QU] Ba tầng phải giải quyết đủ khi phát hành:**

| Tầng | Chủ thể | Giấy tờ cần |
|---|---|---|
| 1. Quyền tác giả | Người viết nhạc, lời (kể cả nhà thơ nếu phổ thơ) | Split sheet; thoả thuận đồng tác giả; văn bản cho phép nếu là tác phẩm phái sinh |
| 2. Quyền người biểu diễn | Ca sĩ, nhạc công, nghệ nhân | Hợp đồng chuyển nhượng/cấp phép quyền biểu diễn |
| 3. Quyền nhà sản xuất bản ghi âm | Người bỏ tiền và tổ chức thu | Hợp đồng sản xuất; quyền với beat, sample |

Vì quyền phát sinh tự động → lưu bằng chứng thời điểm sáng tác: file demo có metadata, bản nháp có ngày, lịch sử dự án DAW, nhật ký sáng tạo.

[Cần kiểm chứng] Danh mục quyền nhân thân (đặt tên, đứng tên, công bố, bảo vệ toàn vẹn) và quyền tài sản (làm tác phẩm phái sinh, biểu diễn, sao chép, phân phối, phát sóng và truyền đạt, cho thuê) đến từ kiến thức nền, chưa trích được toàn văn Điều 19–20.

## 17.3. Đăng ký tại Cục Bản quyền tác giả

**[BC]** Đăng ký **tự nguyện**, nhưng tạo chứng cứ ban đầu khi tranh chấp.

| Mục | Nội dung |
|---|---|
| Hồ sơ | Tờ khai có chữ ký/điểm chỉ; **02 bản sao tác phẩm + 01 bản điện tử**; giấy uỷ quyền (nếu qua đại diện); giấy tờ tuỳ thân hoặc ĐKDN; giấy tờ chứng minh quyền sở hữu (nếu có); văn bản cam đoan nếu tác giả không đồng thời là chủ sở hữu; **văn bản đồng ý của đồng tác giả**; bản dịch tiếng Việt cho tài liệu nước ngoài |
| Thời hạn | Xem xét trong 01 tháng; cấp Giấy chứng nhận trong **15 ngày làm việc** nếu hợp lệ; thực tế thường 1–2 tháng |
| Nơi nộp | Cục Bản quyền tác giả (Hà Nội) hoặc văn phòng đại diện TP.HCM, Đà Nẵng |
| Lệ phí | Theo Thông tư 211/2016/TT-BTC |
| Thủ tục mới | NĐ 134/2026 quy định lại thủ tục đăng ký (lsvn.vn) |
| Tác phẩm có dùng AI | Kê khai trung thực nếu được yêu cầu; chứng minh đóng góp sáng tạo của con người bằng **prompt, lịch sử tương tác, bản nháp, thông số kỹ thuật** (Luật Việt An – AI) |

[Cần kiểm chứng]:
- Tên đơn vị hành chính trong địa chỉ có thể đã đổi sau sắp xếp địa giới 2025; có thể đã có kênh nộp trực tuyến.
- Mức phí theo kiến thức nền: 100.000 đồng (tác phẩm âm nhạc), 200.000 đồng (bản ghi âm, ghi hình); chưa rõ 2026 có thông tư mới không.
- Giá trị chứng cứ của giấy chứng nhận theo Điều 49 Luật SHTT chưa trích được nguồn.

[QU] Một bài đã thu âm có thể đăng ký **hai giấy chứng nhận**: tác phẩm âm nhạc (nhạc sĩ) và bản ghi âm (nhà sản xuất).

## 17.4. Quản lý tập thể: VCPMC thu phần tác giả, distributor không thu

**[BC]**
- VCPMC năm 2025 thu **hơn 424,3 tỷ đồng** (+8% so với 2024); **7.207 tác giả uỷ quyền**; thoả thuận với 92 tổ chức nước ngoài phủ 163 quốc gia/vùng lãnh thổ; phân phối 4 kỳ/năm theo chuẩn CISAC; đã phân phối khoảng 269 tỷ đồng trong năm (Báo Văn hoá).
- Thu nhạc nền quán xá, nhà hàng còn vi phạm nhiều; truyền hình trả tiền chậm thanh toán, đang tranh chấp tại toà.
- VCPMC **chỉ thu phí với tác phẩm của tác giả đã uỷ quyền** (Đại Đoàn Kết).
- NĐ 134/2026 cho phép tổ chức đại diện tập thể **tuyên bố bảo lưu quyền, không cho dùng tác phẩm để huấn luyện AI** (opt-out).

**[QU]** Distributor quốc tế chỉ trả phần **bản ghi âm**, không thu phần **tác giả**. Bài được hát trong show, phát sóng, vào karaoke, làm nhạc nền → cân nhắc uỷ thác cho VCPMC; có thể nhờ VCPMC tuyên bố opt-out AI.

[Cần kiểm chứng] Thủ tục uỷ thác; tỷ lệ phí quản lý; VCPMC có thu từ YouTube, Spotify, TikTok không; vai trò RIAV với quyền nhà sản xuất; tổ chức đại diện quyền người biểu diễn.

## 17.5. Không cần xin phép phổ biến, nhưng nội dung vẫn bị hậu kiểm

**[BC]** **NĐ 144/2020/NĐ-CP** (hiệu lực 01/02/2021, thay NĐ 79/2012) **bỏ cơ chế cấp phép phổ biến tác phẩm âm nhạc**, kể cả yêu cầu riêng với ca khúc trước 1975 ở miền Nam và tác phẩm của người Việt ở nước ngoài.

**Điều 3 – nội dung bị cấm** (rà lời theo danh sách này, Phụ lục B13):
1. Chống Nhà nước.
2. Xuyên tạc lịch sử, chủ quyền.
3. Xúc phạm lãnh tụ, anh hùng dân tộc.
4. Gây chia rẽ dân tộc, xúc phạm tôn giáo.
5. Kích động bạo lực, gây hận thù.
6. Trang phục, ngôn ngữ, âm thanh, hình ảnh trái thuần phong mỹ tục.

- Chương trình **biểu diễn** vẫn cần văn bản chấp thuận của Bộ VHTTDL hoặc UBND cấp tỉnh tuỳ loại, và thông báo UBND nơi biểu diễn.
- Tiền lệ hậu kiểm: năm 2019 Cục Nghệ thuật biểu diễn xin lỗi và huỷ lệnh dừng lưu hành 5 ca khúc trước 1975 vì không đủ căn cứ (Báo Pháp luật) → nguy cơ hậu kiểm là có thật.

[Cần kiểm chứng] NĐ 144/2020 đã được sửa đổi/thay thế đến 2026 chưa; nghị định xử phạt hành chính hiện hành trong lĩnh vực nghệ thuật biểu diễn.

## 17.6. Dân ca, cover, sample: ba mức xin phép

**[BC]**
- Điều 23 Luật SHTT quy định quyền tác giả với tác phẩm văn học, nghệ thuật dân gian.
- Giới nhạc sĩ cho rằng cover bất kỳ ca khúc nào không xin phép đều sai, kể cả không vì lợi nhuận. Vụ *Độ ta không độ nàng*: bên nắm quyền yêu cầu người cover gỡ bài hoặc trả 5 triệu đồng + 33% doanh thu (SGGP). Một số nghệ sĩ nhận xét VCPMC khó quản lý chặt cover.
- Nhạc ngoại đặt lời Việt không xin phép = **tác phẩm phái sinh trái phép**.
- NĐ 341/2025: phạt chung 1–250 triệu đồng. NĐ 131/2013 trước đây: tối đa 250 triệu (cá nhân), 500 triệu (tổ chức).

[Cần kiểm chứng] Theo kiến thức nền, dùng dân ca không phải xin phép nhưng phải dẫn chiếu xuất xứ và bảo đảm giá trị đích thực — chưa đối chiếu toàn văn. Mức phạt cụ thể của NĐ 341/2025 cho từng hành vi xâm phạm tác phẩm âm nhạc chưa tra được.

**[QU] Ba mức:**

| Chất liệu | Phải làm | Ghi danh |
|---|---|---|
| **Dân ca không rõ tác giả** | Dùng làn điệu/lời gốc, tự phối mới; không sao chép bản phối hay bản thu của nghệ sĩ khác; không xuyên tạc. Bản phối mới là tác phẩm phái sinh người phối có thể đăng ký | "Dân ca [vùng]" + tên người phối |
| **Cover** | Xin phép tác giả trực tiếp hoặc qua VCPMC; đổi lời hoặc đổi phối → cần thêm đồng ý làm tác phẩm phái sinh. Giấy phép mechanical (luật Hoa Kỳ) distributor bán **không thay** được sự cho phép theo luật Việt Nam với tác phẩm Việt | Tên tác giả gốc |
| **Sample, remix** | Xin phép **cả** tác giả **lẫn** nhà sản xuất bản ghi âm; kiểm tra beat mua độc quyền hay không | Theo license |

## 17.7. Phổ thơ: tác phẩm phái sinh, xin phép nhà thơ

**[BC]**
- Luật SHTT 2005, Điều 4 khoản 8: **tác phẩm phái sinh** gồm dịch, phóng tác, cải biên, chuyển thể, biên soạn, chú giải, tuyển chọn.
- Điều 14 + NĐ 22/2018: tác phẩm phái sinh được bảo hộ khi (1) không phương hại quyền tác giả tác phẩm gốc, (2) được chủ thể quyền cho phép, (3) có tính sáng tạo. **Làm phái sinh không xin phép là xâm phạm (Điều 28)** → thoả thuận bằng văn bản.
- Luật sửa đổi 2022 (Luật 07/2022/QH15) và 2025 (Luật 131/2025). Thời hạn suốt đời + 50 năm → nhà thơ đã mất trong thời hạn thì xin phép **người thừa kế**.
- Thực tiễn còn tranh luận (hội thảo 2024, Báo Văn hoá): tên nhà thơ có đứng trước nhạc sĩ; trích bao nhiêu thì ghi "phỏng thơ", "trích thơ", "ý thơ"; nhạc sĩ có được sửa lời thơ không hỏi nhà thơ.
- SGGP: trong một đợt Giải thưởng Nhà nước, 10/15 nhạc sĩ được giải nhờ tác phẩm phổ thơ; nhà thơ Lê Thiếu Nhơn coi ghi rõ tên tác giả là "điều bắt buộc".
- Thơ có giá thị trường: 2004 một công ty đầu karaoke trả 100 triệu đồng cho *Màu tím hoa sim*; 2013 MASECO trả 300 triệu đồng cho *Ở hai đầu nỗi nhớ*. Phú Quang ghi nguồn và trả thù lao ngay cả khi chỉ mượn một ý thơ.

**[QU] Quy trình an toàn 4 bước:**
1. Xin phép bằng văn bản nhà thơ (hoặc người thừa kế).
2. Thoả thuận phạm vi sửa lời và cách ghi danh ("Thơ: …", "Ý thơ: …").
3. Thoả thuận chia nhuận bút, kể cả phần thu qua VCPMC.
4. Lưu thoả thuận để đăng ký (17.3), uỷ thác VCPMC (17.4); ghi đồng tác giả lời vào split sheet (17.10).

Ca dao không rõ tác giả → chế độ tác phẩm dân gian (17.6).

[Cần kiểm chứng] (1) Chưa có nguồn pháp lý nêu rõ bài phổ thơ là "tác phẩm phái sinh" hay "tác phẩm âm nhạc có lời trích từ tác phẩm văn học". (2) Chưa đọc toàn văn Điều 20 (quyền làm phái sinh) và Điều 25 (ngoại lệ không phải xin phép). (3) Số điều theo bản 2005/2022 chưa đối chiếu với Luật 131/2025. (4) Chưa rõ các nhạc sĩ phổ *Màu tím hoa sim* trước 1975 có xin phép Hữu Loan không. Hỏi luật sư hoặc Cục Bản quyền tác giả trước khi phát hành thương mại một bài phổ thơ.

## 17.8. Nhạc có dùng AI: con người phải có đóng góp quyết định

**[BC] NĐ 134/2026 bổ sung Điều 5a vào NĐ 17/2023:** tác giả phải là con người; AI chỉ là công cụ. Quyền chỉ phát sinh khi đủ **3 điều kiện**:
1. Con người có đóng góp sáng tạo **đáng kể và mang tính quyết định** (viết prompt, đánh giá, chỉnh sửa, sắp xếp, ra quyết định cuối cùng).
2. Con người chịu trách nhiệm pháp lý.
3. Dữ liệu đầu vào không xâm phạm quyền người khác.

Sản phẩm do AI tạo hoàn toàn → **không phát sinh quyền**. Áp dụng cho tác phẩm, bản ghi âm, chương trình phát sóng (Luật Việt An – AI).

**[BC] Huấn luyện AI:** tác phẩm chỉ được dùng cho nghiên cứu, thử nghiệm, huấn luyện không nhằm thương mại; đầu ra không thay thế thị trường tác phẩm gốc; chủ thể quyền được opt-out bằng thông tin máy đọc được, biện pháp kỹ thuật hoặc qua tổ chức đại diện tập thể.

**[BC] Luật Trí tuệ nhân tạo 134/2025/QH15 – gắn nhãn:**

| Quy định | Nội dung |
|---|---|
| Điều 11 khoản 2 | Âm thanh, hình ảnh, video do AI tạo phải được đánh dấu ở định dạng máy đọc |
| Điều 11 khoản 3 | Thông báo rõ khi nội dung có thể gây nhầm lẫn về tính xác thực |
| Điều 11 khoản 4 | Nhãn dễ nhận biết với nội dung mô phỏng giọng nói/ngoại hình người thật; cách gắn nhãn phù hợp cho tác phẩm nghệ thuật |
| Điều 7 khoản 5 | Cấm tẩy xoá nhãn |

[Cần kiểm chứng] Chưa đọc toàn văn Điều 5a; chưa có văn bản hướng dẫn kỹ thuật gắn nhãn; chưa rõ ghi "có sử dụng AI" trong mô tả bài đã đủ chưa.

**[BC] Chính sách nền tảng** (theo một nguồn thứ cấp – Jack Righteous):

| Nền tảng | Chính sách nhạc AI |
|---|---|
| DistroKid | Nhận nếu người phát hành có đủ quyền và không mạo danh giọng; có mục khai báo AI |
| Spotify | Không cấm; xử lý mạo danh và spam |
| Apple Music | Có trường metadata "AI Transparency" |
| Deezer | Gắn nhãn nhạc AI hoàn toàn, loại khỏi gợi ý |
| YouTube Content ID | Đòi quyền độc quyền với nội dung tham chiếu |

**[QU] Hệ quả thực hành:**
- Bài chỉ có prompt + một lần bấm tạo nhiều khả năng **không được bảo hộ** ở Việt Nam; người dùng vẫn khai thác theo hợp đồng với nền tảng nhưng khó ngăn người khác sao chép.
- **Không dùng giọng AI mô phỏng ca sĩ thật**: vừa phải gắn nhãn, vừa có nguy cơ xâm phạm quyền nhân thân.
- **Gắn nhãn âm thanh AI** ở metadata (trường khai báo AI của distributor) và trong mô tả bài.
- **Giữ nhật ký sáng tạo**: ngày tháng, mọi bản nháp lời, giai điệu, quyết định chọn/sửa, **toàn bộ prompt** (style, lyrics, exclude), các phiên bản AI đã tạo, lý do chọn bản cuối, phần đã thay bằng người thật. Đây là bằng chứng đóng góp của con người theo NĐ 134/2026.
- Điều khoản và giới hạn tải của từng công cụ AI: `08-cong-cu-ai.md`.

## 17.9. Phân phối: YouTube và Zing MP3 quan trọng hơn Spotify

**[BC]** Decision Lab quý 1/2024, thị phần nghe nhạc tại Việt Nam: **YouTube 77%, Zing MP3 52%, NhacCuaTui 32%, Spotify 28%**; Zing MP3 phủ hơn 90% nhạc Việt (InterSpace). ⚠️ Độ tin cậy nguồn: đây là blog của một distributor, có tính tự quảng bá → cần đối chiếu.

- Distributor được nêu: DistroKid, TuneCore, Amuse, Ditto, CD Baby, InterSpace (tự giới thiệu có giao Zing MP3 và NhacCuaTui), Virgin Music Group Vietnam (liên doanh với The Metub).
- Spotify có danh mục nhà cung cấp phân phối được uỷ quyền bằng tiếng Việt (Spotify for Artists).
- IFPI công bố danh sách cơ quan ISRC quốc gia. [Cần kiểm chứng] Chưa xác định Việt Nam có cơ quan nào trong danh sách.

**[QU] Lộ trình:**
1. Chọn distributor **xác nhận được** việc giao bài đến **Zing MP3 và NhacCuaTui** (không chỉ Spotify/Apple). Hỏi trực tiếp, lưu xác nhận.
2. Để distributor cấp **ISRC** cho mỗi bản thu và **UPC** cho mỗi release.
3. Chỉ đăng ký **Content ID** khi bản thu độc quyền, không chứa sample/beat không độc quyền, không phải nhạc AI hoàn toàn.
4. Uỷ thác phần tác giả cho VCPMC.

## 17.10. Split sheet, hợp đồng, thuế

**[QU] Split sheet** — ký **trước khi phát hành**:

| Trường | Ghi |
|---|---|
| Tên bài | Có dấu chuẩn Unicode NFC |
| Người góp phần | Từng người: nhạc, lời, phối (kể cả nhà thơ nếu phổ thơ) |
| Tỷ lệ quyền tác giả | % mỗi người |
| Tỷ lệ doanh thu master | % mỗi bên |
| Mã IPI | Nếu có |
| Người được uỷ quyền đăng ký | Tên |
| Chữ ký, ngày | Mọi bên |

Hồ sơ đăng ký đã yêu cầu văn bản đồng ý của đồng tác giả (Luật Việt An) → split sheet cũng là chứng từ cho bước này.

**[QU] Hợp đồng cần có:**
- Với **ca sĩ**: chuyển nhượng hoặc cấp phép quyền người biểu diễn; thù lao; chia doanh thu; quyền dùng tên, hình ảnh.
- Với **producer**: làm thuê hay đồng tác giả; quyền với beat; độc quyền hay không.
- Với **nhạc công phiên thu, nghệ nhân**: chuyển giao quyền người biểu diễn.

[Cần kiểm chứng] Theo kiến thức nền, hợp đồng chuyển nhượng quyền phải lập thành văn bản (Điều 46–48 Luật SHTT). Chưa tìm được mẫu split sheet hay hợp đồng theo chuẩn Việt Nam.

**[BC] Thuế** (từ 01/7/2026, Điều 16 Luật Thuế TNCN 109/2025/QH15):
- Thu nhập tính thuế từ tiền bản quyền của cá nhân cư trú = **phần vượt 20 triệu đồng** nhận theo **từng hợp đồng**; thuế suất **5%**; tính tại thời điểm trả thu nhập.
- Cá nhân không cư trú cũng 5% trên phần vượt 20 triệu đồng.
- Ngưỡng cũ: 10 triệu đồng.
- Trang tổng hợp ghi trạng thái hiệu lực "Kiểm tra" → đối chiếu nguồn chính thức.

[Cần kiểm chứng] Cách khai thuế tiền nhận từ distributor nước ngoài; tiền stream xếp là tiền bản quyền hay thu nhập kinh doanh.

[QU] Tổ chức trong nước như VCPMC khấu trừ tại nguồn; tiền từ distributor nước ngoài có thể phải tự khai → hỏi cơ quan thuế.

## Danh sách kiểm tra pháp lý – phát hành (Phụ lục H và I)

**H. Pháp lý**

39. Ký split sheet với mọi người góp phần nhạc, lời, phối (17.10). Bài phổ thơ: ghi nhà thơ là tác giả lời hoặc ghi "Ý thơ", kèm thoả thuận nhuận bút và danh sách chỗ đã sửa lời (17.7, V16).
40. Ký hợp đồng bằng văn bản với ca sĩ, producer, nhạc công, nghệ nhân (17.10).
41. Rà soát chất liệu bên thứ ba: dân ca (ghi xuất xứ, không dùng bản phối/bản thu của người khác); cover và lời Việt cho nhạc ngoại (xin phép tác giả hoặc VCPMC); sample và beat (license, độc quyền hay không) (17.6).
42. Nếu có dùng AI: dùng gói trả phí; không mô phỏng giọng người thật; gắn nhãn theo Luật 134/2025/QH15; lưu bằng chứng đóng góp của con người theo NĐ 134/2026 (17.8).
43. Cân nhắc đăng ký tác phẩm âm nhạc và bản ghi âm tại Cục Bản quyền tác giả (17.3).
44. Cân nhắc uỷ thác phần tác giả cho VCPMC, kể cả tuyên bố opt-out AI (17.4).
45. Nếu tổ chức biểu diễn ra mắt, xin văn bản chấp thuận hoặc thông báo theo NĐ 144/2020 (17.5).

**I. Phát hành**

46. Chọn distributor xác nhận được việc giao đến YouTube Music, Zing MP3 và NhacCuaTui (17.9).
47. Nhận ISRC cho mỗi bản thu và UPC cho mỗi release.
48. Điền metadata: tên bài có dấu chuẩn Unicode NFC, tác giả nhạc và lời, producer, người phối, nhạc công dân tộc, ngôn ngữ, explicit, lời bài hát, khai báo AI.
49. Chỉ đăng ký Content ID khi bản thu độc quyền và không phải nhạc AI hoàn toàn.
50. Phát hành lyric sheet chuẩn kèm bản thu để hạn chế hát sai lời (N9).
51. Lưu chứng từ thu nhập; tiền bản quyền chịu 5% trên phần vượt 20 triệu đồng mỗi hợp đồng từ 01/7/2026 (17.10).
52. Đối chiếu mọi mục [Cần kiểm chứng] với Cục Bản quyền tác giả hoặc luật sư trước khi phát hành thương mại.

Liên quan từ giai đoạn trước: A4 (mở nhật ký sáng tạo từ đầu, lưu mọi bản nháp, demo, prompt AI); B5 (có văn bản cho phép của nhà thơ trước khi viết nếu dùng thơ người khác); B13 (rà lời theo Điều 3 NĐ 144/2020).
