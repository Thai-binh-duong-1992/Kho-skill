> Tệp tra cứu của skill sang-tac-va-phoi-khi 2.0. Ranh giới đạo đức và bản quyền khi sáng tác (mọi thể loại, mọi ngôn ngữ). Nhãn: [BC] có bằng chứng; [QU] quy ước thực hành; [Cần kiểm chứng].

# Bản quyền và đạo đức sáng tác

Không phải tư vấn pháp lý; tệp này chỉ đặt ranh giới an toàn cho việc sáng tác. Chi tiết pháp lý và phát hành tại Việt Nam (luật 2025–2026, đăng ký, VCPMC, cover, phổ thơ, AI, phân phối, thuế): `17-phap-ly-phat-hanh.md`. Skill chỉ ghi phần pháp lý vào tài liệu đầu ra, không làm gián đoạn sáng tác.

## 9b.1. Bản quyền và đạo đức sáng tác

- **Chỉ sáng tác nguyên bản:** không chép hoặc phỏng theo lời, câu móc, giai điệu, tiến trình đặc trưng của một bài hát cụ thể còn bản quyền, kể cả bài mẫu người dùng đưa ra. Vòng hợp âm phổ biến và đặc trưng thể loại thì dùng tự do.
- **Không đặt lời mới, chế lời cho giai điệu còn bản quyền:** Claude không viết lời mới trên giai điệu đó; đề xuất sáng tác bài mới cùng tinh thần, hoặc người dùng tự xin phép tác giả. [BC] Ở Việt Nam, nhạc ngoại đặt lời Việt không xin phép là tác phẩm phái sinh trái phép; cover đổi lời hoặc đổi phối cần thêm sự đồng ý làm phái sinh (`17-phap-ly-phat-hanh.md` 17.6).
- **Phổ thơ, dùng thơ của người khác:** ghi vào tài liệu đầu ra (gói bàn giao mục 9 và 11) rằng cần văn bản cho phép của nhà thơ hoặc người thừa kế (thơ còn trong thời hạn bảo hộ: suốt đời + 50 năm) và thoả thuận cách ghi danh ("Thơ: …", "Ý thơ: …"). Claude vẫn hỗ trợ kỹ thuật phổ thơ; ghi lưu ý vào gói bàn giao (17.7, V16).
- **Giai điệu dân gian cổ truyền:** thường thuộc phạm vi công cộng, dùng làm chất liệu được; ghi rõ nguồn ("Dân ca [vùng]") và tên người phối; không sao chép bản phối hay bản thu của nghệ sĩ khác; không xuyên tạc. Bản phối hay lời mới của người khác trên giai điệu đó vẫn có thể còn bản quyền. [Cần kiểm chứng] Nghĩa vụ dẫn chiếu xuất xứ theo Điều 23 Luật SHTT chưa đối chiếu toàn văn.
- **Không bắt chước danh tính nghệ sĩ:** không dùng tên ca sĩ, ban nhạc, bài hát thật trong prompt; không yêu cầu máy giả giọng một ca sĩ thật. [BC] Luật Trí tuệ nhân tạo 134/2025/QH15 bắt buộc gắn nhãn dễ nhận biết với nội dung mô phỏng giọng người thật; việc này còn có nguy cơ xâm phạm quyền nhân thân.
- **Quyền sử dụng bản thu AI:** phụ thuộc điều khoản và gói tài khoản từng công cụ (gói miễn phí thường không được dùng thương mại; ví dụ Suno: lượt tải dùng thử gói Free chỉ dùng cá nhân). Claude ghi vào tài liệu đầu ra (gói bàn giao mục 9) lời nhắc đọc điều khoản hiện hành trước khi phát hành, quảng cáo hoặc đăng lên nền tảng có kiếm tiền. Bảng điều khoản: `08-cong-cu-ai.md` 10.4.
- **Nội dung lời:** khi bài phát hành tại Việt Nam, rà lời theo các nội dung bị cấm tại Điều 3 NĐ 144/2020 (17.5); ghi kết quả vào danh sách kiểm tra, không chặn việc sáng tác.
- **Ghi công:** đề xuất dòng ghi công (lời, nhạc, phối khí, thơ gốc nếu có, công cụ AI) phù hợp mục đích.
- **Khi cần phát hành thương mại:** khuyên người dùng hỏi luật sư sở hữu trí tuệ hoặc Cục Bản quyền tác giả; đưa danh sách kiểm tra H–I (`17-phap-ly-phat-hanh.md`) vào gói bàn giao.

## 9b.2. Quyền tác giả khi có AI

**[BC] Nền pháp lý Việt Nam** (NĐ 134/2026/NĐ-CP, Điều 5a bổ sung vào NĐ 17/2023): tác giả phải là con người; AI chỉ là công cụ. Quyền chỉ phát sinh khi con người có đóng góp sáng tạo **đáng kể và mang tính quyết định**, chịu trách nhiệm pháp lý, và dữ liệu đầu vào không xâm phạm quyền người khác. Sản phẩm do AI tạo hoàn toàn không phát sinh quyền. [Cần kiểm chứng] Chưa đọc được toàn văn Điều 5a.

Claude (một mô hình AI) cũng là "công cụ AI" theo nghĩa này. Skill phân biệt hai chế độ làm việc:

| | **Chế độ cá nhân** (mặc định) | **Chế độ thương mại** |
|---|---|---|
| Khi nào | Bài tặng, sinh hoạt, học tập, demo, không phát hành kiếm tiền | Người dùng nói sẽ phát hành, phân phối, đăng ký bản quyền, kiếm tiền, dùng cho quảng cáo/thương hiệu |
| Vai trò | Claude có thể đề xuất trọn bài (lời, hợp âm, phối) | **Người dùng là tác giả chính**; Claude hỗ trợ: đưa phương án, phân tích, kiểm lỗi theo bộ kiểm tra, gợi ý sửa |
| Quyết định | Claude chủ động chọn, người dùng duyệt | Người dùng ra quyết định cuối ở mỗi điểm sáng tạo then chốt: ý cốt lõi, hình ảnh trung tâm, hook, chọn giữa các phương án lời/giai điệu, cấu trúc, chỉnh sửa cuối |
| Cách Claude làm | Giao bản hoàn chỉnh | Đưa 2–3 phương án có lý do; mời người dùng tự viết/sửa câu then chốt; ghi rõ phần nào người dùng viết, phần nào sửa từ gợi ý |
| Nhật ký sáng tạo | Khuyến khích | **Bắt buộc**: ngày tháng; bản nháp mỗi vòng; quyết định của người dùng và lý do; mọi prompt cho Claude và cho công cụ nhạc AI; các phiên bản AI đã tạo; phần thay bằng người thật. Xuất kèm gói bàn giao |
| Gắn nhãn | Nhắc nếu đăng công khai | Gắn nhãn âm thanh AI theo Luật 134/2025/QH15; khai báo AI ở metadata distributor |

[QU] Chế độ hỏi ở câu 1 của Bước 1 (SKILL.md). Nếu về sau người dùng nhắc tới phát hành, kiếm tiền, đăng ký quyền thì hỏi xác nhận một câu có chuyển sang thương mại không; không giảng giải pháp lý lúc đó. Chi tiết, danh sách kiểm tra và luật liên quan: `17-phap-ly-phat-hanh.md` (17.3, 17.8, H–I).
