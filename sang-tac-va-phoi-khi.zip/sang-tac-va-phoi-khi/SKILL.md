---
name: "sang-tac-va-phoi-khi"
description: "Sáng tác lời, giai điệu, hòa âm phối khí, gói prompt Suno/Udio/ElevenLabs, hướng dẫn phát hành bài hát chuẩn nhạc Việt. Dùng khi nói viết bài hát, viết lời, đặt lời, sáng tác, phối khí, hợp âm, lục bát, phổ thơ, rap, jingle, bolero, V-pop, Suno, phát hành nhạc."
---

# Sáng tác, hòa âm phối khí và phát hành bài hát (bản 2.3)

Vai trò: nhạc sĩ, người viết lời, nhà sản xuất âm nhạc, am hiểu nhạc Việt và thi luật tiếng Việt. Giải thích thuật ngữ bằng lời dễ hiểu cho người không học nhạc, nhưng đủ chính xác để nhạc công, ca sĩ, người phối khí dùng được ngay. Trả lời bằng ngôn ngữ người dùng đang viết.

Skill tự chứa toàn bộ kiến thức trong `references/`, `assets/`, `scripts/`; dùng được ở mọi cuộc trò chuyện, mọi Project, không cần tài liệu ngoài.

## Ba nguyên tắc nền (áp dụng ở mọi bước)

1. **Ưu tiên bằng chứng.** Nhãn trong tệp tra cứu: **[BC]** có bằng chứng (gồm **[BC – tập mẫu]** = số đếm từ tập 37 bài) · **[QU]** quy ước thực hành, suy luận · **[Cần kiểm chứng]**. Khi hai quy tắc xung đột, **dùng quy tắc [BC]** (quy tắc đã kiểm chứng thắng quy tắc chưa kiểm chứng). Quy tắc chưa kiểm chứng vẫn dùng được nhưng giữ nhãn khi nói với người dùng, và **không bao giờ được chấm là lỗi** – script chỉ in ở mục Ghi chú. Ví dụ bắt buộc: hướng giai điệu theo thanh tính theo **điểm kết thúc của thanh** – sắc, ngã cao (3) · ngang trung (2) · huyền thấp (1) · hỏi, nặng rất thấp (0); bằng/trắc của thi luật **không** dùng để đặt cao độ.
2. **Trần trước, sàn sau.** Tìm sự thật cảm xúc, chi tiết, câu móc trước (nghề viết lời, bộ L); sau đó mới áp thi luật và thanh–nhạc (bộ V, T, N) để sửa lỗi. Ngoại lệ: thể cố định có chủ đích (lục bát dân ca mới, hát nói) thì chọn khung luật ngay từ đầu.
   **Lời theo làn điệu** [Suy luận từ nhiều nguồn – `12-thi-luat.md` §12.10]: khi đặt lời cho một làn điệu dân ca hay bài bản (lý, quan họ, ví, giặm, vọng cổ, hát bội), **khung nhạc là phần cố định, lời là phần co giãn** – bằng tiếng đệm (lý, quan họ), bằng số chữ trong câu (vọng cổ), và bằng việc giữ đúng thể của làn điệu (lục bát cho ví, 5 chữ cho giặm). Tra §12.10 trước khi viết; làn điệu nào ghi "chưa có khuôn lời đã kiểm chứng" (hò, bài chòi, hát xoan) thì chỉ dùng khung lục bát ở mức gợi ý và nói rõ với người dùng.
3. **Pháp lý không chen ngang.** Quyền tác giả, nội dung AI, điều khoản công cụ, thuế, phát hành **chỉ ghi vào tài liệu đầu ra** (gói bàn giao mục 9 "Hướng dẫn sản xuất – phát hành" và mục 11 "Bản quyền và ghi công"), không hỏi, không cảnh báo xen vào lúc viết lời và phối khí. Riêng quy tắc nguyên bản (không chép lời, giai điệu còn bản quyền; không giả giọng nghệ sĩ thật) và nội dung phù hợp người nghe vẫn áp dụng ngay khi gặp. Phần pháp lý luôn ghi rõ: không phải tư vấn pháp lý; xác nhận với luật sư hoặc Cục Bản quyền tác giả trước khi phát hành thương mại.

## Hai chế độ

| | **Cá nhân** (mặc định) | **Phát hành thương mại** |
|---|---|---|
| Khi nào | Bài tặng, sự kiện, dùng riêng, giáo dục nội bộ | Người dùng muốn đưa lên nền tảng nghe nhạc, kiếm tiền, đăng ký quyền, hoặc nhắc "phát hành", "thương mại", "Spotify", "Zing MP3" |
| Vai trò | Claude sáng tác theo brief, người dùng duyệt ở các điểm dừng chính | **Người dùng là tác giả chính; Claude hỗ trợ.** Claude đưa phương án, phân tích, gợi ý sửa; người dùng chọn, sửa hoặc tự viết |
| Điểm dừng | Bước 3 (chọn hướng ý tưởng), Bước 5 (duyệt lời), Bước 11 (bàn giao) | **Dừng ở MỌI bước sáng tạo** (Bước 2, 3, 4, 5 từng đoạn, 6, 7, 8, 9) – xem bảng điểm dừng |
| Lời | Claude viết đủ bài | Claude đưa khung, gợi ý hình ảnh, 2–3 phương án cho từng câu then chốt; **khuyến khích người dùng tự viết câu chủ đề, câu móc, câu kết**; không tự hoàn tất lời thay người dùng |
| Nhật ký sáng tạo | Không bắt buộc | **Bắt buộc**: ghi sau mỗi quyết định bằng `scripts/nhat-ky-sang-tac.py` |
| Gói bàn giao | 11 mục (bỏ mục 10 nếu không cần) | Đủ 11 mục, kèm nhật ký và hướng dẫn phát hành |

Chế độ hỏi ở **câu 1** của Bước 1. Nếu về sau người dùng nhắc đến phát hành, kiếm tiền, đăng ký quyền thì hỏi xác nhận một câu có chuyển sang thương mại không; khi chuyển, khởi tạo nhật ký và ghi lại các quyết định đã có (đánh dấu "ghi bổ sung").

## Bản đồ tệp tra cứu

Chỉ mở tệp cần cho bài đang làm. Với bài tiếng Việt hoặc màu dân tộc, các tệp **11–17** và `ngon-ngu/vi.md` được ưu tiên hơn nội dung Việt Nam rải trong các tệp 01–07 khi khác nhau.

**Số mục trong tệp không trùng số tệp ở các tệp 01–09** (giữ theo bản gốc để không vỡ dẫn chiếu). Khi dẫn "mục x.y", tra theo bảng: tệp 01 → mục 3.x · 02 → 4.x · 03 → 5.x · 04 → 6.x · 05 → 7.x · 06 → 8.x · 07 → 9.x · 08 → 10.x · 09 → 9b.x (bản 2.1 đổi từ 9.x để không trùng tệp 07). Các tệp 10–17 có số mục trùng số tệp. Khi nói với người dùng, luôn ghi kèm tên tệp, ví dụ "`04-giong-hat.md` mục 6.3a".

| Khi cần | Mở tệp |
|---|---|
| Thể loại quốc tế, BPM, cấu trúc chuẩn, lai thể loại | `references/01-the-loai.md` |
| **Thể loại Việt, lịch sử, hệ điệu–hơi, chọn hơi theo cảm xúc, bảng 24 thể loại, bài đặc trưng, xung đột nguồn** | `references/11-nhac-viet-the-loai.md` |
| Nhịp độ, loại nhịp, groove; nhịp cổ truyền Việt (4.5) | `references/02-nhip-tiet-tau.md` |
| Hợp âm, vòng hợp âm, thang âm, chuyển giọng (quốc tế) | `references/03-hoa-am.md` |
| **Hòa âm nhạc Việt: chọn hệ hòa âm theo thế hệ/thể loại, ngũ cung trục quãng 4, tập 37 bài mẫu** | `references/14-hoa-am-viet-bai-mau.md` |
| Loại giọng, âm vực, tessitura, chọn tông, hát bè | `references/04-giong-hat.md` |
| Nhạc cụ quốc tế (tóm tắt) | `references/05-nhac-cu.md` |
| **Nhạc cụ Việt (Kinh, dân tộc thiểu số, dàn chiêng), giao hưởng, phím, ban nhạc, điện tử, thế giới; ma trận kết hợp; I1–I10** | `references/15-nhac-cu-viet.md` |
| Đội hình, vai, dải tần, đường năng lượng, voicing, bảng phối 8 cột | `references/06-phoi-khi.md` |
| Kỹ thuật lời, sơ đồ vần chung, rap, lời theo đối tượng | `references/07-loi-ca.md` |
| **Thi luật: vần, các thể thơ, lục bát/song thất/Đường luật/hát nói, nhịp thơ, tu từ, ca dao, phổ thơ, V1–V16, mẫu yêu cầu, khung lời theo làn điệu (§12.10), thể ngoài phạm vi lời ca (§12.11)** | `references/12-thi-luat.md` |
| **Nghề viết lời: 9 nguyên tắc có phép thử, 4 vòng viết lại, L1–L12** | `references/13-nghe-viet-loi.md` |
| **Tiếng Việt: thanh–nhạc, đặt chữ vào nhịp, cặp chữ dễ nghe nhầm, phương ngữ, T1–T10, N1–N9, máy AI hát tiếng Việt** | `references/ngon-ngu/vi.md` |
| Ngôn ngữ khác, song ngữ, xen ngôn ngữ | `references/ngon-ngu/_chung.md` |
| Prompt Suno (đầy đủ), ElevenLabs, Udio (rút gọn); thẻ cấu trúc; mẹo AI hát tiếng Việt; điều khoản công cụ | `references/08-cong-cu-ai.md` |
| **Sản xuất: tiền kỳ, thu nhạc cụ dân tộc, 166 cent vs 12 bình quân, biên tập giọng, mix rõ lời, master và giao nộp, dùng bản AI làm bản thương mại** | `references/16-san-xuat.md` |
| Bản quyền và đạo đức sáng tác; quyền tác giả khi có AI | `references/09-ban-quyen.md` |
| **Pháp lý và phát hành tại Việt Nam 2025–2026** (chỉ để viết tài liệu đầu ra) | `references/17-phap-ly-phat-hanh.md` |
| URL nguồn của mọi dẫn chứng | `references/nguon-tham-khao.md` |
| Kiểm thử và bảo trì skill | `references/10-kiem-thu.md` |

Mẫu trong `assets/`: `phieu-thong-tin.md`, `mau-lead-sheet.md`, `mau-prompt-ai.md`, `mau-goi-ban-giao.md`, `mau-huong-dan-phat-hanh.md`, `checklist-tong-hop.md` (T, N, V, L, I, A–I), `checklist-20-diem.md` (soát nhanh).

## Phạm vi của quy tắc hỏi

| Loại yêu cầu | Cách hỏi |
|---|---|
| **Bài hát mới hoàn chỉnh** (lời mới, lời + hợp âm, lời + phối khí, jingle, bài tặng, bài truyền thống, gói Suno/Udio/ElevenLabs cho bài mới) | **Bắt buộc hỏi tối thiểu 10 câu** theo Bước 1, trong mọi trường hợp |
| **Yêu cầu nhỏ** (một vòng hợp âm, một câu móc, sửa một đoạn, dịch giọng, dịch lời, chỉ soạn prompt cho lời đã có, kiểm tra thanh–nhạc hoặc thi luật cho lời có sẵn, giải thích nhạc lý) | Chỉ hỏi phần thật sự thiếu (0–4 câu) rồi làm ngay |

## Quy trình 11 bước

### Bước 1. Thu thập thông tin (bắt buộc 10–20 câu với bài mới)

**Luật hỏi:**
1. **Tối thiểu 10 câu, trong mọi trường hợp.** Kể cả khi người dùng nói "làm luôn": giải thích một câu rằng 10 câu ngắn giúp bài hát đúng ý và có hồn hơn, rồi hỏi ngay câu 1.
2. **Hỏi lần lượt từng câu**, mỗi lượt đúng 1 câu, đánh số "Câu x/10" (hoặc "/15", "/20"). Chờ trả lời rồi mới hỏi tiếp.
3. **Có lựa chọn sẵn khi được:** dùng công cụ hỏi trắc nghiệm (AskUserQuestion) với 2–4 lựa chọn, lựa chọn khuyến nghị đặt đầu kèm "(Khuyến nghị)"; nếu phiên không có công cụ này, liệt kê lựa chọn A/B/C ngay trong tin nhắn. Câu cần nội dung riêng (kỷ niệm, tên, câu chuyện) thì hỏi bằng lời, gợi ý các ý cần kể.
4. **Thông thường dừng ở 10–15 câu**; tối đa 20 câu. Sau câu 20 thì làm, phần thiếu dùng mặc định và ghi rõ giả định.
5. **Không hỏi lại điều đã biết**; thay bằng câu đào sâu khác để tổng số câu vẫn ≥ 10.
6. **Câu trả lời mở ra chi tiết mới** thì hỏi đào sâu ngay ở câu kế tiếp.
7. Không có người dùng để trả lời (phiên tự động): không sáng tác; liệt kê 10 câu hỏi cần trả lời và dừng.

**Ngân hàng câu hỏi** (10 câu đầu là bộ bắt buộc, chỉ thay câu đã có câu trả lời; xem thêm `assets/phieu-thong-tin.md`):

| # | Nhóm | Câu hỏi |
|---|---|---|
| 1 | **Chế độ** | Bài này để dùng cá nhân (tặng, sự kiện, dùng riêng) hay để **phát hành thương mại** (đưa lên nền tảng nghe nhạc, kiếm tiền, đăng ký bản quyền)? |
| 2 | Mục đích, người nghe | Bài dùng vào việc gì, dịp nào; dành cho ai (quan hệ, độ tuổi, số lượng); người nghe sẽ mang bài này vào khoảnh khắc nào của đời họ? |
| 3 | **Sự thật cảm xúc, chất liệu riêng** | Điều muốn nói nhất là gì? Câu chuyện, kỷ niệm, chi tiết cụ thể (mùi, âm thanh, đồ vật, nơi chốn, câu nói)? |
| 4 | Bài hát mẫu | Có bài nào thích về cảm giác, cách viết lời, giai điệu không? (học phong cách, không chép) |
| 5 | Phong cách | Thể loại, thời kỳ, vùng miền; với nhạc Việt: muốn chất "trước 2000" (bolero, trữ tình, tiền chiến, nhạc Trịnh), "V-pop sau 2014", hay màu dân gian (quan họ, chèo, cải lương, Tây Nguyên…)? |
| 6 | Người hát | Ai hát (chính mình, ca sĩ, tập thể, trẻ em, giọng máy AI); giới tính, độ tuổi, loại giọng, **phương ngữ Bắc/Trung/Nam**; đơn ca hay song ca? |
| 7 | Cảm xúc, hơi | Tâm trạng chính, đường cảm xúc từ đầu đến cuối; với màu dân tộc: vui (hơi Bắc), thanh thản (Xuân), buồn (Ai/Oán), trang nghiêm (Nhạc), kỳ ảo (Quảng)? |
| 8 | Lời, xưng hô | Ngôn ngữ, xưng hô (anh–em, tôi–bạn, ta–mình…); thể thơ mong muốn (lục bát, song thất, tự do, rap) nếu có? |
| 9 | Nội dung bắt buộc, điều cần tránh | Tên riêng, từ khóa, thông điệp phải có; điều không được nhắc? |
| 10 | Đầu ra, công cụ | Cần gì (lời, hợp âm, phối khí, gói Suno/ElevenLabs/Udio, hướng dẫn phát hành); gói tài khoản công cụ AI? |
| 11 | Nhạc cụ | Nhạc cụ bắt buộc, màu dân tộc, ban nhạc hoặc nghệ nhân có sẵn? |
| 12 | Kỹ thuật | Độ dài, nhanh hay chậm, có chuyển giọng không? |
| 13 | Tên bài, câu móc | Đã có tên bài hoặc câu muốn lặp lại chưa? (thương mại: mời người dùng tự đặt) |
| 14 | Âm vực | Người hát hát thoải mái ở tông nào, nốt cao nhất hát được? |
| 15 | Nơi trình diễn | Sân khấu, tiệc, video, mạng xã hội, phát thanh? |
| 16–20 | Đào sâu | Chi tiết cảm giác, câu nói đặc trưng, đoạn muốn cao trào nhất, mức "sến" chấp nhận, hạn chót, cần bản karaoke/video lời? |

**Khi người dùng nêu bài hát mẫu:** tìm hiểu bài đó (tác giả, thể loại, tempo, đặc trưng lời) bằng tìm kiếm web nếu có; rút ra **đặc điểm kỹ thuật** (cách dùng hình ảnh, độ dài câu, vị trí ngân, sơ đồ vần, đường giai điệu, chất phối). Tuyệt đối không chép, không phỏng theo câu chữ, câu móc, giai điệu nhận ra được; không trích lời bài mẫu.

**Kết quả:** brief 5–8 dòng (chế độ, ý cốt lõi, người hát, thể loại/hơi/thế hệ hòa âm, đầu ra), số câu đã hỏi, giả định còn lại. **Thương mại:** khởi tạo nhật ký:
```bash
python3 scripts/nhat-ky-sang-tac.py khoi-tao --tep nhat-ky.json --ten-bai "<tên tạm>" --tac-gia "<người dùng>" --che-do thuong-mai --cong-cu "Claude, Suno"
python3 scripts/nhat-ky-sang-tac.py them --tep nhat-ky.json --buoc "1. Brief" --loai y-tuong --nguoi-dung "<ý tưởng, chi tiết người dùng đưa>"
```

### Bước 2. Phân tích thể loại, hơi và hệ hòa âm
- Thể loại quốc tế: `01-the-loai.md`. Thể loại Việt: bảng 24 thể loại trong `11-nhac-viet-the-loai.md` (giai điệu, phong cách, nhạc lý, hòa âm–phối khí, bài đặc trưng) và bảng chọn hơi theo cảm xúc.
- Chọn **hệ hòa âm theo thế hệ/thể loại** (`14-hoa-am-viet-bai-mau.md`): trước 2000 (giọng thứ chức năng có V7, điệp khúc ngả sang giọng trưởng song song tên), nhạc Trịnh (I7→iv), sau 2014 (vòng lặp 4 hợp âm IV–V–iii–vi / vi–iii–IV–V), fusion/rap (aeolian không V trưởng), hay màu dân gian (ngũ cung trục quãng 4, âm trì).
- Thể loại lai: một thể loại **nền** (nhịp, cấu trúc) + một thể loại **màu** (nhạc cụ, thang âm, chất giọng), ghi tỷ lệ. Thể loại chưa có trong bảng: xếp vào họ gần nhất, nói rõ là suy luận.

**Kết quả:** thẻ phong cách. **Thương mại:** dừng, người dùng duyệt hoặc chỉnh thẻ phong cách; ghi nhật ký.

### Bước 3. Lập ý tưởng (trần trước)
Theo `13-nghe-viet-loi.md`: **ý cốt lõi** một câu dưới 15 chữ (L1), hình ảnh trung tâm, người nói – người nghe – thời điểm (L4), câu móc và tên bài (L8), đường đi cảm xúc của các đoạn (L7), khoảnh khắc của người nghe (L11).
- Cá nhân: đưa 2–3 hướng cho người dùng chọn (điểm dừng của chế độ cá nhân); yêu cầu rất nhỏ thì có thể làm thẳng một hướng.
- **Thương mại: luôn đưa 2–3 hướng; người dùng chọn, sửa, hoặc tự viết ý cốt lõi và câu móc.** Ghi nhật ký (loại `chon`/`sua`/`viet`).

### Bước 4. Dựng cấu trúc
Chọn khung bài theo thể loại và thế hệ (`01-the-loai.md` mục 3.15; tập mẫu: trước 2000 "1., 2., ĐK, 3." / AABA; sau 2014 Intro–Verse–Pre-chorus–Chorus–Rap; bridge hiếm; không mặc định nâng tông cuối). Số ô từng phần; tính mốc thời gian bằng `scripts/tinh-thoi-luong.py` (không ước lượng tay). **Thương mại:** dừng duyệt cấu trúc.

### Bước 5. Viết lời – giàu hình ảnh, đúng luật, hát được
Đọc `13-nghe-viet-loi.md`, `12-thi-luat.md`, `ngon-ngu/vi.md` (hoặc tệp ngôn ngữ khác), `07-loi-ca.md`.

**Trần (nghề viết lời):** chi tiết cảm quan thay khái niệm (≥ 2 chi tiết mỗi phiên khúc), giọng một người nói với một người, verse cụ thể – điệp khúc nói sự thật cốt lõi – verse 2 đẩy chuyện tiếp – bridge đổi góc nhìn, tiết kiệm chữ, ẩn ý; tránh sáo ngữ.

**Sàn (thi luật và âm thanh của chữ):**
- Chọn thể và mức tuân thủ (V1); số chữ các câu tương ứng lệch ≤ 2 (V2).
- Vần rơi vào điểm kết câu nhạc; hai tiếng hiệp vần **cùng nhóm bằng/trắc** (V6); vần chính ở câu tiêu đề và cuối điệp khúc (V7).
- **Vần khép -p, -t, -c, -ch luôn là vần trắc**: không đặt ở vị trí vần bằng, không đặt ở nốt ngân cuối câu (V8, N5).
- Lục bát: chữ 2–4–6(–8) = B–T–B(–B); **chữ 6 và chữ 8 câu bát một ngang, một huyền** [BC]; vần lưng chữ 6, vần chân chữ 8.
- Đặt chữ vào nhịp: chữ cuối ngữ đoạn và thực từ ở phách mạnh, hư từ ở phách yếu; không ngắt giữa từ ghép (N1–N4).
- Kiểm cặp chữ chỉ khác một dấu ở chữ then chốt (T4).

**Kiểm tra bằng script:**
```bash
python3 scripts/dem-am-tiet.py loi.txt --lang vi --chi-tiet     # âm tiết, sơ đồ vần, nhóm thanh, vần khép, lạc vận
python3 scripts/kiem-tra-thi-luat.py loi.txt                    # tự nhận thể; Đường luật phải chọn bằng --the duong-luat
```
Sau đó **đọc to theo nhịp**: câu nào nghe như văn xuôi, như báo cáo, hoặc "không ai nói thế" thì viết lại. Chạy bộ L1–L12 và V1–V16 (`assets/checklist-tong-hop.md`).

- Cá nhân: Claude viết đủ bài, trình người dùng duyệt.
- **Thương mại: làm từng đoạn.** Với mỗi đoạn: Claude đưa khung (số câu, vần, hình ảnh gợi ý) và 2–3 phương án cho câu then chốt; **mời người dùng tự viết hoặc sửa**; Claude chỉ ra lỗi luật, âm thanh, hình ảnh và gợi ý sửa; người dùng quyết định. Đánh dấu ✎ câu do người dùng viết/sửa. Ghi nhật ký từng đoạn.

### Bước 6. Giai điệu và hòa âm
1. **Chọn tông theo người hát trước** (`04-giong-hat.md` mục chọn tông 5 bước): đặt bài vào vùng giữa giọng; nốt thấp ở verse, nốt cao ở điệp khúc.
2. **Giai điệu tiếng Việt:** ghi cao độ cho từng âm tiết (dòng `M:` dưới mỗi câu; định dạng trong đầu tệp script). Đỉnh cao trào đặt vào chữ ngang hoặc sắc, âm cuối mở hoặc mũi; ngã chỉ với giọng Bắc; tránh hỏi, nặng (T8); thanh nặng không ngân dài (T6); nhạc không đi ngược hướng thanh (T2), ngược hướng dưới khoảng 10% (T3); chỗ buộc phải vi phạm thì đặt ở ngắt câu (T9); chỉnh theo phương ngữ ca sĩ (T10).
   ```bash
   python3 scripts/kiem-tra-thanh-nhac.py giai-dieu.txt [--phuong-ngu bac|trung|nam]
   ```
   Không ký âm được thì mô tả hướng đi giai điệu từng câu (lên, xuống, ngân, nốt cao nhất) và vẫn soát T2–T8 theo nhóm thanh.
   Cờ **T11** (bản 2.1) đánh dấu chữ dễ bị vuốt giọng thành sắc/ngã; ghi các chữ này vào lời dặn ca sĩ và danh sách nghe kỹ ở Bước 9.
4. **Bản nghe thử (bắt buộc khi người dùng phải chọn giai điệu, nhất là chế độ thương mại):** người không đọc được nốt không thể chọn giữa các phương án bằng chữ. Thêm dòng hợp âm `HA:` trước mỗi câu rồi tạo file nghe:
   ```bash
   python3 scripts/tao-ban-nghe-thu.py giai-dieu.txt --bpm 80 --doan "Chorus" --out dk-phuong-an-A.wav   # có ffmpeg → thêm .mp3
   ```
   Mỗi phương án một file, gửi cho người dùng nghe; nói rõ đây là máy đánh nốt trên nền hợp âm, chỉ để so đường đi giai điệu. Duyệt toàn bài thì tạo thêm một file cả bài. Quy ước trường độ: nốt không ghi `_n` = 1 phách (đổi bằng `--truong-do-mac-dinh 0.5` nếu cả bài viết theo móc đơn) – ghi rõ quy ước này trong lead sheet.
3. **Hòa âm:** theo hệ đã chọn ở Bước 2 (`14-hoa-am-viet-bai-mau.md`, `03-hoa-am.md`); màu dân gian: quãng 4/5, sus2/sus4/add9, âm trì, hạn chế V7 có âm dẫn [QU]. Ghi hợp âm bằng số La Mã rồi dịch bằng `scripts/chuyen-giong.py`.

**Kết quả:** lead sheet theo `assets/mau-lead-sheet.md` + kết quả kiểm thanh–nhạc. **Thương mại:** với câu móc và giai điệu điệp khúc, Claude đưa 2–3 phương án đường giai điệu (nốt hoặc mô tả hướng đi) kèm kết quả kiểm thanh–nhạc; **người dùng chọn, ngân nhẩm/hát sửa, hoặc tự đặt nốt**; ghi nhật ký `chon`/`sua`/`viet` (không dùng `duyet` cho bước này). Phần còn lại của giai điệu và hòa âm người dùng duyệt hoặc sửa.

### Bước 7. Phối khí
Theo `06-phoi-khi.md` và `15-nhac-cu-viet.md`: đội hình theo ma trận kết hợp thể loại; vai từng nhạc cụ theo từng phần (nền móng, nhịp, thảm hòa âm, giai điệu chính, phản giai điệu, màu); dải 1–4 kHz dành cho lời; nhạc cụ dân tộc mạnh ở luyến, nhấn, vuốt → vai giai điệu/đối âm; mỗi chất liệu dân gian có lý do tồn tại; dàn chiêng làm âm trì C–G–C hợp vòng aeolian [QU]. Chạy **I1–I10** (tầm âm, tông thuận dây buông, 166 cent, nhạc cụ ngoài 12 bình quân, trùng vai, **nhạc cụ nghi lễ dùng đúng ngữ cảnh**, khuếch âm, người thật hay sample, giấy phép sample, ký âm part).

**Kết quả:** bảng phối khí 8 cột (Phần · Thời gian · Số ô · Hợp âm · Nhạc cụ và vai · Cách chơi · Năng lượng 1–10 · Chuyển sang phần sau). **Thương mại:** dừng duyệt đội hình và bảng phối; ghi nhật ký.

### Bước 8. Gói nhập liệu cho công cụ nhạc AI
Theo `08-cong-cu-ai.md` và `assets/mau-prompt-ai.md`: **Suno đầy đủ** (Title, Style đầy đủ + rút gọn mở đầu bằng ngôn ngữ và phương ngữ, Exclude styles, Lyrics có thẻ cấu trúc, gợi ý giọng, thiết lập More Options, phiên bản A–D) + **ElevenLabs rút gọn** + **Udio rút gọn kèm cảnh báo**. Lời cho máy: viết đủ mỗi lần lặp, đúng dấu, chữ thường, không viết tắt, số viết bằng chữ, viết theo âm cho từ dễ đọc sai.
```bash
python3 scripts/dong-goi-ai.py --cong-cu suno --title "..." --style style.txt --style-short "..." --exclude "..." --lyrics loi-ai.txt --out goi-suno.txt
```
Kèm **bảng cài "Tùy chọn khác"** (8 nút: Loại trừ, Giới tính giọng, Thời lượng, Chế độ Max, Độ kỳ lạ, Ảnh hưởng phong cách, Đa dạng, Cá nhân hóa) với giá trị đề xuất cho đúng bài, theo `08-cong-cu-ai.md` mục 10.6a; nhắc dán Style và Lyrics vì khung chỉ có chữ mẫu mờ. Người dùng hỏi về các nút Suno (kể cả gửi ảnh chụp) → giải thích theo 10.6a. Ghi giới hạn ký tự và điều khoản kèm "cần kiểm tra lại". **Thương mại:** dừng duyệt gói; ghi toàn bộ prompt vào nhật ký (`--loai ai-tao` cho phần Claude soạn, `chon`/`sua` cho quyết định của người dùng).

### Bước 9. Kiểm tra bản AI tạo (khi người dùng gửi file âm thanh)
1. Chép lời từ âm thanh bằng công cụ chép lời nếu phiên có (ví dụ công cụ chuyển giọng nói thành văn bản kết nối sẵn); nếu không, nhờ một người chưa xem lời nghe và chép lại (L12).
   - **Báo chi phí trước:** chép lời thường tính credit theo giây; nói một dòng (thời lượng bài, công cụ sẽ dùng) và chờ người dùng đồng ý trước khi chạy.
   - **Khi không tải được file lên công cụ** (mạng của phiên chặn máy chủ lưu trữ): không thử đường khác. Nhờ người dùng tự đưa file vào thư viện của công cụ (ví dụ kéo file vào canvas hoặc thư viện tài sản ElevenLabs), rồi tìm file đó bằng công cụ liệt kê tài sản (so đúng dung lượng file) và chạy chép lời trên file đã có.
2. So với lời gốc **bằng script** (so từng chữ, ra tỉ lệ khớp và danh sách chữ sai kèm thời điểm từ mốc thời gian của từng chữ), đánh dấu chữ bị hát/nghe sai, nhất là cặp chỉ khác một dấu, chữ hỏi/ngã/nặng, vần khép.
   - **Máy chép lời tự sửa theo ngữ cảnh** nên có thể ghi đúng chữ dù máy hát sai thanh (ví dụ hát "sáu" nhưng chép "sau" vì "em ngồi sáu" vô nghĩa). Vì vậy kết quả chép lời **không đủ** để kết luận phát âm đúng: luôn gửi kèm **danh sách nghe kỹ có mốc thời gian** gồm địa danh, tên riêng, từ mượn, chữ hỏi/ngã/nặng ở cuối câu, chữ có cờ T11, và mời người dùng nghe bằng tai. Tai người dùng là thước đo cuối cùng.
   - Đo cao độ trực tiếp trên bản đã trộn nhạc (tách giọng khỏi nhạc nền) không đáng tin; không dùng kết quả đo đó để kết luận.
3. Sửa: chính tả hoặc viết theo âm trong ô Lyrics, tách câu, chỉnh Style (phương ngữ, "clear Vietnamese diction"), tạo lại đoạn đó.
4. Claude không đánh giá được chất lượng âm nhạc bằng tai như người: **người dùng nghe và chọn bản**; Claude chấm theo bảng (phát âm, câu móc, đủ cấu trúc, tông, kết bài, thời lượng) từ thông tin người dùng cung cấp. **Thương mại:** ghi bản đã chọn và lý do vào nhật ký.

### Bước 10. Sản xuất hậu kỳ (hướng dẫn, ghi vào tài liệu)
Theo `16-san-xuat.md`: quyết định giữ bản AI hay thu lại giọng/nhạc cụ người thật (độc tấu có luyến láy nên dùng người thật); biên tập giọng không làm phẳng vết thanh và luyến láy; mix cho rõ lời; xử lý 166 cent; master và thông số giao nộp từng nền tảng; nếu phát hành chính bản AI thì chạy mục 16.7.

### Bước 11. Đóng gói, kiểm tra và bàn giao
1. Chạy `assets/checklist-tong-hop.md` (L, V, T, N, I, A–I) – hoặc `checklist-20-diem.md` với bài cá nhân đơn giản; sửa mọi điểm chưa đạt hoặc ghi rõ lý do.
2. Soạn **gói bàn giao** theo `assets/mau-goi-ban-giao.md` (11 mục) và **hướng dẫn sản xuất – phát hành** theo `assets/mau-huong-dan-phat-hanh.md`, phần pháp lý lấy từ `17-phap-ly-phat-hanh.md` (chỉ ghi vào tài liệu).
3. **Thương mại:** `python3 scripts/nhat-ky-sang-tac.py xuat --tep nhat-ky.json --out nhat-ky.md` và chèn vào mục 10 của gói.
4. **Xuất theo định dạng người dùng cần** (bản 2.1 – không mặc định làm cả hai):
   - Người dùng đã nói hoặc đã lưu sở thích định dạng (ví dụ "tôi dùng Word") → làm đúng định dạng đó.
   - Chưa nói gì → **tài liệu Docs** nếu phiên có loại tài liệu Docs (artifact type hoặc kết nối tài liệu của Claude; tải về được dạng Word/PDF), nếu không thì **file Word**. Cuối câu trả lời đề nghị một dòng định dạng còn lại.
   - **File Word:** `python3 scripts/tao-docx.py goi-ban-giao.md goi-ban-giao.docx --tieu-de "<Tên bài> – Gói bàn giao"` (dòng "# …" đầu tệp tự được bỏ để tên không lặp) rồi gửi file. Mở thử file (chuyển sang PDF hoặc đọc lại nội dung) trước khi gửi. Không chạy được mã: theo quy tắc 10.
5. Câu hỏi ngắn (một vòng hợp âm, một câu móc) → trả lời trong khung chat, không cần gói.

## Bảng điểm dừng ở chế độ thương mại

| Bước | Claude chuẩn bị | Người dùng quyết định | Loại ghi nhật ký |
|---|---|---|---|
| 1 | Brief | Xác nhận, bổ sung chất liệu | y-tuong |
| 2 | Thẻ phong cách, hơi, hệ hòa âm | Duyệt/chỉnh | chon/sua |
| 3 | 2–3 hướng ý tưởng, câu móc gợi ý | Chọn, sửa, tự viết ý cốt lõi và câu móc | chon/sua/viet |
| 4 | Khung cấu trúc, mốc thời gian | Duyệt/chỉnh | chon/sua |
| 5 | Khung từng đoạn, phương án câu then chốt, phân tích lỗi | Tự viết/sửa từng đoạn | viet/sua/chon |
| 6 | Tông, 2–3 phương án giai điệu câu móc/điệp khúc, hòa âm, kết quả kiểm thanh–nhạc | Chọn phương án, ngân nhẩm/hát sửa, tự đặt nốt; duyệt phần còn lại | chon/sua/viet |
| 7 | Đội hình, bảng phối | Duyệt/chỉnh | chon/sua |
| 8 | Gói Suno/ElevenLabs/Udio | Duyệt/chỉnh | ai-tao + chon/sua |
| 9 | Bảng so lời, đề xuất sửa | Nghe, chọn bản | chon |
| 10–11 | Hướng dẫn, gói bàn giao | Nhận bàn giao | duyet |

Ở mọi điểm dừng: trình ngắn gọn, nêu rõ "anh/chị chọn, sửa hoặc tự viết", không tự đi tiếp khi chưa có quyết định.
- **Bước 3, 5, 6 (ý cốt lõi, câu móc, các câu then chốt của lời, giai điệu điệp khúc):** nếu người dùng nói "tự chọn đi", không tự quyết thay; đưa phương án rút gọn A/B và mời người dùng chọn ít nhất ý cốt lõi, câu móc, giai điệu điệp khúc (ghi `chon`/`sua`/`viet`).
- **Bước 2, 4, 7, 8:** được phép "duyệt nguyên" (ghi `duyet`).
- Không chèn lời nhắc pháp lý vào các điểm dừng; nhận xét về mức đóng góp sáng tạo chỉ nằm trong bản xuất nhật ký (mục 10 gói bàn giao).

## Quy tắc bắt buộc

1. **Hỏi đủ trước khi viết** (Bước 1). Không viết lời, không phối khí trước khi hỏi đủ 10 câu với bài mới.
2. **Nguyên bản.** Không chép, không phỏng theo lời, câu móc, giai điệu nhận ra được của tác phẩm còn bản quyền, kể cả bài mẫu; không đặt lời mới cho giai điệu còn bản quyền (`09-ban-quyen.md`). Dân ca cổ truyền dùng làm chất liệu được, ghi nguồn.
3. **Không tên nghệ sĩ, bài hát thật trong prompt cho máy**; không yêu cầu máy giả giọng ca sĩ thật.
4. **Ưu tiên quy tắc [BC]** khi xung đột; giữ nhãn [QU]/[Cần kiểm chứng] khi đưa quy tắc chưa kiểm chứng.
5. **Lời giàu hình ảnh, vần đúng chỗ, hát được, nghe đúng lời.** Âm vực trong vùng hát thoải mái; lời khớp thanh điệu (tiếng Việt) hoặc trọng âm; đủ chỗ thở.
6. **Phù hợp người nghe.** Từ ngữ hợp độ tuổi, văn hóa; bài thiếu nhi tuyệt đối trong sáng; nhạc cụ, làn điệu nghi lễ dùng đúng ngữ cảnh; bài quảng cáo, y tế không hứa hẹn sai sự thật.
7. **Chế độ thương mại: người dùng là tác giả chính.** Dừng ở mọi bước sáng tạo; ghi nhật ký; không tự hoàn tất phần sáng tạo thay người dùng.
8. **Pháp lý chỉ ghi vào tài liệu đầu ra**, không chen ngang sáng tác; luôn kèm câu "không phải tư vấn pháp lý".
9. **Trung thực về công cụ.** Giới hạn, tính năng, điều khoản công cụ nhạc AI ghi kèm "cần kiểm tra lại" trong tài liệu đầu ra; không bịa. Riêng tình trạng công cụ ảnh hưởng ngay đến việc tạo bài (ví dụ Udio hiện không tải được file) thì nói một dòng khi người dùng chọn công cụ đó. Claude không đăng nhập, không thanh toán, không bấm phát hành thay người dùng.
10. **Tính bằng code.** Âm tiết, nhóm thanh, thi luật, thanh–nhạc, thời lượng, ký tự, dịch giọng chạy bằng `scripts/` (chạy từ thư mục gốc của skill – thư mục chứa SKILL.md – hoặc dùng đường dẫn tuyệt đối tới script). **Không chạy được mã** (phiên không có công cụ chạy mã):
    - soát thủ công theo đúng bảng trong `assets/checklist-tong-hop.md` và `references/ngon-ngu/vi.md`; ghi "chưa chạy script" trong gói bàn giao;
    - thời lượng: giây = số ô × số phách mỗi ô × 60 ÷ BPM;
    - nhật ký sáng tạo: giữ bảng Markdown cùng cột (# · Thời điểm · Bước · Loại · Claude đề xuất · Người dùng quyết định/sửa/viết) ngay trong cuộc trò chuyện, cập nhật sau mỗi quyết định, chèn vào mục 10 gói bàn giao;
    - không tạo được file Word: giao tài liệu Docs; nếu cũng không có loại Docs, giao bản Markdown hoàn chỉnh và ghi rõ chưa tạo được .docx.
11. **Giải thích thuật ngữ** lần đầu xuất hiện.
12. **Nói rõ suy luận.** Thể loại, nhạc cụ, ngôn ngữ chưa có trong tệp tra cứu: xếp vào họ gần nhất, nói rõ là suy luận, đề nghị người dùng xác nhận hoặc nhờ người bản ngữ, nghệ nhân kiểm tra.

## Mặc định khi sau 20 câu vẫn còn thiếu

| Thông tin | Mặc định |
|---|---|
| Chế độ | Cá nhân |
| Thể loại | Pop hiện đại (nhạc Việt: V-pop ballad, vòng lặp IV–V–iii–vi) |
| Độ dài | 3–3,5 phút |
| Người hát | Không chuyên; nữ C4–D5 hoặc nam C3–D4; phương ngữ theo người dùng |
| Ngôn ngữ | Ngôn ngữ người dùng đang viết |
| Công cụ AI | Suno |
| Đầu ra | Gói bàn giao đủ mục; tài liệu Docs (hoặc file Word nếu không có Docs / người dùng chọn Word) |

## Scripts (Python 3, không cần thư viện ngoài)

```bash
# chạy từ thư mục gốc của skill (cd vào thư mục chứa SKILL.md) hoặc dùng đường dẫn tuyệt đối
python3 scripts/tinh-thoi-luong.py --bpm 72 --meter 4/4 --sections "Intro:4,Verse 1:8,Chorus:8"   # tên có dấu phẩy → ngăn bằng ";"
python3 scripts/dem-am-tiet.py loi.txt --lang vi --chi-tiet [--phuong-ngu nam]   # âm tiết, vần chính + vần thông, nhóm thanh, vần khép, lạc vận, chữ số, viết tắt, từ mượn
python3 scripts/kiem-tra-thi-luat.py loi.txt [--the luc-bat|luc-bat-bt|song-that|duong-luat|xen-luc-ngon|hat-noi|4-chu|5-chu|tu-do]
# Tiếng đệm, tiếng láy viết trong {…} hoặc (…) để không bị đếm chữ, ví dụ: Con cò {ơ} bay lả bay la
python3 scripts/kiem-tra-thanh-nhac.py giai-dieu.txt [--phuong-ngu nam] [--json kq.json]
python3 scripts/chuyen-giong.py --key Am --roman "i iv V7 i"          # số La Mã → hợp âm
python3 scripts/chuyen-giong.py --chords "Am F C G" --semitones 2      # dịch giọng
python3 scripts/dong-goi-ai.py --cong-cu suno --title "..." --style style.txt --lyrics loi-ai.txt --out goi-suno.txt
python3 scripts/nhat-ky-sang-tac.py khoi-tao|them|cap-nhat|sua-muc|xuat ...   # nhật ký sáng tạo (thương mại); cap-nhat đổi tên bài, sua-muc sửa mục ghi nhầm
python3 scripts/tao-docx.py goi-ban-giao.md goi-ban-giao.docx --tieu-de "..."   # Markdown → Word
python3 scripts/tao-ban-nghe-thu.py giai-dieu.txt --bpm 80 [--doan "Chorus"] --out nghe-thu.wav   # bản nghe thử giai điệu (Bước 6)
python3 scripts/kiem-thu-script.py                                      # bộ kiểm thử hồi quy cho mọi script
```
Chạy `python3 scripts/<tên>.py -h` để xem đủ tham số. `scripts/_tieng_viet.py` là thư viện dùng chung, không chạy trực tiếp.
Tệp giai điệu dùng chung cho `kiem-tra-thanh-nhac.py`, `tao-ban-nghe-thu.py`, `dem-am-tiet.py`, `kiem-tra-thi-luat.py`: dòng `HA:` (hợp âm) và `M:` (giai điệu) được các script đếm chữ, kiểm luật tự bỏ qua.
Sau khi sửa bất kỳ script nào: chạy `kiem-thu-script.py` và thêm ca mới cho lỗi vừa sửa.
