#!/usr/bin/env python3
"""Kiểm tra thi luật cho lời/thơ tiếng Việt (bộ kiểm tra V – references/12-thi-luat.md). Bản 2.2.

Nguyên tắc: quy tắc ĐÃ KIỂM CHỨNG (có nguồn) mới được chấm là LỖI; quy tắc chưa kiểm chứng chỉ in ở mục Ghi chú.

Thể hỗ trợ (--the; mặc định tự nhận theo số chữ mỗi dòng, KHÔNG bao giờ tự gán Đường luật):
  luc-bat       Lục bát: chữ 2–4–6(–8) = B–T–B(–B); luật trầm bổng [BC]: chữ 6 và 8 câu bát một ngang, một huyền;
                vần lưng chữ 6 lục ↔ chữ 6 bát; vần chân chữ 8 bát ↔ chữ 6 lục kế tiếp. Vần ở chữ 4 câu bát chỉ báo.
  luc-bat-bt    Lục bát biến thể: câu dôi chữ; tìm chữ hiệp vần với chữ cuối câu trên ở BẤT KỲ vị trí nào của câu dưới
                (báo vị trí); không chấm luật chữ chẵn. Vần trắc ở chữ 6 hiếm nhưng có [BC].
  song-that     Song thất lục bát (7–7–6–8): chữ 3–5–7 câu thất trên = T–B–T, dưới = B–T–B; cặp 6–8 theo lục bát.
                Sơ đồ vần giữa hai câu thất và vần nối khổ có nguồn mâu thuẫn → chỉ báo [Cần kiểm chứng].
  duong-luat    Bát cú (8 câu) hoặc tứ tuyệt (4 câu), 7 chữ: luật bằng/trắc theo chữ 2 câu 1; chữ 2 và 6 cùng nhóm,
                chữ 4 ngược (Từ điển thuật ngữ văn học tr. 265); niêm bát cú 1–8, 2–3, 4–5, 6–7; vần bằng câu 1, 2, 4, 6, 8.
                Niêm tứ tuyệt và mọi luật ngũ ngôn (5 chữ) chưa có nguồn → chỉ báo. Đối câu 3–4, 5–6 phải tự soát.
  xen-luc-ngon  Thất ngôn xen lục ngôn (Hàn luật kiểu Nguyễn Trãi): câu 6 chữ ở vị trí không cố định [BC];
                kiểm vần câu 1–2–4–6–8 và luật chữ 2–4–6 ở câu 7 chữ; câu 6 chữ chỉ báo.
  hat-noi       Hát nói: khổ đủ 11 câu chia 4–4–3 [BC]; câu cuối 6 chữ, kết thanh bằng [BC];
                chuỗi bằng–trắc chữ cuối câu chỉ báo. Mưỡu (lục bát) kiểm riêng bằng --the luc-bat.
  4-chu, 5-chu  Thơ 4 chữ / 5 chữ (vè, đồng dao, giặm): đếm chữ, báo vần chân (cuối ↔ cuối) và vần lưng
                (cuối câu trên ↔ chữ 2 câu dưới), gợi ý nhịp – chỉ báo.
  tu-do         Thơ tự do / lời pop / Thơ Mới: nhóm bằng–trắc, vần liền; khổ 4 câu báo thêm vần cách, vần ôm [QU].

Đầu vào: tệp văn bản, mỗi câu một dòng; dòng [Nhãn] và dòng trống được bỏ qua.
Tiếng đệm, tiếng láy đặt trong ngoặc nhọn {…} hoặc ngoặc tròn (…) sẽ KHÔNG được đếm vào số chữ và vị trí luật,
ví dụ: "Con chim {ơ} manh manh {tình bằng} …".
Ví dụ:
  python3 kiem-tra-thi-luat.py loi.txt
  python3 kiem-tra-thi-luat.py tho.txt --the luc-bat-bt
"""
import argparse, os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _tieng_viet import phan_tich, tach_tu, so_van  # noqa: E402


def doc(path):
    dong = []
    for raw in open(path, encoding="utf-8").read().splitlines():
        s = raw.strip()
        if not s or re.fullmatch(r"\[[^\]]+\]", s) or re.match(r"(?i)^(M|HA)\s*:", s):
            continue
        s = re.sub(r"\([^)]*\)|\{[^}]*\}", "", s)  # bỏ tiếng đệm, tiếng láy, bè trong ngoặc tròn/nhọn
        w = tach_tu(s)
        if w:
            dong.append((s, [phan_tich(x) for x in w]))
    return dong


def bt(at):
    return "".join(x["bang_trac"] for x in at)


def mo_ta_van(a, b):
    kieu, cung = so_van(a, b)
    if kieu == "khong":
        return False, f"«{a['chu']}» – «{b['chu']}» không vần"
    ghi = "vần chính" if kieu == "chinh" else "vần thông? [Cần kiểm chứng]"
    if not cung:
        return False, f"«{a['chu']}» – «{b['chu']}» {ghi} nhưng KHÁC nhóm bằng/trắc (lạc vận)"
    return True, f"«{a['chu']}» – «{b['chu']}» {ghi}"


def kiem_vi_tri(at, yeu_cau, ten):
    loi = []
    for vt, can in yeu_cau.items():
        if vt <= len(at) and at[vt - 1]["bang_trac"] != can:
            loi.append(f"{ten}: chữ {vt} «{at[vt-1]['chu']}» là {'bằng' if at[vt-1]['bang_trac']=='B' else 'trắc'}, "
                       f"luật cần {'bằng' if can=='B' else 'trắc'}")
    return loi


def luc_bat(ds, bat_dau=0):
    loi, info = [], []
    i = bat_dau
    while i + 1 < len(ds):
        (sl, l), (sb, b) = ds[i], ds[i + 1]
        if len(l) != 6 or len(b) != 8:
            info.append(f"Cặp dòng {i+1}–{i+2} không phải 6–8 ({len(l)}–{len(b)} chữ): bỏ qua.")
            i += 2
            continue
        loi += kiem_vi_tri(l, {2: "B", 4: "T", 6: "B"}, f"Câu lục {i+1} «{sl}»")
        loi_bat = kiem_vi_tri(b, {2: "B", 4: "T", 6: "B", 8: "B"}, f"Câu bát {i+2} «{sb}»")
        ok, msg = mo_ta_van(l[5], b[5])
        if not ok:
            ok4, msg4 = mo_ta_van(l[5], b[3])
            if ok4:
                info.append(f"Câu {i+1}–{i+2}: biến thể vần lưng ở chữ 4 câu bát ({msg4}); "
                            f"khi đó 2–4–6 câu bát đảo thành T–B–T.")
                loi_bat = kiem_vi_tri(b, {2: "T", 4: "B", 6: "T", 8: "B"}, f"Câu bát {i+2} (biến thể) «{sb}»")
            else:
                loi.append(f"Vần lưng câu {i+1}–{i+2}: {msg}")
        loi += loi_bat
        t6, t8 = b[5]["thanh"], b[7]["thanh"]
        if {t6, t8} != {"ngang", "huyền"}:
            loi.append(f"Luật trầm bổng [BC] câu bát {i+2}: chữ 6 «{b[5]['chu']}» ({t6}) và chữ 8 «{b[7]['chu']}» ({t8}) "
                       f"phải một ngang, một huyền.")
        if i + 2 < len(ds) and len(ds[i + 2][1]) == 6:
            ok, msg = mo_ta_van(b[7], ds[i + 2][1][5])
            if not ok:
                loi.append(f"Vần chân câu {i+2}→{i+3}: {msg}")
        i += 2
    return loi, info


def song_that(ds):
    loi, info = [], []
    for k in range(0, len(ds) - 3, 4):
        kh = ds[k:k + 4]
        dai = [len(x[1]) for x in kh]
        if dai != [7, 7, 6, 8]:
            info.append(f"Khổ bắt đầu dòng {k+1} không phải 7–7–6–8 ({dai}): bỏ qua.")
            continue
        loi += kiem_vi_tri(kh[0][1], {3: "T", 5: "B", 7: "T"}, f"Câu thất trên {k+1} «{kh[0][0]}»")
        loi += kiem_vi_tri(kh[1][1], {3: "B", 5: "T", 7: "B"}, f"Câu thất dưới {k+2} «{kh[1][0]}»")
        _, m1 = mo_ta_van(kh[0][1][6], kh[1][1][4])
        _, m2 = mo_ta_van(kh[1][1][6], kh[2][1][5])
        info.append(f"Khổ {k//4+1} – vần câu thất [Cần kiểm chứng, nguồn mâu thuẫn]: chữ 7 thất trên ↔ chữ 5 thất dưới: "
                    f"{m1}; chữ 7 thất dưới ↔ chữ 6 câu lục: {m2}")
        l2, i2 = luc_bat(ds[k + 2:k + 4])
        loi += l2
        info += i2
    return loi, info


def duong_luat(ds):
    loi, info = [], []
    n = len(ds)
    dai = {len(x[1]) for x in ds}
    if n not in (4, 8) or len(dai) != 1 or dai.pop() not in (5, 7):
        return [f"Đường luật cần 4 hoặc 8 câu cùng 7 chữ (hoặc 5 chữ); tệp có {n} câu, độ dài {[len(x[1]) for x in ds]}."], []
    so_chu = len(ds[0][1])
    if so_chu == 5:
        info.append("Ngũ ngôn (5 chữ): các luật bằng–trắc, niêm riêng cho ngũ ngôn CHƯA có nguồn kiểm chứng → script chỉ báo "
                    "nhóm thanh và vần chân, không chấm lỗi.")
        for c in ([1, 2, 4, 6, 8] if n == 8 else [1, 2, 4]):
            at = ds[c - 1][1]
            info.append(f"Câu {c}: chữ cuối «{at[-1]['chu']}» ({'bằng' if at[-1]['bang_trac']=='B' else 'trắc'})")
        return loi, info
    luat = "bằng" if ds[0][1][1]["bang_trac"] == "B" else "trắc"
    info.append(f"Chữ 2 câu 1 «{ds[0][1][1]['chu']}» → bài theo LUẬT {luat.upper()}.")
    for i, (s, at) in enumerate(ds, 1):
        if at[1]["bang_trac"] == at[3]["bang_trac"] or at[3]["bang_trac"] == at[5]["bang_trac"]:
            loi.append(f"Câu {i} «{s}»: chữ 2–4–6 là {at[1]['bang_trac']}–{at[3]['bang_trac']}–{at[5]['bang_trac']}; "
                       f"luật cần chữ 2 và 6 cùng nhóm, chữ 4 ngược (Từ điển thuật ngữ văn học tr. 265).")
    if n == 8:
        for a, b in [(1, 8), (2, 3), (4, 5), (6, 7)]:
            if ds[a - 1][1][1]["bang_trac"] != ds[b - 1][1][1]["bang_trac"]:
                loi.append(f"Thất niêm câu {a}–{b}: chữ 2 «{ds[a-1][1][1]['chu']}» và «{ds[b-1][1][1]['chu']}» khác nhóm.")
    else:
        for a, b in [(1, 4), (2, 3)]:
            if ds[a - 1][1][1]["bang_trac"] != ds[b - 1][1][1]["bang_trac"]:
                info.append(f"Niêm tứ tuyệt câu {a}–{b} [Cần kiểm chứng – chưa có nguồn, không chấm lỗi]: "
                            f"chữ 2 «{ds[a-1][1][1]['chu']}» và «{ds[b-1][1][1]['chu']}» khác nhóm.")
    _van_duong_luat(ds, [1, 2, 4, 6, 8] if n == 8 else [1, 2, 4], loi, info)
    info.append("Bố cục bát cú: Đề (1–2) – Thực (3–4) – Luận (5–6) – Kết (7–8) [BC]. "
                "Đối câu 3–4 và 5–6: tự soát đối ý, đối từ loại, đối thanh – script không chấm.")
    return loi, info


def _van_duong_luat(ds, cau_van, loi, info):
    goc = ds[1][1][-1]
    for c in cau_van:
        if c > len(ds):
            continue
        at = ds[c - 1][1]
        if at[-1]["bang_trac"] != "B":
            (info if c == 1 else loi).append(f"Câu {c}: chữ cuối «{at[-1]['chu']}» không phải vần bằng"
                                             + (" (câu 1 có thể không gieo vần)." if c == 1 else "."))
            continue
        if c != 2:
            ok, msg = mo_ta_van(goc, at[-1])
            if not ok:
                loi.append(f"Vần câu 2 ↔ câu {c}: {msg}")


def xen_luc_ngon(ds):
    loi, info = [], []
    n = len(ds)
    dai = [len(x[1]) for x in ds]
    if n not in (4, 8) or any(d not in (6, 7) for d in dai):
        return [f"Thất ngôn xen lục ngôn cần 4 hoặc 8 câu dài 6 hoặc 7 chữ; tệp có {n} câu, độ dài {dai}."], []
    info.append(f"Câu 6 chữ ở vị trí {[i for i, d in enumerate(dai, 1) if d == 6] or 'không có'} – "
                "Hàn luật xen câu 6 tiếng ở vị trí không cố định [BC]; vẫn giữ vần và đối như Đường luật.")
    for i, (s, at) in enumerate(ds, 1):
        if len(at) == 7 and (at[1]["bang_trac"] == at[3]["bang_trac"] or at[3]["bang_trac"] == at[5]["bang_trac"]):
            loi.append(f"Câu {i} «{s}»: chữ 2–4–6 là {at[1]['bang_trac']}–{at[3]['bang_trac']}–{at[5]['bang_trac']}; "
                       f"luật cần chữ 2 và 6 cùng nhóm, chữ 4 ngược.")
        if len(at) == 6:
            info.append(f"Câu {i} (6 chữ) «{s}»: {bt(at)} – luật thanh câu 6 chữ chưa có nguồn, chỉ báo.")
    _van_duong_luat(ds, [c for c in ([1, 2, 4, 6, 8] if n == 8 else [1, 2, 4])], loi, info)
    return loi, info


def hat_noi(ds):
    loi, info = [], []
    n = len(ds)
    if n == 11:
        info.append("Khổ đủ 11 câu, chia 4–4–3 [BC]: câu 1–4 | 5–8 | 9–11.")
    elif n > 11:
        info.append(f"{n} câu: khổ dôi (hơn 11 câu) [BC] – script không chia đoạn.")
    else:
        info.append(f"{n} câu: ít hơn 11 câu (khổ thiếu) – script không chia đoạn.")
    cuoi = ds[-1][1]
    if len(cuoi) != 6:
        loi.append(f"Câu cuối «{ds[-1][0]}» có {len(cuoi)} chữ; hát nói kết bằng câu 6 chữ [BC].")
    if cuoi[-1]["bang_trac"] != "B":
        loi.append(f"Câu cuối kết bằng «{cuoi[-1]['chu']}» (trắc); hát nói kết thanh bằng [BC].")
    if len(cuoi) == 6:
        info.append("Câu cuối 6 chữ thường ngắt nhịp 2/2/2 [BC].")
    chuoi = "".join(x[1][-1]["bang_trac"] for x in ds)
    info.append(f"Chuỗi bằng–trắc chữ cuối câu: {chuoi} – vần chân hát nói đi theo cặp 'bằng bằng – trắc trắc' [BC]; "
                "vị trí chính xác của từng cặp trong khổ là [Cần kiểm chứng], nên script chỉ báo, không chấm.")
    if n >= 6:
        info.append("Câu 5–6 thường là hai câu thơ 7 chữ (chữ Hán hoặc Nôm) [BC]: "
                    + ", ".join(f"câu {k} có {len(ds[k-1][1])} chữ" for k in (5, 6)))
    info.append("Mưỡu (nếu có) là các câu lục bát đặt trước hoặc sau bài [BC]: tách ra kiểm bằng --the luc-bat.")
    return loi, info


def tho_ngan(ds, so):
    info = []
    lech = [i for i, (_, at) in enumerate(ds, 1) if len(at) != so]
    info.append(f"Thơ {so} chữ: {len(ds) - len(lech)}/{len(ds)} câu đúng {so} chữ"
                + (f"; câu lệch: {lech}" if lech else "") + ".")
    info.append("Gợi ý nhịp: " + ("2/2." if so == 4 else "2/3 hoặc 3/2.") + " Vè dùng cả vần chân và vần lưng [BC].")
    for i in range(len(ds) - 1):
        a, b = ds[i][1], ds[i + 1][1]
        ok, msg = mo_ta_van(a[-1], b[-1])
        if ok:
            info.append(f"Vần chân câu {i+1}–{i+2}: {msg}")
        if len(b) >= 2:
            ok2, msg2 = mo_ta_van(a[-1], b[1])
            if ok2:
                info.append(f"Vần lưng câu {i+1} → chữ 2 câu {i+2}: {msg2}")
    return [], info


def luc_bat_bt(ds):
    loi, info = [], []
    info.append("Lục bát biến thể: không chấm luật chữ chẵn; chỉ tìm vần lưng ở vị trí trôi và vần chân giữa các cặp.")
    i = 0
    while i + 1 < len(ds):
        (sl, l), (sb, b) = ds[i], ds[i + 1]
        tim = []
        for k, x in enumerate(b[:-1], 1):
            ok, msg = mo_ta_van(l[-1], x)
            if ok:
                tim.append((k, msg))
        if tim:
            k, msg = tim[-1]
            chuan = " (vị trí chuẩn)" if (k == 6 and len(b) == 8) else ""
            info.append(f"Cặp {i+1}–{i+2} ({len(l)}–{len(b)} chữ): vần lưng ở chữ {k} câu dưới{chuan}: {msg}")
            if l[-1]["bang_trac"] == "T":
                info.append(f"Cặp {i+1}–{i+2}: vần trắc – hợp lệ nhưng hiếm, không nên kéo dài quá hai câu [BC].")
        else:
            loi.append(f"Cặp {i+1}–{i+2}: không tìm thấy chữ nào ở câu dưới hiệp vần với «{l[-1]['chu']}» (chữ cuối câu trên).")
        if len(b) == 8 and b[5]["bang_trac"] == "B" and b[7]["bang_trac"] == "B" and {b[5]["thanh"], b[7]["thanh"]} != {"ngang", "huyền"}:
            info.append(f"Câu {i+2}: chữ 6 và 8 cùng {b[5]['thanh']} – luật trầm bổng [BC] yêu cầu một ngang, một huyền.")
        if i + 2 < len(ds):
            ok, msg = mo_ta_van(b[-1], ds[i + 2][1][-1])
            if ok:
                info.append(f"Vần chân câu {i+2}→{i+3}: {msg}")
            else:
                info.append(f"Vần chân câu {i+2}→{i+3}: {msg} (biến thể có thể gieo ở vị trí khác)")
        i += 2
    return loi, info


def tu_do(ds):
    info = []
    for i, (s, at) in enumerate(ds, 1):
        cuoi = at[-1]
        ghi = " · VẦN KHÉP cuối dòng: tránh đặt nốt ngân dài" if cuoi["khep"] else ""
        info.append(f"{i:>2}. {bt(at):<14} {s}  | cuối «{cuoi['chu']}» ({cuoi['thanh']}){ghi}")
    for i in range(len(ds) - 1):
        ok, msg = mo_ta_van(ds[i][1][-1], ds[i + 1][1][-1])
        if ok:
            info.append(f"Vần liền dòng {i+1}–{i+2}: {msg}")
    if len(ds) % 4 == 0:
        for k in range(0, len(ds), 4):
            c = [x[1][-1] for x in ds[k:k + 4]]
            for (p, q, ten) in [(0, 2, "vần cách"), (1, 3, "vần cách"), (0, 3, "vần ôm"), (1, 2, "vần ôm")]:
                ok, msg = mo_ta_van(c[p], c[q])
                if ok:
                    info.append(f"Khổ {k//4+1}, {ten} [QU] câu {k+p+1}–{k+q+1}: {msg}")
    return [], info


def tu_nhan(ds):
    dai = [len(x[1]) for x in ds]
    if len(dai) >= 4 and dai[:4] == [7, 7, 6, 8]:
        return "song-that", ""
    if len(dai) >= 2 and all(d == (6 if k % 2 == 0 else 8) for k, d in enumerate(dai)):
        return "luc-bat", ""
    if len(dai) >= 2 and len(dai) % 2 == 0 and all((5 <= d <= 8) if k % 2 == 0 else (8 <= d <= 12)
                                                   for k, d in enumerate(dai)):
        return "luc-bat-bt", "Các cặp gần 6–8 nhưng có câu dôi chữ → kiểm như lục bát biến thể."
    if all(d == 4 for d in dai):
        return "4-chu", ""
    if all(d == 5 for d in dai):
        return "5-chu", ""
    if len(dai) in (4, 8) and all(d == 7 for d in dai):
        return "tu-do", ("Khổ 4/8 câu × 7 chữ có thể là Đường luật HOẶC Thơ Mới 7 chữ (Thơ Mới rời khuôn Đường luật [BC]). "
                         "Muốn chấm luật Đường thì chạy lại với --the duong-luat.")
    return "tu-do", ""


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file")
    ap.add_argument("--the", choices=["tu-dong", "luc-bat", "luc-bat-bt", "song-that", "duong-luat", "xen-luc-ngon",
                                     "hat-noi", "4-chu", "5-chu", "tu-do"], default="tu-dong")
    a = ap.parse_args()
    ds = doc(a.file)
    if not ds:
        sys.exit("Tệp không có dòng lời nào.")
    goi_y = ""
    if a.the == "tu-dong":
        the, goi_y = tu_nhan(ds)
    else:
        the = a.the
    print(f"Thể thơ: {the}" + (" (tự nhận theo số chữ)" if a.the == "tu-dong" else ""))
    if goi_y:
        print(f"Gợi ý: {goi_y}")
    print("\n## Nhóm bằng (B) / trắc (T) từng dòng")
    for i, (s, at) in enumerate(ds, 1):
        print(f"{i:>2}. [{len(at)}] {bt(at):<14} {s}")
    loi, info = {"luc-bat": luc_bat, "luc-bat-bt": luc_bat_bt, "song-that": song_that, "duong-luat": duong_luat,
                 "xen-luc-ngon": xen_luc_ngon, "hat-noi": hat_noi, "4-chu": lambda x: tho_ngan(x, 4),
                 "5-chu": lambda x: tho_ngan(x, 5), "tu-do": tu_do}[the](ds)
    if info:
        print("\n## Ghi chú")
        print("\n".join(f"- {x}" for x in info))
    print("\n## Lỗi thi luật (V3–V10)")
    print("\n".join(f"- {x}" for x in loi) if loi else "Không có lỗi.")
    print("\nLưu ý: thi luật là 'cái sàn' của lời; bằng/trắc KHÔNG quyết định cao độ hát – chạy thêm "
          "kiem-tra-thanh-nhac.py khi đã có giai điệu.")


if __name__ == "__main__":
    main()
