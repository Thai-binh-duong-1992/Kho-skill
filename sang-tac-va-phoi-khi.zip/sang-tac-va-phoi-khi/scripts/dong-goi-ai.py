#!/usr/bin/env python3
"""Đóng gói prompt cho công cụ nhạc AI và kiểm tra lỗi thường gặp (bản 2.0).

Ví dụ:
  python3 dong-goi-ai.py --title "Tên bài" --style style.txt --style-short "pop rock, male vocal, 120 BPM" \
      --exclude "ballad, slow" --lyrics loi.txt --phat-am phat-am.json --out goi-suno.txt
--style / --style-short / --exclude / --lyrics nhận chuỗi hoặc đường dẫn tệp.
--phat-am: tệp JSON {"từ gốc": "viết theo âm"} chỉ áp dụng cho ô Lyrics.
--cong-cu suno|udio|elevenlabs: chọn bộ giới hạn ký tự mặc định và ghi chú công cụ.
Giới hạn mặc định lấy theo references/08-cong-cu-ai.md (cập nhật 11/2026, CẦN KIỂM TRA LẠI trên công cụ):
  suno: Style 1000 · Exclude 1000 · Lyrics 5000 (nguồn bên thứ ba) · Title 80 (chưa kiểm chứng)
  udio, elevenlabs: không kiểm giới hạn (0) – xem 08-cong-cu-ai.md
Đổi bằng --max-style, --max-style-short, --max-exclude, --max-lyrics, --max-title (0 = không kiểm).
Kiểm thêm cho lời tiếng Việt: dòng thiếu dấu, chữ viết tắt (ko, k, dc, j, vs…), chữ số (nên viết bằng chữ).
"""

GIOI_HAN = {"suno": dict(title=80, style=1000, short=200, exclude=1000, lyrics=5000),
            "udio": dict(title=0, style=0, short=0, exclude=0, lyrics=0),
            "elevenlabs": dict(title=0, style=0, short=0, exclude=0, lyrics=0)}
GHI_CHU = {"suno": "Suno: tải bản trên gói trả phí mới được dùng thương mại; gói Free chỉ dùng cá nhân (cần kiểm tra lại).",
           "udio": "Udio: từ 30/10/2025 đã tắt tải xuống; nền tảng cấp phép mới chưa xác nhận ra mắt – hiện chưa phát hành được bản Udio (cần kiểm tra lại).",
           "elevenlabs": "ElevenLabs Music: gói Free/Starter không được phân phối lên nền tảng nghe nhạc; Creator trở lên được; tự công bố nội dung AI (cần kiểm tra lại)."}
VIET_TAT = ["ko", "k", "dc", "đc", "j", "vs", "ng", "mik", "mn", "bt", "ntn", "trc", "r", "e", "a"]
import argparse, json, os, re, sys

def val(x):
    if x and os.path.isfile(x):
        return open(x, encoding="utf-8").read().strip()
    return (x or "").strip()

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--title", required=True); ap.add_argument("--style", required=True)
    ap.add_argument("--style-short"); ap.add_argument("--exclude"); ap.add_argument("--lyrics", required=True)
    ap.add_argument("--phat-am"); ap.add_argument("--out", default="goi-nhac-ai.txt")
    ap.add_argument("--cong-cu", choices=list(GIOI_HAN), default="suno")
    ap.add_argument("--max-title", type=int); ap.add_argument("--max-style", type=int)
    ap.add_argument("--max-style-short", type=int); ap.add_argument("--max-exclude", type=int); ap.add_argument("--max-lyrics", type=int)
    ap.add_argument("--ten-nghe-si", default="", help="danh sách tên cần chặn, cách nhau dấu phẩy")
    a = ap.parse_args()
    gh = GIOI_HAN[a.cong_cu]
    for k, attr in (("title", "max_title"), ("style", "max_style"), ("short", "max_style_short"),
                    ("exclude", "max_exclude"), ("lyrics", "max_lyrics")):
        if getattr(a, attr) is None:
            setattr(a, attr, gh[k])
    title, style, short, excl, lyr = val(a.title), val(a.style), val(a.style_short), val(a.exclude), val(a.lyrics)
    warns = []
    # Làm sạch lời cho máy: bỏ ghi chú cho người, bỏ markdown đậm
    lyr = re.sub(r"\*\*(\[[^\]]+\])\*\*", r"\1", lyr)
    lyr = re.sub(r"(?im)\((?:lớp hô|tập thể|lop ho)[:\s]*", "(", lyr)
    lyr = re.sub(r"(?m)^\s*#.*$\n?", "", lyr)
    if re.search(r"(?i)(hát lại|x\s?2\b|×\s?2|\brepeat\b|như trên)", lyr):
        warns.append("Lời có ghi chú lặp (hát lại / x2 / repeat): hãy viết đủ lời mỗi lần lặp.")
    if not re.search(r"\[[^\]]+\]", lyr):
        warns.append("Lời chưa có thẻ cấu trúc [Verse], [Chorus]…")
    long = [l for l in lyr.splitlines() if len(l) > 90 and not l.startswith("[")]
    if long:
        warns.append(f"{len(long)} dòng dài trên 90 ký tự, nên tách đôi để máy ngắt câu đúng.")
    noi_dung = [l for l in lyr.splitlines() if l.strip() and not l.strip().startswith("[")]
    thieu_dau = [l for l in noi_dung if re.fullmatch(r"[A-Za-z0-9 ,.'!?()\-]+", l.strip()) and len(l.split()) >= 4]
    if thieu_dau and len(thieu_dau) >= max(1, len(noi_dung) // 4):
        warns.append(f"{len(thieu_dau)} dòng lời không có dấu tiếng Việt: máy sẽ hát sai thanh – viết đủ dấu.")
    tat = sorted({w for l in noi_dung for w in re.findall(r"[\wÀ-ỹ]+", l.lower()) if w in VIET_TAT})
    if tat:
        warns.append(f"Có thể là chữ viết tắt: {', '.join(tat)} – viết đầy đủ để máy đọc đúng.")
    if any(re.search(r"\d", l) for l in noi_dung):
        warns.append("Lời có chữ số: viết số bằng chữ (ví dụ 'hai mươi', không phải '20').")
    if a.phat_am:
        mp = json.load(open(a.phat_am, encoding="utf-8")) if os.path.isfile(a.phat_am) else json.loads(a.phat_am)
        for k, v in mp.items():
            lyr = re.sub(rf"(?<![\w]){re.escape(k)}(?![\w])", v, lyr)
    for name in [n.strip() for n in a.ten_nghe_si.split(",") if n.strip()]:
        if re.search(re.escape(name), style + short, re.I):
            warns.append(f"Style có tên nghệ sĩ '{name}': thay bằng mô tả đặc điểm âm nhạc.")
    checks = [("Title", title, a.max_title), ("Style đầy đủ", style, a.max_style),
              ("Style rút gọn", short, a.max_style_short), ("Exclude styles", excl, a.max_exclude),
              ("Lyrics", lyr, a.max_lyrics)]
    sep = "=" * 60
    out = [f"GÓI PROMPT NHẠC AI ({a.cong_cu.upper()}) – {title}",
           "Giới hạn ký tự theo bản ghi 11/2026 – cần kiểm tra lại trên công cụ.", GHI_CHU[a.cong_cu],
           "Nhắc: âm thanh do AI tạo phải được gắn nhãn khi phát hành (Luật Trí tuệ nhân tạo 134/2025/QH15); "
           "lưu prompt này vào nhật ký sáng tạo.", ""]
    blocks = [("TITLE", title), ("STYLE – BẢN ĐẦY ĐỦ", style), ("STYLE – BẢN RÚT GỌN", short),
              ("EXCLUDE STYLES", excl), ("LYRICS", lyr)]
    for h, body in blocks:
        if body:
            out += [sep, f"{h} ({len(body)} ký tự)", sep, body, ""]
    print("| Ô | Ký tự | Giới hạn | Trạng thái |\n|---|---|---|---|")
    for n, body, mx in checks:
        if body:
            ok = (not mx) or len(body) <= mx
            print(f"| {n} | {len(body)} | {mx or 'không kiểm'} | {'đạt' if ok else 'VƯỢT'} |")
            if not ok:
                warns.append(f"{n} vượt giới hạn {len(body) - mx} ký tự.")
    if warns:
        out += [sep, "CẢNH BÁO", sep] + [f"- {w}" for w in warns]
    open(a.out, "w", encoding="utf-8").write("\n".join(out) + "\n")
    print("\n".join(f"- {w}" for w in warns) if warns else "Không có cảnh báo.")
    print(f"Đã ghi: {a.out}")

if __name__ == "__main__":
    main()
