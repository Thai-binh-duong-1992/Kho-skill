#!/usr/bin/env python3
"""Nhật ký sáng tạo: ghi lại ai đề xuất gì, người dùng chọn/sửa/viết gì ở từng bước.

Mục đích: làm chứng cứ đóng góp sáng tạo của con người (chế độ thương mại). Theo NĐ 134/2026/NĐ-CP,
sản phẩm do AI tạo hoàn toàn không có quyền tác giả; con người phải có đóng góp sáng tạo đáng kể,
mang tính quyết định và kê khai việc dùng AI khi được yêu cầu (references/17-phap-ly-phat-hanh.md).
Không phải tư vấn pháp lý.

Lệnh:
  khoi-tao  --tep nk.json --ten-bai "..." --tac-gia "..." --che-do thuong-mai|ca-nhan [--cong-cu "Claude, Suno"]
  them      --tep nk.json --buoc "2. Lời" --loai y-tuong|chon|sua|viet|duyet|tu-choi|ai-tao
            [--claude "Claude đề xuất gì"] [--nguoi-dung "người dùng quyết định/viết gì"] [--tep-kem "demo1.mp3"]
  xuat      --tep nk.json --out nhat-ky.md      (bảng Markdown + thống kê đóng góp)
  cap-nhat  --tep nk.json [--ten-bai "..."] [--tac-gia "..."] [--cong-cu "..."] [--che-do ...]   (bản 2.1)
            đổi thông tin chung, ví dụ khi bài có tên chính thức; lần đổi được ghi lại thành một mục
  sua-muc   --tep nk.json --so 12 [--loai ...] [--claude "..."] [--nguoi-dung "..."] [--tep-kem "..."] (bản 2.1)
            sửa một mục ghi nhầm; nội dung cũ được lưu trong "lich_su_sua" của mục, không mất
Bản 2.1: dấu | trong nội dung được giữ (xuất thành \\| – tao-docx.py hiểu được), không đổi thành /.

Loại đóng góp:
  y-tuong  người dùng đưa ý tưởng, chất liệu, chi tiết thật    viet   người dùng tự viết câu/đoạn
  chon     người dùng chọn giữa các phương án                   sua    người dùng sửa phương án của Claude
  duyet    người dùng duyệt nguyên phương án                    tu-choi người dùng bác bỏ phương án
  ai-tao   công cụ AI tạo (Claude, Suno, Udio, ElevenLabs…)   – ghi để kê khai minh bạch
"""
import argparse, datetime, json, os, sys

LOAI = {"y-tuong": "Ý tưởng/chất liệu của người dùng", "chon": "Người dùng chọn phương án",
        "sua": "Người dùng sửa", "viet": "Người dùng tự viết", "duyet": "Người dùng duyệt",
        "tu-choi": "Người dùng bác bỏ", "ai-tao": "Công cụ AI tạo"}
DONG_GOP_NGUOI = {"y-tuong", "chon", "sua", "viet", "tu-choi"}


def doc(tep):
    if not os.path.isfile(tep):
        sys.exit(f"Chưa có nhật ký {tep}. Chạy lệnh khoi-tao trước.")
    return json.load(open(tep, encoding="utf-8"))


def ghi(tep, data):
    json.dump(data, open(tep, "w", encoding="utf-8"), ensure_ascii=False, indent=2)


def bay_gio():
    return datetime.datetime.now().astimezone().strftime("%Y-%m-%d %H:%M %z")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="lenh", required=True)
    k = sub.add_parser("khoi-tao")
    k.add_argument("--tep", required=True); k.add_argument("--ten-bai", required=True)
    k.add_argument("--tac-gia", required=True); k.add_argument("--che-do", choices=["thuong-mai", "ca-nhan"], required=True)
    k.add_argument("--cong-cu", default="Claude")
    t = sub.add_parser("them")
    t.add_argument("--tep", required=True); t.add_argument("--buoc", required=True)
    t.add_argument("--loai", choices=list(LOAI), required=True)
    t.add_argument("--claude", default=""); t.add_argument("--nguoi-dung", default=""); t.add_argument("--tep-kem", default="")
    c = sub.add_parser("cap-nhat")
    c.add_argument("--tep", required=True); c.add_argument("--ten-bai"); c.add_argument("--tac-gia")
    c.add_argument("--cong-cu"); c.add_argument("--che-do", choices=["thuong-mai", "ca-nhan"])
    s_ = sub.add_parser("sua-muc")
    s_.add_argument("--tep", required=True); s_.add_argument("--so", type=int, required=True)
    s_.add_argument("--loai", choices=list(LOAI)); s_.add_argument("--claude"); s_.add_argument("--nguoi-dung")
    s_.add_argument("--tep-kem")
    x = sub.add_parser("xuat")
    x.add_argument("--tep", required=True); x.add_argument("--out", required=True)
    a = ap.parse_args()

    if a.lenh == "khoi-tao":
        if os.path.isfile(a.tep):
            sys.exit(f"{a.tep} đã tồn tại – không ghi đè nhật ký cũ.")
        ghi(a.tep, {"ten_bai": a.ten_bai, "tac_gia": a.tac_gia, "che_do": a.che_do,
                    "cong_cu": a.cong_cu, "tao_luc": bay_gio(), "muc": []})
        print(f"Đã tạo nhật ký: {a.tep}")
        return
    data = doc(a.tep)
    if a.lenh == "them":
        data["muc"].append({"luc": bay_gio(), "buoc": a.buoc, "loai": a.loai,
                            "claude": a.claude, "nguoi_dung": a.nguoi_dung, "tep_kem": a.tep_kem})
        ghi(a.tep, data)
        print(f"Đã ghi mục {len(data['muc'])}: [{a.buoc}] {LOAI[a.loai]}")
        return
    if a.lenh == "cap-nhat":
        doi = {k_: v for k_, v in (("ten_bai", a.ten_bai), ("tac_gia", a.tac_gia), ("cong_cu", a.cong_cu),
                                   ("che_do", a.che_do)) if v}
        if not doi:
            sys.exit("Không có gì để cập nhật (dùng --ten-bai, --tac-gia, --cong-cu hoặc --che-do).")
        mo_ta = "; ".join(f"{k_}: {data.get(k_, '')} → {v}" for k_, v in doi.items())
        data.update(doi)
        data.setdefault("lich_su_cap_nhat", []).append({"luc": bay_gio(), "thay_doi": mo_ta})
        ghi(a.tep, data)
        print(f"Đã cập nhật: {mo_ta}")
        return
    if a.lenh == "sua-muc":
        if not 1 <= a.so <= len(data["muc"]):
            sys.exit(f"Không có mục {a.so} (nhật ký có {len(data['muc'])} mục).")
        m = data["muc"][a.so - 1]
        cu = {k_: m.get(k_, "") for k_ in ("loai", "claude", "nguoi_dung", "tep_kem")}
        for k_, v in (("loai", a.loai), ("claude", a.claude), ("nguoi_dung", a.nguoi_dung), ("tep_kem", a.tep_kem)):
            if v is not None:
                m[k_] = v
        m.setdefault("lich_su_sua", []).append({"luc": bay_gio(), "cu": cu})
        ghi(a.tep, data)
        print(f"Đã sửa mục {a.so}: [{m['buoc']}] {LOAI[m['loai']]}")
        return
    # xuat
    muc = data["muc"]
    dem = {kk: sum(1 for m in muc if m["loai"] == kk) for kk in LOAI}
    nguoi = sum(dem[kk] for kk in DONG_GOP_NGUOI)
    tong_quyet_dinh = sum(dem[kk] for kk in ("chon", "sua", "viet", "duyet", "tu-choi"))
    out = [f"# Nhật ký sáng tạo – {data['ten_bai']}", "",
           f"- Tác giả (người dùng): **{data['tac_gia']}**",
           f"- Chế độ: {'Phát hành thương mại' if data['che_do'] == 'thuong-mai' else 'Cá nhân'}",
           f"- Công cụ AI đã dùng: {data['cong_cu']}",
           f"- Bắt đầu: {data['tao_luc']} · Số mục: {len(muc)}"]
    for c_ in data.get("lich_su_cap_nhat", []):
        out.append(f"- Cập nhật thông tin {c_['luc']}: {c_['thay_doi']}")
    out += ["",
           "| # | Thời điểm | Bước | Loại | Claude/AI đề xuất hoặc tạo | Người dùng quyết định, sửa, viết | Tệp kèm |",
           "|---|---|---|---|---|---|---|"]
    for i, m in enumerate(muc, 1):
        if m.get("lich_su_sua"):
            m = dict(m, buoc=m["buoc"] + f" (đã sửa {len(m['lich_su_sua'])} lần)")
        cell = lambda s: (s or "–").replace("|", "\\|").replace("\n", " ")
        out.append(f"| {i} | {m['luc']} | {cell(m['buoc'])} | {LOAI[m['loai']]} | {cell(m['claude'])} | "
                   f"{cell(m['nguoi_dung'])} | {cell(m['tep_kem'])} |")
    out += ["", "## Thống kê đóng góp", "",
            "| Loại | Số mục |", "|---|---|"] + [f"| {LOAI[kk]} | {dem[kk]} |" for kk in LOAI]
    out += ["", f"- Mục thể hiện đóng góp sáng tạo của người dùng (ý tưởng, chọn, sửa, viết, bác bỏ): **{nguoi}**",
            f"- Quyết định chủ động / tổng số lần duyệt–chọn: {tong_quyet_dinh - dem['duyet']}/{tong_quyet_dinh}"
            if tong_quyet_dinh else "- Chưa có quyết định nào được ghi.", ""]
    if data["che_do"] == "thuong-mai":
        canh = []
        if dem["viet"] + dem["sua"] == 0:
            canh.append("Chưa có mục người dùng tự viết hoặc sửa lời/nhạc: đóng góp sáng tạo của con người khó chứng minh.")
        if dem["duyet"] > dem["chon"] + dem["sua"] + dem["viet"]:
            canh.append("Phần lớn bước chỉ 'duyệt nguyên' phương án AI: nên tự sửa, tự viết các câu then chốt.")
        out += ["## Lưu ý pháp lý (không phải tư vấn pháp lý)", "",
                "- NĐ 134/2026/NĐ-CP: sản phẩm AI tạo hoàn toàn không được bảo hộ; con người phải có đóng góp đáng kể, "
                "mang tính quyết định; kê khai việc dùng AI khi được yêu cầu.",
                "- Luật Trí tuệ nhân tạo 134/2025/QH15: âm thanh do AI tạo phải được gắn nhãn.",
                "- Lưu kèm nhật ký này: bản nháp lời, demo, file dự án, prompt và bản tải về từ công cụ AI.",
                "- Xác nhận với luật sư hoặc Cục Bản quyền tác giả trước khi phát hành thương mại."]
        out += [f"- ⚠ {c}" for c in canh]
    open(a.out, "w", encoding="utf-8").write("\n".join(out) + "\n")
    print(f"Đã xuất: {a.out} ({len(muc)} mục; đóng góp người dùng: {nguoi})")


if __name__ == "__main__":
    main()
