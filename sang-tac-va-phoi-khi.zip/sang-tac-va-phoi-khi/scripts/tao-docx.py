#!/usr/bin/env python3
"""Chuyển tệp Markdown (gói bàn giao, hướng dẫn sản xuất – phát hành) sang Word .docx.

Chỉ dùng thư viện chuẩn Python 3 nên chạy được ở mọi phiên có công cụ chạy mã.
Hỗ trợ: tiêu đề #–###### (cấp 5–6 dùng kiểu cấp 4), đoạn văn, ***đậm nghiêng***, **đậm**, *nghiêng*, `mã`,
[liên kết](url), danh sách -, *, 1., việc cần làm - [ ] / - [x], bảng | a | b | (hàng tiêu đề tô màu, hàng xen kẽ;
viết "\\|" để có dấu | trong ô), khối ``` (chữ đơn cách, nền xám), trích dẫn >, đường kẻ ---.
Khổ A4, lề 2 cm, đánh số trang ở chân trang.
Bản 2.1: khi có --tieu-de mà dòng đầu tệp là tiêu đề "# …", dòng đó được bỏ để tên không bị lặp.

Ví dụ:
  python3 tao-docx.py goi-ban-giao.md goi-ban-giao.docx
  python3 tao-docx.py huong-dan.md huong-dan.docx --tieu-de "Hướng dẫn sản xuất – phát hành" --mau 2C3D84
"""
import argparse, re, zipfile
from xml.sax.saxutils import escape

W_NS = ('xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"')


class Doc:
    def __init__(self, mau):
        self.body, self.links, self.mau = [], [], mau

    def rid(self, url):
        self.links.append(url)
        return f"rIdL{len(self.links)}"

    # ---------- inline ----------
    def runs(self, text, extra=""):
        out, pos = [], 0
        pat = re.compile(r"(\*\*\*(.+?)\*\*\*|\*\*(.+?)\*\*|\*(.+?)\*|`(.+?)`|\[([^\]]+)\]\(([^)\s]+)\))")
        for m in pat.finditer(text):
            if m.start() > pos:
                out.append(self.run(text[pos:m.start()], extra))
            if m.group(2) is not None:
                out.append(self.runs(m.group(2), extra + "<w:b/><w:i/>"))
                pos = m.end()
                continue
            g = [None, None] + list(m.groups()[2:])  # dời nhóm để giữ logic cũ
            if g[2] is not None:
                out.append(self.runs(g[2], extra + "<w:b/>"))
            elif g[3] is not None:
                out.append(self.runs(g[3], extra + "<w:i/>"))
            elif g[4] is not None:
                out.append(self.run(g[4], extra + '<w:rFonts w:ascii="Consolas" w:hAnsi="Consolas"/>'
                                    '<w:shd w:val="clear" w:color="auto" w:fill="EEEEEE"/>'))
            else:
                r = self.rid(g[6])
                out.append(f'<w:hyperlink r:id="{r}">' + self.run(g[5], extra +
                           f'<w:color w:val="{self.mau}"/><w:u w:val="single"/>') + "</w:hyperlink>")
            pos = m.end()
        if pos < len(text):
            out.append(self.run(text[pos:], extra))
        return "".join(out)

    @staticmethod
    def run(t, rpr=""):
        return f'<w:r><w:rPr>{rpr}</w:rPr><w:t xml:space="preserve">{escape(t)}</w:t></w:r>'

    def para(self, text, style=None, ppr="", rpr=""):
        st = f'<w:pStyle w:val="{style}"/>' if style else ""
        self.body.append(f"<w:p><w:pPr>{st}{ppr}</w:pPr>{self.runs(text, rpr)}</w:p>")

    def table(self, rows):
        ncol = max(len(r) for r in rows)
        grid = "".join('<w:gridCol w:w="%d"/>' % (9638 // ncol) for _ in range(ncol))
        x = ['<w:tbl><w:tblPr><w:tblW w:w="5000" w:type="pct"/><w:tblBorders>' +
             "".join(f'<w:{b} w:val="single" w:sz="4" w:space="0" w:color="BFC5D2"/>'
                     for b in ("top", "left", "bottom", "right", "insideH", "insideV")) +
             '</w:tblBorders><w:tblCellMar><w:left w:w="80" w:type="dxa"/><w:right w:w="80" w:type="dxa"/>'
             '</w:tblCellMar></w:tblPr><w:tblGrid>' + grid + "</w:tblGrid>"]
        for i, r in enumerate(rows):
            r = r + [""] * (ncol - len(r))
            hdr = i == 0
            fill = self.mau if hdr else ("EEF1F8" if i % 2 == 0 else "FFFFFF")
            trpr = "<w:trPr><w:tblHeader/></w:trPr>" if hdr else ""
            cells = []
            for c in r:
                rpr = '<w:b/><w:color w:val="FFFFFF"/>' if hdr else ""
                noi_dung = self.runs(c.strip(), rpr + '<w:sz w:val="20"/>')
                cells.append(f'<w:tc><w:tcPr><w:shd w:val="clear" w:color="auto" w:fill="{fill}"/></w:tcPr>'
                             f'<w:p><w:pPr><w:spacing w:before="40" w:after="40"/></w:pPr>'
                             f'{noi_dung}</w:p></w:tc>')
            x.append(f"<w:tr>{trpr}{''.join(cells)}</w:tr>")
        x.append("</w:tbl>")
        self.body.append("".join(x))
        self.para("")


def tach_o(dong):
    """Tách một hàng bảng Markdown thành các ô; "\\|" là dấu | nằm trong ô."""
    return [c.replace("\\|", "|") for c in re.split(r"(?<!\\)\|", dong.strip().strip("|"))]


def chuyen(md, doc, tieu_de=None):
    lines = md.splitlines()
    if tieu_de:
        doc.para(tieu_de, "Title")
        for k, l in enumerate(lines):
            if l.strip():
                if re.match(r"#\s+", l.strip()):
                    lines[k] = ""  # tránh lặp tên: --tieu-de đã thay cho tiêu đề cấp 1 đầu tệp
                break
    i = 0
    while i < len(lines):
        ln = lines[i].rstrip()
        s = ln.strip()
        if s.startswith("```"):
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                doc.body.append('<w:p><w:pPr><w:pStyle w:val="Code"/></w:pPr>' +
                                Doc.run(lines[i]) + "</w:p>")
                i += 1
            i += 1
            continue
        if s.startswith("|") and i + 1 < len(lines) and re.fullmatch(r"\|?[\s:\-|]+\|?", lines[i + 1].strip()):
            rows = [tach_o(s)]
            i += 2
            while i < len(lines) and lines[i].strip().startswith("|"):
                rows.append(tach_o(lines[i]))
                i += 1
            doc.table(rows)
            continue
        m = re.match(r"(#{1,6})\s+(.*)", s)
        if m:
            doc.para(m.group(2), f"Heading{min(len(m.group(1)), 4)}")
        elif re.fullmatch(r"-{3,}|\*{3,}", s):
            doc.body.append('<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" '
                            'w:color="BFC5D2"/></w:pBdr></w:pPr></w:p>')
        elif s.startswith(">"):
            doc.para(s.lstrip("> "), "Quote")
        elif re.match(r"[-*+]\s+", s):
            lvl = (len(ln) - len(ln.lstrip())) // 2
            noi = re.sub(r"^[-*+]\s+", "", s)
            dau = "• "
            mt = re.match(r"\[( |x|X)\]\s+(.*)", noi)
            if mt:
                dau, noi = ("☐ " if mt.group(1) == " " else "☑ "), mt.group(2)
            doc.para(dau + noi, None,
                     f'<w:ind w:left="{360 + 360 * lvl}" w:hanging="240"/><w:spacing w:after="40"/>')
        elif re.match(r"\d+[.)]\s+", s):
            lvl = (len(ln) - len(ln.lstrip())) // 3
            doc.para(s, None, f'<w:ind w:left="{360 + 360 * lvl}" w:hanging="300"/><w:spacing w:after="40"/>')
        elif s:
            doc.para(s)
        i += 1


def styles(mau):
    def h(n, size, color, before):
        return (f'<w:style w:type="paragraph" w:styleId="Heading{n}"><w:name w:val="heading {n}"/>'
                f'<w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/>'
                f'<w:spacing w:before="{before}" w:after="120"/><w:outlineLvl w:val="{n-1}"/></w:pPr>'
                f'<w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:b/>'
                f'<w:color w:val="{color}"/><w:sz w:val="{size}"/></w:rPr></w:style>')
    return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles {W_NS}>'
            '<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" '
            'w:cs="Times New Roman" w:eastAsia="Times New Roman"/><w:sz w:val="24"/><w:lang w:val="vi-VN"/>'
            '</w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="288" w:lineRule="auto"/>'
            '</w:pPr></w:pPrDefault></w:docDefaults>'
            '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>'
            '<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/>'
            f'<w:pPr><w:spacing w:after="240"/><w:pBdr><w:bottom w:val="single" w:sz="12" w:space="4" w:color="{mau}"/>'
            '</w:pBdr></w:pPr><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:b/>'
            f'<w:color w:val="{mau}"/><w:sz w:val="40"/></w:rPr></w:style>'
            + h(1, 32, mau, 360) + h(2, 28, mau, 280) + h(3, 24, "333F48", 200) + h(4, 22, "333F48", 160) +
            '<w:style w:type="paragraph" w:styleId="Quote"><w:name w:val="Quote"/><w:basedOn w:val="Normal"/>'
            f'<w:pPr><w:ind w:left="360"/><w:pBdr><w:left w:val="single" w:sz="18" w:space="8" w:color="{mau}"/>'
            '</w:pBdr><w:shd w:val="clear" w:color="auto" w:fill="F3F5FA"/></w:pPr><w:rPr><w:i/></w:rPr></w:style>'
            '<w:style w:type="paragraph" w:styleId="Code"><w:name w:val="Code"/><w:basedOn w:val="Normal"/>'
            '<w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/><w:shd w:val="clear" w:color="auto" '
            'w:fill="F2F2F2"/></w:pPr><w:rPr><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas"/><w:sz w:val="18"/>'
            '</w:rPr></w:style></w:styles>')


def viet(path, doc, mau):
    footer = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr {W_NS}><w:p><w:pPr><w:jc w:val="center"/>'
              '</w:pPr><w:r><w:t xml:space="preserve">Trang </w:t></w:r><w:r><w:fldChar w:fldCharType="begin"/></w:r>'
              '<w:r><w:instrText xml:space="preserve"> PAGE </w:instrText></w:r><w:r><w:fldChar w:fldCharType="end"/>'
              '</w:r></w:p></w:ftr>')
    sect = ('<w:sectPr><w:footerReference w:type="default" r:id="rIdF"/><w:pgSz w:w="11906" w:h="16838"/>'
            '<w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="567" w:footer="567" '
            'w:gutter="0"/></w:sectPr>')
    document = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document {W_NS}><w:body>'
                + "".join(doc.body) + sect + "</w:body></w:document>")
    rels = ['<Relationship Id="rIdS" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" '
            'Target="styles.xml"/>',
            '<Relationship Id="rIdF" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" '
            'Target="footer1.xml"/>']
    for k, url in enumerate(doc.links, 1):
        rels.append(f'<Relationship Id="rIdL{k}" Type="http://schemas.openxmlformats.org/officeDocument/2006/'
                    f'relationships/hyperlink" Target="{escape(url, {chr(34): "&quot;"})}" TargetMode="External"/>')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/'
                   'package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-'
                   'package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
                   '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.'
                   'wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/'
                   'vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/footer1.xml" '
                   'ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>')
        z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://'
                   'schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.'
                   'openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
                   '</Relationships>')
        z.writestr("word/_rels/document.xml.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships '
                   'xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + "".join(rels) + "</Relationships>")
        z.writestr("word/document.xml", document)
        z.writestr("word/styles.xml", styles(mau))
        z.writestr("word/footer1.xml", footer)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("vao"); ap.add_argument("ra")
    ap.add_argument("--tieu-de", help="tiêu đề lớn đầu tài liệu (tuỳ chọn)")
    ap.add_argument("--mau", default="2C3D84", help="màu nhấn dạng hex, mặc định 2C3D84 (xanh chàm)")
    a = ap.parse_args()
    d = Doc(a.mau.lstrip("#").upper())
    chuyen(open(a.vao, encoding="utf-8").read(), d, a.tieu_de)
    viet(a.ra, d, d.mau)
    print(f"Đã tạo: {a.ra} ({len(d.body)} khối, {len(d.links)} liên kết)")


if __name__ == "__main__":
    main()
