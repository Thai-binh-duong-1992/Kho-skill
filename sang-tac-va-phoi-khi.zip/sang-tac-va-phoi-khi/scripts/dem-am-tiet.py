#!/usr/bin/env python3
"""Đếm âm tiết từng câu, so các đoạn cùng loại, kiểm tra vần và thanh cuối câu (bản 2.1).

Đầu vào: tệp lời có nhãn phần dạng [Verse 1], [Chorus]… Mỗi câu một dòng.
Ví dụ:
  python3 dem-am-tiet.py loi.txt --lang vi
  python3 dem-am-tiet.py lyrics.txt --lang en --bo-ngoac
--lang vi : mỗi chữ = 1 âm tiết; báo vần, thanh, bằng/trắc của chữ cuối.
--lang en : ước lượng âm tiết theo cụm nguyên âm (sai số ±1).
--lang auto: chữ có dấu tiếng Việt hoặc thuộc tiếng Việt → 1; còn lại ước lượng như tiếng Anh.
--bo-ngoac: bỏ phần trong ngoặc đơn (bè, tiếng hô) khi đếm.
--chi-tiet: (tiếng Việt) in nhóm cao độ thanh từng chữ: 3 cao (sắc, ngã) · 2 trung (ngang) ·
            1 thấp (huyền) · 0 rất thấp (hỏi, nặng) – quy tắc [BC] theo điểm kết thúc của thanh.
Bản 2.0 thêm: so vần bỏ âm đệm (hoa–xa cùng vần), cảnh báo vần khép -p/-t/-c/-ch ở cuối câu
(vần trắc, không ngân được), cảnh báo cùng chữ cái vần nhưng khác nhóm bằng/trắc (lạc vận).
Bản 2.1 thêm:
  - bỏ qua dòng giai điệu "M: …" và dòng hợp âm "HA: …" (dùng chung tệp lead sheet được);
  - cảnh báo chữ số (số âm tiết đang đếm thiếu), chữ viết tắt, từ mượn (Honda, show…) có thể hát thành 2 âm tiết trở lên;
  - nhận vần thông (gợi ý [QU]): lâu–nhau, Tre–quê, tóc–dốc… dùng chung chữ cái trong sơ đồ vần, liệt kê riêng;
  - --phuong-ngu bac|trung|nam: nhóm thanh theo giọng (nam: ngã gộp với hỏi ở mức thấp), khớp kiem-tra-thanh-nhac.py.
Kiểm hướng giai điệu theo thanh: dùng kiem-tra-thanh-nhac.py; kiểm thi luật: kiem-tra-thi-luat.py.
"""
import argparse, os, re, sys, unicodedata
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _tieng_viet import phan_tich, so_van, nhom_phuong_ngu, la_am_tiet_viet, VIET_TAT  # noqa: E402

TONE = {"̀": "huyền", "́": "sắc", "̉": "hỏi", "̃": "ngã", "̣": "nặng"}
BANG = {"ngang", "huyền"}
INIT = ["ngh", "ng", "nh", "ch", "gh", "gi", "kh", "ph", "th", "tr", "qu",
        "b", "c", "d", "đ", "g", "h", "k", "l", "m", "n", "p", "r", "s", "t", "v", "x"]
VI_MARK = re.compile(r"[ăâđêôơưàáảãạằắẳẵặầấẩẫậèéẻẽẹềếểễệìíỉĩịòóỏõọồốổỗộờớởỡợùúủũụừứửữựỳýỷỹỵ]", re.I)
WORD = re.compile(r"[^\W\d_]+(?:['’][^\W\d_]+)?", re.U)

def tone_and_base(w):
    nfd = unicodedata.normalize("NFD", w.lower())
    tone = "ngang"
    for ch, t in TONE.items():
        if ch in nfd:
            tone = t
    base = unicodedata.normalize("NFC", "".join(c for c in nfd if c not in TONE))
    return tone, base

def van(w):
    tone, base = tone_and_base(w)
    for ini in INIT:
        if base.startswith(ini) and len(base) > len(ini):
            rest = base[len(ini):]
            if ini == "gi" and rest[0] not in "aăâeêoôơuưy":
                rest = "i" + rest
            return rest, tone
    return base, tone

def en_syl(w):
    w = w.lower().strip("'’")
    if len(w) <= 3:
        return 1
    w = re.sub(r"(?:[^laeiouy]es|ed|[^laeiouy]e)$", "", w)
    w = re.sub(r"^y", "", w)
    return max(1, len(re.findall(r"[aeiouy]{1,2}", w)))

def count(line, lang):
    words = WORD.findall(line)
    if lang == "vi":
        return len(words), words
    if lang == "en":
        return sum(en_syl(w) for w in words), words
    return sum(1 if VI_MARK.search(w) or len(w) <= 4 else en_syl(w) for w in words), words

def parse(text, bo_ngoac):
    secs, cur = [], None
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        m = re.fullmatch(r"\*{0,2}\[([^\]]+)\]\*{0,2}(.*)", line)
        if m:
            name = m.group(1).split(":")[0].strip()
            # thẻ mô tả như [Soft piano] ngay sau nhãn phần → bỏ qua
            if cur is not None and not cur[1] and not re.match(r"(?i)(intro|verse|pre|chorus|post|hook|bridge|rap|outro|break|interlude|drop|build|final|solo|instrumental|key|end|đoạn|điệp)", name):
                continue
            cur = (name, []); secs.append(cur)
            rest = m.group(2).strip()
            if rest:
                cur[1].append(rest)
            continue
        if re.match(r"(?i)^(M|HA)\s*:", line):
            continue  # dòng giai điệu / hợp âm của lead sheet, không phải lời
        if cur is None:
            cur = ("(không nhãn)", []); secs.append(cur)
        if bo_ngoac:
            line = re.sub(r"\([^)]*\)", "", line).strip()
        if line:
            cur[1].append(line)
    return secs

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file"); ap.add_argument("--lang", default="auto", choices=["vi", "en", "auto"])
    ap.add_argument("--bo-ngoac", action="store_true"); ap.add_argument("--chi-tiet", action="store_true")
    ap.add_argument("--phuong-ngu", choices=["bac", "trung", "nam"], default="bac",
                    help="nhóm thanh theo giọng (mặc định bac); nam: ngã gộp với hỏi ở mức thấp [QU]")
    ap.add_argument("--nguong", type=int, default=2,
                    help="độ lệch âm tiết tối đa cho phép giữa câu tương ứng (mặc định 2)")
    a = ap.parse_args()
    secs = parse(open(a.file, encoding="utf-8").read(), a.bo_ngoac)
    groups = defaultdict(list)
    for name, lines in secs:
        if not lines:
            continue
        print(f"\n## {name}")
        letters, scheme, data, bt_theo_chu = {}, [], [], defaultdict(set)
        dai_dien, van_thong = {}, []   # chữ cái → âm tiết đại diện; các cặp vần thông
        for ln in lines:
            n, words = count(ln, a.lang)
            info, canh = "", []
            if a.lang != "en":
                so = re.findall(r"\d+", ln)
                if so:
                    canh.append(f"có chữ số {', '.join(so)} – chưa được đếm, viết bằng chữ")
                tat = sorted({w for w in words if w.lower() in VIET_TAT})
                if tat:
                    canh.append(f"có thể là chữ viết tắt: {', '.join(tat)}")
                muon = [w for w in words if not la_am_tiet_viet(w)]
                if muon and a.lang == "vi":
                    canh.append(f"từ mượn/không phải âm tiết Việt: {', '.join(muon)} – khi hát có thể thành 2 âm tiết trở lên")
            if words and a.lang != "en":
                pt = phan_tich(words[-1])
                v, t = pt["van"], pt["thanh"]
                key = pt["van_so_sanh"]
                if key not in letters:
                    chu_thong = None
                    for chu_cai, dd in dai_dien.items():
                        kq, cung_bt = so_van(pt, dd)
                        if kq == "thong?" and cung_bt:  # vần thông phải cùng nhóm bằng/trắc (12-thi-luat.md)
                            chu_thong = chu_cai
                            break
                    if chu_thong:
                        letters[key] = chu_thong
                        van_thong.append(f"{dai_dien[chu_thong]['chu']} – {words[-1]}")
                    else:
                        letters[key] = chr(ord("A") + len(set(letters.values()))) if len(set(letters.values())) < 26 else "?"
                        dai_dien[letters[key]] = pt
                scheme.append(letters[key])
                bt_theo_chu[letters[key]].add(pt["bang_trac"])
                info = f"  | cuối: {words[-1]} (vần -{v}, {t}, {'bằng' if t in BANG else 'trắc'}, nhóm cao độ {nhom_phuong_ngu(pt, a.phuong_ngu)})"
                if pt["khep"]:
                    info += " · VẦN KHÉP: không đặt nốt ngân dài (N5)"
            data.append(n)
            print(f"{n:>3}  {ln}{info}")
            for c in canh:
                print(f"     ! {c}")
            if a.chi_tiet and words and a.lang != "en":
                print("     nhóm thanh: " + " ".join(str(nhom_phuong_ngu(phan_tich(w), a.phuong_ngu)) for w in words))
        if scheme:
            print(f"Sơ đồ vần: {''.join(scheme)}")
            if van_thong:
                print(f"Vần thông (gợi ý [QU], tai nghe vẫn thấy vần): {'; '.join(van_thong)}")
            lac = [c for c, s_ in bt_theo_chu.items() if len(s_) > 1 and scheme.count(c) > 1]
            if lac:
                print(f"Cảnh báo: vần {', '.join(lac)} trộn bằng và trắc – hiệp vần cần cùng nhóm bằng/trắc (V6).")
        base = re.sub(r"\s*\d+$", "", name).lower()
        groups[base].append((name, data))
    warn = 0
    print("\n## So sánh các đoạn cùng loại")
    for base, items in groups.items():
        if len(items) < 2:
            continue
        ref_name, ref = items[0]
        for name, d in items[1:]:
            if len(d) != len(ref):
                print(f"- {name}: {len(d)} câu, khác {ref_name} ({len(ref)} câu)"); warn += 1
            for i, (x, y) in enumerate(zip(ref, d), 1):
                if abs(x - y) > a.nguong:
                    print(f"- {name} câu {i}: {y} âm tiết, {ref_name} câu {i}: {x} (lệch {abs(x-y)})"); warn += 1
    print("Không có chênh lệch vượt ngưỡng." if not warn else f"Tổng {warn} cảnh báo.")

if __name__ == "__main__":
    main()
