#!/usr/bin/env python3
"""Bộ kiểm thử hồi quy cho các script của skill sang-tac-va-phoi-khi (bản 2.2).

Chạy: python3 scripts/kiem-thu-script.py        (in ĐẠT/LỖI từng ca, mã thoát 1 nếu có ca lỗi)
Mỗi ca ghi lại một lỗi đã từng gặp hoặc một hành vi phải giữ. Thêm ca mới khi sửa script.
Chỉ dùng thư viện chuẩn; tạo tệp tạm trong thư mục tạm của hệ thống.
"""
import os, subprocess, sys, tempfile, zipfile

TM = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable
CA = []


def chay(script, *args):
    r = subprocess.run([PY, os.path.join(TM, script), *args], capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


def ca(ten):
    def dk(f):
        CA.append((ten, f)); return f
    return dk


def tep(thu_muc, ten, noi_dung):
    p = os.path.join(thu_muc, ten)
    open(p, "w", encoding="utf-8").write(noi_dung)
    return p


def main():
    loi = 0
    with tempfile.TemporaryDirectory() as d:
        for ten, f in CA:
            try:
                ok, ghi_chu = f(d)
            except Exception as e:  # noqa: BLE001
                ok, ghi_chu = False, f"ngoại lệ: {e}"
            print(f"{'ĐẠT' if ok else 'LỖI'}  {ten}" + ("" if ok else f"  → {ghi_chu}"))
            loi += not ok
    print(f"\nTổng: {len(CA) - loi}/{len(CA)} ca đạt.")
    sys.exit(1 if loi else 0)


# ---------- Các ca ----------
@ca("Mọi script chạy được -h")
def _(d):
    hong = [s for s in sorted(os.listdir(TM)) if s.endswith(".py") and not s.startswith("_")
            and s != "kiem-thu-script.py" and chay(s, "-h")[0] != 0]
    return not hong, f"lỗi: {hong}"


@ca("Thi luật: lục bát chuẩn không lỗi")
def _(d):
    p = tep(d, "lb.txt", "Trâu ơi ta bảo trâu này\nTrâu ra ngoài ruộng trâu cày với ta\n")
    return "Không có lỗi" in chay("kiem-tra-thi-luat.py", p)[1], "báo lỗi sai"


@ca("Thi luật: bắt lỗi chữ 4 câu bát là bằng")
def _(d):
    p = tep(d, "lb.txt", "Trâu ơi ta bảo trâu này\nTrâu ra ngoài đồng trâu cày với ta\n")
    return "chữ 4 «đồng»" in chay("kiem-tra-thi-luat.py", p)[1], "không bắt lỗi"


@ca("Thi luật: bỏ qua dòng M: và HA:")
def _(d):
    p = tep(d, "lb.txt", "HA: C | G\nTrâu ơi ta bảo trâu này\nM: C4 C4 C4 C4 C4 C4\nTrâu ra ngoài ruộng trâu cày với ta\n")
    out = chay("kiem-tra-thi-luat.py", p, "--the", "luc-bat")[1]
    return "HA:" not in out and "Không có lỗi" in out, out[-300:]


@ca("Thi luật 2.2: khổ Thơ Mới 7 chữ không bị tự nhận là Đường luật (Đây thôn Vĩ Dạ)")
def _(d):
    p = tep(d, "vi.txt", "Sao anh không về chơi thôn Vĩ\nNhìn nắng hàng cau nắng mới lên\n"
                          "Vườn ai mướt quá xanh như ngọc\nLá trúc che ngang mặt chữ điền\n")
    out = chay("kiem-tra-thi-luat.py", p)[1]
    return "Thể thơ: tu-do" in out and "Không có lỗi" in out and "--the duong-luat" in out, out[:300]


@ca("Thi luật 2.2: lục bát biến thể nhận vần nhà–bà ở chữ 7 câu 9 chữ")
def _(d):
    p = tep(d, "nl.txt", "Ngó lên nuộc lạt mái nhà\nBao nhiêu nuộc lạt nhớ ông bà bấy nhiêu\n")
    out = chay("kiem-tra-thi-luat.py", p)[1]
    return "luc-bat-bt" in out and "chữ 7" in out and "«nhà» – «bà»" in out, out[:300]


@ca("Thi luật 2.2: niêm tứ tuyệt chỉ là ghi chú, không thành lỗi")
def _(d):
    p = tep(d, "tt.txt", "Sao anh không về chơi thôn Vĩ\nNhìn nắng hàng cau nắng mới lên\n"
                          "Vườn ai mướt quá xanh như ngọc\nLá trúc che ngang mặt chữ điền\n")
    out = chay("kiem-tra-thi-luat.py", p, "--the", "duong-luat")[1]
    loi = out.split("## Lỗi thi luật")[1]
    return "Thất niêm" not in loi and "Niêm tứ tuyệt" in out, out[-400:]


@ca("Thi luật 2.2: tiếng đệm trong {…} không được đếm chữ")
def _(d):
    p = tep(d, "dem.txt", "Con cò {ơ} bay lả bay la\nBay qua {tình bằng} cửa phủ bay về Đồng Đăng\n")
    out = chay("kiem-tra-thi-luat.py", p)[1]
    return "Thể thơ: luc-bat" in out and "[6]" in out and "[8]" in out, out[:300]


@ca("Thi luật 2.2: hát nói bắt câu cuối không phải 6 chữ thanh bằng")
def _(d):
    cau = ["Nghĩ đời người như giấc mộng"] * 10 + ["Cuộc vui này còn mãi nữa đây"]
    p = tep(d, "hn.txt", "\n".join(cau) + "\n")
    out = chay("kiem-tra-thi-luat.py", p, "--the", "hat-noi")[1]
    return "Khổ đủ 11 câu" in out and "câu 6 chữ" in out, out[-400:]


@ca("Đếm âm tiết: bỏ qua dòng M: và HA: (lỗi bản 2.0)")
def _(d):
    p = tep(d, "a.txt", "[A]\nHA: F | G\nTừ bàn tay che mưa năm ấy\nM: E4 E4 G4 G4 A4 A4 C5_3\n")
    out = chay("dem-am-tiet.py", p, "--lang", "vi")[1]
    return "M:" not in out and "HA:" not in out and "  7  Từ bàn tay" in out, out


@ca("Đếm âm tiết: cảnh báo chữ số (lỗi bản 2.0: đếm thiếu không báo)")
def _(d):
    p = tep(d, "a.txt", "ko biết 2 đứa mình\n")
    out = chay("dem-am-tiet.py", p, "--lang", "vi")[1]
    return "chữ số 2" in out and "viết tắt: ko" in out, out


@ca("Đếm âm tiết: cảnh báo từ mượn Honda")
def _(d):
    p = tep(d, "a.txt", "Từ chiếc Honda Tây Ninh lên Sài Gòn\n")
    return "Honda" in chay("dem-am-tiet.py", p, "--lang", "vi")[1].split("cuối:")[-1], "không cảnh báo"


@ca("Đếm âm tiết: nhận vần thông lâu–nhau, cùng bằng/trắc")
def _(d):
    p = tep(d, "a.txt", "Em ngồi sau nghiêng vai anh thật lâu\nĐến bây giờ mình mãi bên nhau\n")
    out = chay("dem-am-tiet.py", p, "--lang", "vi")[1]
    return "Sơ đồ vần: AA" in out and "lâu – nhau" in out, out


@ca("Đếm âm tiết: không ghép vần thông khi khác bằng/trắc")
def _(d):
    p = tep(d, "a.txt", "Em ngồi thật lâu\nAnh đến ẩn náu\n")  # âu–au gần âm nhưng bằng/trắc khác
    return "Sơ đồ vần: AB" in chay("dem-am-tiet.py", p, "--lang", "vi")[1], "ghép sai"


@ca("Đếm âm tiết: --phuong-ngu nam xếp ngã vào mức thấp")
def _(d):
    p = tep(d, "a.txt", "mãi mãi\n")
    out = chay("dem-am-tiet.py", p, "--lang", "vi", "--chi-tiet", "--phuong-ngu", "nam")[1]
    return "nhóm thanh: 0 0" in out, out


@ca("Thanh–nhạc: bắt cặp ngược hướng, T6, N5, thiếu nốt")
def _(d):
    p = tep(d, "a.txt", "[A]\nĐến bây giờ\nM: C4 E4 G4\nChờ anh dưới nhà trọ\nM: C4 D4 E4 D4 G4_4\n"
                        "Nắng chiều trên mái tóc\nM: C4 D4 E4 G4 A4_4\nAnh hai ơi\nM: A4 A4\n")
    out = chay("kiem-tra-thanh-nhac.py", p)[1]
    return all(k in out for k in ("NGƯỢC", "T6", "N5", "nốt.")), out[-500:]


@ca("Thanh–nhạc: có dòng lỗi dữ liệu thì không kết luận ĐẠT (lỗi bản 2.0)")
def _(d):
    p = tep(d, "a.txt", "[A]\nTừ bàn tay che mưa năm ấy\nM: E4 E4 G4 G4 A4 A4 C5_3\nAnh hai ơi\nM: A4 A4\n")
    out = chay("kiem-tra-thanh-nhac.py", p)[1]
    return "CHƯA KẾT LUẬN ĐƯỢC" in out, out[-300:]


@ca("Thanh–nhạc: T11 cảnh báo nhảy lên lớn giữa hai chữ cùng mức thanh")
def _(d):
    p = tep(d, "a.txt", "[A]\nAnh ơi xa\nM: C4 G4 G4\n")
    return "T11" in chay("kiem-tra-thanh-nhac.py", p)[1], "không cảnh báo"


@ca("Thanh–nhạc: bỏ qua dòng HA:")
def _(d):
    p = tep(d, "a.txt", "[A]\nHA: F | G\nTừ bàn tay che mưa năm ấy\nM: E4 E4 G4 G4 A4 A4 C5_3\n")
    return "HA:" not in chay("kiem-tra-thanh-nhac.py", p)[1], "còn đọc HA: như lời"


@ca("Dịch giọng: số La Mã và hợp âm có bass")
def _(d):
    a = chay("chuyen-giong.py", "--key", "Am", "--roman", "i iv V7 i")[1]
    b = chay("chuyen-giong.py", "--chords", "Csus2 Am7 F/A Bb", "--semitones", "-3")[1]
    return "Am – Dm – E7 – Am" in a and "Asus2 – F#m7 – D/F# – G" in b, a + b


@ca("Thời lượng: 80 BPM 4/4, 70 ô = 3:30")
def _(d):
    return "3:30" in chay("tinh-thoi-luong.py", "--bpm", "80", "--sections", "A:70")[1], "sai"


@ca("Thời lượng: BPM 0 báo lỗi rõ, không traceback (lỗi bản 2.0)")
def _(d):
    rc, out = chay("tinh-thoi-luong.py", "--bpm", "0", "--sections", "A:4")
    return rc != 0 and "Traceback" not in out, out


@ca("Thời lượng: tên đoạn có dấu phẩy, ngăn bằng ;")
def _(d):
    out = chay("tinh-thoi-luong.py", "--bpm", "80", "--sections", "Verse 1, nam:8;Chorus:8")[1]
    return "| Verse 1, nam | 8 |" in out, out


@ca("Gói AI: bắt viết tắt, chữ số, tên nghệ sĩ, vượt giới hạn")
def _(d):
    ly = tep(d, "ly.txt", "[Verse]\nko biết năm 2005\n")
    out = chay("dong-goi-ai.py", "--cong-cu", "suno", "--title", "T", "--style", "x" * 1200 + " Son Tung",
               "--lyrics", ly, "--ten-nghe-si", "Son Tung", "--out", os.path.join(d, "g.txt"))[1]
    return all(k in out for k in ("viết tắt", "chữ số", "Son Tung", "VƯỢT")), out


@ca("Nhật ký: khởi tạo, ghi, cập nhật tên bài, sửa mục, giữ dấu |")
def _(d):
    nk = os.path.join(d, "nk.json"); md = os.path.join(d, "nk.md")
    chay("nhat-ky-sang-tac.py", "khoi-tao", "--tep", nk, "--ten-bai", "Tạm", "--tac-gia", "A", "--che-do", "thuong-mai")
    chay("nhat-ky-sang-tac.py", "them", "--tep", nk, "--buoc", "1", "--loai", "chon", "--nguoi-dung", "x | y")
    chay("nhat-ky-sang-tac.py", "cap-nhat", "--tep", nk, "--ten-bai", "Bàn tay che mưa")
    chay("nhat-ky-sang-tac.py", "sua-muc", "--tep", nk, "--so", "1", "--loai", "viet")
    rc, _ = chay("nhat-ky-sang-tac.py", "khoi-tao", "--tep", nk, "--ten-bai", "B", "--tac-gia", "A", "--che-do", "ca-nhan")
    chay("nhat-ky-sang-tac.py", "xuat", "--tep", nk, "--out", md)
    out = open(md, encoding="utf-8").read()
    return rc != 0 and "Bàn tay che mưa" in out and "x \\| y" in out and "Người dùng tự viết" in out, out


@ca("Word: ô bảng có \\|, đậm nghiêng, việc cần làm, không lặp tiêu đề")
def _(d):
    md = tep(d, "a.md", "# Tên\n\n***đn*** và **đ**\n\n- [ ] việc\n\n| A | B |\n|---|---|\n| x \\| y | z |\n")
    out_p = os.path.join(d, "a.docx")
    chay("tao-docx.py", md, out_p, "--tieu-de", "Tên")
    x = zipfile.ZipFile(out_p).read("word/document.xml").decode("utf-8")
    return (x.count(">Tên<") == 1 and "<w:b/><w:i/>" in x and "☐ việc" in x and "x | y" in x
            and x.count("<w:tc>") == 4), "sai cấu trúc"


@ca("Bản nghe thử: tạo được WAV có thời lượng > 0")
def _(d):
    p = tep(d, "g.txt", "[Chorus – song ca]\nHA: F | G\nTừ bàn tay che mưa năm ấy\nM: E4 E4 G4 G4 A4 A4 C5_3\n")
    w = os.path.join(d, "n.wav")
    out = chay("tao-ban-nghe-thu.py", p, "--bpm", "80", "--truong-do-mac-dinh", "0.5", "--out", w)[1]
    import wave
    with wave.open(w) as f:
        giay = f.getnframes() / f.getframerate()
    return giay > 5, out


if __name__ == "__main__":
    main()
