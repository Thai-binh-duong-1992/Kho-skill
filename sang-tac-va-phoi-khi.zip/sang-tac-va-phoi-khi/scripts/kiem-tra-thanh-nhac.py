#!/usr/bin/env python3
"""Kiểm tra tương ứng thanh điệu – giai điệu cho lời tiếng Việt (bộ kiểm tra T và N).

Quy tắc [BC] (Kirby & Ladd): xếp thanh theo điểm kết thúc
  sắc, ngã = cao (3) · ngang = trung (2) · huyền = thấp (1) · hỏi, nặng = rất thấp (0)
Với mỗi cặp âm tiết liền nhau: hướng thanh (lên/xuống/ngang) so với hướng giai điệu.
  cùng hướng  : giai điệu đi cùng chiều thanh, hoặc cả hai đứng yên
  xiên        : một bên đứng yên, bên kia di chuyển (chấp nhận được, nhất là chuỗi thanh ngang)
  NGƯỢC       : giai điệu đi ngược chiều thanh → rủi ro nghe nhầm lời (cần sửa)
Ngưỡng tự kiểm [QU]: cùng hướng khoảng 70–80% trở lên, ngược hướng dưới khoảng 10%.
Chỗ ngắt câu (dấu "/" trong lời, hoặc hết dòng) là nơi an toàn: cặp vắt qua ngắt câu không chấm.

ĐỊNH DẠNG TỆP ĐẦU VÀO (UTF-8):
  [Verse 1]
  Chiều về trên cánh đồng xa / lúa vàng
  M: G4 E4 G4 A4 C5 A4_2 C5 A4
  - Dòng lời bình thường; dòng ngay sau bắt đầu "M:" là giai điệu, mỗi âm tiết một nốt.
  - Nốt: C4 (Đô giữa), F#3, Bb4, hoặc solfège Sol4, Đô5. Hậu tố _n = trường độ n phách (mặc định 1).
  - Luyến nhiều nốt trên một chữ: nối bằng "-" (vd G4-A4); script dùng nốt đầu để tính hướng
    đi vào và nốt cuối để tính hướng đi ra.
  - Dòng lời không có dòng M: chỉ được phân tích thanh (không chấm hướng).
  - Dòng "HA: F | G" (hợp âm, dùng cho tao-ban-nghe-thu.py) được bỏ qua.

Tuỳ chọn phương ngữ (T10) --phuong-ngu bac|trung|nam (mặc định bac – lưới Kirby & Ladd đo trên giọng Bắc):
  nam   : hỏi và ngã gộp (cùng mã 0); cặp hỏi–ngã không chấm hướng [QU]
  trung : Huế/Bình Trị Thiên gộp hỏi–ngã, khoảng cách thanh hẹp → chỉ báo, không chấm cặp hỏi–ngã [QU]

Các cờ khác: T4 chữ có rủi ro cặp tối thiểu nằm trong cặp ngược hướng (ưu tiên sửa);
T6 thanh nặng trên nốt ngân dài; T8 nốt cao nhất mỗi đoạn rơi vào hỏi/nặng (mở rộng [QU]: cả huyền);
N5/V8 vần khép (-p, -t, -c, -ch) trên nốt ngân dài hoặc nốt cuối câu.
Bản 2.1 thêm:
  T11 [QU] – cặp chữ CÙNG mức thanh (ví dụ ngang → ngang) mà giai điệu NHẢY LÊN từ quãng 3 trưởng (≥ 4 nửa cung)
        vào chữ thanh ngang hoặc huyền: tai dễ nghe chữ sau thành thanh đi lên (sắc/ngã), nhất là khi người hát
        hoặc máy AI vuốt giọng (ví dụ "sau" thành "sáu"). Cờ nhắc dặn ca sĩ vào nốt thẳng và nghe kỹ chữ đó ở
        Bước 9. Lỗi vuốt giọng còn do cách hát, nên script không bắt được hết: vẫn phải nghe bằng tai.
  Có dòng lỗi dữ liệu (thiếu nốt, nốt không đọc được) → không kết luận ĐẠT, vì các dòng đó chưa được chấm.

Ví dụ:
  python3 kiem-tra-thanh-nhac.py giai-dieu.txt
  python3 kiem-tra-thanh-nhac.py giai-dieu.txt --phuong-ngu nam --json ket-qua.json
"""
import argparse, json, os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _tieng_viet import phan_tich, tach_tu, not_sang_midi, dau_hieu, NHOM_TEN, CAP_DE_NHAM_DA_GHI_NHAN  # noqa: E402

TU_RUI_RO = {w for cap in CAP_DE_NHAM_DA_GHI_NHAN for w in cap}

HUONG = {1: "lên", -1: "xuống", 0: "ngang"}


def doc_tep(path):
    doan, cur = [], None
    lines = open(path, encoding="utf-8").read().splitlines()
    i = 0
    while i < len(lines):
        s = lines[i].strip()
        i += 1
        if not s:
            continue
        m = re.fullmatch(r"\[([^\]]+)\]", s)
        if m:
            cur = {"ten": m.group(1), "dong": []}
            doan.append(cur)
            continue
        if s.upper().startswith("M:"):
            continue  # đã xử lý cùng dòng lời
        if re.match(r"(?i)^HA\s*:", s):
            continue  # dòng hợp âm (bản 2.1, dùng chung với tao-ban-nghe-thu.py)
        if cur is None:
            cur = {"ten": "(không nhãn)", "dong": []}
            doan.append(cur)
        mel = None
        if i < len(lines) and lines[i].strip().upper().startswith("M:"):
            mel = lines[i].strip()[2:].split()
            i += 1
        cur["dong"].append((s, mel))
    return doan


def doc_not(tok):
    """'G4-A4_2' → (midi_vao, midi_ra, truong_do, so_not)."""
    tdo = 1.0
    m = re.fullmatch(r"(.+?)_(\d+(?:[.,]\d+)?)", tok)
    if m:
        tok, tdo = m.group(1), float(m.group(2).replace(",", "."))
    notes = [not_sang_midi(x) for x in tok.split("-")]
    if any(n is None for n in notes):
        return None
    return notes[0], notes[-1], tdo, len(notes)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file")
    ap.add_argument("--json", help="ghi kết quả chi tiết ra tệp JSON")
    ap.add_argument("--nguong-nguoc", type=float, default=10.0, help="ngưỡng %% ngược hướng (mặc định 10)")
    ap.add_argument("--nguong-cung", type=float, default=70.0, help="ngưỡng %% cùng hướng tối thiểu (mặc định 70)")
    ap.add_argument("--not-dai", type=float, default=2.0, help="trường độ (phách) coi là nốt ngân dài (mặc định 2)")
    ap.add_argument("--phuong-ngu", choices=["bac", "trung", "nam"], default="bac")
    ap.add_argument("--quang-vuot", type=int, default=4,
                    help="T11: bước nhảy lên tối thiểu (nửa cung) giữa hai chữ cùng mức thanh để cảnh báo (mặc định 4)")
    a = ap.parse_args()

    tong = {"cung": 0, "xien": 0, "nguoc": 0, "bo": 0}
    canh_bao, loi, ket_qua = [], [], []
    for d in doan_list(a.file):
        print(f"\n## {d['ten']}")
        cao_nhat = None  # (midi, âm tiết, dòng)
        for dong, mel in d["dong"]:
            # tách theo "/" để biết ranh giới ngắt câu
            khuc = [tach_tu(x) for x in dong.split("/")]
            chu, ngat_sau = [], set()
            for k in khuc:
                chu += k
                if chu:
                    ngat_sau.add(len(chu) - 1)
            at = [phan_tich(c) for c in chu]
            if a.phuong_ngu == "nam":
                for x in at:
                    if x["thanh"] == "ngã":
                        x["nhom"] = 0
            nhom_str = " ".join(str(x["nhom"]) for x in at)
            print(f"\n{dong}")
            print(f"  Nhóm thanh: {nhom_str}   (3 cao · 2 trung · 1 thấp · 0 rất thấp)")
            if mel is None:
                print("  (không có dòng M: – chỉ phân tích thanh)")
                continue
            if len(mel) != len(at):
                msg = f"{d['ten']}: «{dong}» có {len(at)} âm tiết nhưng {len(mel)} nốt."
                loi.append(msg)
                print("  LỖI: " + msg)
                continue
            notes = [doc_not(t) for t in mel]
            if any(n is None for n in notes):
                msg = f"{d['ten']}: «{dong}» có nốt không đọc được: {' '.join(mel)}"
                loi.append(msg)
                print("  LỖI: " + msg)
                continue
            dong_kq = []
            for j in range(len(at)):
                vao, ra, tdo, sn = notes[j]
                if cao_nhat is None or max(vao, ra) > cao_nhat[0]:
                    cao_nhat = (max(vao, ra), at[j], dong)
                if at[j]["thanh"] == "nặng" and tdo >= a.not_dai:
                    canh_bao.append(f"T6 – chữ nặng «{at[j]['chu']}» ngân {tdo:g} phách ở «{dong}»: nặng nên là nốt ngắn, thấp.")
                if at[j]["khep"] and (tdo >= a.not_dai or (j == len(at) - 1 and tdo >= 1.5)):
                    canh_bao.append(f"N5 – «{at[j]['chu']}» (âm cuối -{at[j]['am_cuoi']}, vần khép) ngân {tdo:g} phách "
                                    f"ở «{dong}»: âm tắc không ngân được, đổi chữ hoặc rút ngắn nốt.")
                if j == len(at) - 1:
                    continue
                if j in ngat_sau:
                    tong["bo"] += 1
                    dong_kq.append((at[j]["chu"], at[j + 1]["chu"], "bỏ qua (ngắt câu)"))
                    continue
                if a.phuong_ngu in ("nam", "trung") and {at[j]["thanh"], at[j + 1]["thanh"]} <= {"hỏi", "ngã"}:
                    tong["bo"] += 1
                    dong_kq.append((at[j]["chu"], at[j + 1]["chu"], f"bỏ qua (hỏi–ngã gộp ở giọng {a.phuong_ngu})"))
                    continue
                h_thanh = dau_hieu(at[j + 1]["nhom"] - at[j]["nhom"])
                h_nhac = dau_hieu(notes[j + 1][0] - ra)
                buoc = notes[j + 1][0] - ra
                if h_thanh == 0 and at[j + 1]["thanh"] in ("ngang", "huyền") and buoc >= a.quang_vuot:
                    canh_bao.append(f"T11 [QU] – «{at[j]['chu']} {at[j+1]['chu']}» ở «{dong}»: nhảy lên {buoc} nửa cung vào chữ "
                                    f"thanh {at[j+1]['thanh']} «{at[j+1]['chu']}» → dễ bị vuốt thành sắc/ngã; dặn hát thẳng nốt, "
                                    f"nghe kỹ chữ này ở bản thu.")
                if h_thanh == h_nhac:
                    loai = "cung"
                elif h_thanh == 0 or h_nhac == 0:
                    loai = "xien"
                else:
                    loai = "nguoc"
                tong[loai] += 1
                nhan = {"cung": "cùng hướng", "xien": "xiên", "nguoc": "NGƯỢC"}[loai]
                dong_kq.append((at[j]["chu"], at[j + 1]["chu"],
                                f"{nhan} (thanh {HUONG[h_thanh]}, nhạc {HUONG[h_nhac]})"))
                if loai == "nguoc":
                    rui_ro = [w["chu"] for w in (at[j], at[j + 1]) if w["chu"].lower() in TU_RUI_RO]
                    if rui_ro:
                        canh_bao.append(f"T4 (ưu tiên) – chữ dễ nghe nhầm {', '.join(rui_ro)} nằm trong cặp ngược hướng ở «{dong}».")
                    canh_bao.append(f"T2 – cặp «{at[j]['chu']} {at[j+1]['chu']}» ở «{dong}»: thanh {HUONG[h_thanh]} "
                                    f"({NHOM_TEN[at[j]['nhom']]}→{NHOM_TEN[at[j+1]['nhom']]}) nhưng giai điệu "
                                    f"{HUONG[h_nhac]} → rủi ro nghe nhầm; đổi nốt, đổi chữ hoặc đặt ngắt câu.")
            for x, y, kq in dong_kq:
                print(f"  {x} → {y}: {kq}")
            ket_qua.append({"doan": d["ten"], "dong": dong, "cap": dong_kq})
        if cao_nhat and cao_nhat[1]["nhom"] <= 1:
            goi_y = "ngang hoặc sắc, âm cuối mở hoặc mũi" + ("; ngã cũng được với giọng Bắc" if a.phuong_ngu == "bac" else "")
            muc = "T8" if cao_nhat[1]["thanh"] in ("hỏi", "nặng") else "T8 (mở rộng [QU] cho huyền/ngã gộp)"
            canh_bao.append(f"{muc} – nốt cao nhất của {d['ten']} rơi vào chữ «{cao_nhat[1]['chu']}» "
                            f"(thanh {cao_nhat[1]['thanh']}) ở «{cao_nhat[2]}». [QU] Nên đặt đỉnh vào chữ {goi_y}; tránh hỏi, nặng.")

    cham = tong["cung"] + tong["xien"] + tong["nguoc"]
    print("\n## Tổng hợp")
    if cham:
        pc = {k: 100 * tong[k] / cham for k in ("cung", "xien", "nguoc")}
        print(f"Số cặp được chấm: {cham} (bỏ qua {tong['bo']} cặp vắt qua ngắt câu)")
        print(f"Cùng hướng: {pc['cung']:.0f}% · Xiên: {pc['xien']:.0f}% · Ngược: {pc['nguoc']:.0f}%")
        print("Tham chiếu [BC]: ngữ liệu tân nhạc Kirby & Ladd ≈ 77% cặp cùng hướng; ngược hướng hiếm.")
        dat = pc["nguoc"] < a.nguong_nguoc and pc["cung"] >= a.nguong_cung
        ket = "ĐẠT" if dat else "CHƯA ĐẠT"
        if loi and dat:
            ket = f"CHƯA KẾT LUẬN ĐƯỢC – {len(loi)} dòng lỗi dữ liệu chưa được chấm (xem dưới)"
        print(f"Kết luận theo ngưỡng [QU] (cùng ≥ {a.nguong_cung:g}%, ngược < {a.nguong_nguoc:g}%): {ket}")
    else:
        print("Chưa có cặp nào được chấm (thiếu dòng M:).")
    if loi:
        print("\n## Lỗi dữ liệu")
        print("\n".join(f"- {x}" for x in loi))
    print("\n## Cảnh báo cần xử lý")
    print("\n".join(f"- {x}" for x in canh_bao) if canh_bao else "Không có.")
    if a.json:
        json.dump({"tong": tong, "canh_bao": canh_bao, "loi": loi, "chi_tiet": ket_qua},
                  open(a.json, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        print(f"\nĐã ghi: {a.json}")


def doan_list(path):
    return doc_tep(path)


if __name__ == "__main__":
    main()
