#!/usr/bin/env python3
"""Dịch giọng hợp âm và đổi số La Mã sang tên hợp âm.

Ví dụ:
  python3 chuyen-giong.py --chords "Am F C G" --semitones 2        # lên 1 cung
  python3 chuyen-giong.py --chords "C G/B Am7 Fmaj7" --to-key D --from-key C
  python3 chuyen-giong.py --key Am --roman "i iv V7 i"
  python3 chuyen-giong.py --key Eb --roman "I V/vi vi IV ii7 V7sus4 bVI bVII I"
Quy ước số La Mã: viết hoa = trưởng, viết thường = thứ, ° hoặc dim = giảm, + = tăng,
tiền tố b/# để hạ/nâng bậc, hậu tố (7, maj7, 9, sus4, add9…) giữ nguyên, V/vi = dominant phụ.
"""
import argparse, re

SHARP = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"]
FLAT  = ["C","Db","D","Eb","E","F","Gb","G","Ab","A","Bb","B"]
PC = {n: i for i, n in enumerate(SHARP)} | {n: i for i, n in enumerate(FLAT)} | {"Cb":11,"Fb":4,"E#":5,"B#":0}
FLAT_KEYS = {"F","Bb","Eb","Ab","Db","Gb","Cb","Dm","Gm","Cm","Fm","Bbm","Ebm","Abm"}

def names_for(key):
    return FLAT if key in FLAT_KEYS or (len(key) > 1 and key[1] == "b") else SHARP

def tr_note(n, k, table):
    return table[(PC[n] + k) % 12]

CH = re.compile(r"^([A-G][#b]?)([^/]*)(?:/([A-G][#b]?))?$")

def transpose(ch, k, table):
    m = CH.match(ch)
    if not m:
        return ch
    r, q, b = m.groups()
    out = tr_note(r, k, table) + q
    if b:
        out += "/" + tr_note(b, k, table)
    return out

MAJ = [0, 2, 4, 5, 7, 9, 11]
MIN = [0, 2, 3, 5, 7, 8, 10]
RN = {"i":1,"ii":2,"iii":3,"iv":4,"v":5,"vi":6,"vii":7}
RX = re.compile(r"^([b#]?)(VII|VI|V|IV|III|II|I|vii|vi|v|iv|iii|ii|i)(°|dim|\+|ø)?(.*)$")

def roman(tok, key):
    minor = key.endswith("m")
    tonic = key[:-1] if minor else key
    table = names_for(key)
    if "/" in tok:  # dominant phụ, ví dụ V/vi, V7/V, vii°/ii
        a, b = tok.split("/", 1)
        tgt_root = CH.match(roman(b, key)).group(1)
        return roman(a, tgt_root)  # bậc a tính trong giọng trưởng của hợp âm đích
    m = RX.match(tok)
    if not m:
        return tok
    acc, deg, qual, ext = m.groups()
    scale = MAJ if (acc or not minor) else MIN  # có b/# thì tính theo thang trưởng song song
    semis = PC[tonic] + scale[RN[deg.lower()] - 1] + (-1 if acc == "b" else 1 if acc == "#" else 0)
    if acc == "b" and not minor:
        table = FLAT
    elif acc == "#":
        table = SHARP
    root = table[semis % 12]
    if qual == "ø":
        return root + "m7b5"
    if qual in ("°", "dim"):
        return root + ("dim" + ext if ext else "dim")
    if qual == "+":
        return root + "aug" + ext
    if deg.islower():
        return root + (ext if ext.startswith("m") else "m" + ext)
    return root + ext

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--chords", help="chuỗi hợp âm cách nhau bởi dấu cách hoặc –")
    ap.add_argument("--semitones", type=int, help="số nửa cung (+ lên, − xuống)")
    ap.add_argument("--from-key"); ap.add_argument("--to-key")
    ap.add_argument("--key", help="giọng cho số La Mã, ví dụ C, Am, Eb")
    ap.add_argument("--roman", help="chuỗi số La Mã")
    a = ap.parse_args()
    if a.roman:
        if not a.key:
            ap.error("--roman cần --key")
        toks = a.roman.replace("–", " ").replace("-", " ").split()
        print(f"Giọng {a.key}: " + " – ".join(roman(t, a.key) for t in toks))
    if a.chords:
        if a.semitones is None:
            if not (a.from_key and a.to_key):
                ap.error("cần --semitones hoặc --from-key và --to-key")
            k = (PC[a.to_key.rstrip("m")] - PC[a.from_key.rstrip("m")]) % 12
            if k > 6: k -= 12
            target = a.to_key
        else:
            k = a.semitones; target = None
        toks = a.chords.replace("–", " ").split()
        table = names_for(target) if target else (FLAT if k in (1, 3, 5, 8, 10, -2, -4, -7, -9, -11) else SHARP)
        print(f"Dịch {k:+d} nửa cung: " + " – ".join(transpose(t, k, table) for t in toks))

if __name__ == "__main__":
    main()
