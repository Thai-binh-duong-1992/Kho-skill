#!/usr/bin/env python3
"""Tạo bản nghe thử (WAV, thêm MP3 nếu máy có ffmpeg) từ tệp giai điệu M: và hợp âm HA: – bản 2.1.

Dùng ở Bước 6 để người dùng KHÔNG đọc được nốt vẫn nghe và chọn phương án giai điệu (máy đánh nốt trên nền
hợp âm, không phải bản phối). Chỉ dùng thư viện chuẩn Python 3.

ĐỊNH DẠNG TỆP (cùng tệp với kiem-tra-thanh-nhac.py; dòng HA: là tuỳ chọn, đặt NGAY TRƯỚC dòng lời):
  [Chorus – song ca]
  HA: F | G
  Từ bàn tay che mưa năm ấy
  M: E4 E4 G4 G4 A4 A4 C5_3
  - HA: hợp âm theo ô nhịp, ngăn ô bằng "|"; nhiều hợp âm trong một ô ngăn bằng dấu cách (chia đều ô).
    Đọc được: C, Cm, C7, Cmaj7, Cm7, Csus2, Csus4, Cadd9, Cdim, Caug, C/E, F#m, Bb…
  - M: mỗi chữ một nốt (C4 = Đô giữa, F#3, Bb4, Sol4…); _n = n phách; nốt nối "-" là luyến.
  - Nốt không ghi trường độ = --truong-do-mac-dinh phách (mặc định 1, cùng quy ước kiem-tra-thanh-nhac.py).
  - Mỗi dòng lời bắt đầu ở đầu khung --o-moi-dong ô (mặc định 2); dòng dài hơn khung thì dòng sau lùi lại.

Giọng: đoạn có tên chứa "nam"/"male" hát thấp một quãng tám; "song ca"/"duet" hát cả hai quãng tám;
còn lại hát đúng cao độ ghi. Đoạn "[Intro]", "[Outro]"… không có dòng lời vẫn phát hợp âm nếu có dòng HA: riêng.

Ví dụ:
  python3 tao-ban-nghe-thu.py giai-dieu.txt --bpm 80 --out nghe-thu.wav
  python3 tao-ban-nghe-thu.py giai-dieu.txt --bpm 80 --doan "Chorus" --truong-do-mac-dinh 0.5 --out dk.wav
Bản nghe thử chỉ để so đường đi giai điệu; không đánh giá được chất giọng, phối khí hay luyến láy thật.
"""
import argparse, array, math, os, re, shutil, subprocess, sys, wave

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _tieng_viet import not_sang_midi  # noqa: E402

SR = 22050
NOT_GOC = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}
CHAT = [("maj7", [0, 4, 7, 11]), ("m7", [0, 3, 7, 10]), ("add9", [0, 4, 7, 14]), ("sus2", [0, 2, 7]),
        ("sus4", [0, 5, 7]), ("dim", [0, 3, 6]), ("aug", [0, 4, 8]), ("m", [0, 3, 7]), ("7", [0, 4, 7, 10]),
        ("", [0, 4, 7])]


def hz(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def doc_hop_am(ten):
    """'F#m7/C#' → danh sách số MIDI (bè trầm + hợp âm quanh quãng 3–4). None nếu không đọc được."""
    m = re.fullmatch(r"([A-G])([#b]?)([^/]*)(?:/([A-G])([#b]?))?", ten.strip())
    if not m:
        return None
    goc = NOT_GOC[m.group(1)] + {"#": 1, "b": -1, "": 0}[m.group(2)]
    chat = m.group(3)
    quang = next((q for k, q in CHAT if chat == k), None)
    if quang is None:
        return None
    bass = goc if not m.group(4) else NOT_GOC[m.group(4)] + {"#": 1, "b": -1, "": 0}[m.group(5)]
    return [36 + bass % 12] + [52 + (goc + q - 4) % 12 + 4 for q in quang]


def doc_tep(path):
    doan, cur, ha_cho = [], None, None
    for raw in open(path, encoding="utf-8"):
        s = raw.strip()
        if not s:
            continue
        m = re.fullmatch(r"\[(.+)\]", s)
        if m:
            cur = {"ten": m.group(1), "dong": []}
            doan.append(cur); ha_cho = None
            continue
        if cur is None:
            cur = {"ten": "(không nhãn)", "dong": []}; doan.append(cur)
        if re.match(r"(?i)^HA\s*:", s):
            ha_cho = s.split(":", 1)[1].strip()
            continue
        if re.match(r"(?i)^M\s*:", s):
            if cur["dong"]:
                cur["dong"][-1]["mel"] = s.split(":", 1)[1].split()
            continue
        cur["dong"].append({"loi": s, "mel": None, "ha": ha_cho}); ha_cho = None
    return doan


class Tron:
    def __init__(self, giay):
        self.buf = array.array("f", bytes(4 * int(giay * SR + SR)))

    def them(self, bat_dau, song_am):
        i0 = int(bat_dau * SR)
        if i0 + len(song_am) > len(self.buf):
            self.buf.extend(array.array("f", bytes(4 * (i0 + len(song_am) - len(self.buf)))))
        for k, v in enumerate(song_am):
            self.buf[i0 + k] += v


def giong_hat(f, dai, amp):
    n = int(dai * SR)
    out = array.array("f", bytes(4 * n))
    w = 2 * math.pi * f / SR
    for k in range(n):
        t = k / SR
        rung = 0.004 * f / 5.2 * math.sin(2 * math.pi * 5.2 * t) * min(1.0, t / 0.4)
        ph = w * k + 2 * math.pi * rung
        env = min(1.0, t / 0.04) * max(0.0, min(1.0, (dai - t) / 0.08))
        out[k] = amp * env * (math.sin(ph) + 0.45 * math.sin(2 * ph) + 0.25 * math.sin(3 * ph))
    return out


def nen(notes, dai, amp=0.06):
    n = int(dai * SR)
    out = array.array("f", bytes(4 * n))
    ws = [2 * math.pi * hz(m) / SR for m in notes]
    for k in range(n):
        t = k / SR
        env = math.exp(-0.9 * t) * min(1.0, t / 0.02) * max(0.0, min(1.0, (dai - t) / 0.05))
        out[k] = amp * env * sum(math.sin(w * k) for w in ws)
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file")
    ap.add_argument("--bpm", type=float, required=True)
    ap.add_argument("--nhip", type=int, default=4, help="số phách mỗi ô (mặc định 4)")
    ap.add_argument("--o-moi-dong", type=float, default=2, help="số ô dành cho mỗi dòng lời (mặc định 2)")
    ap.add_argument("--truong-do-mac-dinh", type=float, default=1.0, help="phách cho nốt không ghi _n (mặc định 1)")
    ap.add_argument("--doan", help="chỉ phát các đoạn có tên chứa chuỗi này (không phân biệt hoa thường)")
    ap.add_argument("--dich", type=int, default=0, help="dịch giọng cả bài bao nhiêu nửa cung (vd -2)")
    ap.add_argument("--out", required=True, help="tệp .wav đầu ra (có ffmpeg thì tạo thêm .mp3 cùng tên)")
    a = ap.parse_args()
    if a.bpm <= 0 or a.o_moi_dong <= 0:
        sys.exit("BPM và --o-moi-dong phải lớn hơn 0.")
    phach = 60 / a.bpm
    o = a.nhip * phach
    doan = [d for d in doc_tep(a.file) if not a.doan or a.doan.lower() in d["ten"].lower()]
    if not doan:
        sys.exit("Không có đoạn nào để phát (kiểm tra tên đoạn hoặc --doan).")
    tron = Tron(60)
    t, loi, canh = 0.0, [], []
    for d in doan:
        ten = d["ten"].lower()
        if any(k in ten for k in ("song ca", "duet")):
            dich_giong = [0, -12]
        elif re.search(r"\b(nam|male)\b", ten):
            dich_giong = [-12]
        else:
            dich_giong = [0]
        for dong in d["dong"]:
            khung = t
            if dong["ha"]:
                o_list = [x.split() for x in dong["ha"].split("|")]
                for j, cac in enumerate(o_list):
                    for q, ten_ha in enumerate(cac):
                        hop = doc_hop_am(ten_ha)
                        if hop is None:
                            loi.append(f"Không đọc được hợp âm «{ten_ha}» ở «{dong['loi']}»"); continue
                        dai = o / len(cac)
                        tron.them(khung + j * o + q * dai, nen([x + a.dich for x in hop], dai))
            ket_thuc = khung
            if dong["mel"]:
                pos = khung
                for tok in dong["mel"]:
                    tdo = a.truong_do_mac_dinh
                    mm = re.fullmatch(r"(.+?)_(\d+(?:[.,]\d+)?)", tok)
                    if mm:
                        tok, tdo = mm.group(1), float(mm.group(2).replace(",", "."))
                    phan = tok.split("-")
                    for p in phan:
                        m = not_sang_midi(p)
                        dai = tdo * phach / len(phan)
                        if m is None:
                            loi.append(f"Không đọc được nốt «{p}» ở «{dong['loi']}»")
                        else:
                            for s in dich_giong:
                                tron.them(pos, giong_hat(hz(m + a.dich + s), dai, 0.22 if s == 0 else 0.17))
                        pos += dai
                ket_thuc = pos
                if pos - khung > a.o_moi_dong * o + 1e-6:
                    canh.append(f"«{dong['loi']}» dài {(pos - khung) / phach:g} phách, quá khung {a.o_moi_dong:g} ô – dòng sau lùi lại.")
            t = max(khung + a.o_moi_dong * o, ket_thuc)
    du_lieu = tron.buf[: int((t + 1.5) * SR)]
    dinh = max(1e-9, max(abs(x) for x in du_lieu))
    pcm = array.array("h", (int(32767 * x / dinh * 0.9) for x in du_lieu))
    with wave.open(a.out, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
    print(f"Đã tạo: {a.out} ({t:.1f} giây, {a.bpm:g} BPM, {len(doan)} đoạn)")
    if shutil.which("ffmpeg"):
        mp3 = os.path.splitext(a.out)[0] + ".mp3"
        subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", a.out, "-b:a", "128k", mp3], check=False)
        if os.path.isfile(mp3):
            print(f"Đã tạo: {mp3}")
    for x in canh:
        print(f"- Lưu ý: {x}")
    for x in loi:
        print(f"- LỖI: {x}")


if __name__ == "__main__":
    main()
