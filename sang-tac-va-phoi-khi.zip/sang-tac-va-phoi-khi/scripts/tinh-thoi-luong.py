#!/usr/bin/env python3
"""Tính mốc thời gian từng phần bài hát từ BPM, nhịp và số ô nhịp.

Ví dụ:
  python3 tinh-thoi-luong.py --bpm 128 --meter 4/4 --sections "Intro:8,Verse 1:8,Pre-Chorus:4,Chorus:12"
  python3 tinh-thoi-luong.py --bpm 60 --meter 6/8 --sections "Verse:16,Chorus:16"   # BPM theo phách chấm
  python3 tinh-thoi-luong.py --bpm 128 --target 210            # cần bao nhiêu ô cho 3:30
  python3 tinh-thoi-luong.py --bpm 80 --sections "Verse 1, nam:8;Chorus:8"   # tên có dấu phẩy → ngăn bằng ";"
Bản 2.1: kiểm tra BPM > 0, nhịp hợp lệ, số ô > 0; danh sách phần ngăn bằng "," hoặc ";" (có ";" thì chỉ tách theo ";").
"""
import argparse, sys

def beats_per_bar(meter: str) -> float:
    try:
        n, d = (int(x) for x in meter.split("/"))
    except ValueError:
        sys.exit(f"Sai nhịp: {meter!r} (ví dụ 4/4, 3/4, 6/8)")
    if n <= 0 or d not in (1, 2, 4, 8, 16):
        sys.exit(f"Sai nhịp: {meter!r} – tử số > 0, mẫu số 1, 2, 4, 8 hoặc 16")
    # Nhịp kép (6/8, 9/8, 12/8): BPM tính theo phách chấm → số phách = n/3
    if d == 8 and n % 3 == 0 and n >= 6:
        return n / 3
    if d == 8:  # nhịp lẻ x/8: BPM tính theo nốt móc đơn
        return n
    return n * 4 / d  # x/4, x/2: quy về nốt đen

def fmt(t: float) -> str:
    m, s = divmod(round(t), 60)
    return f"{m}:{s:02d}"

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--bpm", type=float, required=True)
    ap.add_argument("--meter", default="4/4", help="4/4, 3/4, 2/4, 6/8, 12/8, 7/8…")
    ap.add_argument("--sections", help='"Tên:số_ô,Tên:số_ô,…"')
    ap.add_argument("--target", type=float, help="thời lượng mong muốn (giây) → số ô nhịp cần")
    a = ap.parse_args()
    if a.bpm <= 0:
        sys.exit("BPM phải lớn hơn 0.")
    bar = beats_per_bar(a.meter) * 60 / a.bpm
    print(f"1 ô nhịp {a.meter} ở {a.bpm:g} BPM = {bar:.3f} giây")
    if a.target:
        print(f"Cần khoảng {a.target / bar:.1f} ô nhịp cho {fmt(a.target)}")
    if not a.sections:
        return
    t = 0.0
    total_bars = 0
    sep = ";" if ";" in a.sections else ","
    items = []
    for item in a.sections.split(sep):
        if not item.strip():
            continue
        name, _, n = item.rpartition(":")
        try:
            n = float(n)
        except ValueError:
            sys.exit(f"Sai định dạng: {item!r} (cần Tên:số_ô; tên có dấu phẩy thì ngăn các phần bằng ';')")
        if n <= 0 or not name.strip():
            sys.exit(f"Sai định dạng: {item!r} (cần tên phần và số ô > 0)")
        items.append((name, n))
    print(f"\n| Phần | Số ô | Bắt đầu | Kết thúc | Dài (giây) |\n|---|---|---|---|---|")
    for name, n in items:
        d = n * bar
        print(f"| {name.strip()} | {n:g} | {fmt(t)} | {fmt(t + d)} | {d:.1f} |")
        t += d
        total_bars += n
    print(f"\nTổng: {total_bars:g} ô nhịp = {fmt(t)} ({t:.1f} giây)")

if __name__ == "__main__":
    main()
