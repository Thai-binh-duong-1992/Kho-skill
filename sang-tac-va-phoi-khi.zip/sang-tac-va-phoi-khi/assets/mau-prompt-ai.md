# Mẫu gói nhập liệu cho công cụ nhạc AI (bản 2.0)

> Tệp mẫu của skill sang-tac-va-phoi-khi 2.0. Đọc `references/08-cong-cu-ai.md` trước (giới hạn ký tự, thẻ, điều khoản, ngày cập nhật – mọi thông tin công cụ **cần kiểm tra lại**). Không ghi tên nghệ sĩ, ban nhạc, bài hát thật. Thứ tự: **Suno (đầy đủ)** → **ElevenLabs Music (rút gọn)** → **Udio (rút gọn, kèm cảnh báo)**. Kiểm ký tự và xuất .txt: `scripts/dong-goi-ai.py --cong-cu suno|elevenlabs|udio`.

---

## A. SUNO – gói đầy đủ

### 1. Title
```text
<Tên bài có dấu>
```

### 2. Style – bản đầy đủ (tiếng Anh; mở đầu bằng ngôn ngữ và phương ngữ)
```text
Vietnamese-language <genre + subgenre>, sung with a <Northern (Hanoi) / Central (Hue) / Southern (Saigon)> Vietnamese accent, clear Vietnamese diction, accurate tones. <era/region color>, <BPM> BPM, <meter>, <key/mode>. <3–5 lead instruments, e.g. dan tranh arpeggios, dan bau melody, nylon guitar, soft strings>. <vocal: gender, perceived age, voice type, timbre, technique, e.g. warm female alto, gentle vibrato, light melisma on held notes>. <mood words>. <structure notes: e.g. sparse verse, full chorus, dan bau solo in interlude>. <production: live band / polished radio mix / lo-fi>.
```
Ghi chú: với nhạc Việt, cấu trúc lấy theo thể loại và thế hệ (references/14-hoa-am-viet-bai-mau.md) – ví dụ tập mẫu 37 bài **không có** nâng tông ở điệp khúc cuối, nên chỉ thêm "key change" khi người dùng muốn.

### 2b. Style – bản rút gọn (dưới 200 ký tự)
```text
Vietnamese <genre>, <accent>, <vocal>, <2–3 instruments>, <BPM> BPM, <mood>
```

### 3. Exclude styles
```text
<thể loại lệch>, heavy autotune, English lyrics, Chinese vocals, <nhạc cụ lệch màu, ví dụ EDM drop cho bài trữ tình>
```

### 4. Lyrics (đã qua 10.3 và 10.3b của 08-cong-cu-ai.md)
```text
[Intro]
[<mô tả ngắn: nhạc cụ, không khí>]

[Verse 1]
<mỗi câu một dòng, chữ thường, đủ dấu, không viết tắt, số viết bằng chữ>

[Pre-Chorus]
...

[Chorus]
<viết đầy đủ>

[Verse 2]
...

[Chorus]
<viết đầy đủ lại, không ghi "x2">

[Bridge]
[<mô tả: ví dụ dan bau solo, soft>]
...

[Final Chorus]
<đầy đủ>

[Outro]
...
[End]
```

### 5. Gợi ý giọng (Persona/Voice nếu giao diện có; nếu không, gộp vào Style) + Vocal Gender
```text
<giới, tuổi cảm nhận, loại giọng, âm sắc, kỹ thuật, phương ngữ>
```

### 6. Thiết lập More Options (gợi ý, cần thử; mô tả bằng thấp/vừa/cao, không bịa số)
| Thiết lập | Gợi ý |
|---|---|
| Mô hình | v6 cho bản chính; v6-wild để thử ý lạ; v6-mini khi dùng gói Free (cần kiểm tra lại) |
| Loại trừ phong cách (Exclude) | Dán ô Exclude ở mục 3 |
| Giới tính giọng hát (Vocal Gender) | Theo người hát; song ca để trống, phân vai bằng thẻ trong Lyrics |
| Thời lượng (Duration) | **Tùy chỉnh** theo `scripts/tinh-thoi-luong.py` (Tự động hay kéo dài intro) |
| Chế độ Max | Tắt khi nháp; bật ở lượt bản chính (bài > 2 phút); tốn thêm credit |
| Độ kỳ lạ (Weirdness) | Thấp cho nhạc truyền thống, trữ tình (khoảng 15–20% [QU – nguồn thứ ba]) |
| Ảnh hưởng phong cách (Style Influence) | Cao khi Style viết kỹ (khoảng 75–80% [QU – nguồn thứ ba]) |
| Đa dạng (Variety) | 0 / Tắt khi Style viết kỹ (mặc định "Bình thường" sẽ viết lại Style) |
| Cá nhân hóa (My Taste) | Tắt để kết quả khớp prompt trong nhật ký |
| Cây đũa phép | Không bấm sau khi đã dán Style |

Giải thích đầy đủ từng nút cho người dùng: `references/08-cong-cu-ai.md` mục 10.6a.

### 7. Phiên bản và biến thể
| Phiên bản | Nội dung | Ghi chú |
|---|---|---|
| A – chính | Style đầy đủ | Tạo 2–4 lượt |
| B | Style rút gọn | Để so độ tự do của máy |
| C – biến thể phối | Đổi nhạc cụ chủ đạo hoặc mật độ (acoustic vs full band) | |
| D – tuỳ chọn | v6-wild hoặc tempo ±8 BPM | |

Nghe và chấm trên nền tảng (phát âm, chữ nghe nhầm, câu móc, đủ cấu trúc, tông, kết bài, thời lượng); **chỉ tải bản thắng** vì có giới hạn lượt tải. Bài định phát hành: chỉ dùng bản tải từ **gói trả phí** (cần kiểm tra lại điều khoản).

---

## B. ELEVENLABS MUSIC – gói rút gọn

**Cách 1 – prompt văn bản (giao diện):**
```text
Vietnamese-language <genre>, <accent>, clear Vietnamese diction, <BPM> BPM, <instruments>, <vocal>, <mood>. Duration <giây hoặc auto>. Lyrics begin at <x> seconds.
```
Dán lời (đã qua 10.3b) ngay sau prompt.

**Cách 2 – composition plan (API):** theo khung JSON ở 08-cong-cu-ai.md mục 10.7 (mỗi đoạn 3–120 giây, tối đa 30 đoạn; style tiếng Anh; lời tiếng Việt; chỉ dẫn trong `{…}`).

Nhắc: gói Free/Starter không được phân phối lên nền tảng nghe nhạc; Creator trở lên được; tự công bố nội dung AI (cần kiểm tra lại).

---

## C. UDIO – gói rút gọn (kèm cảnh báo)

> **Cảnh báo (cần kiểm tra lại – 11/2026):** Udio đã tắt tải xuống từ 30/10/2025; nền tảng cấp phép mới chưa xác nhận ra mắt → bài tạo trên Udio hiện **chưa phát hành được**. Chỉ dùng để phác thảo, nghe thử.

```text
Title: <tên bài>
Prompt: <Style rút gọn, có ngôn ngữ và phương ngữ>
Lyrics: <như mục A.4>
```

---

## Bảng viết theo âm (chỉ áp dụng cho ô Lyrics của máy; bản trình chiếu giữ chữ gốc)
```json
{"Claude": "Clốt", "AI": "Ây Ai", "OK": "ô kê"}
```

## Từ khóa giọng hát hữu ích (tiếng Anh cho ô Style)
- Giới, tuổi: male, female, boy, girl, child, young, mature, elderly
- Loại giọng: soprano, mezzo, alto, tenor, baritone, bass, choir, duet
- Chất giọng: breathy, raspy, powerful, warm, bright, nasal, operatic, whispery
- Kỹ thuật: belting, falsetto, vibrato, melisma, ad-libs, rap, spoken word, harmonies, gang vocals
- Nhạc Việt: bolero-style ornamentation, cai luong vocal ornaments, folk-style melisma, quan ho call-and-response

## Nhắc pháp lý (ghi vào gói bàn giao, không chặn quá trình)
- Gắn nhãn âm thanh do AI tạo khi phát hành (Luật Trí tuệ nhân tạo 134/2025/QH15).
- Lưu toàn bộ prompt, lời, thiết lập, phiên bản vào nhật ký sáng tạo (NĐ 134/2026/NĐ-CP).
