# Danh sách tự kiểm nhanh 20 điểm trước khi giao (bản 2.0)

> Bản rút gọn để soát nhanh. Bài phát hành thương mại hoặc bài tiếng Việt quan trọng: chạy đủ `assets/checklist-tong-hop.md` (T, N, V, L, I, A–I). Khi xung đột, theo quy tắc [BC].

- [ ] 1\. Đủ mọi nội dung bắt buộc trong brief; chế độ (cá nhân/thương mại) đã ghi rõ
- [ ] 2\. Lời nguyên bản, không trùng câu móc, giai điệu nhận ra được của bài còn bản quyền
- [ ] 3\. Ý cốt lõi nói được trong một câu; câu móc ở vị trí mạnh, lặp ít nhất 3 lần (L1, L8)
- [ ] 4\. Số âm tiết các câu tương ứng giữa các đoạn lệch không quá 2 (V2)
- [ ] 5\. Vần đúng vị trí, hai tiếng hiệp vần cùng nhóm bằng/trắc; không vần khép -p/-t/-c/-ch ở nốt ngân (V5, V6, V8)
- [ ] 6\. Tiếng Việt: hướng giai điệu không ngược hướng thanh theo nhóm điểm kết thúc (sắc/ngã cao · ngang trung · huyền thấp · hỏi/nặng rất thấp); ngược hướng dưới khoảng 10% – đã chạy `kiem-tra-thanh-nhac.py` (T2, T3)
- [ ] 7\. Thể thơ cố định (lục bát, song thất…) đã chạy `kiem-tra-thi-luat.py`; lục bát đúng luật trầm bổng chữ 6/8 câu bát (V3, V4)
- [ ] 8\. Chi tiết cảm quan cụ thể, không sáo rỗng, không câu giải thích thừa (L2, L3, L10)
- [ ] 9\. BPM, nhịp, cấu trúc, hệ hoà âm đúng chất thể loại và thế hệ (trước 2000 / sau 2014)
- [ ] 10\. Thời lượng tính bằng script, đúng yêu cầu
- [ ] 11\. Âm vực giai điệu nằm trong vùng hát thoải mái; nốt cao trào mang thanh ngang hoặc sắc (T8)
- [ ] 12\. Hợp âm đúng giọng, chuyển giọng có chuẩn bị
- [ ] 13\. Mỗi dải tần chỉ một vai chính tại một thời điểm; dải 1–4 kHz dành cho lời
- [ ] 14\. Nhạc cụ chơi trong âm vực thực tế; tông thuận dây buông nhạc cụ dân tộc; lưu ý 166 cent (I1–I4)
- [ ] 15\. Đường năng lượng có lên có xuống, có cao trào
- [ ] 16\. Nhạc cụ nghi lễ (chiêng, hầu đồng, kèn đám ma…) dùng đúng ngữ cảnh (I6)
- [ ] 17\. Prompt AI không có tên nghệ sĩ thật, đúng giới hạn ký tự (`dong-goi-ai.py`)
- [ ] 18\. Lời cho máy AI viết đủ mỗi lần lặp, đúng dấu, không viết tắt, số viết bằng chữ
- [ ] 19\. Chế độ thương mại: nhật ký sáng tạo đã xuất; người dùng có quyết định/sửa/viết ở mọi bước sáng tạo
- [ ] 20\. Mục pháp lý – phát hành đã ghi trong tài liệu đầu ra (không chặn quá trình sáng tác)
