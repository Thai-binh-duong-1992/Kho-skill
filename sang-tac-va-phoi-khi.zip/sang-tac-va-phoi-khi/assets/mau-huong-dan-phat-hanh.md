# Mẫu hướng dẫn sản xuất – phát hành cho một bài hát

> Tệp mẫu của skill sang-tac-va-phoi-khi 2.0. Điền riêng cho từng bài từ `references/16-san-xuat.md` và `references/17-phap-ly-phat-hanh.md`. Phần pháp lý **chỉ ghi vào tài liệu này**, không chen vào lúc sáng tác. Mọi thông số nền tảng, điều khoản công cụ và quy định pháp luật ghi kèm "cần kiểm tra lại (cập nhật 11/2026)".
>
> **Không phải tư vấn pháp lý.** Xác nhận với luật sư hoặc Cục Bản quyền tác giả trước khi phát hành thương mại.

## 1. Lộ trình tổng quát

| Giai đoạn | Việc chính | Người làm | Trạng thái |
|---|---|---|---|
| Tạo bản thu | Nhập gói prompt, tạo nhiều bản, nghe chọn | Người dùng | ☐ |
| Kiểm tra bản AI | Chép lời từ âm thanh, so lời gốc, sửa chữ nghe nhầm | Người dùng + Claude | ☐ |
| Hậu kỳ | Quyết định giữ bản AI hay thu lại giọng/nhạc cụ người thật; mix | Người dùng / phòng thu | ☐ |
| Master và giao nộp | Theo bảng thông số mục 4 | Người dùng / kỹ sư | ☐ |
| Pháp lý | Mục 5 | Người dùng (+ luật sư) | ☐ |
| Phân phối | Mục 6 | Người dùng | ☐ |

## 2. Tạo và chọn bản thu trên công cụ AI

- Công cụ, gói tài khoản, ngày tạo; số bản đã tạo; bản được chọn và lý do (ghi vào nhật ký sáng tạo).
- Tải bản chất lượng cao nhất gói cho phép (WAV nếu có); lưu cả prompt, lời, ảnh chụp màn hình cài đặt.

## 3. Hậu kỳ

- Phần sẽ thay bằng người thật (giọng chính, độc tấu nhạc cụ dân tộc có luyến láy…).
- Biên tập giọng: không làm phẳng vết thanh và luyến láy; chỉnh cao độ phải không nghe thấy.
- Mix: dải 1–4 kHz dành cho lời; nhạc cụ dân tộc ở vai giai điệu/đối âm; xử lý chênh lệch cao độ thang Việt (khoảng 166 cent) với nhạc cụ 12 bình quân.

## 4. Master và giao nộp

| Nền tảng | Mức chuẩn hoá âm lượng | True peak | Định dạng nộp | Ghi chú |
|---|---|---|---|---|
| (điền từ 16-san-xuat.md) | | | | |

## 5. Pháp lý (ghi để làm, không chặn sáng tác)

- [ ] Nhật ký sáng tạo đầy đủ; lưu bản nháp, demo, file dự án, prompt (chứng cứ đóng góp của con người – NĐ 134/2026/NĐ-CP).
- [ ] Gắn nhãn nội dung có âm thanh do AI tạo (Luật Trí tuệ nhân tạo 134/2025/QH15) – hình thức gắn nhãn theo hướng dẫn hiện hành.
- [ ] Đọc điều khoản thương mại của công cụ AI theo đúng gói đã dùng khi tạo bản thu.
- [ ] Split sheet giữa các tác giả, ca sĩ, nhà sản xuất, nghệ nhân (tỉ lệ, chữ ký, ngày).
- [ ] Hợp đồng với ca sĩ, nhạc công, nhà sản xuất (quyền liên quan).
- [ ] Nếu dùng thơ, sample, cover, dân ca của người khác: giấy phép tương ứng.
- [ ] Rà nội dung theo các điều cấm (Điều 3 NĐ 144/2020/NĐ-CP).
- [ ] Cân nhắc đăng ký quyền tác giả tại Cục Bản quyền tác giả; ủy thác VCPMC nếu muốn thu tiền tác quyền.
- [ ] Thuế thu nhập cá nhân từ tiền bản quyền (Luật Thuế TNCN 109/2025/QH15).

## 6. Phân phối và metadata

- Nhà phân phối: kiểm tra có giao bài lên Zing MP3, NhacCuaTui, YouTube, Spotify, Apple Music.
- Metadata: tên bài, nghệ sĩ, tác giả lời, tác giả nhạc, nhà sản xuất, năm, thể loại, ngôn ngữ, ISRC, UPC, lời bài hát, nhãn AI (nếu nền tảng yêu cầu).
- Content ID: chỉ đăng ký khi có quyền độc quyền với bản thu.
- Lịch phát hành, ảnh bìa (nguyên bản, có quyền dùng), lời bài hát chuẩn (lyric sheet) để ca sĩ và người nghe không học sai.

## 7. Lưu trữ bằng chứng

| Tệp | Nơi lưu | Ngày |
|---|---|---|
| Nhật ký sáng tạo (.json + .md) | | |
| Bản nháp lời các vòng | | |
| Demo, file dự án DAW | | |
| Prompt và bản tải từ công cụ AI | | |
| Split sheet, hợp đồng, giấy phép | | |
