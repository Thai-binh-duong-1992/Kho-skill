> Tệp mẫu của skill sang-tac-va-phoi-khi 2.0. Bộ kiểm tra tổng hợp: T (thanh–nhạc), N (đặt chữ vào nhịp), V (thi luật), L (nghề viết lời), I (chọn nhạc cụ) và danh sách A–I theo giai đoạn đến phát hành. Nhãn: [BC] có bằng chứng · [QU] quy ước/suy luận · [Cần kiểm chứng]. Khi xung đột, theo quy tắc [BC].

# Danh sách kiểm tra tổng hợp

## Tra số mục trong ngoặc

Số mục trong ngoặc như (4.6), (6.2), (8.3) là số mục của tài liệu gốc "Nhạc Việt sáng tác, hoà âm phối khí". Tra trong skill theo bảng:

| Tài liệu gốc | Tệp trong skill |
|---|---|
| Phần 1 (1.1, 1.2, 1.4, 1.6), Phần 2 | references/11-nhac-viet-the-loai.md |
| 1.3, Phần 4 (4.1–4.7) | references/ngon-ngu/vi.md (âm vực: references/04-giong-hat.md) |
| 1.5, Phần 5 | references/14-hoa-am-viet-bai-mau.md |
| Phần 6 (6.1–6.6) | references/16-san-xuat.md |
| Phần 7 (7.1–7.9) | references/17-phap-ly-phat-hanh.md |
| Phần 8 (8.1–8.9) | references/12-thi-luat.md |
| Phần 9 | references/13-nghe-viet-loi.md |
| Phần 10 (10.1–10.12) | references/15-nhac-cu-viet.md |
| Phụ lục (mục 1–52, 16b) | mục A–I cuối tệp này |

## Cách chạy

| Bộ | Khi nào | Script hỗ trợ |
|---|---|---|
| L1–L12 | Bước 3 (ý tưởng) và Bước 5 (lời), trước khi áp luật – "trần trước, sàn sau" | – (soát bằng đọc to, người nghe thử) |
| V1–V16 | Bước 5, khi có bản lời hoàn chỉnh; chạy lại sau khi chỉnh lời theo giai điệu | `kiem-tra-thi-luat.py`, `dem-am-tiet.py` |
| T1–T10, N1–N9 | Bước 6, khi đã có giai điệu (dòng M: cho từng câu) | `kiem-tra-thanh-nhac.py`, `dem-am-tiet.py --chi-tiet` |
| I1–I10 | Bước 7, sau khi chốt tông và BPM | – |
| A–I | Bước 11, trước khi giao gói bàn giao và trước khi phát hành | – |

Khi không chạy được script, soát thủ công theo đúng các bảng dưới đây và ghi rõ trong gói bàn giao là "chưa chạy script".


## Nhóm thanh và thanh–nhạc (T1–T10)


Bảng mã nhóm thanh dùng cho mọi bước, theo Ladd & Kirby: **Cao = sắc, ngã · Trung = ngang · Thấp = huyền · Rất thấp = hỏi, nặng.**

| # | Bước kiểm tra | Cách làm | Cờ đỏ | Cơ sở |
|---|---|---|---|---|
| T1 | Gán nhóm thanh | Ghi chữ C/T/Th/RT dưới từng âm tiết của lời | — | [BC] |
| T2 | So hướng từng cặp chữ liền nhau | Nhóm thanh tăng thì nốt đi lên hoặc đứng yên; nhóm giảm thì nốt đi xuống hoặc đứng yên | Nhạc đi **ngược** hướng thanh | [BC] hướng; ngưỡng là suy luận |
| T3 | Đếm tỉ lệ | Mục tiêu khoảng 70–80% cùng hướng, dưới khoảng 10% ngược hướng | Trên 10% ngược hướng | [QU] từ số liệu Việt và Thái |
| T4 | Kiểm tra cặp tối thiểu | Với mỗi chữ then chốt về nghĩa, hỏi: có từ nào chỉ khác một dấu không (lả/là, đắm/đắng)? Nếu có, giai điệu phải "nói đúng" thanh đó | Chữ then chốt bị ngược hướng | [QU] |
| T5 | Huyền và sắc | Huyền kết bằng nét đi xuống hoặc nốt thấp hơn chữ trước; sắc ở nốt cao hơn hoặc có luyến nhẹ đi lên | Huyền nhảy lên; sắc rơi xuống | [BC] Ru con: huyền đi xuống 81/90, sắc đi lên 28/42 (riêng khi chữ trước là hỏi hoặc nặng thì huyền là bước đi lên 0→1: theo T2) |
| T6 | Hỏi, ngã, nặng | Hỏi đặt nốt thấp, có thể luyến xuống rồi lên; nặng dùng nốt ngắn, thấp, không luyến dài; ngã giọng Bắc nên là nốt ngắn hoặc luyến hai nốt đi lên | Nặng trên nốt ngân dài; ngã (giọng Bắc) đặt thấp hơn chữ trước | [QU] |
| T7 | Chuỗi cùng thanh | Hai chữ cùng thanh, nhất là ngang–ngang, có thể chung một nốt | — | [BC] xiên được dung nạp |
| T8 | Nốt cao trào | Nốt cao nhất bài mang thanh ngang hoặc sắc, nguyên âm mở (a, o, e), âm cuối mở hoặc mũi | Hỏi hoặc nặng trên nốt cao nhất | [QU] |
| T9 | Vi phạm có chủ ý | Nếu buộc phải ngược hướng, đặt ở chỗ ngắt câu hoặc ở chữ mà ngữ cảnh đã rõ nghĩa | Vi phạm giữa một từ ghép | [QU]; "biến thanh" ở quan họ là tiền lệ |
| T10 | Phương ngữ mục tiêu | Xác định ca sĩ và khán giả Bắc, Trung hay Nam rồi chỉnh mức nghiêm (xem 4.6) | Nét đúng với giọng Nam nhưng lệch với giọng Bắc | [BC] phương ngữ; hệ quả là suy luận |

## Đặt chữ vào nhịp (N1–N9)


| # | Bước kiểm tra | Cách làm | Cơ sở |
|---|---|---|---|
| N1 | Đánh dấu ranh giới ngữ đoạn | Gạch "/" ở cuối mỗi cụm nghĩa và "//" ở cuối mệnh đề | [BC] ranh giới ngữ đoạn kéo dài âm tiết |
| N2 | Chữ cuối ngữ đoạn | Đặt trên phách mạnh hoặc nốt dài | [QU] từ mức kéo dài khoảng 35–41% |
| N3 | Thực từ và hư từ | Thực từ quan trọng ở phách mạnh; hư từ, loại từ (cái, con, của, thì, mà, là, những) ở phách yếu hoặc nốt ngắn | [BC] thực từ mang trọng âm |
| N4 | Không tách từ | Không đặt nghỉ hay lấy hơi giữa hai âm tiết của từ ghép hoặc từ láy ("hạnh / phúc" là lỗi); chỗ lấy hơi trùng ranh giới mệnh đề | [BC] đặt sai trọng âm làm vỡ từ; quy tắc là suy luận |
| N5 | Âm cuối của nốt ngân | Nốt ngân dài dùng âm tiết kết bằng nguyên âm, -m, -n, -ng, -nh; tránh âm tắc -p, -t, -c, -ch | [QU]; nhất quán với thực hành đặt lời Việt |
| N6 | Mật độ âm tiết | Ballad khoảng 1–2 âm tiết mỗi phách; rap khoảng 2–4; bolero luyến láy dày cuối câu | [QU], chưa có số liệu đo |
| N7 | Lục bát | Chữ chẵn (mang luật) vào phách mạnh; vần chữ 6 và chữ 8 trùng nốt ngân cuối tiết hoặc câu; chữ 6 và chữ 8 câu bát là một huyền, một ngang, nên nốt cuối câu bát có sẵn hướng (huyền thấp hơn ngang) | Cách đặt nhịp: [QU]. Luật huyền–ngang: [BC]. Xem 8.3 |
| N8 | Hook rap được hát | Khi rapper chuyển sang hát hook trên nốt cố định, chạy lại T2–T6 cho hook | [QU]; chưa có nghiên cứu về thanh điệu trong rap Việt |
| N9 | Bản lời chuẩn | Phát hành lyric sheet hoặc bản ký âm chuẩn kèm demo để ca sĩ không học sai | [QU] từ khuyến nghị của NS Đức Trịnh và Đức Huy |

## Thi luật cho lời ca (V1–V16)


Chạy bộ này **sau khi có bản lời hoàn chỉnh và trước khi phác giai điệu** (bước 11 của quy trình phổ thơ, `references/12-thi-luat.md` mục 12.7). Chạy lại một lần nữa sau khi chỉnh lời theo giai điệu. Bộ này bổ sung cho T1–T10 (thanh–nhạc) và N1–N9 (đặt chữ vào nhịp) ở trên.

| # | Kiểm tra | Cách làm | Cờ đỏ | Cơ sở |
|---|---|---|---|---|
| V1 | Thể và khung | Ghi rõ lời theo thể nào (lục bát, song thất, 4/5/7/8 chữ, tự do, rap) và mức tuân thủ (chặt, vừa, tự do) | Trộn thể không chủ ý giữa các phiên khúc | [QU] |
| V2 | Số chữ | Đếm chữ mỗi dòng; phiên khúc 1 và 2 cùng vị trí phải bằng số chữ, để hát chung giai điệu | Phiên khúc 2 dư hoặc thiếu chữ so với phiên khúc 1 | [QU] |
| V3 | Bằng–trắc ở vị trí bắt buộc | Lục bát: chữ 2–4–6–8. Song thất: chữ 3–5–7. Đường luật: chữ 2–4–6 và niêm | Chữ 4 câu lục bát là bằng; chữ 6 hoặc 8 là trắc | [BC] (8.3) |
| V4 | Trầm bổng câu bát | Chữ 6 và chữ 8 câu bát: một huyền, một ngang | Cả hai cùng ngang hoặc cùng huyền | [BC] |
| V5 | Vị trí vần | Đánh dấu V ở mọi vị trí phải gieo vần theo sơ đồ; kiểm từng cặp | Lạc vận ở vị trí bắt buộc | [BC] sơ đồ; tên lỗi [QU] |
| V6 | Cùng nhóm thanh | Hai tiếng hiệp vần cùng bằng hoặc cùng trắc | Vần bằng gặp vần trắc ở thể truyền thống | [BC] |
| V7 | Độ giàu và độ tự nhiên của vần | Vần chính ở câu tiêu đề và cuối điệp khúc; vần thông được dùng ở phiên khúc. Đọc to từng câu, hỏi: nếu bỏ yêu cầu vần, có ai nói câu này không? | Ép vần: từ gượng nghĩa chỉ để có vần | [QU] |
| V8 | Vần khép | Tiếng kết bằng -p, -t, -c, -ch không đặt ở vị trí vần bằng, không đặt ở nốt ngân cuối câu | Vần khép ở cuối điệp khúc hoặc ở chữ 6, chữ 8 lục bát | [BC] vần khép chỉ mang sắc, nặng; hệ quả [QU] |
| V9 | Cách gieo vần trong khổ | Chọn liền, cách hoặc ôm cho phiên khúc và giữ nhất quán; điệp khúc có thể đổi để tạo tương phản | Mỗi khổ một kiểu vần không có lý do | [QU] [Cần kiểm chứng] |
| V10 | Niêm và đối (nếu dùng) | Đường luật: niêm 1–8, 2–3, 4–5, 6–7; đối 3–4, 5–6. Song thất: cặp thất T–B–T / B–T–B | Thất niêm, thất đối khi tuyên bố theo Đường luật | [BC] |
| V11 | Nhịp và ranh giới từ | Ngắt nhịp thơ trùng ranh giới ngữ đoạn; không cắt đôi từ ghép hoặc từ láy qua vạch nhịp | Nhịp 3/3 cắt giữa một từ ghép | [BC] chân thơ song tiết; quy tắc [QU] (8.4, N4) |
| V12 | Bằng–trắc gặp cao độ | Với mỗi chữ vần, ghi thêm nhóm cao độ: ngang trung, huyền thấp, sắc/ngã cao, hỏi/nặng rất thấp; chọn hướng nốt tương ứng | Vần huyền đặt trên nốt đỉnh; vần hỏi hoặc nặng ở nốt cao nhất | [BC] hai lưới (8.1); hệ quả [QU] |
| V13 | Tu từ và hook | Một hình ảnh hoặc ẩn dụ trung tâm; điệp ngữ hoặc điệp cấu trúc mang hook; không quá một "điểm đặc biệt" mỗi đoạn | "Chỗ nào cũng đặc biệt" | [BC] Hứa Kim Tuyền; vai trò điệp ngữ [QU] |
| V14 | Dễ hiểu khi nghe | Đọc to cho người chưa xem lời; đánh dấu chữ Hán Việt khó, cấu trúc đảo ngữ khó nghe, cặp chữ chỉ khác một dấu (T4) | Người nghe không nhắc lại được câu điệp khúc sau một lần nghe | [BC] Nguyễn Văn Hoàn |
| V15 | Rap | Đánh dấu vần đơn, đôi, ba và vần nội; vần rơi vào phách 2, 4 hoặc cuối ô; hook hát phải chạy T2–T6 | Vần chỉ ở cuối câu, flow đều đều; hook hát ngược thanh | [BC] thuật ngữ; quy tắc [QU] |
| V16 | Nguồn thơ và quyền | Nếu lời dùng thơ của người khác: có văn bản cho phép; ghi "Thơ:" hoặc "Ý thơ:"; liệt kê chỗ đã sửa; thỏa thuận nhuận bút | Phát hành bài phổ thơ chưa có văn bản đồng ý | [BC] Điều 28 Luật SHTT (qua Hệ thống pháp luật); [Cần kiểm chứng] với phổ thơ |

## Nghề viết lời (L1–L12)


| Mã | Kiểm tra | Đạt khi | Nhãn |
|---|---|---|---|
| L1 | Ý cốt lõi | Viết được trong một câu dưới 15 chữ, là cảm xúc hoặc nhận ra, không phải chủ đề | [QU]; [BC] một điểm nhấn (Hứa Kim Tuyền) |
| L2 | Chi tiết cảm quan | Mỗi phiên khúc có ít nhất hai chi tiết cảm quan cụ thể | [QU] |
| L3 | Từ trừu tượng | Số từ cảm xúc trừu tượng không nhiều hơn số chi tiết | [QU] |
| L4 | Người nói, người nghe | Rõ ai nói, nói với ai, lúc nào; ngôi xưng nhất quán | [QU] |
| L5 | Giọng tự nhiên | Đọc to không có câu "không ai nói thế" ngoài chủ đích phong cách | [QU]; [BC] lời đời thường của Đen Vâu |
| L6 | Âm thanh câu hook | Hook dễ hát; nguyên âm mở ở nốt ngân; không vần khép ở cuối câu điệp khúc | [BC] 8.1; [QU] |
| L7 | Đường đi | Mỗi đoạn tóm được bằng một động từ khác nhau; verse 2 không lặp verse 1 | [QU] |
| L8 | Vị trí hook | Câu hook (thường là tên bài) ở đầu hoặc cuối điệp khúc; mang thêm nghĩa sau mỗi verse | [QU] |
| L9 | Tiết kiệm | Không còn câu bỏ đi được mà bài không mất gì | [BC] Phú Quang 21/443; [QU] |
| L10 | Ẩn ý | Không có câu giải thích lại điều hình ảnh đã gợi | [QU] |
| L11 | Khoảnh khắc của người nghe | Trả lời được "người nghe mang bài này vào lúc nào trong đời họ" | [QU] |
| L12 | Người nghe thử | Một người chưa xem lời chép lại đúng lời và hiểu đúng ý cốt lõi | [QU]; liên quan T4 (Phần 4) |

## Chọn nhạc cụ (I1–I10)


Chạy bộ này ở tiền kỳ, sau khi chốt tông và BPM, trước khi viết arrangement map (Phụ lục, mục 16b).

| Mã | Câu hỏi kiểm tra | Cách làm, căn cứ |
|---|---|---|
| **I1** | Mỗi bè có nằm trong tầm âm thực dụng của nhạc cụ không? | Đối chiếu bảng 10.5. Lấy hẹp hơn tầm tối đa khoảng một quãng 4 ở mỗi đầu cho nhạc công phòng thu thông thường. Tránh vùng yếu, ví dụ clarinet throat F4–Ab4 |
| **I2** | Tông bài có thuận dây buông của nhạc cụ dân tộc không? | Tỳ bà, tam, phím lõm thuận C và F. Nếu tông khác, hỏi nhạc công có lên lại dây được không, hoặc nhích tông nửa cung (4.5) |
| **I3** | Hệ cao độ có tương thích không (vấn đề 166 cent)? | Chọn một trong hai chiến lược ở 6.2: nhạc cụ theo synth, hoặc synth theo nhạc cụ. Ghi rõ đoạn nào là độc tấu dân tộc "tự do cao độ" |
| **I4** | Có nhạc cụ nào ngoài hệ 12 bình quân không (gamelan, dàn chiêng)? | Ghi rõ dàn chiêng nào (Ê Đê 6 âm hay Gia Rai 5 âm có bán cung). Đo cao độ chiêng thật hoặc dùng hệ lên dây tương ứng trong DAW. Không đặt pad 12 bình quân dày dưới chiêng thật |
| **I5** | Có hai nhạc cụ trùng vai không? | Không xếp tranh với guzheng hoặc koto, nhị với erhu, sáo trúc với dizi cùng vai. Không để synth pluck rải cùng quãng với đàn tranh (10.9) |
| **I6** | Nhạc cụ có mang nghĩa nghi lễ hoặc tâm linh không? | Cồng chiêng (mỗi chiêng chứa một vị thần), hát văn và hầu đồng, then, khèn H'Mông (xưa chỉ dùng trong đám tang), kèn đám ma, trống tang H'Mông, mõ và chuông chùa. Hỏi ý kiến nghệ nhân hoặc cộng đồng; tránh đặt vào ngữ cảnh chế giễu; ghi credit nghệ nhân và dân tộc |
| **I7** | Nhạc cụ có đủ âm lượng trong dàn không, hay cần khuếch đại? | Đàn bầu cần pickup. Chapi, đàn tính, đàn đáy, đàn môi, k'ni âm nhỏ, cần micro áp sát hoặc pickup tiếp xúc [QU]. Kèn bầu và trống to, thu xa micro. Xem 6.2 |
| **I8** | Có nhạc công thật không, hay dùng sample? | Độc tấu có luyến láy (bầu, sáo, nhị, nguyệt) nên dùng người thật ở bản cuối. Sample cho demo và lớp nền (6.6). Ghi danh sách phần sẽ thay bằng người thật (Phụ lục mục 19) |
| **I9** | Giấy phép của sample, thư viện và công cụ AI có cho phép dùng thương mại không? | Đọc EULA của từng thư viện mẫu. Với AI, đọc điều khoản hiện hành của Suno và Udio, vì đã đổi sau các thỏa thuận với hãng đĩa (10.8, 7.7). Ghi nghệ nhân vào split sheet hoặc credit (7.9) |
| **I10** | Part giao cho nhạc công đã đúng ký âm chưa? | Xuất part dịch giọng cho sax, trumpet, horn, clarinet; DAW thường ghi cao độ thực. Với nghệ nhân dân tộc, gửi guide audio có luyến láy kèm bản nhạc, vì chưa có hệ ký hiệu luyến láy chuẩn Việt (4.7) |

## Danh sách theo giai đoạn đến phát hành (A–I)

Mục có nguồn được trình bày trong các phần tương ứng. Mục không có nguồn là quy ước thực hành.

**A. Ý tưởng và định hướng**

1. Chọn thể loại, hơi (vui, thanh thản, buồn) và "hệ" hòa âm: giọng thứ chức năng có V7 cho bolero, Trịnh, tiền chiến; vòng lặp IV–V–iii–vi hoặc vi–iii–IV–V cho V-pop; vòng aeolian không V trưởng cho fusion và rap (1.5).
2. Nếu dùng chất liệu dân gian, ghi rõ vai trò của từng chi tiết: hook, màu sắc, cấu trúc nhịp hay kể chuyện (6.1).
3. Xác định phương ngữ của ca sĩ và khán giả mục tiêu (4.6).
4. Mở nhật ký sáng tạo ngay từ đầu, ghi ngày tháng và lưu mọi bản nháp, demo, prompt AI (7.2, 7.7).

**B. Viết lời và giai điệu**

5. Chọn thể thơ, mức tuân thủ luật và cách gieo vần cho phiên khúc và điệp khúc; nếu dùng thơ của người khác, có văn bản cho phép của nhà thơ hoặc người thừa kế trước khi viết (8.2, 8.7, V1, V16).
6. Chạy bộ kiểm tra thi luật trên bản lời hoàn chỉnh: số chữ giữa các phiên khúc (V2); bằng–trắc ở vị trí bắt buộc và luật chữ 6 với chữ 8 câu bát là một huyền, một ngang (V3–V4); vị trí vần, cùng nhóm thanh, không ép vần (V5–V7); không có vần khép -p, -t, -c, -ch ở vị trí vần bằng hoặc nốt ngân (V8); cách gieo vần, niêm, đối nếu có (V9–V10); với rap thì đánh dấu vần đơn, đôi, ba và vần nội (V15) (8.8).
7. Kiểm tra tu từ và độ dễ nghe: một hình ảnh trung tâm, hook mang điệp ngữ, đọc to cho người chưa xem lời (V13–V14).
7b. Chạy bộ kiểm tra nghề viết lời L1–L12: ý cốt lõi trong một câu; chi tiết cảm quan; giọng và ngôi xưng nhất quán; đường đi của các đoạn; vị trí hook; lược bỏ câu thừa; không giải thích thừa; người chưa xem lời chép lại đúng (Phần 9).
8. Lời: đánh dấu ranh giới ngữ đoạn; chữ cuối ngữ đoạn và thực từ ở phách mạnh; hư từ ở phách yếu; không ngắt giữa từ ghép; nhịp thơ trùng vạch nhịp (N1–N4, V11, 8.4).
9. Gán nhóm thanh cho từng chữ và kiểm tra hướng từng cặp; mục tiêu dưới khoảng 10% ngược hướng (T1–T3).
10. Kiểm tra cặp tối thiểu cho các chữ then chốt về nghĩa (T4).
11. Kiểm tra huyền, sắc, hỏi, ngã, nặng và nốt cao trào (T5–T8); với mỗi chữ vần, đối chiếu nhóm bằng–trắc với nhóm cao độ (V12).
12. Nốt ngân dài không rơi vào âm tiết kết bằng -p, -t, -c, -ch (N5).
13. Rà lời theo các nội dung bị cấm tại Điều 3 Nghị định 144/2020 (7.5).

**C. Tiền kỳ**

14. Đo âm vực và tessitura của ca sĩ thật; chọn tông theo năm bước; với bài thiếu nhi, chọn tông theo trẻ (4.4, 4.5).
15. Thử tông với nhạc cụ dân tộc trước khi chốt.
16. Chốt BPM và grid; đánh dấu các đoạn rubato.
16b. Chạy bộ kiểm tra chọn nhạc cụ I1–I10: tầm âm thực dụng; tông thuận dây buông; chiến lược cao độ cho bậc 166 cent, gamelan và dàn chiêng; không trùng vai tranh–guzheng, nhị–erhu; ý nghĩa nghi lễ của chiêng, hát văn, khèn tang; khuếch đại nhạc cụ âm nhỏ; người thật hay sample; giấy phép sample và AI; part dịch giọng và guide audio (10.11).
17. Hoàn thiện lead sheet, arrangement map, guide audio và guide vocal có luyến láy (6.1, 4.7).
18. Thống nhất 2–3 reference track.
19. Nếu dùng AI hoặc thư viện mẫu cho demo, ghi rõ phần nào sẽ được thay bằng người thật (6.6).

**D. Thu âm**

20. Thu 24-bit ở 44,1 hoặc 48 kHz và giữ nguyên sample rate suốt dự án.
21. Chọn chiến lược cao độ: nhạc cụ theo synth (dây buông A440) hoặc synth theo nhạc cụ (6.2).
22. Đàn bầu: thu DI pickup cộng micro. Đàn tranh: micro ngang đầu người chơi, có thể thêm micro dưới gầm, kiểm tra pha (6.2).
23. Thu song lang và phách thành track riêng.
24. Giọng: 3–6 take toàn bài và punch-in câu khó.

**E. Biên tập giọng**

25. Comp theo câu, không cắt giữa âm tiết.
26. Chỉnh cao độ thủ công, tắt snapping, Pitch Drift gần 0% cho giọng chính; không lượng tử hóa luyến láy (6.3).
27. Nghe lại riêng các chữ hỏi, ngã, nặng sau khi chỉnh, và chạy lại T2–T6 trên bản đã chỉnh.

**F. Mix**

28. Dành dải 1–4 kHz cho giọng; cắt nhạc nền 5–10 dB ở dải này khi cần (6.4).
29. De-esser không ăn mất x, s, ch, tr, th; nén giữ transient phụ âm đầu.
30. Kiểm tra va chạm giữa nhạc cụ dân tộc và pad hoặc synth ở các đoạn độc tấu.
31. Nghe thử trên loa điện thoại, tai nghe, loa xe và loa karaoke.

**G. Master và giao nộp**

32. Đo integrated LUFS theo ITU-R BS.1770; so với −14 (Spotify, YouTube) và −16 (Apple) (6.5).
33. True peak ≤ −1 dBTP, hoặc ≤ −2 dBTP nếu master to hơn −14 LUFS.
34. Chạy afclip và kiểm tra file AAC đã mã hóa không bị clip.
35. Với album, kiểm tra chênh lệch âm lượng giữa các bài.
36. Xuất master FLAC hoặc WAV PCM (không EXTENSIBLE), 24-bit gốc, không upsample.
37. Xuất instrumental, bản TV/karaoke, acapella, stems, bản clean, đoạn hook 15–60 giây.
38. Nếu làm Atmos: ADM BWF 24-bit/48 kHz, khớp thời lượng bản stereo.

**H. Pháp lý**

39. Ký split sheet với mọi người góp phần nhạc, lời, phối (7.9). Với bài phổ thơ: ghi nhà thơ là tác giả lời hoặc ghi "Ý thơ", kèm thỏa thuận nhuận bút và danh sách chỗ đã sửa lời (8.7, V16).
40. Ký hợp đồng bằng văn bản với ca sĩ, producer, nhạc công và nghệ nhân (7.9).
41. Rà soát chất liệu bên thứ ba: dân ca (ghi xuất xứ, không dùng bản phối hay bản thu của người khác); cover và lời Việt cho nhạc ngoại (xin phép tác giả hoặc VCPMC); sample và beat (license, độc quyền hay không) (7.6).
42. Nếu có dùng AI: dùng gói trả phí; không mô phỏng giọng người thật; gắn nhãn theo Luật 134/2025/QH15; lưu bằng chứng đóng góp của con người theo NĐ 134/2026 (7.7).
43. Cân nhắc đăng ký tác phẩm âm nhạc và bản ghi âm tại Cục Bản quyền tác giả (7.3).
44. Cân nhắc ủy thác phần tác giả cho VCPMC, kể cả tuyên bố opt-out AI (7.4).
45. Nếu tổ chức biểu diễn ra mắt, xin văn bản chấp thuận hoặc thông báo theo NĐ 144/2020 (7.5).

**I. Phát hành**

46. Chọn distributor xác nhận được việc giao đến YouTube Music, Zing MP3 và NhacCuaTui (7.8).
47. Nhận ISRC cho mỗi bản thu và UPC cho mỗi release.
48. Điền metadata: tên bài có dấu chuẩn Unicode NFC, tác giả nhạc và lời, producer, người phối, nhạc công dân tộc, ngôn ngữ, explicit, lời bài hát, khai báo AI.
49. Chỉ đăng ký Content ID khi bản thu là độc quyền và không phải nhạc AI hoàn toàn.
50. Phát hành lyric sheet chuẩn kèm bản thu để hạn chế hát sai lời (N9).
51. Lưu chứng từ thu nhập; tiền bản quyền chịu 5% trên phần vượt 20 triệu đồng mỗi hợp đồng từ 01/7/2026 (7.9).
52. Đối chiếu mọi mục [Cần kiểm chứng] với Cục Bản quyền tác giả hoặc luật sư trước khi phát hành thương mại.

---

