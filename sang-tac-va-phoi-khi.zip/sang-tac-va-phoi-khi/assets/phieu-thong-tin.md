# Phiếu thông tin đầu vào (bản 2.0)

> Tệp mẫu của skill sang-tac-va-phoi-khi 2.0. Claude chỉ hỏi những mục còn thiếu và ảnh hưởng lớn đến kết quả, theo thứ tự ưu tiên từ trên xuống. Câu hỏi về **chế độ** luôn là câu đầu tiên với bài mới.

| Nhóm | Thông tin | Mặc định khi người dùng không nói |
| --- | --- | --- |
| **Chế độ** | **Cá nhân** (tặng, sự kiện nội bộ, dùng riêng) hay **Phát hành thương mại** (đưa lên nền tảng nghe nhạc, kiếm tiền, đăng ký quyền) | Cá nhân. Hỏi ở câu 1; nếu về sau người dùng nhắc phát hành, kiếm tiền, Spotify, Zing MP3, YouTube kiếm tiền, đăng ký bản quyền → hỏi xác nhận một câu có chuyển sang thương mại không |
| Tác giả | Tên tác giả lời, tác giả nhạc, nghệ danh (chế độ thương mại: ghi vào nhật ký sáng tạo) | Tên người dùng |
| Mục đích | Dùng ở đâu (sự kiện, quảng cáo, phim, game, cá nhân, giáo dục, tôn giáo, thể thao, phát hành) | Nghe thưởng thức |
| Người nghe | Độ tuổi, văn hóa, vùng miền, số lượng; "người nghe mang bài này vào khoảnh khắc nào" (L11) | Người trưởng thành phổ thông |
| Chất liệu riêng | Sự thật cảm xúc, câu chuyện, kỷ niệm, chi tiết cảm quan (mùi, âm thanh, đồ vật, nơi chốn) | Hỏi đào sâu; không tự bịa chi tiết riêng |
| Người hát | Ca sĩ chuyên, người không chuyên, tập thể, trẻ em, người cao tuổi, giọng máy AI; giới tính, độ tuổi, loại giọng, **phương ngữ** (Bắc/Trung/Nam) | Ca sĩ không chuyên, âm vực an toàn |
| Cảm xúc, hơi | Tâm trạng chính và đường cảm xúc; với nhạc Việt màu dân tộc: hơi Bắc (vui), Quảng (kỳ ảo), Nhạc (trang nghiêm), Xuân (thanh thản), Ai/Oán (buồn) | Theo mục đích |
| Phong cách | Thể loại, thời kỳ, vùng miền; **thế hệ hoà âm** (trước 2000: giọng thứ chức năng có V7 / sau 2014: vòng lặp 4 hợp âm / màu dân gian ngũ cung); bài tham khảo về cảm giác (chỉ để hiểu, không chép) | Pop hiện đại |
| Lời | Thể thơ (lục bát, song thất, 4/5/7/8 chữ, tự do, rap); xưng hô; từ khóa, tên riêng, điều cần tránh | Thơ tự do có vần chân; xưng hô theo ngữ cảnh |
| Kỹ thuật | Độ dài, BPM, nhịp, tông (theo giọng người hát) | Theo thể loại; 3–3,5 phút |
| Ngôn ngữ | Một hay nhiều ngôn ngữ, tỷ lệ, phương ngữ | Ngôn ngữ người dùng đang viết |
| Nhạc cụ | Nhạc cụ bắt buộc, màu dân tộc, ban nhạc hoặc nghệ nhân có sẵn | Theo thể loại và ma trận kết hợp (15-nhac-cu-viet.md) |
| Công cụ AI | Suno (chính), Udio, ElevenLabs Music, hay thu âm người thật; gói tài khoản (miễn phí/trả phí) | Suno; điều khoản theo gói ghi vào tài liệu đầu ra (gói bàn giao mục 9) |
| Đầu ra | Chỉ lời; lời có hợp âm; bảng phối khí; gói prompt AI; hướng dẫn sản xuất – phát hành; tất cả | Tất cả; tài liệu Docs + file Word |
