# Mẫu gói bàn giao bài hát (bản 2.1)

> Tệp mẫu của skill sang-tac-va-phoi-khi 2.0. Dùng khung này cho mọi bài mới. Mỗi mục một tiêu đề cấp 2. Bỏ mục 6 nếu không dùng nhạc AI; bỏ mục 10 ở chế độ cá nhân nếu người dùng không cần. Xuất theo định dạng người dùng cần (SKILL.md Bước 11): định dạng người dùng đã chọn; nếu chưa chọn thì **tài liệu Docs** khi phiên có, không thì **file Word** (`scripts/tao-docx.py`).

## 1. Thông tin bài hát

| Hạng mục | Nội dung |
|---|---|
| Tên bài | |
| Tác giả lời / tác giả nhạc | (chế độ thương mại: người dùng là tác giả chính; Claude và công cụ AI ghi ở mục "Công cụ hỗ trợ") |
| Chế độ | Cá nhân / Phát hành thương mại |
| Thể loại (nền + màu, tỷ lệ); hơi | |
| Thế hệ hoà âm | Trước 2000 (giọng thứ chức năng có V7) / sau 2014 (vòng lặp) / ngũ cung dân gian |
| Tempo, nhịp | ... BPM, .../... |
| Giọng (tông), điệu thức | ...; chuyển giọng ở ... (nếu có) |
| Thời lượng | ... (tính bằng scripts/tinh-thoi-luong.py) |
| Người hát | Loại giọng, độ tuổi, phương ngữ, vùng hát thoải mái ...–... |
| Ý cốt lõi (L1) | Một câu dưới 15 chữ |
| Công cụ hỗ trợ | Claude (gợi ý lời, nhạc lý, phối khí); Suno/Udio/ElevenLabs (tạo bản thu) |

## 2. Lời bài hát (bản trình bày)

- Nhãn từng phần in đậm: **[Verse 1]**, **[Pre-chorus]**, **[Chorus]**…
- Mỗi câu một dòng; dấu "/" đánh ranh giới ngữ đoạn khi cần cho người hát.
- Chế độ thương mại: đánh dấu câu do người dùng tự viết hoặc sửa (ví dụ ký hiệu ✎ cuối dòng) – khớp với nhật ký.

## 3. Phân tích lời (tiếng Việt)

| Câu | Thể/nhịp thơ | Nhóm thanh (3 cao · 2 trung · 1 thấp · 0 rất thấp) | Vần (vị trí, chính/thông, B/T) | Ghi chú (vần khép, cặp dễ nghe nhầm) |
|---|---|---|---|---|

Kèm kết quả `dem-am-tiet.py --chi-tiet` và `kiem-tra-thi-luat.py` (nếu là thể cố định).

## 4. Bản lời có hợp âm và giai điệu (lead sheet)

Theo `assets/mau-lead-sheet.md`. Với lời tiếng Việt: kèm dòng hợp âm "HA:" và giai điệu "M:" từng câu, **ghi rõ quy ước trường độ** (nốt không ghi `_n` = mấy phách), kết quả `kiem-tra-thanh-nhac.py` (tỉ lệ cùng hướng/xiên/ngược, các cặp ngược hướng đã xử lý, cờ T11) và tên các file nghe thử đã gửi (`tao-ban-nghe-thu.py`).

## 5. Bảng phối khí

Mỗi bảng phối khí phải có đủ 8 cột:

| Phần | Thời gian | Số ô | Hợp âm | Nhạc cụ và vai | Cách chơi | Năng lượng 1–10 | Chuyển sang phần sau |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Ví dụ: Verse 1 | 0:15–0:30 | 8 | i–iv–V7–i | Đàn tranh rải (màu), piano (thảm), bass có âm trì (nền), trống hi-hat (nhịp), giọng (lead) | Tranh rải ngũ cung vào khoảng nghỉ của lời | 4 | Snare dồn 1 ô |

Kèm: danh sách nhạc cụ (ghi rõ nhạc cụ dịch giọng, nhạc cụ dân tộc và dây buông, phần nào thay bằng người thật), kết quả bộ I1–I10, hướng dẫn giọng hát (chất giọng, bè, ad-lib, luyến láy, phương ngữ).

## 6. Gói nhập liệu cho công cụ nhạc AI

Theo `assets/mau-prompt-ai.md`: **Suno (đầy đủ)**, **Udio (rút gọn)**, **ElevenLabs Music (rút gọn)**. Xuất tệp .txt bằng `scripts/dong-goi-ai.py --cong-cu ...`. Ghi các giới hạn ký tự kèm "cần kiểm tra lại".

## 7. Kết quả kiểm tra

| Bộ kiểm tra | Kết quả | Điểm đã sửa | Còn lại (lý do) |
|---|---|---|---|
| L1–L12 (nghề viết lời) | | | |
| V1–V16 (thi luật) | | | |
| T1–T10, N1–N9 (thanh–nhạc, đặt chữ) | tỉ lệ cùng/xiên/ngược | | |
| I1–I10 (nhạc cụ) | | | |
| Checklist nhanh 20 điểm | | | |

Ghi "chưa chạy script" nếu phiên không chạy được mã.

## 8. Kiểm tra bản AI tạo (sau khi người dùng có file âm thanh)

Ghi công cụ chép lời và chi phí; tỉ lệ khớp tính bằng so từng chữ; chữ nghe nhầm kèm mốc thời gian; **ghi riêng các lỗi tai người dùng phát hiện mà máy chép lời bỏ sót**.

| Bản | Lời chép từ âm thanh khớp lời gốc | Chữ bị nghe nhầm (mốc thời gian) | Phát âm/phương ngữ | Đủ cấu trúc, câu móc | Chọn |
|---|---|---|---|---|---|

## 9. Hướng dẫn sản xuất – phát hành

Theo `assets/mau-huong-dan-phat-hanh.md` (hậu kỳ, master, giao nộp, pháp lý, phân phối, lưu trữ bằng chứng).

## 10. Nhật ký sáng tạo

Xuất bằng `scripts/nhat-ky-sang-tac.py xuat` và chèn nguyên bảng vào đây (chế độ thương mại: bắt buộc).

## 11. Bản quyền và ghi công

- Lưu ý bản quyền theo `references/09-ban-quyen.md` và `references/17-phap-ly-phat-hanh.md` (không phải tư vấn pháp lý).
- Dòng ghi công đề xuất, ví dụ: "Lời & nhạc: [tác giả]. Sáng tác có sự hỗ trợ của công cụ AI (Claude; bản thu tạo bằng Suno)."
