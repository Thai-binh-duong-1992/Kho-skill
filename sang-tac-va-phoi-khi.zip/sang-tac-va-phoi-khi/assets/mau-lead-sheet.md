# Mẫu bản lời có hợp âm (lead sheet)

Dùng định dạng ChordPro rút gọn: hợp âm trong ngoặc vuông đặt **ngay trước âm tiết** đổi hợp âm. Đầu bản ghi thông tin nền.

```text
Tên bài: ...            Giọng: Am (bản gốc) · Capo: 0
Tempo: 72 BPM · Nhịp: 4/4 · Tiết tấu đệm: bolero
Âm vực giai điệu: A3–D5 (nữ) / A2–D4 (nam)
Số La Mã: i – iv – V7 – i

[Verse 1]
[Am]Chiều nay em [Dm]về qua bến [E7]cũ
[Am]Gió heo [F]may thổi [E7]nhẹ trên [Am]sông

[Chorus]                       ↗ nốt cao nhất D5 ở chữ "thương"
[A]Thương mấy cho [C#m]vừa…
```

Quy ước:
- `↗` giai điệu đi lên, `↘` đi xuống, `—` ngân, `~` luyến; ghi ở đầu câu khi không có ký âm.
- Ghi nốt cao nhất và thấp nhất của mỗi đoạn.
- Có cả số La Mã để nhạc công đổi giọng nhanh (`scripts/chuyen-giong.py`).
- Nhạc cụ đệm cần tiết tấu riêng thì ghi dòng `Tiết tấu:` dưới nhãn phần.

## Dạng dòng HA: / M: (bản 2.1 – dùng cho script)

Song song với bản ChordPro, lưu một tệp `giai-dieu.txt` cho các script `kiem-tra-thanh-nhac.py` và `tao-ban-nghe-thu.py`:

```text
Quy ước trường độ: nốt không ghi _n = 1 phách (ghi rõ nếu bài dùng 0.5)
[Chorus – song ca]
HA: F | G
Từ bàn tay che mưa năm ấy
M: E4 E4 G4 G4 A4 A4 C5_3
```

- `HA:` hợp âm theo ô nhịp, ngăn ô bằng `|`; hai hợp âm trong một ô ngăn bằng dấu cách (`F G | C`).
- `M:` mỗi chữ một nốt; `_n` = n phách; `G4-A4` = luyến một chữ qua hai nốt.
- Tên đoạn có "nam"/"male" → bản nghe thử hạ một quãng tám; "song ca"/"duet" → phát cả hai quãng tám.
