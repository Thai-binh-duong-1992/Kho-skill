# Skill sang-tac-va-phoi-khi – bản 2.3

Sáng tác lời, giai điệu, hòa âm phối khí, gói prompt cho công cụ nhạc AI (Suno đầy đủ; ElevenLabs, Udio rút gọn) và hướng dẫn sản xuất – phát hành bài hát, chuẩn nhạc Việt; vẫn dùng được cho mọi thể loại, ngôn ngữ, giọng hát, độ tuổi.

## Điểm mới bản 2.3 (04/11/2026) – hướng dẫn nút Suno v6
- `references/08-cong-cu-ai.md` mục mới **10.6a**: giải thích 8 nút "Tùy chọn khác" của Suno v6 giao diện tiếng Việt (Loại trừ, Giới tính giọng, Thời lượng, Chế độ Max, Độ kỳ lạ, Ảnh hưởng phong cách, Đa dạng, Cá nhân hóa) cùng Ảnh hưởng âm thanh, cây đũa phép, + Âm thanh/Voice/Inspo; giá trị đề xuất cho nhạc Việt truyền thống kèm nhãn nguồn; quy trình thử từng nút.
- `assets/mau-prompt-ai.md` mục 6 và SKILL.md Bước 8: gói Suno luôn kèm bảng cài 8 nút cho đúng bài.

## Điểm mới bản 2.2 (04/11/2026) – bổ sung thể thơ, chỉ nội dung có nguồn
- `12-thi-luat.md`: thêm nguyên tắc ưu tiên quy tắc đã kiểm chứng; sửa bảng thể thơ theo nguồn mới (vè, mưỡu, lục bát biến thể, bố cục Đường luật, thất ngôn xen lục ngôn, thơ 8 chữ…); mục mới §12.10 "Khung lời theo làn điệu" (lý Nam Bộ, quan họ, ví, giặm, vọng cổ nhịp 32, hát bội) và §12.11 "Các thể ngoài phạm vi lời ca"; sửa tham chiếu script ở bộ kiểm tra V.
- `11-nhac-viet-the-loai.md`: thêm thể lời có nguồn cho từng làn điệu, trỏ về §12.10.
- `kiem-tra-thi-luat.py`: không còn tự nhận Đường luật (khổ Thơ Mới 7 chữ từng bị báo lỗi sai); niêm tứ tuyệt và luật ngũ ngôn (chưa có nguồn) chỉ còn là ghi chú; chế độ mới `luc-bat-bt`, `xen-luc-ngon`, `hat-noi`, `4-chu`, `5-chu`; tiếng đệm trong `{…}` không bị đếm chữ; báo vần cách, vần ôm [QU] cho khổ 4 câu.
- `kiem-thu-script.py`: 27 ca kiểm thử hồi quy (thêm 5 ca cho các lỗi trên).
- SKILL.md: nguyên tắc "lời theo làn điệu" [Suy luận từ nhiều nguồn].

## Điểm mới bản 2.1 (03/11/2026) – sửa lỗi sau khi dùng thật với bài "Bàn tay che mưa"
- `dem-am-tiet.py`: bỏ qua dòng `M:`/`HA:` (trước đây đếm nhầm thành lời); cảnh báo chữ số (trước đây đếm thiếu không báo), chữ viết tắt, từ mượn; nhận **vần thông** (lâu–nhau, Tre–quê) cùng nhóm bằng/trắc; thêm `--phuong-ngu`.
- `kiem-tra-thanh-nhac.py`: có dòng lỗi dữ liệu thì không còn kết luận "ĐẠT"; thêm cờ **T11** (nguy cơ vuốt giọng thành sắc/ngã); bỏ qua dòng `HA:`.
- `kiem-tra-thi-luat.py`: bỏ qua dòng `HA:` (trước đây làm lệch cặp câu lục–bát).
- `tao-docx.py`: dấu `\|` trong ô bảng không còn tách cột; hỗ trợ ***đậm nghiêng***, tiêu đề cấp 5–6, việc cần làm `- [ ]`; không lặp tiêu đề khi dùng `--tieu-de`.
- `tinh-thoi-luong.py`: báo lỗi rõ khi BPM ≤ 0, nhịp sai, số ô ≤ 0; tên đoạn có dấu phẩy (ngăn bằng `;`).
- `nhat-ky-sang-tac.py`: lệnh mới `cap-nhat` (đổi tên bài, tác giả…) và `sua-muc` (sửa mục ghi nhầm, giữ lịch sử); giữ dấu `|` trong nội dung.
- Script mới `tao-ban-nghe-thu.py` (bản nghe thử giai điệu trên nền hợp âm, chỉ thư viện chuẩn) và `kiem-thu-script.py` (22 ca kiểm thử hồi quy).
- SKILL.md: Bước 6 bắt buộc bản nghe thử khi người dùng chọn giai điệu; Bước 9 báo chi phí trước khi chép lời, cách xử lý khi không tải được file, và **bắt buộc nghe bằng tai** vì máy chép lời tự sửa theo ngữ cảnh; Bước 11 xuất theo định dạng người dùng cần thay vì luôn làm cả Docs và Word; bảng tra số mục của các tệp 01–09; tệp 09 đổi số mục sang 9b.x (trước trùng 9.x với tệp 07).

## Điểm mới bản 2.0 so với 1.0
- Hai chế độ: **Cá nhân** và **Phát hành thương mại** (người dùng là tác giả chính, Claude dừng ở mọi bước sáng tạo, nhật ký sáng tạo tự động).
- Quy trình 11 bước: thêm kiểm tra bản AI tạo, sản xuất hậu kỳ, đóng gói Docs + Word.
- Toàn bộ tài liệu "Nhạc Việt sáng tác, hoà âm phối khí" (Phần 1–10) chuyển vào `references/11`–`17` và `ngon-ngu/vi.md`; quy tắc có bằng chứng [BC] được ưu tiên khi xung đột.
- Bộ kiểm tra tổng hợp T, N, V, L, I, A–I (`assets/checklist-tong-hop.md`).
- Script mới: `kiem-tra-thanh-nhac.py`, `kiem-tra-thi-luat.py`, `nhat-ky-sang-tac.py`, `tao-docx.py`; nâng cấp `dem-am-tiet.py`, `dong-goi-ai.py`.
- Pháp lý 2025–2026 (quyền tác giả khi có AI, gắn nhãn AI, thuế, phân phối) chỉ ghi vào tài liệu đầu ra, không làm gián đoạn sáng tác.

## Cài đặt
- **claude.ai / ứng dụng Claude:** Cài đặt (Settings) → Skills → tải tệp `sang-tac-va-phoi-khi.zip`, thay bản cũ cùng tên, bật skill.
- **Claude Code:** giải nén vào `~/.claude/skills/sang-tac-va-phoi-khi/`.

## Cách dùng
Nói tự nhiên, ví dụ: "Tôi muốn sáng tác và phát hành một bài bolero về quê mẹ, dùng Suno". Claude hỏi lần lượt 10–15 câu (câu đầu: cá nhân hay thương mại) rồi làm theo 11 bước.

## Cấu trúc
- `SKILL.md` – nguyên tắc nền, hai chế độ, quy trình 11 bước, bảng điểm dừng, quy tắc, bản đồ tệp
- `references/` – 01–10 (quốc tế, đã đồng bộ), 11–17 (nhạc Việt, thi luật, nghề viết lời, hòa âm và tập mẫu, nhạc cụ, sản xuất, pháp lý), `ngon-ngu/`, `nguon-tham-khao.md`
- `assets/` – phiếu thông tin, lead sheet, mẫu prompt AI, gói bàn giao, hướng dẫn sản xuất – phát hành, checklist tổng hợp, checklist nhanh 20 điểm
- `scripts/` – Python 3, không cần thư viện ngoài

## Bảo trì
Rà `references/08-cong-cu-ai.md` mỗi 3 tháng; `references/17-phap-ly-phat-hanh.md` khi có văn bản mới; chạy 18 bài kiểm thử trong `references/10-kiem-thu.md` mỗi 6 tháng; chạy `python3 scripts/kiem-thu-script.py` sau mỗi lần sửa script.

Phiên bản 2.3 – 04/11/2026. Các bản 2.2, 2.1, 2.0, 1.0 được lưu dự phòng.
