#!/usr/bin/env python3
"""abg_calc.py - tinh toan tat dinh cho skill abg-electrolyte-cdss (v2).
Dau vao: JSON (file hoac stdin). Dau ra: JSON gon. Thoat ma 2 neu thieu/sai du lieu.
Don vi: mmHg, mmol/L, Albumin g/L, Hb g/L hoac g/dL (tu nhan), FiO2 0.21-1.0 (hoac %).
KHOA HOP LE (sai ten khoa -> thoat ma 2, khong bo qua im lang):
  sample: arterial | central_venous | peripheral_venous | cord
  pH, pCO2, HCO3, HCO3_source (abg_calc | chemistry_tCO2), resp_chronic (true/false)
  Albumin_baseline_gL, AG_baseline (tuy chon: tham chieu nen cua chinh nguoi benh)
  Na, K, Cl, Albumin_gL, Lactate, Lactate_prev, iCa, Mg, PO4 (mmol/L)
  Glucose (mmol/L), Urea (mmol/L) HOAC BUN_mgdL, Osm_measured
  pO2, FiO2, Patm, SpO2, O2Hb, COHb, MetHb, Hb, CO_L_min
  age, sex (M/F), weight_kg, context (vd "DKA")
  Urine_PO4 (mmol/L), Serum_Cr va Urine_Cr (cung umol/L) -> FeP%
  cord: UA{pH,pCO2,pO2,BD,Lactate}, UV{pH,pCO2}
"""
import json, math, sys
KNOWN = {"sample","pH","pCO2","HCO3","HCO3_source","resp_chronic","Na","K","Cl","Albumin_gL","Albumin_baseline_gL","AG_baseline","Lactate","Lactate_prev",
         "iCa","Mg","PO4","Glucose","Urea","BUN_mgdL","Osm_measured","pO2","FiO2","Patm","SpO2","O2Hb","COHb","MetHb",
         "Hb","CO_L_min","age","sex","weight_kg","context","Urine_PO4","Urine_Cr","Serum_Cr","UA","UV"}

def fail(msg):
    print(json.dumps({"error": msg}, ensure_ascii=False)); sys.exit(2)

def rng(d, k, lo, hi):
    v = d.get(k)
    if v is None: return None
    try: v = float(v)
    except Exception: fail(f"{k} khong phai so: {v!r}")
    if not (lo <= v <= hi): fail(f"{k}={v} ngoai khoang sinh ly cho phep [{lo},{hi}] - kiem tra don vi/nhap lieu")
    return v

def main():
    d = json.load(open(sys.argv[1])) if len(sys.argv) > 1 else json.load(sys.stdin)
    out, alerts = {}, []
    bad = sorted(set(d) - KNOWN)
    if bad: fail(f"Khoa khong hop le: {bad}. Xem danh sach KHOA HOP LE trong docstring.")
    if "Urea" in d and "BUN_mgdL" in d: fail("Chi nhap mot trong Urea (mmol/L) hoac BUN_mgdL")
    if "BUN_mgdL" in d: d["Urea"] = float(d["BUN_mgdL"]) / 2.8
    st = d.get("sample", "arterial")  # arterial | central_venous | peripheral_venous | cord
    if st not in ("arterial", "central_venous", "peripheral_venous", "cord"): fail(f"sample khong hop le: {st}")
    if st == "cord":
        return cord(d)
    pH = rng(d, "pH", 6.5, 8.0); pco2 = rng(d, "pCO2", 5, 200); hco3 = rng(d, "HCO3", 1, 60)
    if None in (pH, pco2): fail("bat buoc co pH va pCO2")
    hco3_src = d.get("HCO3_source", "abg_calc")  # abg_calc | chemistry_tCO2
    if hco3 is None:
        hco3 = 0.03 * pco2 * 10 ** (pH - 6.1); hco3_src = "abg_calc"
    # Quy doi mau tinh mach (uoc tinh, khong dung pO2)
    if st != "arterial":
        dpH, dCO2, dHC = (0.035, 4.5, 0.8) if st == "central_venous" else (0.03, 5.0, 1.0)
        pH, pco2, hco3 = pH + dpH, pco2 - dCO2, hco3 - dHC
        alerts.append("Mau tinh mach: gia tri da quy doi uoc tinh sang dong mach; KHONG danh gia oxy hoa bang pO2 tinh mach; quy doi kem tin cay khi soc/giam tuoi mau.")
    out["sample"] = st
    out["values_used"] = {"pH": round(pH, 3), "pCO2": round(pco2, 1), "HCO3": round(hco3, 1)}
    # Kiem tra Henderson-Hasselbalch chi co y nghia khi HCO3 tu sinh hoa (tCO2)
    pH_calc = 6.1 + math.log10(hco3 / (0.03 * pco2))
    out["HH_pH_calc"] = round(pH_calc, 3)
    if hco3_src == "chemistry_tCO2" and abs(pH_calc - pH) > 0.05:
        alerts.append(f"Khong nhat quan H-H (pH tinh {pH_calc:.2f} vs do {pH:.2f}): nghi sai nhap lieu / mau khac thoi diem.")
    # Phan loai nguyen phat
    status = "acidemia" if pH < 7.35 else "alkalemia" if pH > 7.45 else "normal_pH"
    out["pH_status"] = status
    prim = []
    if status == "acidemia":
        if hco3 < 22: prim.append("metabolic_acidosis")
        if pco2 > 45: prim.append("respiratory_acidosis")
    elif status == "alkalemia":
        if hco3 > 26: prim.append("metabolic_alkalosis")
        if pco2 < 35: prim.append("respiratory_alkalosis")
    else:
        if (pco2 > 45 and hco3 > 26) or (pco2 < 35 and hco3 < 22):
            prim.append("mixed_or_fully_compensated")
    out["primary_candidates"] = prim
    if status != "normal_pH" and not prim:
        alerts.append("pH bat thuong nhung pCO2/HCO3 khong vuot nguong: kiem tra lai so lieu hoac roi loan hon hop nhe - khong ket luan tu dong.")
    comp = {}
    def put(name, **kw): comp[name] = kw
    chronic = d.get("resp_chronic")  # True/False/None
    if "metabolic_acidosis" in prim:
        e = 40 - 1.2 * (24 - hco3); w = 1.5 * hco3 + 8
        put("metabolic_acidosis", pCO2_expected=[round(e - 3, 1), round(e + 3, 1)], winter_pCO2=[round(w - 2, 1), round(w + 2, 1)],
            verdict="kem toan ho hap" if pco2 > e + 3 else "kem kiem ho hap" if pco2 < e - 3 else "bu tru phu hop")
    if "metabolic_alkalosis" in prim:
        e = 40 + 0.7 * (hco3 - 24)
        put("metabolic_alkalosis", pCO2_expected=[round(e - 4, 1), round(e + 4, 1)],
            verdict="kem toan ho hap" if pco2 > e + 4 else "kem kiem ho hap" if pco2 < e - 4 else "bu tru phu hop")
    if "respiratory_acidosis" in prim:
        a = 24 + 0.1 * (pco2 - 40); c = 24 + 0.35 * (pco2 - 40)
        put("respiratory_acidosis", HCO3_expected_acute=round(a, 1), HCO3_expected_chronic=round(c, 1), chronic_flag=chronic,
            verdict=rverdict(hco3, a, c, chronic))
    if "respiratory_alkalosis" in prim:
        a = 24 - 0.2 * (40 - pco2); c = max(12, 24 - 0.5 * (40 - pco2))
        put("respiratory_alkalosis", HCO3_expected_acute=round(a, 1), HCO3_expected_chronic=round(c, 1), chronic_flag=chronic,
            verdict=rverdict(hco3, a, c, chronic))
    if len(prim) == 2: alerts.append("Hai roi loan nguyen phat cung chieu (toan chuyen hoa + toan ho hap): roi loan hon hop.")
    out["compensation"] = comp
    # Dien giai / AG
    na = rng(d, "Na", 90, 200); k = rng(d, "K", 1, 10); cl = rng(d, "Cl", 60, 150)
    alb = rng(d, "Albumin_gL", 5, 75); lac = rng(d, "Lactate", 0, 30)
    if na is not None and cl is not None:
        ag = na - (cl + hco3); out["AG"] = round(ag, 1)
        agc = ag + 0.23 * (45 - alb) if alb is not None else ag
        out["AG_corr"] = round(agc, 1)
        if alb is None: alerts.append("Thieu Albumin: AG chua hieu chinh, co the bo sot toan tang AG khi albumin thap.")
        alb0 = rng(d, "Albumin_baseline_gL", 5, 75); ag0 = rng(d, "AG_baseline", -5, 40)
        ref_ag = 12
        if alb0 is not None:
            if alb is None: fail("Co Albumin_baseline_gL nhung thieu Albumin_gL hien tai")
            agb = ag + 0.23 * (alb0 - alb); out["AG_corr_vs_baseline_alb"] = round(agb, 1)
            agc = agb  # uu tien tham chieu nen cua nguoi benh (Toffaletti, Chuong 2)
        if ag0 is not None:
            ref_ag = ag0; out["AG_rise_vs_baseline"] = round(agc - ag0, 1)
            if agc - ag0 > 4: alerts.append(f"AG (hieu chinh) tang {agc - ag0:.1f} so voi AG nen > 4 (vuot bien thien do luong ±4): goi y toan tang AG moi.")
        out["AG_reference_used"] = {"albumin_ref": alb0 if alb0 is not None else 45, "AG_ref": ref_ag}
        if (agc - ref_ag > 4 if ag0 is not None else agc > 16) and hco3 < 24:
            dg = (agc - ref_ag) - (24 - hco3); dr = (agc - ref_ag) / (24 - hco3)
            out["delta_gap"] = round(dg, 1); out["delta_ratio"] = round(dr, 2)
            out["delta_interp"] = ("toan tang AG + toan khong tang AG" if dg <= -5 or dr < 0.8 else
                                   "toan tang AG + kiem chuyen hoa (hoac nen toan ho hap man)" if dg >= 5 or dr >= 2.0 else
                                   "toan tang AG don thuan")
        ca = rng(d, "iCa", 0.3, 3.0); mg = rng(d, "Mg", 0.1, 5)
        sid = na + (k or 0) - cl - (lac or 0) + (2 * ca if ca else 0) + (2 * mg if mg else 0)
        out["SIDa"] = round(sid, 1)
    # Tham thau
    glu = rng(d, "Glucose", 0.5, 100); urea = rng(d, "Urea", 0.5, 100); osm_m = rng(d, "Osm_measured", 200, 450)
    if na is not None and glu is not None:
        out["Na_corr_glucose"] = round(na + 2.4 * max(0, glu - 5.55) / 5.55, 1)
        if urea is not None:
            oc = 2 * na + glu + urea; out["Osm_calc"] = round(oc, 1)
            if osm_m is not None:
                og = osm_m - oc; out["Osm_gap"] = round(og, 1)
                if og > 10: alerts.append(f"Khoang trong tham thau {og:.0f} > 10: nghi ruou doc (methanol, ethylene glycol...) neu kem toan tang AG.")
    # FWD
    wt = rng(d, "weight_kg", 2, 300)
    if na is not None and wt and (na > 145 or na < 130):
        if "sex" not in d or "age" not in d:
            alerts.append("Thieu tuoi/gioi: khong tinh TBW, thieu hut nuoc tu do, Adrogue-Madias.")
        else:
            sex, age = d["sex"], float(d["age"])
            if sex not in ("M", "F"): fail("sex phai la M hoac F")
            f = (0.5 if sex == "M" else 0.45) if age >= 65 else (0.6 if sex == "M" else 0.5)
            tbw = f * wt; out["TBW_L"] = round(tbw, 1)
            if na > 145: out["free_water_deficit_L"] = round(tbw * (na / 140 - 1), 2)
            out["AdrogueMadias_dNa_per_L"] = {"NaCl_3pct": round((513 + 0 - na) / (tbw + 1), 1),
                                             "NaCl_0_9pct": round((154 - na) / (tbw + 1), 1),
                                             "D5W": round((0 - na) / (tbw + 1), 1)}
            alerts.append("Adrogue-Madias thuong uoc thap muc thay doi Na: chi de khoi dau, do Na moi 2-4 gio.")
    po4 = rng(d, "PO4", 0.1, 5); up = rng(d, "Urine_PO4", 0.1, 200); ucr = rng(d, "Urine_Cr", 0.1, 50000); scr = rng(d, "Serum_Cr", 10, 3000)
    if cl is not None and po4: out["Cl_PO4_ratio_SI"] = round(cl / po4, 0)
    if po4 and up and ucr and scr: out["FeP_pct"] = round(up * scr / (po4 * ucr) * 100, 1)
    # Oxy hoa (chi mau dong mach)
    po2 = rng(d, "pO2", 10, 700); fio2 = d.get("FiO2")
    if fio2 is not None:
        fio2 = float(fio2); fio2 = fio2 / 100 if fio2 > 1 else fio2
        if not (0.21 <= fio2 <= 1.0): fail(f"FiO2={fio2} ngoai 0.21-1.0")
    if st == "arterial" and po2 is not None and fio2 is not None:
        patm = rng(d, "Patm", 400, 800) or 760
        pao2 = (patm - 47) * fio2 - pco2 / 0.8
        out["PAO2"] = round(pao2, 1); out["A_a"] = round(pao2 - po2, 1)
        age = d.get("age")
        if age: out["A_a_expected_max"] = round(age / 4 + 4, 1)
        pf = po2 / fio2; out["PF"] = round(pf, 0)
        if pf <= 300:
            out["PF_category"] = "nang (<=100)" if pf <= 100 else "vua (101-200)" if pf <= 200 else "nhe (201-300)"
            alerts.append("P/F <= 300: chi goi y ARDS khi dong thoi du tieu chuan lam sang - hinh anh (Berlin can PEEP >=5; dinh nghia toan cau 2023 chap nhan HFNO >=30 L/phut).")
    spo2 = rng(d, "SpO2", 30, 100); o2hb = rng(d, "O2Hb", 10, 100); cohb = rng(d, "COHb", 0, 80); methb = rng(d, "MetHb", 0, 80)
    if spo2 is not None and fio2 is not None and spo2 <= 97:
        out["SF"] = round(spo2 / fio2, 0)
    if spo2 is not None and o2hb is not None and spo2 - o2hb >= 5:
        alerts.append(f"SpO2 - O2Hb = {spo2 - o2hb:.0f}%: SpO2 gia binh thuong, xem COHb/MetHb.")
    if cohb is not None and cohb >= 5: alerts.append(f"COHb {cohb}% (nguoi hut thuoc co the toi 10%).")
    if methb is not None and methb >= 2: alerts.append(f"MetHb {methb}%.")
    hb = rng(d, "Hb", 3, 250)
    if hb is not None and po2 is not None and st == "arterial":
        hb_gdl = hb / 10 if hb > 25 else hb
        sat = (o2hb if o2hb is not None else spo2)
        if sat is not None:
            cao2 = 1.36 * hb_gdl * sat / 100 + 0.003 * po2; out["CaO2_mL_dL"] = round(cao2, 1)
            co = rng(d, "CO_L_min", 0.5, 20)
            if co: out["DO2_mL_min"] = round(co * cao2 * 10, 0)
    # Kali & lactat
    if k is not None:
        if k >= 6.0: alerts.append(f"K+ {k}: tang kali nang - can ECG ngay.")
        if k < 3.5 and d.get("context") == "DKA": alerts.append("DKA voi K+ < 3.5: HOAN insulin, bu K+ truoc (ADA/EASD 2024).")
        if k >= 5.5 and pH >= 7.35: alerts.append("Tang K+ voi pH binh thuong: loai tru gia tang kali (tan mau, garo, tieu cau/bach cau cao).")
    if lac is not None:
        out["lactate_level"] = "binh thuong" if lac < 2 else "tang (2-4)" if lac <= 4 else "tang nang (>4)"
        lac0 = rng(d, "Lactate_prev", 0, 30)
        if lac0: out["lactate_clearance_pct"] = round((lac0 - lac) / lac0 * 100, 0)
    out["alerts"] = alerts
    print(json.dumps(out, ensure_ascii=False))

def rverdict(hco3, a, c, chronic):
    lo, hi = (min(a, c), max(a, c)) if chronic is None else ((c, c) if chronic else (a, a))
    if hco3 < lo - 2: return "kem toan chuyen hoa"
    if hco3 > hi + 2: return "kem kiem chuyen hoa"
    return "bu tru phu hop" + (" (chua ro cap/man)" if chronic is None else "")

def cord(d):
    ua = d.get("UA", {}); uv = d.get("UV", {})
    a = []
    for key in ("pH", "pCO2"):
        if key not in ua: fail(f"mau cuong ron thieu UA.{key}")
    if uv and "pH" in uv and ua["pH"] >= uv["pH"]: a.append("pH DM ron >= TM ron: nghi nham mau DM/TM.")
    if uv and "pCO2" in uv and ua["pCO2"] <= uv["pCO2"]: a.append("pCO2 DM ron <= TM ron: nghi nham mau DM/TM.")
    if ua["pH"] < 7.0: a.append("pH DM ron < 7,00 (nguong ngat chu sinh).")
    if ua.get("BD", 0) >= 12: a.append("BD DM ron >= 12 mmol/L.")
    if ua.get("Lactate", 0) > 6.0: a.append("Lactat DM ron > 6,0 mmol/L.")
    if uv and "pCO2" in uv and ua["pCO2"] - uv["pCO2"] > 25: a.append("Chenh pCO2 DM-TM > 25 mmHg: goi y tac day ron cap.")
    if ua.get("pO2", 0) > 38: a.append("pO2 DM ron > 38 mmHg: nghi bot khi hoac lay nham mau TM.")
    print(json.dumps({"sample": "cord", "alerts": a}, ensure_ascii=False))

if __name__ == "__main__":
    main()
