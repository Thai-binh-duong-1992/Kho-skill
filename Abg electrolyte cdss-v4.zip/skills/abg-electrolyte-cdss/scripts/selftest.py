#!/usr/bin/env python3
"""Tu kiem 7 ca cho abg_calc.py. Chay: python3 scripts/selftest.py  -> phai 16/16 PASS."""
import json, subprocess, sys, os
CALC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "abg_calc.py")
def run(d):
    p = subprocess.run([sys.executable, CALC], input=json.dumps(d), capture_output=True, text=True)
    return p.returncode, json.loads(p.stdout)
cases = [
 ("DKA toan tang AG don thuan + canh bao K",
  {"pH":7.10,"pCO2":20,"HCO3":6,"Na":135,"Cl":100,"K":3.2,"Albumin_gL":40,"context":"DKA"},
  lambda c,o: c==0 and o["AG"]==29.0 and o["delta_interp"]=="toan tang AG don thuan" and any("HOAN insulin" in a for a in o["alerts"])),
 ("Toan ho hap man bu du",
  {"pH":7.34,"pCO2":60,"HCO3":31,"resp_chronic":True,"pO2":55,"FiO2":0.28,"age":70,"Hb":120,"SpO2":88},
  lambda c,o: c==0 and o["compensation"]["respiratory_acidosis"]["HCO3_expected_chronic"]==31.0 and o["CaO2_mL_dL"]==14.5),
 ("Mau TM trung tam - roi loan hon hop",
  {"sample":"central_venous","pH":7.25,"pCO2":50,"HCO3":21,"pO2":38},
  lambda c,o: c==0 and len(o["primary_candidates"])==2 and "PAO2" not in o),
 ("Cuong ron ngat",
  {"sample":"cord","UA":{"pH":6.95,"pCO2":75,"BD":14,"Lactate":8},"UV":{"pH":7.15,"pCO2":45}},
  lambda c,o: c==0 and len(o["alerts"])==4),
 ("Kiem chuyen hoa bu phu hop",
  {"pH":7.52,"pCO2":48,"HCO3":38,"Na":138,"Cl":88,"K":2.8},
  lambda c,o: c==0 and o["compensation"]["metabolic_alkalosis"]["verdict"]=="bu tru phu hop"),
 ("Toan hon hop AG + tang Cl, CO",
  {"pH":7.30,"pCO2":30,"HCO3":14,"Na":140,"Cl":115,"Albumin_gL":20,"pO2":60,"FiO2":60,"SpO2":91,"COHb":12,"O2Hb":80},
  lambda c,o: c==0 and o["delta_interp"]=="toan tang AG + toan khong tang AG" and o["PF"]==100),
 ("Nhap sai don vi -> thoat ma 2",
  {"pH":74,"pCO2":40},
  lambda c,o: c==2 and "error" in o),
 ("Sai ten khoa -> thoat ma 2 (khong bo qua im lang)",
  {"pH":7.30,"pCO2":30,"HCO3":14,"Na":140,"Cl":110,"Albumin":20},
  lambda c,o: c==2 and "Albumin" in o["error"]),
 ("Toan ho hap CAP + HCO3 31 -> kem kiem chuyen hoa",
  {"pH":7.34,"pCO2":60,"HCO3":31,"resp_chronic":False},
  lambda c,o: c==0 and o["compensation"]["respiratory_acidosis"]["verdict"]=="kem kiem chuyen hoa"),
 ("pH bat thuong, khong ro nguyen phat -> canh bao",
  {"pH":7.33,"pCO2":44,"HCO3":23},
  lambda c,o: c==0 and any("khong ket luan tu dong" in a for a in o["alerts"])),
 ("Tang Na thieu tuoi/gioi -> khong tu gia dinh",
  {"pH":7.40,"pCO2":40,"HCO3":24,"Na":155,"weight_kg":60},
  lambda c,o: c==0 and "free_water_deficit_L" not in o and any("Thieu tuoi/gioi" in a for a in o["alerts"])),
 ("Ha Na + BUN mg/dL + Adrogue-Madias",
  {"pH":7.40,"pCO2":40,"HCO3":24,"Na":120,"K":4,"Glucose":5,"BUN_mgdL":28,"weight_kg":60,"sex":"F","age":70},
  lambda c,o: c==0 and o["Osm_calc"]==255.0 and o["AdrogueMadias_dNa_per_L"]["NaCl_3pct"]==14.0),
 ("FeP% va Cl:PO4",
  {"pH":7.40,"pCO2":40,"HCO3":24,"Na":140,"Cl":104,"PO4":0.5,"Urine_PO4":10,"Serum_Cr":80,"Urine_Cr":8000},
  lambda c,o: c==0 and o["FeP_pct"]==20.0 and o["Cl_PO4_ratio_SI"]==208),
 ("Bang 2.2 sach: albumin cao 70, lactat binh thuong -> AG hieu chinh ~12",
  {"pH":7.40,"pCO2":40,"HCO3":24,"Na":140,"K":4,"Cl":98,"Albumin_gL":70,"Lactate":2},
  lambda c,o: c==0 and o["AG"]==18.0 and o["AG_corr"]==12.2),
 ("Albumin/AG nen cua nguoi benh: AG tang moi duoc phat hien",
  {"pH":7.30,"pCO2":32,"HCO3":16,"Na":136,"Cl":108,"Albumin_gL":22,"Albumin_baseline_gL":30,"AG_baseline":6},
  lambda c,o: c==0 and o["AG_corr_vs_baseline_alb"]==13.8 and o["AG_rise_vs_baseline"]==7.8 and any("AG nen" in a for a in o["alerts"])),
 ("Albumin nen ma thieu albumin hien tai -> thoat ma 2",
  {"pH":7.40,"pCO2":40,"HCO3":24,"Na":140,"Cl":104,"Albumin_baseline_gL":35},
  lambda c,o: c==2),
]
ok = 0
for name, d, chk in cases:
    c, o = run(d); r = chk(c, o); ok += r
    print(("PASS " if r else "FAIL ") + name)
print(f"{ok}/{len(cases)} PASS"); sys.exit(0 if ok == len(cases) else 1)
