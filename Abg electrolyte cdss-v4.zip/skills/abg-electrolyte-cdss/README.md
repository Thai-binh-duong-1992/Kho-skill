# abg-electrolyte-cdss v2.4 — Skill hỗ trợ đọc khí máu & điện giải

Tác giả / phụ trách: BS. Nguyễn Trung Kiên — ngày 15/11/2026.

## Skill làm gì
Từ một bộ kết quả khí máu (động mạch, tĩnh mạch, cuống rốn) và điện giải → một phiếu phân tích toan-kiềm, oxy hóa, điện giải, lactat kèm đề xuất xử trí ưu tiên cho **người lớn**. Mọi phép tính do script Python thực hiện (không để mô hình tự làm toán).

Gọi skill bằng các câu như: "đọc giúp khí máu ca này", "phân tích khí máu / ABG", "ca này rối loạn toan kiềm gì", hoặc dán thẳng kết quả.

## Cài đặt
- **Claude (web/desktop):** Cài đặt → Năng lực (Capabilities) → Skills → Tải lên skill → chọn file `abg-electrolyte-cdss.zip`. Cần bật "Code execution" để chạy script.
- **Claude Code:** giải nén vào `~/.claude/skills/` (dùng cho cá nhân) hoặc `.claude/skills/` trong dự án.
- Kiểm tra: `python3 scripts/selftest.py` → phải ra `16/16 PASS`.

## Cấu trúc
```
abg-electrolyte-cdss/
├── SKILL.md            quy trình, checklist "Xong nghĩa là", Bảo vệ, phụ lục
├── scripts/abg_calc.py tính toán tất định (JSON vào → JSON ra, có kiểm khoảng sinh lý)
└── scripts/selftest.py 16 ca thử hồi quy
```

## Lưu ý an toàn
- Đầu ra là **phiếu hỗ trợ quyết định**. Bác sĩ điều trị xác nhận trước khi ra y lệnh.
- Không dùng để tính liều nhi khoa. Với khí máu cuống rốn chỉ diễn giải, không kê liều.
- Không đưa họ tên hoặc số hồ sơ người bệnh vào dữ liệu nhập.
- Nguồn: Toffaletti & Rackley, *Blood Gases and Critical Care Testing* 3rd Ed. (2022); Định nghĩa ARDS toàn cầu 2023; Sepsis-3; SSC 2021; Đồng thuận ADA/EASD 2024. Hệ số AG hiệu chỉnh cần đối chiếu sách gốc trước khi áp dụng tại đơn vị.
