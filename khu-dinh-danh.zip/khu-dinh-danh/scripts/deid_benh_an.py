#!/usr/bin/env python3
"""
deid_benh_an.py — Khử định danh bệnh án, chạy 100% offline.   (phiên bản 4.2c)

Bản dựng lại bằng mã Python đọc được từ ứng dụng KhuDinhDanh.exe (lõi deid_benh_an 4.2),
dùng làm lõi cho skill "khu-dinh-danh". Kết quả khử định danh giữ nguyên như bản app.

Hỗ trợ: .txt, .docx, .xlsx, .pdf (PDF có lớp chữ; xuất ra .txt)

Cách dùng:
    python deid_benh_an.py benh_an.pdf
    python deid_benh_an.py thu_muc_benh_an/
    python deid_benh_an.py thu_muc/ --doi-ngay 37          (dịch lùi mọi ngày tháng 37 ngày)
    python deid_benh_an.py thu_muc/ --xoa-nam-sinh --giu-ten-nvyt

Mặc định: xóa tên bệnh nhân, người nhà, nhân viên y tế; giữ năm sinh; không dịch ngày.

Mỗi file đầu vào tạo ra:
    <tên>_DEID.<đuôi>        file đã khử định danh
    <tên>_DEID_log.txt       thống kê số chỗ đã thay (không chứa dữ liệu thật)
    <tên>_DEID_KIEMTRA.txt   (nếu có) danh sách chỗ NGHI CÒN SÓT để người duyệt xem lại.
                             File này có thể chứa dữ liệu thật — XÓA sau khi duyệt.

Khóa bí mật: file deid_khoa.txt (ngẫu nhiên) cạnh script; cùng khóa => cùng một người luôn ra cùng một mã.
"""
import argparse
import datetime as dt
import functools
import hashlib
import re
import secrets
import sys
import unicodedata
from collections import Counter
from pathlib import Path

# ---------------------------------------------------------------- bảng ký tự
_CHARS = [chr(c) for c in list(range(65, 123)) + list(range(192, 592)) + list(range(7840, 7930))]
HOA = ''.join(c for c in _CHARS if c.isalpha() and c.isupper())
THUONG = ''.join(c for c in _CHARS if c.isalpha() and c.islower())
CHU = HOA + THUONG
CHU_SET = frozenset(CHU)
_CAM_TRUOC = CHU_SET | {'[', '_'}
_CAM_SAU = CHU_SET | {']', '_'}
TU_TEN = f'(?:[{HOA}][{THUONG}]*|[{HOA}]+)'
RE_CHUOI_HOA = re.compile(f'(?<![{CHU}\\[_])({TU_TEN}(?: {TU_TEN})*)(?![{CHU}\\]_])')
RE_PLACEHOLDER = re.compile('\\[[A-ZÀ-Ỹ_:]+(?:_[0-9A-F]{6})?\\]|\\[xx/xx/\\d{4}\\]')


def bo_dau(s):
    s = unicodedata.normalize('NFD', s)
    s = ''.join(c for c in s if unicodedata.category(c) != 'Mn')
    return s.replace('đ', 'd').replace('Đ', 'D')


_RE_TRANG = re.compile('\\s+')


@functools.lru_cache(maxsize=65536)
def chuan(s):
    return _RE_TRANG.sub(' ', bo_dau(s)).strip().upper()


# ---------------------------------------------------------------- từ điển & nhãn
HO_VN = set(['bành', 'bùi', 'bạch', 'bế', 'cao', 'chau', 'chu', 'châu', 'cù', 'cấn', 'cổ', 'danh', 'diệp', 'doãn', 'dư', 'dương',
 'giang', 'giáp', 'hoa', 'hoàng', 'huỳnh', 'hà', 'hàn', 'hầu', 'hồ', 'hứa', 'kha', 'khúc', 'khưu', 'khương', 'khổng',
 'kim', 'kiều', 'la', 'lâm', 'lã', 'lê', 'lò', 'lý', 'lăng', 'lưu', 'lương', 'lường', 'lạc', 'lại', 'lục', 'lữ', 'ma',
 'mai', 'mã', 'mông', 'mạc', 'mạch', 'mẫn', 'nghiêm', 'nguyễn', 'ngô', 'ngụy', 'nhan', 'ninh', 'nông', 'phan', 'phí',
 'phó', 'phùng', 'phạm', 'quan', 'quang', 'quách', 'sơn', 'sầm', 'thái', 'thân', 'thôi', 'thạch', 'tiêu', 'triệu',
 'trác', 'trình', 'trương', 'trần', 'trịnh', 'tô', 'tôn', 'tăng', 'tạ', 'tất', 'tống', 'từ', 'ung', 'uông', 'vi',
 'viên', 'vòng', 'võ', 'vũ', 'vương', 'ân', 'âu', 'ông', 'đinh', 'đoàn', 'đàm', 'đào', 'đậu', 'đặng', 'đồng', 'đỗ'])

TEN_DEM = set(['thị', 'văn'])

TU_LOAI_TRU = set(['bhxh', 'bhyt', 'biên', 'bs', 'bscki', 'bscki.', 'bsckii', 'bsnt', 'bác', 'bđ', 'bản', 'bảng', 'bệnh', 'bộ', 'chai',
 'chuyển', 'chất', 'chẩn', 'chụp', 'chủ', 'chứng', 'cki', 'ckii', 'cn', 'cnxn', 'cái', 'cấp', 'cắt', 'cộng', 'của',
 'cứu', 'diện', 'do', 'ds', 'dsckii', 'duyệt', 'dân', 'dõi', 'dưỡng', 'dược', 'dị', 'dịch', 'ghi', 'giai', 'giá',
 'giám', 'giải', 'giấy', 'giới', 'giờ', 'gmhs', 'gs', 'gây', 'gói', 'hiểm', 'hoạch', 'huyết', 'huyện', 'hình',
 'hướng', 'họ', 'học', 'hồi', 'hợp', 'kcb', 'kcbbđ', 'khuẩn', 'khám', 'kinh', 'kiểm', 'ktv', 'kê', 'ký', 'kế', 'kết',
 'lai', 'lần', 'lọ', 'lọc', 'lớp', 'miếng', 'ms', 'máu', 'mã', 'mê', 'mạn', 'mẫu', 'nghiệm', 'nghiệp', 'nghề',
 'ngoại', 'ngày', 'người', 'nhi', 'nhiễm', 'nhs', 'nhà', 'nhận', 'nhịp', 'nv', 'nơi', 'nội', 'nộp', 'pgs', 'phiếu',
 'phòng', 'phó', 'phường', 'phần', 'phẫu', 'phố', 'phụ', 'quát', 'quả', 'quận', 'quỹ', 'rõ', 'siêu', 'soát', 'suy',
 'sàng', 'sĩ', 'sơ', 'sản', 'số', 'sở', 'sức', 'sử', 'theo', 'ths', 'thuốc', 'tháng', 'tháo', 'thôn', 'thư', 'thận',
 'thở', 'thực', 'tim', 'tiêm', 'tiền', 'toán', 'truyền', 'trưởng', 'trả', 'trấn', 'trị', 'ts', 'tuyến', 'tuổi', 'tên',
 'tính', 'tóm', 'tại', 'tắt', 'tế', 'tỉnh', 'tổ', 'tổng', 'tộc', 'viện', 'vào', 'vị', 'vụ', 'xn', 'xác', 'xã', 'xét',
 'ys', 'án', 'áp', 'âm', 'đa', 'đd', 'đdv', 'điều', 'điện', 'đk', 'đoán', 'đoạn', 'đái', 'đánh', 'đơn', 'đốc', 'độc',
 'ảnh', 'ấp', 'ống', 'ứng'])

TU_CO_THE_LA_TEN = set(['biên', 'bản', 'bảng', 'bộ', 'chuyển', 'chất', 'chủ', 'cấp', 'của', 'diện', 'duyệt', 'dân', 'dưỡng', 'dược', 'giá',
 'giải', 'giới', 'hoạch', 'hình', 'hướng', 'học', 'hồi', 'hợp', 'kinh', 'kiểm', 'ký', 'kế', 'lai', 'lọc', 'mẫu',
 'nghiệp', 'nhi', 'nhận', 'phần', 'phụ', 'quát', 'quả', 'rõ', 'sĩ', 'sơ', 'sản', 'sử', 'thôn', 'thư', 'thực', 'tiền',
 'toán', 'truyền', 'trưởng', 'trị', 'tuyến', 'tính', 'tại', 'tế', 'viện', 'vị', 'vụ', 'án', 'đa', 'điện', 'đoạn',
 'đơn', 'đốc', 'ảnh'])

DIA_DANH = set(['AN GIANG', 'BA RIA', 'BA RIA VUNG TAU', 'BAC GIANG', 'BAC KAN', 'BAC LIEU', 'BAC NINH', 'BACH MAI', 'BEN CAU',
 'BEN TRE', 'BINH DINH', 'BINH DUONG', 'BINH HOA', 'BINH PHUOC', 'BINH THUAN', 'CA MAU', 'CACH MANG THANG TAM',
 'CAN THO', 'CAO BANG', 'CHAU THANH', 'CHO RAY', 'DA NANG', 'DAK LAK', 'DAK NONG', 'DIEN BIEN', 'DINH TIEN HOANG',
 'DONG NAI', 'DONG THAP', 'DUONG MINH CHAU', 'GIA LAI', 'GO DAU', 'HA GIANG', 'HA NAM', 'HA NOI', 'HA TINH',
 'HAI BA TRUNG', 'HAI DUONG', 'HAI PHONG', 'HAU GIANG', 'HO CHI MINH', 'HO VAN HUE', 'HOA BINH', 'HOA THANH',
 'HOANG HOA THAM', 'HOANG VAN THU', 'HUE', 'HUNG VUONG', 'HUNG YEN', 'KHANH HOA', 'KIEN GIANG', 'KIM BANG', 'KON TUM',
 'LAI CHAU', 'LAM DONG', 'LANG SON', 'LAO CAI', 'LE DUAN', 'LE HONG PHONG', 'LE LOI', 'LE VAN THINH', 'LONG AN',
 'LONG HOA', 'LUONG SON', 'LY THUONG KIET', 'MAI CHAU', 'NAM DINH', 'NGHE AN', 'NGUYEN DINH CHIEU', 'NGUYEN HUE',
 'NGUYEN TRAI', 'NGUYEN TRI PHUONG', 'NGUYEN VAN CU', 'NINH BINH', 'NINH THUAN', 'PHAM NGOC THACH', 'PHAN DINH PHUNG',
 'PHAN RANG', 'PHAN THIET', 'PHU THO', 'PHU YEN', 'QUANG BINH', 'QUANG NAM', 'QUANG NGAI', 'QUANG NINH', 'QUANG TRI',
 'SOC TRANG', 'SON LA', 'TAN BIEN', 'TAN CHAU', 'TAY NINH', 'THAI BINH', 'THAI NGUYEN', 'THANH HOA', 'THONG NHAT',
 'THU DUC', 'THUA THIEN HUE', 'TIEN GIANG', 'TRA VINH', 'TRAN HUNG DAO', 'TRAN PHU', 'TRANG BANG', 'TRUNG VUONG',
 'TU DU', 'TUYEN QUANG', 'VINH LONG', 'VINH PHUC', 'VO THI SAU', 'VUNG TAU', 'YEN BAI'])

TINH_THANH = ['An Giang', 'Bà Rịa', 'Vũng Tàu', 'Bắc Giang', 'Bắc Kạn', 'Bạc Liêu', 'Bắc Ninh', 'Bến Tre', 'Bình Định',
 'Bình Dương', 'Bình Phước', 'Bình Thuận', 'Cà Mau', 'Cần Thơ', 'Cao Bằng', 'Đà Nẵng', 'Đắk Lắk', 'Đắk Nông',
 'Điện Biên', 'Đồng Nai', 'Đồng Tháp', 'Gia Lai', 'Hà Giang', 'Hà Nam', 'Hà Nội', 'Hà Tĩnh', 'Hải Dương', 'Hải Phòng',
 'Hậu Giang', 'Hòa Bình', 'Hưng Yên', 'Khánh Hòa', 'Kiên Giang', 'Kon Tum', 'Lai Châu', 'Lâm Đồng', 'Lạng Sơn',
 'Lào Cai', 'Long An', 'Nam Định', 'Nghệ An', 'Ninh Bình', 'Ninh Thuận', 'Phú Thọ', 'Phú Yên', 'Quảng Bình',
 'Quảng Nam', 'Quảng Ngãi', 'Quảng Ninh', 'Quảng Trị', 'Sóc Trăng', 'Sơn La', 'Tây Ninh', 'Thái Bình', 'Thái Nguyên',
 'Thanh Hóa', 'Thừa Thiên Huế', 'Tiền Giang', 'Trà Vinh', 'Tuyên Quang', 'Vĩnh Long', 'Vĩnh Phúc', 'Yên Bái', 'Huế',
 'Thủ Đức', 'Gò Dầu', 'Hòa Thành', 'Trảng Bàng', 'Châu Thành', 'Dương Minh Châu', 'Tân Biên', 'Tân Châu', 'Bến Cầu',
 'Long Hoa', 'Bình Hòa']

CUM_NHAN = [['năm', 'sinh'], ['ngày', 'sinh'], ['sinh', 'ngày'], ['giới', 'tính'], ['dân', 'tộc'], ['nghề', 'nghiệp'],
 ['địa', 'chỉ'], ['số', 'điện', 'thoại'], ['điện', 'thoại'], ['mã', 'số'], ['số', 'thẻ'], ['mã', 'thẻ'],
 ['số', 'giường'], ['số', 'phòng'], ['chẩn', 'đoán'], ['khoa', 'điều', 'trị'], ['họ', 'và', 'tên'], ['họ', 'tên'],
 ['ngày', 'vào', 'viện'], ['ngày', 'ra', 'viện'], ['tuổi'], ['giới'], ['phòng'], ['giường'], ['buồng']]

NHAN_TEN_BN = ['họ\\s*(?:và)?\\s*tên(?:\\s*người\\s*bệnh|\\s*bệnh\\s*nhân|\\s*bn)?', 'tên\\s*(?:người\\s*bệnh|bệnh\\s*nhân|bn)',
 'người\\s*bệnh', 'bệnh\\s*nhân',
 'họ\\s*tên\\s*(?:bố|mẹ|cha|vợ|chồng|con|người\\s*nhà|người\\s*thân|người\\s*giám\\s*hộ)',
 'người\\s*nhà(?:\\s*(?:bệnh\\s*nhân|người\\s*bệnh))?', 'người\\s*thân', 'người\\s*giám\\s*hộ',
 'người\\s*đại\\s*diện', 'người\\s*liên\\s*hệ', 'khi\\s*cần\\s*báo\\s*tin(?:\\s*cho)?', 'báo\\s*tin\\s*cho', 'name']

NHAN_TEN_NVYT = ['bác\\s*sĩ(?:\\s*(?:điều\\s*trị|làm\\s*bệnh\\s*án|khám(?:\\s*bệnh)?|chỉ\\s*định|đọc\\s*kết\\s*quả|trực|phẫu\\s*thuật|gây\\s*mê|hội\\s*chẩn|thực\\s*hiện|tham\\s*gia))?',
 '(?:nữ\\s*)?hộ\\s*sinh', 'điều\\s*dưỡng(?:\\s*(?:trưởng|viên|chăm\\s*sóc|thực\\s*hiện))?',
 'tên\\s*điều\\s*dưỡng(?:\\s*thực\\s*hiện)?', 'kỹ\\s*thuật\\s*viên(?:\\s*xét\\s*nghiệm)?',
 'cử\\s*nhân(?:\\s*xét\\s*nghiệm)?', 'dược\\s*sĩ', 'y\\s*sĩ', 'trưởng\\s*khoa', 'phó\\s*(?:trưởng\\s*)?khoa',
 'trưởng\\s*phòng', 'giám\\s*đốc', 'phó\\s*giám\\s*đốc', 'chủ\\s*(?:trì|tọa|tịch)', 'thư\\s*ký', 'thành\\s*viên',
 'phẫu\\s*thuật\\s*viên', 'phụ\\s*mổ',
 'người\\s*(?:làm\\s*bệnh\\s*án|thực\\s*hiện|đọc(?:\\s*kết\\s*quả)?|duyệt|giao(?:\\s*hồ\\s*sơ)?|nhận(?:\\s*hồ\\s*sơ|\\s*mẫu|\\s*tiền)?|lập(?:\\s*phiếu|\\s*bảng\\s*kê|\\s*biểu)?|ghi|ký|chỉ\\s*định|lấy\\s*mẫu|kiểm\\s*tra|xác\\s*nhận|đánh\\s*giá|nộp\\s*tiền|thu\\s*tiền)',
 'chỉ\\s*định\\s*bởi', 'kiểm\\s*soát\\s*bởi', 'ký\\s*bởi', 'ký\\s*tên', 'thực\\s*hiện\\s*bởi',
 'kế\\s*toán(?:\\s*viện\\s*phí)?', 'thủ\\s*quỹ', 'thu\\s*ngân',
 '(?:người\\s*|cán\\s*bộ\\s*)?giám\\s*định(?:\\s*viên|\\s*bhyt)?', 'cnxn', 'ktv(?:\\s*xn)?', 'nhs', 'đd']

CHUC_DANH = ['GS', 'PGS', 'TS', 'ThS', 'CKI{1,2}', 'CK[12]', 'BS(?:CK(?:I{1,2}|[12])|NT|ĐK|YHCT)?', 'Bs', 'bs',
 'CN\\.?[ ]?XN(?:YH)?', 'Cn\\.?[ ]?[Xx]n', 'cnxn', 'CNĐD', 'CNHS', 'CN', 'KTV\\.?[ ]?(?:XN)?', 'Ktv', 'NHS', 'HS',
 'NV', 'ĐD[VTS]?', 'ĐDCS', 'DS(?:CK(?:I{1,2}|[12])|ĐH)?', 'DSTH', 'YS', '(?i:bác\\s*sĩ)', '(?i:điều\\s*dưỡng)',
 '(?i:nữ\\s*hộ\\s*sinh)', '(?i:hộ\\s*sinh)', '(?i:kỹ\\s*thuật\\s*viên)', '(?i:cử\\s*nhân)', '(?i:dược\\s*sĩ)',
 '(?i:y\\s*sĩ)']

CHUC_DANH_BN = ['(?i:ông)', '(?i:bà)', '(?i:anh)', '(?i:chị)', '(?i:cô)', '(?i:chú)', '(?i:cháu)', '(?i:em)', '(?i:bé)', 'BN',
 '(?i:bệnh\\s*nhân)', '(?i:người\\s*bệnh)', '(?i:sản\\s*phụ)', '(?i:thai\\s*phụ)']

NHAN_KHAC = {'MÃ_HỒ_SƠ': ['mã\\s*(?:bn|bệnh\\s*nhân|người\\s*bệnh|y\\s*tế|yt|hồ\\s*sơ|lưu\\s*trữ|bệnh\\s*án|khám|đợt\\s*điều\\s*trị|điều\\s*trị|vào\\s*viện|tiếp\\s*nhận|phiếu|xét\\s*nghiệm|mẫu|bệnh\\s*phẩm|barcode|vạch|lk|liên\\s*kết|kcb|đk|hóa\\s*đơn|hoá\\s*đơn)',
              'mã\\s*số\\s*(?:người\\s*bệnh|bn|bệnh\\s*nhân)',
              'số\\s*(?:lưu\\s*trữ|vào\\s*viện|vv|bệnh\\s*án|hồ\\s*sơ|phiếu|nhập\\s*viện|khám\\s*bệnh|biên\\s*lai|hóa\\s*đơn|hoá\\s*đơn|chứng\\s*từ|tiếp\\s*nhận)',
              'pid', 'mrn', 'sid', 'barcode', 'mã\\s*định\\s*danh(?:\\s*y\\s*tế)?'],
 'MÃ_NVYT': ['mã\\s*(?:nv|nhân\\s*viên|bs|bác\\s*sĩ|người\\s*dùng|đăng\\s*nhập|cán\\s*bộ)', '(?:số\\s*)?cchn',
             '(?:số\\s*)?chứng\\s*chỉ\\s*hành\\s*nghề', 'user(?:name)?', 'tài\\s*khoản'],
 'NƠI_KCB_BĐ': ['nơi\\s*(?:đăng\\s*ký|đk)\\s*(?:khám\\s*(?:chữa\\s*)?bệnh\\s*|kcb\\s*)?(?:ban\\s*đầu|bđ)',
                'nơi\\s*đkbđ', 'nơi\\s*đk\\s*kcbbđ', '(?:cơ\\s*sở\\s*)?(?:kcb|khám\\s*chữa\\s*bệnh)\\s*ban\\s*đầu',
                'mã\\s*(?:nơi\\s*)?(?:đk\\s*)?(?:kcb\\s*)?(?:bđ|ban\\s*đầu)', 'mã\\s*cskcb(?:bđ)?', 'mã\\s*đkbđ',
                'mã\\s*kcbbđ', 'nơi\\s*đk\\s*kcb'],
 'NƠI_LÀM_VIỆC': ['nơi\\s*làm\\s*việc', 'cơ\\s*quan(?:\\s*công\\s*tác)?', 'đơn\\s*vị(?:\\s*công\\s*tác)'],
 'SĐT': ['(?:số\\s*)?điện\\s*thoại(?:\\s*số)?', 'sđt', 'đt(?:dđ)?', 'di\\s*động', 'tel', 'zalo', 'phone'],
 'SỐ_BHYT': ['(?:số\\s*|mã\\s*)?thẻ\\s*bhyt(?:\\s*\\d)?', 'số\\s*bhyt', 'bhyt\\s*số', 'mã\\s*bhyt',
             'mã\\s*số\\s*bhxh', 'số\\s*thẻ', 'mã\\s*thẻ(?:\\s*bảo\\s*hiểm(?:\\s*y\\s*tế)?)?(?:\\s*\\d)?',
             'thẻ\\s*bảo\\s*hiểm\\s*y\\s*tế(?:\\s*số)?'],
 'SỐ_GIẤY_TỜ': ['(?:số\\s*)?cccd', '(?:số\\s*)?cmnd', 'căn\\s*cước(?:\\s*công\\s*dân)?',
                'số\\s*định\\s*danh(?:\\s*cá\\s*nhân)?', 'hộ\\s*chiếu', 'giấy\\s*khai\\s*sinh'],
 'ĐỊA_CHỈ': ['địa\\s*chỉ(?:\\s+[^\\s:：]+){0,3}?', 'nơi\\s*ở(?:\\s*hiện\\s*nay)?', 'quê\\s*quán', 'nơi\\s*cư\\s*trú',
             'nơi\\s*sinh', 'hộ\\s*khẩu(?:\\s*thường\\s*trú)?', 'address']}

NHAN_NGAY_SINH = ['ngày\\s*(?:tháng\\s*năm\\s*)?sinh', 'sinh\\s*ngày', 'năm\\s*sinh', 'ns', 'dob']

MAU_TU_DO = [('EMAIL', '[\\w.+-]+@[\\w-]+\\.[\\w.-]+'),
 ('SỐ_BHYT', '(?<![A-Za-z0-9])[A-Z]{2}[ .\\-]?\\d[ .\\-]?\\d{2}(?:[ .\\-]?\\d){10}(?!\\d)'),
 ('MÃ_HỒ_SƠ', '\\b(?:HD|HĐ|BL|PT|PC)/\\d{6,8}/\\d+\\b'), ('MÃ_NVYT', '\\b\\d{6}/(?:BYT|SYT|[A-Z]{2,4})-CCHN\\b'),
 ('SỐ_GIẤY_TỜ', '(?<![\\d.,/:\\-])\\d{12}(?![\\d.,/])'), ('SỐ_GIẤY_TỜ', '(?<![\\d.,/:\\-])\\d{9}(?![\\d.,/])'),
 ('MÃ_SỐ', '(?<![\\d.,/:\\-])\\d{10,20}(?![\\d.,/])')]

RE_SDT = re.compile('(?<![\\d.,/\\-])(?:\\+84[ .]?|0)\\d{2,3}(?:[ .\\-]?\\d{3,4}){2}(?![\\d.,/\\-])')

RE_MAU_TU_DO = [(loai, re.compile(mau)) for loai, mau in MAU_TU_DO]
RE_KHOANG = re.compile('[ \\t]+')
_GOI = '|'.join(CHUC_DANH_BN)
RE_SAU_GOI = [
    re.compile(f'(?<![{CHU}])(?=(?:{g})[ \\t]+([{CHU}]+)(?:[ \\t]+([{CHU}]+))?)')
    for g in CHUC_DANH_BN
]
RE_O_CHU_NGANG = re.compile(f'(?<![^\\s|])(?:[{CHU}0-9][ \\t|]+){{3,}}[{CHU}0-9](?![^\\s|])')
RE_TEN_XUONG_DONG = re.compile(f'(\\[TÊN_[0-9A-F]{{6}}\\][ \\t]*\\n)[ \\t]*([{HOA}]{{2,7}})[ \\t]*(?=\\n|$)')
RE_NGAY_BHYT = re.compile(
    '((?i:thời\\s*điểm\\s*đủ\\s*0?5\\s*năm\\s*liên\\s*tục|miễn\\s*cùng\\s*chi\\s*trả(?:\\s*trong\\s*năm)?)'
    '(?:\\s*(?i:từ\\s*ngày))?\\s*[:：]?\\s*)(\\d{1,2}\\s*/\\s*\\d{1,2}\\s*/\\s*\\d{2,4})')
RE_GIUONG_1 = re.compile('((?i:(?:số\\s*)?giường)\\s*[:：]\\s*)(?i:giường\\s*số\\s*)?\\d+(?![\\d,.])')
RE_GIUONG_2 = re.compile('(?<![\\w])((?i:giường\\s*số)\\s*)\\d+(?![\\d,.])')
RE_BUONG = re.compile('((?i:(?:số\\s*)?(?:buồng|phòng))\\s*[:：]\\s*)\\d+(?![\\d,.])')
RE_MA_KCB = re.compile(
    '(\\[NƠI_KCB_BĐ_[0-9A-F]{6}\\][^\\n]*?(?<![\\w])mã(?:\\s*số)?(?:\\s*cơ\\s*sở)?\\s*[:：]\\s*)([^\\s;|)\\]]+)', re.I)
RE_O_MA = re.compile('^\\s*mã(?:\\s*số)?(?:\\s*cơ\\s*sở)?\\s*[:：]?\\s*$', re.I)
RE_NS_CO_NGAY = re.compile('\\d{1,2}\\s*[/.\\-]\\s*\\d{1,2}\\s*[/.\\-]\\s*\\d{2,4}|(?<!\\d)(?:19|20)\\d\\d(?!\\d)')
RE_NAM = re.compile('(19|20)\\d\\d')
RE_CHI_NAM = re.compile('\\s*(19|20)\\d\\d\\s*')
RE_CAT_GT = re.compile('\\s*[,(]|\\s+-\\s+')
RE_CHUOI_TEN_DAU = re.compile(f'{TU_TEN}(?: {TU_TEN})*')
RE_KHUC = re.compile('[ \\t]{2,}|\\t|\\|')
RE_KHUC_TEN = re.compile(f'{TU_TEN}(?: {TU_TEN}){{1,4}}')
RE_O_TEN = re.compile(f'{TU_TEN}(?: {TU_TEN})+')
RE_SOT_SAU_MA = re.compile(f'\\[TÊN_[0-9A-F]{{6}}\\] ({TU_TEN})(?![{CHU}])')
RE_DAY_SO_DAI = re.compile('(?<![\\d.,])\\d{6,}(?![\\d.,])')
RE_A_CONG = re.compile('@\\w')


@functools.lru_cache(maxsize=None)
def _bien_dich_nhan(ds_nhan):
    """Biên dịch danh sách nhãn thành regex "nhãn: giá trị"."""
    dung = (
        '(?=[ \\t]{2,}|\\t|\\n|;|\\||\\)|$|[ \\t]+(?:giới(?:\\s*tính)?|tuổi|dân\\s*tộc|nghề\\s*nghiệp|ngày\\s*sinh|'
        'năm\\s*sinh|sinh|sđt|điện\\s*thoại|mã\\s*bn|mã\\s*nv|cchn|ký\\s*tên|ngày|giá\\s*trị(?:\\s*sử\\s*dụng)?'
        '(?:\\s*từ)?|từ\\s*ngày|đến(?:\\s*ngày)?|hạn\\s*(?:sử\\s*dụng|thẻ)|nơi(?:\\s+\\S+){1,6}?|mã(?:\\s+\\S+){0,4}?|'
        'số(?:\\s+\\S+){0,3}?|khoa|phòng|buồng|giường)\\s*[:：])')
    return re.compile(
        '(?P<nhan>(?<![\\w])(?:' + '|'.join(ds_nhan)
        + ')(?:[ \\t]*\\([^)\\n]{0,30}\\))?[ \\t]*[:：][ \\t]*)(?P<gt>[^\\s;|)][^\\n;|)]*?)' + dung,
        re.IGNORECASE)


# ---------------------------------------------------------------- lõi
class KhuDinhDanh:
    def __init__(self, khoa, giu_nam_sinh=True, xoa_ten_nvyt=True, doi_ngay=0):
        self.khoa = khoa
        self.giu_nam_sinh = giu_nam_sinh
        self.xoa_ten_nvyt = xoa_ten_nvyt
        self.doi_ngay = doi_ngay
        self.ten = {}
        self.giu_lai = set()
        self.ma_da_gap = {}
        self.mo_rong = {}
        self.dem = Counter()

        self._da_biet = set()
        self._da_biet_max = 0
        self._ten_lien = {}
        self._phien = 0
        self._kh_phien = -1
        self._kh = ([], [], True)
        self._pat = {}

        self.re_ngay_sinh = self._nhan_re(NHAN_NGAY_SINH)
        self.re_khac = [(loai, self._nhan_re(ds)) for loai, ds in NHAN_KHAC.items()]
        self.re_nv = re.compile(
            f'(?<![{CHU}])(?:(?:{"|".join(CHUC_DANH)})[ \\t]*[.:,\\-]?[ \\t]*)+'
            f'(?P<ten>{TU_TEN}(?: {TU_TEN}){{1,7}})')

        nhan = NHAN_TEN_BN + (NHAN_TEN_NVYT if xoa_ten_nvyt else [])
        self.re_nhan_bn = self._nhan_re(NHAN_TEN_BN)
        self.re_nhan_ten = self._nhan_re(nhan)
        cd = CHUC_DANH_BN + (CHUC_DANH if xoa_ten_nvyt else [])
        self.re_cd_dau = re.compile(f'^(?:(?:{"|".join(CHUC_DANH)})[ \\t]*[.:,\\-]?[ \\t]*)+')
        self.re_chuc_danh = re.compile(
            f'(?<![{CHU}])(?:(?:{"|".join(cd)})[ \\t]*[.:,\\-]?[ \\t]*)+'
            f'(?P<ten>{TU_TEN}(?: {TU_TEN}){{1,7}})')
        self.re_goi_y_ky = re.compile(
            '\\(\\s*ký|họ\\s*tên|người\\s*(?:lập|thực\\s*hiện|duyệt|đọc|giao|nhận|thu|nộp|đánh)|kế\\s*toán|giám\\s*định|'
            'xác\\s*nhận|thủ\\s*quỹ|thu\\s*ngân|trưởng\\s*khoa|bác\\s*s[ĩỹ]|cn\\.?\\s*xn|ktv|kỹ\\s*thuật\\s*viên|'
            'điều\\s*dưỡng|hộ\\s*sinh|nhs|giám\\s*đốc|thư\\s*ký|chủ\\s*tọa|tham\\s*gia|<chuky', re.I)
        self.nhan_o = [
            (re.compile('^\\s*(?:' + '|'.join(nhan) + ')\\s*[:：]?\\s*$', re.I), 'TÊN'),
            (re.compile('^\\s*(?:' + '|'.join(NHAN_NGAY_SINH) + ')\\s*[:：]?\\s*$', re.I), 'NGÀY_SINH'),
        ]
        for loai, ds in NHAN_KHAC.items():
            self.nhan_o.append((re.compile('^\\s*(?:' + '|'.join(ds) + ')\\s*[:：]?\\s*$', re.I), loai))

    # ------------------------------------------------------------ mã giả
    def ma_gia(self, loai, gia_tri):
        if loai == 'TÊN':
            k = chuan(gia_tri).replace(' ', '')
        else:
            k = chuan(gia_tri)
        h = hashlib.sha256((self.khoa + '|' + loai + '|' + k).encode()).hexdigest()
        return f'[{loai}_{h[:6].upper()}]'

    @staticmethod
    def _nhan_re(ds_nhan):
        return _bien_dich_nhan(tuple(ds_nhan))

    def la_ho(self, w):
        return w.lower() in HO_VN

    def _hop_le(self, tu, can_ho=False):
        if not (2 <= len(tu) <= 6):
            return False
        if any(w.lower() in TU_LOAI_TRU and not (j >= 2 and w.lower() in TU_CO_THE_LA_TEN)
               for j, w in enumerate(tu)):
            return False
        if can_ho and not self.la_ho(tu[0]):
            return False
        if chuan(' '.join(tu)) in DIA_DANH:
            return False
        if all(len(w) == 1 for w in tu):
            return False
        dai = [w for w in tu if len(w) > 1]
        if dai and (all(w.isupper() for w in dai) or all(not w[1:].isupper() for w in dai)):
            return True
        return False

    def _them_ten(self, tu, uu_tien=1):
        if isinstance(tu, str):
            tu = tu.split()
        tu = [w.strip(' .,:-') for w in tu if w.strip(' .,:-')]
        if not tu:
            return
        ten = ' '.join(tu)
        k = chuan(ten)
        if k in self.giu_lai and uu_tien < 3:
            return
        goc = self.mo_rong.get(k)
        if goc and uu_tien > 0 and self._hop_le(goc):
            self._them_ten(goc, 0)
        cu = self.ten.get(k)
        if cu:
            if uu_tien <= cu[2]:
                return
            cu[2] = uu_tien
        else:
            ma = self.ma_gia('TÊN', ten)
            self.ten[k] = [ten, ma, uu_tien]
            self._ten_lien.setdefault(k.replace(' ', ''), ma)
        self._phien += 1
        if uu_tien > 0:
            kt = tuple(k.split())
            self._da_biet.add(kt)
            self._da_biet_max = max(self._da_biet_max, len(kt))

    def tach_chuoi(self, tu):
        """Tách chuỗi từ viết hoa thành các đoạn là tên người."""
        doan, cur = [], []
        i = 0
        ds_goc = []
        kieu = lambda x: 'U' if len(x) > 1 and x.isupper() else ('T' if len(x) > 1 else '')
        cw = [chuan(w) for w in tu]
        da_biet = self._da_biet
        so_tu = len(tu)
        while i < so_tu:
            khop = next((n for n in range(min(self._da_biet_max, so_tu - i), 0, -1)
                         if tuple(cw[i:i + n]) in da_biet), 0)
            if khop:
                if cur:
                    doan.append(cur)
                cur = []
                i += khop
                continue
            dd = next((n for n in (4, 3, 2)
                       if i + n <= so_tu and ' '.join(cw[i:i + n]) in DIA_DANH), 0)
            if dd:
                if cur:
                    doan.append(cur)
                cur = []
                i += dd
                continue
            nhan = next((len(c) for c in CUM_NHAN
                         if [w.lower() for w in tu[i:i + len(c)]] == c), 0)
            if (not nhan and tu[i].lower() in TU_CO_THE_LA_TEN and 2 <= len(cur) <= 4
                    and self.la_ho(cur[0])
                    and all((not kieu(c)) or kieu(c) == kieu(tu[i]) for c in cur)
                    and (i + 1 == len(tu) or tu[i + 1].lower() not in TU_LOAI_TRU)):
                ds_goc.append(list(cur))
                cur.append(tu[i])
                i += 1
                continue
            if nhan or tu[i].lower() in TU_LOAI_TRU:
                if cur:
                    doan.append(cur)
                cur = []
                i += max(nhan, 1)
                continue
            if cur and kieu(tu[i]) and any(kieu(c) and kieu(c) != kieu(tu[i]) for c in cur):
                doan.append(cur)
                cur = []
            cur.append(tu[i])
            i += 1
        if cur:
            doan.append(cur)

        kq = []
        for d in doan:
            seg = [d[0]]
            for j in range(1, len(d)):
                w = d[j]
                sau = d[j + 1].lower() if j + 1 < len(d) else ''
                tach = (self.la_ho(w) and seg[-1].lower() not in TEN_DEM
                        and (len(seg) >= 3 or (len(seg) >= 2 and sau in TEN_DEM)))
                if tach or len(seg) >= 5:
                    kq.append(seg)
                    seg = [w]
                else:
                    seg.append(w)
            kq.append(seg)
        for seg in kq:
            for g in ds_goc:
                if len(seg) > len(g) and seg[:len(g)] == g:
                    self.mo_rong[chuan(' '.join(seg))] = g
        return kq

    @staticmethod
    def _khoa_ma(gt):
        return re.sub('[^0-9A-Za-z]', '', bo_dau(gt)).upper()

    def _ghi_ma(self, loai, gt):
        k = self._khoa_ma(gt)
        if len(k) >= 4:
            self.ma_da_gap.setdefault(k, self.ma_gia(loai, gt))

    # ------------------------------------------------------------ thu thập tên
    def thu_thap_ten(self, text):
        sach = RE_PLACEHOLDER.sub(' | ', text)
        for loai, re_n in self.re_khac:
            if loai in ('ĐỊA_CHỈ', 'NƠI_LÀM_VIỆC', 'NƠI_KCB_BĐ'):
                continue
            for m in re_n.finditer(sach):
                self._ghi_ma(loai, m.group('gt').strip())
        if not self.xoa_ten_nvyt:
            for m in self.re_nv.finditer(sach):
                ds = self.tach_chuoi(m.group('ten').split())
                if ds and self._hop_le(ds[0]):
                    self.giu_lai.add(chuan(' '.join(ds[0])))
        for re_n, ut in ((self.re_nhan_bn, 3), (self.re_nhan_ten, 2)):
            for m in re_n.finditer(sach):
                gt = RE_CAT_GT.split(m.group('gt'))[0].strip()
                gt = self.re_cd_dau.sub('', gt)
                m2 = RE_CHUOI_TEN_DAU.match(gt)
                if not m2:
                    continue
                for d in self.tach_chuoi(m2.group().split())[:1]:
                    if self._hop_le(d):
                        self._them_ten(d, ut)
        for m in self.re_chuc_danh.finditer(sach):
            ds = self.tach_chuoi(m.group('ten').split())
            if ds and self._hop_le(ds[0]):
                self._them_ten(ds[0], 2)

        dong = sach.split('\n')
        vung_ky = set()
        for i, d in enumerate(dong):
            if self.re_goi_y_ky.search(d):
                vung_ky.update(range(i, i + 7))
        for i, d in enumerate(dong):
            for m in RE_CHUOI_HOA.finditer(d):
                for seg in self.tach_chuoi(m.group().split()):
                    toi_thieu = 2 if (i in vung_ky and self.xoa_ten_nvyt) else 3
                    if len(seg) >= toi_thieu and self._hop_le(seg, can_ho=True):
                        self._them_ten(seg, 1)
            if i in vung_ky and self.xoa_ten_nvyt:
                for khuc in RE_KHUC.split(d):
                    khuc = self.re_cd_dau.sub('', khuc.strip()).strip(' .')
                    if not RE_KHUC_TEN.fullmatch(khuc):
                        continue
                    for seg in self.tach_chuoi(khuc.split()):
                        if self._hop_le(seg):
                            self._them_ten(seg, 1)
        return self

    # ------------------------------------------------------------ ô chữ (tên viết rời từng chữ)
    def ma_cho_o_chu(self, chuoi):
        km = self._khoa_ma(chuoi)
        if km in self.ma_da_gap:
            return self.ma_da_gap[km]
        ma = self._ten_lien.get(chuan(chuoi).replace(' ', ''))
        if ma:
            return ma
        if sum(c.isalpha() for c in chuoi) > len(chuoi) / 2:
            return self.ma_gia('TÊN', chuoi)
        return self.ma_gia('SỐ_Ô_CHỮ', chuoi)

    @staticmethod
    def _la_o_chu(s):
        """Dãy ký tự đơn có phải tên/mã viết ô chữ không (loại "K K K K", "A A A")."""
        if len(s) < 4:
            return False
        if s.isdigit():
            return len(s) >= 8 and (s not in '123456789101112131415161718192021')
        return len(set(s.upper())) >= 3

    @classmethod
    def tim_day_o_chu(cls, ds):
        n = len(ds)
        i = 0
        kq = []
        don = lambda x: len(x.strip()) == 1 and x.strip().isalnum()
        while i < n:
            if don(ds[i]):
                cuoi = i
                ky = []
                j = i
                while j < n and (don(ds[j]) or ds[j].strip() == ''):
                    if ds[j].strip():
                        ky.append(ds[j].strip())
                        cuoi = j
                    j += 1
                if cls._la_o_chu(''.join(ky)):
                    kq.append((i, cuoi, ''.join(ky)))
                i = cuoi + 1
            else:
                i += 1
        return kq

    def xu_ly_o_chu(self, text):
        dong = text.split('\n')
        for dau, cuoi, s in reversed(self.tim_day_o_chu(dong)):
            dong[dau:cuoi + 1] = [self.ma_cho_o_chu(s)]
            self.dem['Ô_CHỮ_DỌC'] += 1
        text = '\n'.join(dong)

        def thay(m):
            s = re.sub('[\\s|]', '', m.group())
            if not self._la_o_chu(s):
                return m.group()
            self.dem['Ô_CHỮ_NGANG'] += 1
            return self.ma_cho_o_chu(s)

        return RE_O_CHU_NGANG.sub(thay, text)

    # ------------------------------------------------------------ thay tên
    def _ke_hoach_ten(self):
        if self._kh_phien != self._phien:
            tat = []
            ds = []
            for ten, ma, ut in self.ten.values():
                kd = bo_dau(ten)
                for bt in dict.fromkeys((ten, ten.upper(), ten.title(), kd, kd.upper(), kd.title())):
                    ds.append((ut, len(bt), bt, ma))
                tu = ten.split()
                for so in (2, 1):
                    if len(tu) > so:
                        tg = ' '.join(tu[-so:])
                        for bt in dict.fromkeys((tg, tg.upper(), bo_dau(tg))):
                            tat.append((bt, ma, so))
            ds.sort(key=lambda x: (-x[0], -x[1]))
            nhanh = all(c in CHU_SET or c == ' ' for bt, _, _ in tat for c in bt)
            self._kh = ([(bt, ma) for _, _, bt, ma in ds], tat, nhanh)
            self._kh_phien = self._phien
        return self._kh

    def _bieu_thuc(self, bt, goi_tat=False):
        pat = self._pat.get((bt, goi_tat))
        if pat is None:
            than = '[ \\t]+'.join(map(re.escape, bt.split()))
            if goi_tat:
                pat = re.compile(f'(?P<g>(?<![{CHU}])(?:{_GOI})[ \\t]+)' + than + f'(?![{CHU}])')
            else:
                pat = re.compile(than)
            self._pat[(bt, goi_tat)] = pat
        return pat

    @staticmethod
    def _thay_ca_cum(pat, ma, text):
        dai = len(text)
        tim = pat.search
        ra, n, dau, pos = [], 0, 0, 0
        while True:
            m = tim(text, pos)
            if not m:
                break
            a, b = m.span()
            if (a and text[a - 1] in _CAM_TRUOC) or (b < dai and text[b] in _CAM_SAU):
                pos = a + 1
                continue
            ra.append(text[dau:a])
            ra.append(ma)
            dau = pos = b
            n += 1
        if not n:
            return text, 0
        ra.append(text[dau:])
        return ''.join(ra), n

    def _thay_goi_tat(self, text, tat, nhanh):
        if not nhanh:
            for bt, ma, _ in tat:
                text, n = self._bieu_thuc(bt, True).subn(lambda m, ma=ma: m.group('g') + ma, text)
                self.dem['TÊN_GỌI_TẮT'] += n
            return text
        vi_tri = []
        for thu_tu, re_g in enumerate(RE_SAU_GOI):
            for m in re_g.finditer(text):
                vi_tri.append((m.start(), thu_tu, m.start(1), m.end(1), m.group(1), m.end(2),
                               m.group(2) or ''))
        if not vi_tri:
            return text
        vi_tri.sort()
        theo = ({}, {}, {})
        for v in vi_tri:
            theo[1].setdefault(v[4], []).append(v)
            if v[6]:
                theo[2].setdefault(v[4] + ' ' + v[6], []).append(v)
        da_thay = bytearray(len(text))
        thay = []
        for bt, ma, so in tat:
            het = 0
            n = 0
            for p, _, e, k1, _, k2, _ in theo[so].get(bt, ()):
                k = k2 if so == 2 else k1
                if p < het or da_thay.find(1, p, k) != -1:
                    continue
                da_thay[e:k] = b'\x01' * (k - e)
                thay.append((e, k, ma))
                het = k
                n += 1
            self.dem['TÊN_GỌI_TẮT'] += n
        if not thay:
            return text
        thay.sort()
        dau = 0
        ra = []
        for e, k, ma in thay:
            ra.append(text[dau:e])
            ra.append(ma)
            dau = k
        ra.append(text[dau:])
        return ''.join(ra)

    def thay_ten(self, text):
        if self.ten:
            day_du, tat, nhanh = self._ke_hoach_ten()
            gon = RE_KHOANG.sub(' ', text)
            for bt, ma in day_du:
                if bt in gon:
                    text, n = self._thay_ca_cum(self._bieu_thuc(bt), ma, text)
                    self.dem['TÊN'] += n
            text = self._thay_goi_tat(text, tat, nhanh)
        text, n = RE_TEN_XUONG_DONG.subn(
            lambda m: (m.group(1) + '[TÊN_PHẦN_CÒN_LẠI]') if m.group(2).lower() not in TU_LOAI_TRU
            else (m.group(1) + m.group(2)), text)
        self.dem['TÊN_XUỐNG_DÒNG'] += n
        return text

    # ------------------------------------------------------------ dịch ngày
    def dich_ngay(self, text):
        if not self.doi_ngay:
            return text
        d = dt.timedelta(days=self.doi_ngay)
        nam_pho_bien = Counter(re.findall('(?<!\\d)(20\\d\\d|19\\d\\d)(?!\\d)', text)).most_common(1)
        nam_mac_dinh = int(nam_pho_bien[0][0]) if nam_pho_bien else dt.date.today().year

        def doi(ng, th, nm):
            try:
                return dt.date(nm, th, ng) - d
            except ValueError:
                return None

        def f1(m):
            x = doi(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            if not x:
                return m.group()
            self.dem['NGÀY_DỊCH'] += 1
            return f'{x.day:02d}/{x.month:02d}/{x.year}'

        text = re.sub('(?<![\\d/])(\\d{1,2})/(\\d{1,2})/(\\d{4})(?![\\d/])', f1, text)

        def f2(m):
            x = doi(int(m.group(2)), int(m.group(3)), int(m.group(4)))
            if not x:
                return m.group()
            self.dem['NGÀY_DỊCH'] += 1
            return f'{m.group(1)}{x.day:02d} tháng {x.month:02d} năm {x.year}'

        text = re.sub('((?i:ngày)\\s+)(\\d{1,2})\\s+tháng\\s+(\\d{1,2})\\s+năm\\s+(\\d{4})', f2, text)

        def f3(m):
            x = doi(int(m.group('d')), int(m.group('m')), nam_mac_dinh)
            if not x:
                return m.group()
            self.dem['NGÀY_DỊCH'] += 1
            return m.group('truoc') + f'{x.day:02d}/{x.month:02d}'

        text = re.sub(
            '(?P<truoc>(?:^|(?<=\\n))[ \\t]*|(?i:ngày|từ|đến|lúc|hôm)\\s+|\\d{1,2}:\\d{2}(?::\\d{2})?\\s+)'
            '(?P<d>\\d{1,2})/(?P<m>\\d{1,2})(?![\\d/])(?=\\s*(?:\\n|$|\\d{1,2}:\\d{2}|[ ,.;)]))', f3, text)
        return text

    # ------------------------------------------------------------ xử lý văn bản
    def xu_ly(self, text, da_thu_thap=False):
        if not text or not text.strip():
            return text
        if not da_thu_thap:
            self.thu_thap_ten(text)
        text = self.xu_ly_o_chu(text)
        text = self.thay_ten(text)

        def thay_ns(m):
            gt = m.group('gt')
            if gt.strip().startswith('[') or not RE_NS_CO_NGAY.search(gt):
                return m.group()
            if self.giu_nam_sinh and RE_CHI_NAM.fullmatch(gt):
                return m.group()
            self.dem['NGÀY_SINH'] += 1
            nam = RE_NAM.search(gt)
            if self.giu_nam_sinh and nam:
                return m.group('nhan') + f'[xx/xx/{nam.group()}]'
            return m.group('nhan') + '[NGÀY_SINH]'

        text = self.re_ngay_sinh.sub(thay_ns, text)

        for loai, re_n in self.re_khac:
            def thay(m, loai=loai):
                gt = m.group('gt').strip()
                if gt.startswith('[') or not gt:
                    return m.group()
                if loai == 'SĐT' and not re.search('\\d{3}', gt):
                    return m.group()
                self.dem[loai] += 1
                return m.group('nhan') + self.ma_gia(loai, gt)
            text = re_n.sub(thay, text)

        text, n = RE_NGAY_BHYT.subn('\\1[NGÀY_BHYT]', text)
        self.dem['NGÀY_BHYT'] += n

        text, n = RE_GIUONG_1.subn('\\1[GIƯỜNG]', text)
        self.dem['GIƯỜNG'] += n
        text, n = RE_GIUONG_2.subn('\\1[GIƯỜNG]', text)
        self.dem['GIƯỜNG'] += n
        text, n = RE_BUONG.subn('\\1[BUỒNG]', text)
        self.dem['BUỒNG'] += n

        text, n = RE_MA_KCB.subn('\\1[MÃ_KCB_BĐ]', text)
        self.dem['MÃ_KCB_BĐ'] += n

        def sdt(m):
            if len(re.sub('\\D', '', m.group())) not in (10, 11):
                return m.group()
            self.dem['SĐT'] += 1
            return '[SĐT]'

        text = RE_SDT.sub(sdt, text)
        for loai, mau in RE_MAU_TU_DO:
            text, n = mau.subn(f'[{loai}]', text)
            self.dem[loai] += n

        return self.dich_ngay(text)

    # ------------------------------------------------------------ ô bảng (Word / Excel): nhãn ở ô này, giá trị ở ô kế
    def xu_ly_hang(self, o):
        """o: danh sách chữ của các ô trong một hàng. Trả về {chỉ số ô: giá trị mới}."""
        sau_kcb = False
        moi = {}
        re_ma = RE_O_MA
        for i, t in enumerate(o):
            if not t or not t.strip():
                continue
            ds = [(re_ma, 'MÃ_KCB_BĐ')] if (sau_kcb and re_ma.match(t)) else self.nhan_o
            for re_n, loai in ds:
                if not re_n.match(t):
                    continue
                j = i + 1
                while j < len(o) and (not o[j].strip() or o[j] == t):
                    j += 1
                if (j >= len(o) or o[j].strip().startswith('[')
                        or any(r.match(o[j]) for r, _ in self.nhan_o)):
                    break
                gt = o[j].strip()
                if loai == 'TÊN' and (not RE_O_TEN.fullmatch(self.re_cd_dau.sub('', gt))
                                      or not self._hop_le(self.re_cd_dau.sub('', gt).split())):
                    break
                if (loai in ('SĐT', 'SỐ_BHYT', 'SỐ_GIẤY_TỜ', 'MÃ_HỒ_SƠ', 'MÃ_NVYT', 'MÃ_KCB_BĐ', 'NGÀY_SINH')
                        and not re.search('\\d', gt)):
                    break
                if loai == 'TÊN':
                    ten = self.re_cd_dau.sub('', gt)
                    self._them_ten(ten, 2)
                    moi[j] = self.ma_gia('TÊN', ten)
                elif loai == 'NGÀY_SINH':
                    nam = RE_NAM.search(gt)
                    if self.giu_nam_sinh and nam:
                        moi[j] = f'xx/xx/{nam.group()}'
                    else:
                        moi[j] = '[NGÀY_SINH]'
                else:
                    moi[j] = self.ma_gia(loai, gt)
                    self._ghi_ma(loai, gt)
                sau_kcb = (loai == 'NƠI_KCB_BĐ')
                self.dem[f'Ô_BẢNG:{loai}'] += 1
                break
        return moi

    # ------------------------------------------------------------ tự kiểm tra
    def tu_kiem_tra(self, text_ra):
        nghi = []
        for so, d in enumerate(text_ra.split('\n'), 1):
            sach = RE_PLACEHOLDER.sub(' | ', d)
            for m in RE_CHUOI_HOA.finditer(sach):
                tu = m.group().split()
                for i in range(len(tu) - 1):
                    if any(chuan(' '.join(tu[a:b])) in DIA_DANH
                           for a in (max(0, i - 2), max(0, i - 1), i)
                           for b in (i + 1, i + 2, i + 3)):
                        continue
                    if not self.la_ho(tu[i]):
                        continue
                    if tu[i].lower() in TU_LOAI_TRU:
                        continue
                    if tu[i + 1].lower() in TU_LOAI_TRU:
                        continue
                    if not self._hop_le(tu[i:i + 2]):
                        continue
                    if any(chuan(' '.join(tu[i:])).startswith(g) for g in self.giu_lai):
                        break
                    nghi.append((so, 'Nghi tên người', ' '.join(tu[i:i + 4]), d))
                    break
            for m in RE_SOT_SAU_MA.finditer(d):
                w = m.group(1).lower()
                if len(w) > 1 and w not in ('nam', 'nữ') and (w not in TU_LOAI_TRU or w in TU_CO_THE_LA_TEN):
                    nghi.append((so, 'Nghi sót tên', m.group(), d))
            for m in RE_DAY_SO_DAI.finditer(sach):
                nghi.append((so, 'Dãy số dài', m.group(), d))
            if RE_A_CONG.search(sach):
                nghi.append((so, 'Có ký tự @', '', d))
        return nghi

    def bao_cao(self, so_nghi):
        dong = ['NHẬT KÝ KHỬ ĐỊNH DANH — bản 4.2 (không chứa dữ liệu thật)', '-' * 50]
        for k, v in sorted(self.dem.items()):
            if v:
                dong.append(f'{k:<20}: {v}')
        dong.append(f'{"Số tên phát hiện":<20}: {len(self.ten)}')
        if self.doi_ngay:
            dong.append(f'{"Dịch lùi ngày":<20}: {self.doi_ngay} ngày')
        dong.append(f'{"Chỗ nghi còn sót":<20}: {so_nghi}' + ('  -> xem file _DEID_KIEMTRA.txt' if so_nghi else ''))
        dong.append('\nLƯU Ý: Luôn đọc lại file kết quả trước khi chia sẻ. '
                    'Không gửi kèm file PDF gốc (mã QR trên phiếu có thể chứa mã bệnh nhân).')
        return '\n'.join(dong)


# ---------------------------------------------------------------- đọc/ghi từng loại file
def xu_ly_txt(src, dst, kdd):
    text = Path(src).read_text(encoding='utf-8', errors='ignore')
    out = kdd.xu_ly(text)
    Path(dst).write_text(out, encoding='utf-8')
    return out


def xu_ly_pdf(src, dst, kdd):
    import pdfplumber
    with pdfplumber.open(src) as pdf:
        text = '\n\n'.join((pg.extract_text() or '') for pg in pdf.pages)
    if not text.strip():
        print(f'  ! {Path(src).name}: PDF scan (không có lớp chữ) — cần OCR trước, bỏ qua.')
        return None
    out = kdd.xu_ly(text)
    Path(dst).write_text(out, encoding='utf-8')
    return out


def _doan_van_docx(doc):
    da_gap = set()

    def tu_khoi(khoi):
        for p in khoi.paragraphs:
            if id(p._p) not in da_gap:
                da_gap.add(id(p._p))
                yield p
        for t in getattr(khoi, 'tables', []):
            for row in t.rows:
                for cell in row.cells:
                    yield from tu_khoi(cell)

    yield from tu_khoi(doc)
    for s in doc.sections:
        for hf in (s.header, s.footer, s.first_page_header, s.first_page_footer,
                   s.even_page_header, s.even_page_footer):
            yield from tu_khoi(hf)


def _cac_hang_docx(doc):
    def tu_bang(ds_bang):
        for t in ds_bang:
            for row in t.rows:
                seen = set()
                cells = []
                for c in row.cells:
                    if id(c._tc) not in seen:
                        seen.add(id(c._tc))
                        cells.append(c)
                yield cells
                for c in cells:
                    yield from tu_bang(c.tables)

    yield from tu_bang(doc.tables)
    for s in doc.sections:
        for hf in (s.header, s.footer, s.first_page_header, s.first_page_footer):
            yield from tu_bang(hf.tables)


def _dat_text(p, moi):
    if p.runs:
        p.runs[0].text = moi
        for r in p.runs[1:]:
            r.text = ''
    else:
        p.add_run(moi)


def _dat_o(cell, moi):
    ps = cell.paragraphs
    _dat_text(ps[0], moi)
    for p in ps[1:]:
        _dat_text(p, '')


def xu_ly_docx(src, dst, kdd):
    from docx import Document
    doc = Document(src)
    doan = list(_doan_van_docx(doc))
    kdd.thu_thap_ten('\n'.join(p.text for p in doan))
    for o_ds in _cac_hang_docx(doc):
        texts = [c.text for c in o_ds]
        for j, gt in kdd.xu_ly_hang(texts).items():
            _dat_o(o_ds[j], gt)
    for dau, cuoi, _ in KhuDinhDanh.tim_day_o_chu([p.text for p in doan]):
        for k in range(dau, cuoi + 1):
            if doan[k].text.strip():
                _dat_text(doan[k], '*')
        kdd.dem['Ô_CHỮ_DOCX'] += 1
    for p in doan:
        goc = p.text
        moi = kdd.xu_ly(goc, da_thu_thap=True)
        if moi != goc:
            _dat_text(p, moi)
    doc.save(dst)
    return '\n'.join(p.text for p in _doan_van_docx(doc))


def xu_ly_xlsx(src, dst, kdd):
    from openpyxl import load_workbook
    wb = load_workbook(src)
    cot = re.compile(
        'họ\\s*tên|tên\\s*(?:bn|bệnh\\s*nhân|người\\s*bệnh)|địa\\s*chỉ|điện\\s*thoại|sđt|cccd|cmnd|bhyt|ngày\\s*sinh|'
        'người\\s*nhà|email|mã\\s*(?:bn|y\\s*tế|nv|nhân\\s*viên|bs|lưu\\s*trữ|điều\\s*trị)|'
        'số\\s*(?:vv|vào\\s*viện|lưu\\s*trữ|biên\\s*lai|khám)|bác\\s*sĩ|bs\\b|điều\\s*dưỡng|ktv|kỹ\\s*thuật\\s*viên|'
        'người\\s*(?:thực\\s*hiện|đọc|chỉ\\s*định|làm|lập)|cnxn|nhs|hộ\\s*sinh|cchn', re.I)
    tat_ca = []
    for ws in wb.worksheets:
        kdd.thu_thap_ten('\n'.join(str(c.value) for r in ws.iter_rows() for c in r
                                   if isinstance(c.value, str)))
        for row in ws.iter_rows():
            texts = [str(c.value) if c.value is not None else '' for c in row]
            for j, gt in kdd.xu_ly_hang(texts).items():
                row[j].value = gt
            for dau, cuoi, _ in KhuDinhDanh.tim_day_o_chu(texts):
                for k in range(dau, cuoi + 1):
                    if texts[k].strip():
                        row[k].value = '*'
                kdd.dem['Ô_CHỮ_EXCEL'] += 1
        tieu_de = {c.column: str(c.value or '') for c in ws[1]}
        for row in ws.iter_rows(min_row=2):
            for c in row:
                if c.value is None:
                    continue
                td = tieu_de.get(c.column, '')
                if cot.search(td):
                    if re.search('ngày\\s*sinh', td, re.I) and kdd.giu_nam_sinh:
                        nam = re.search('(19|20)\\d\\d', str(c.value))
                        c.value = nam.group() if nam else '[NGÀY_SINH]'
                    else:
                        c.value = kdd.ma_gia(re.sub('\\s+', '_', td.strip().upper())[:20], str(c.value))
                    kdd.dem[f'CỘT:{td[:20]}'] += 1
                elif isinstance(c.value, str):
                    c.value = kdd.xu_ly(c.value, da_thu_thap=True)
                tat_ca.append(str(c.value))
    wb.save(dst)
    return '\n'.join(tat_ca)


BO_XU_LY = {'.txt': xu_ly_txt, '.docx': xu_ly_docx, '.xlsx': xu_ly_xlsx, '.pdf': xu_ly_pdf}


# ---------------------------------------------------------------- dòng lệnh
def lay_khoa(khoa_tham_so):
    if khoa_tham_so:
        return khoa_tham_so
    f = Path(__file__).with_name('deid_khoa.txt')
    if f.exists() and f.read_text(encoding='utf-8').strip():
        return f.read_text(encoding='utf-8').strip()
    k = secrets.token_hex(16)
    f.write_text(k, encoding='utf-8')
    print(f'Đã tạo khóa bí mật mới: {f.name}  (giữ kín, KHÔNG gửi kèm file kết quả)')
    return k


def xu_ly_file(src, args, khoa):
    ham = BO_XU_LY.get(src.suffix.lower())
    if not ham or src.name.startswith('~$'):
        return None
    duoi = '.txt' if src.suffix.lower() == '.pdf' else src.suffix
    trung = any(f != src and f.is_file() and f.stem.lower() == src.stem.lower()
                and f.suffix.lower() in BO_XU_LY for f in src.parent.iterdir())
    goc = src.stem + (('_' + src.suffix[1:].lower()) if trung else '')
    dst = src.with_name(goc + '_DEID' + duoi)
    kdd = KhuDinhDanh(khoa, giu_nam_sinh=not args.xoa_nam_sinh, xoa_ten_nvyt=not args.giu_ten_nvyt,
                      doi_ngay=args.doi_ngay)
    try:
        out = ham(str(src), str(dst), kdd)
        if out is None:
            return None
        nghi = kdd.tu_kiem_tra(out)
        f_kt = src.with_name(goc + '_DEID_KIEMTRA.txt')
        if nghi:
            dong = ['CHỖ NGHI CÒN SÓT — file này CÓ THỂ CHỨA DỮ LIỆU THẬT. XÓA SAU KHI DUYỆT.',
                    'Mở file _DEID, tìm theo số dòng, sửa tay nếu đúng là định danh.',
                    '------------------------------------------------------------']
            for so, ly_do, cum, d in nghi:
                dong.append(f'Dòng {so:>5} | {ly_do:<15} | {cum:<30} | {d.strip()[:90]}')
            f_kt.write_text('\n'.join(dong), encoding='utf-8')
        elif f_kt.exists():
            f_kt.unlink()
        src.with_name(goc + '_DEID_log.txt').write_text(kdd.bao_cao(len(nghi)), encoding='utf-8')
        canh_bao = f'  ⚠ {len(nghi)} chỗ cần xem lại' if nghi else '  ✓ tự kiểm tra: sạch'
        print(f'  • {src.name} -> {dst.name} ({sum(kdd.dem.values())} chỗ thay, {len(kdd.ten)} tên){canh_bao}')
    except Exception as e:
        print(f'  ✗ {src.name}: lỗi {type(e).__name__}: {e}')
    return None


def main():
    ap = argparse.ArgumentParser(description='Khử định danh bệnh án (offline) — bản 4.2')
    ap.add_argument('duong_dan', help='File hoặc thư mục bệnh án')
    ap.add_argument('--xoa-nam-sinh', action='store_true', help='Xóa cả năm sinh')
    ap.add_argument('--giu-ten-nvyt', action='store_true', help='Giữ tên nhân viên y tế')
    ap.add_argument('--doi-ngay', type=int, default=0, help='Dịch lùi mọi ngày tháng N ngày')
    ap.add_argument('--khoa', default='', help='Khóa bí mật (mặc định đọc deid_khoa.txt)')
    ap.add_argument('--xoa-ten-bac-si', action='store_true', help=argparse.SUPPRESS)
    args = ap.parse_args()

    p = Path(args.duong_dan)
    if not p.exists():
        sys.exit(f'Không tìm thấy: {p}')
    khoa = lay_khoa(args.khoa)
    if p.is_file():
        files = [p]
    else:
        files = sorted(f for f in p.iterdir()
                       if f.is_file() and '_DEID' not in f.stem and f.name != 'deid_khoa.txt')
    print(f'Đang xử lý {len(files)} file...')
    for f in files:
        xu_ly_file(f, args, khoa)


if __name__ == '__main__':
    main()
