#!/usr/bin/env python3
"""Che chữ định danh trên ảnh (ảnh chụp màn hình PACS/DSA, siêu âm...) bằng ô đen.

Dùng:  python3 che_anh.py anh.png                       # che góc trên trái (mặc định)
       python3 che_anh.py anh.png --vung 0,0,0.17,0.054 # x0,y0,x1,y1 theo tỉ lệ 0-1 của ảnh
       python3 che_anh.py anh.png --vung ... --vung ...   # che nhiều vùng
       python3 che_anh.py anh.png --px 0,0,260,52         # hoặc theo pixel
Kết quả: <tên>_DEID.png (cùng thư mục). Luôn mở ảnh kết quả để kiểm tra bằng mắt.
"""
import argparse
from pathlib import Path
from PIL import Image, ImageDraw

ap = argparse.ArgumentParser()
ap.add_argument('anh')
ap.add_argument('--vung', action='append', help='x0,y0,x1,y1 theo tỉ lệ 0-1')
ap.add_argument('--px', action='append', help='x0,y0,x1,y1 theo pixel')
a = ap.parse_args()
p = Path(a.anh)
im = Image.open(p).convert('RGB')
W, H = im.size
hop = []
for v in a.vung or ([] if a.px else ['0,0,0.17,0.054']):
    x0, y0, x1, y1 = map(float, v.split(','))
    hop.append((x0 * W, y0 * H, x1 * W, y1 * H))
for v in a.px or []:
    hop.append(tuple(map(float, v.split(','))))
d = ImageDraw.Draw(im)
for b in hop:
    d.rectangle(b, fill=(0, 0, 0))
out = p.with_name(p.stem + '_DEID.png')
im.save(out)
print(f'{p.name} -> {out.name} ({len(hop)} vùng che)')
