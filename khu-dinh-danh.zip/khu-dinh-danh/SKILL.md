---
name: khu-dinh-danh
description: Khử định danh hồ sơ/bệnh án (txt, docx, xlsx, pdf có lớp chữ, và ảnh chụp màn hình PACS/DSA) giống app KhuDinhDanh — xóa tên bệnh nhân, người nhà, nhân viên y tế, SĐT, địa chỉ, BHYT, CCCD, mã hồ sơ. Dùng khi người dùng gửi bệnh án và nói khử định danh, ẩn danh, xóa tên, de-identify.
---

# Khử định danh bệnh án

Chạy `scripts/deid_benh_an.py` (bản dựng lại từ app KhuDinhDanh 4.2, kết quả khớp bản app) trên file người dùng gửi.

## Các bước
1. Copy file hồ sơ (hoặc cả thư mục) vào thư mục làm việc.
2. Chạy: `python3 scripts/deid_benh_an.py <file_hoặc_thư_mục> [tùy chọn]`
   - `--xoa-nam-sinh`: xóa cả năm sinh (mặc định giữ năm sinh)
   - `--giu-ten-nvyt`: giữ tên nhân viên y tế (mặc định xóa)
   - `--doi-ngay N`: dịch lùi mọi ngày tháng N ngày
   - `--khoa <chuỗi>`: khóa bí mật; không truyền thì dùng/tạo `deid_khoa.txt` cạnh script. Cùng khóa thì cùng một người luôn ra cùng một mã.
   - Chỉ dùng tùy chọn khi người dùng yêu cầu; nếu chưa rõ thì hỏi 1 câu về năm sinh/tên nhân viên y tế/dịch ngày.
3. Mỗi file tạo ra `<tên>_DEID.<đuôi>` (PDF → `.txt`), `<tên>_DEID_log.txt`, và nếu có chỗ nghi sót thì `<tên>_DEID_KIEMTRA.txt`.
4. Đọc `_KIEMTRA` (nếu có), đối chiếu với file `_DEID`, sửa tay các chỗ đúng là định danh còn sót.
5. Gửi lại cho người dùng bằng SendUserFile: file `_DEID` và `_log`. KHÔNG gửi file gốc, file `_KIEMTRA` (chứa dữ liệu thật) hay `deid_khoa.txt`.
6. Báo ngắn: số tên/chỗ đã thay, còn chỗ nghi sót nào, nhắc người dùng đọc lại trước khi chia sẻ.

## Ảnh (PNG/JPG chụp màn hình PACS, DSA, siêu âm...)
Chữ định danh nằm đè trên ảnh nên phải che bằng ô đen, không dùng script văn bản.
1. Nhìn ảnh, xác định mọi vùng có tên, mã bệnh nhân, năm sinh, tuổi, giới, mã/ID bệnh viện (thường góc trên trái; xem cả các góc khác).
2. Chạy `python3 scripts/che_anh.py <ảnh>` (mặc định che góc trên trái, tỉ lệ 0–17% rộng, 0–5,4% cao). Vùng khác: thêm `--vung x0,y0,x1,y1` (tỉ lệ 0–1) hoặc `--px`.
3. Mở ảnh `_DEID.png` để kiểm tra: không còn chữ định danh nào và không che mất phần ảnh chẩn đoán. Chưa sạch thì chỉnh vùng, chạy lại.
4. Mặc định giữ ngày giờ chụp, tên máy, thông số hiển thị; che hoặc nói với người dùng nếu họ muốn che cả ngày giờ. Gửi ảnh `_DEID` bằng SendUserFile, không gửi ảnh gốc.

## Lưu ý
- PDF scan (không có lớp chữ) bị bỏ qua: cần OCR trước.
- Không gửi PDF gốc đi nơi khác (mã QR trên phiếu có thể chứa mã bệnh nhân).
- Dữ liệu được xử lý trong môi trường Claude, không phải offline như app; nếu cần offline tuyệt đối thì dùng app.
- Mã thay thế chỉ trùng với app Windows khi dùng cùng khóa `deid_khoa.txt`.
- Cần python-docx, openpyxl, pdfplumber cho docx/xlsx/pdf.
